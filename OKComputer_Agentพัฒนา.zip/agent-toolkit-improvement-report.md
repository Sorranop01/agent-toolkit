# รายงานวิเคราะห์: สิ่งที่ควรเพิ่มเติมสำหรับ agent-toolkit Swarm Prompt
## เพื่อให้ Agent ทำงานได้ดีขึ้น เก่งขึ้น สมบูรณ์ยิ่งขึ้น

**วันที่วิเคราะห์:** 2026-04-22  
**ผู้วิเคราะห์:** Multi-Agent Analysis Swarm (6 specialists)  
**ขอบเขต:** Architecture, Domain Requirements, Persona/Skill/Workflow, Infrastructure, Security, Best Practices  

---

## บทสรุปผู้บริหาร (Executive Summary)

หลังจากวิเคราะห์ Swarm Prompt ฉบับปัจจุบันอย่างละเอียดด้วย specialist 6 สาขา พบว่า prompt มี **รากฐานที่ดี** แต่ยังขาด **7 ด้านสำคัญ** ที่จำเป็นต้องแก้ไขเพื่อให้ระบบทำงานได้จริงใน production:

| ลำดับ | ด้าน | ระดับความสำคัญ | จำนวน Issues |
|-------|------|-----------------|-------------|
| 1 | **Transport & Architecture** | CRITICAL | 7 |
| 2 | **Domain Requirements (Solar + Health + RAG)** | CRITICAL | 7 |
| 3 | **Security & Compliance** | CRITICAL | 3 |
| 4 | **Observability & Monitoring** | HIGH | 8 |
| 5 | **Persona, Skill & Workflow** | HIGH | 10 |
| 6 | **Memory & Context Management** | HIGH | 6 |
| 7 | **Infrastructure Reliability** | HIGH | 5 |

**ข้อสรุปสำคัญที่สุด 5 ข้อ:**
1. **SSE ถูก deprecated แล้ว** — ต้องเปลี่ยนเป็น Streamable HTTP (MCP spec 2025)
2. **LINE Notify ปิดให้บริการแล้ว** — ต้องย้ายเป็น LINE Messaging API
3. **ไม่มี Observability ใดๆ** — ไม่รู้ว่าระบบพังตอนไหน ทำไมพัง
4. **ขาด Emergency Bypass** — ถ้าคนไม่อยู่ ระบบค้าง ไม่มีใครแก้ไขได้
5. **Architecture ไม่รองรับการขยาย** — เพิ่ม domain ใหม่ต้องแก้ core code ทุกครั้ง

---

## ส่วนที่ 1: สิ่งที่ต้องแก้ไขด่วน (Critical Fixes)

> ถ้าไม่แก้ ระบบจะทำงานไม่ได้ หรือมีความเสี่ยงสูงมาก

### C1. [ARCHITECTURE] SSE → Streamable HTTP

| รายละเอียด | |
|-------------|---|
| **ปัญหา** | Option B "SSE over LAN" ถูก deprecated โดย MCP spec ตั้งแต่มีนาคม 2025 |
| **ผลกระทบ** | สร้างบนรากฐานที่ไม่มีอนาคต SDK จะค่อยๆ เลิกรองรับ |
| **แนวทางแก้ไข** | เปลี่ยนเป็น **Streamable HTTP** — ใช้ single `/mcp` endpoint, SDK รองรับตั้งแต่ TypeScript 1.10.0+ |
| **ความยาก** | LOW — เปลี่ยนแค่ endpoint structure |

```yaml
# ใน config.yaml เดิมใช้:
# transport: sse  # ❌ DEPRECATED

# แก้เป็น:
transport: streamable-http  # ✅ Current standard
port_range: 3001-3050
health_check_interval: 30s
```

---

### C2. [ARCHITECTURE] ขาด Heartbeat + Circuit Breaker

| รายละเอียด | |
|-------------|---|
| **ปัญหา** | lean ไม่รู้ว่า ecolife-2 ยังมีชีวิตอยู่ไหม ถ้า call แล้ว fail จะ fail ซ้ำๆ ไม่มีการ recover |
| **ผลกระทบ** | Cascading failure — lean เรียกซ้ำจน资源หมด, user ไม่รู้ว่าทำไมถึงช้า/ค้าง |
| **แนวทางแก้ไข** | เพิ่ม 3 mechanisms: ① Heartbeat push ทุก 10s จาก ecolife-2 ② Circuit breaker (5 failures → OPEN 30s) ③ Exponential backoff with jitter |

```python
# เพิ่มใน Section 8 (Infrastructure)
mcp_supervisor:
  heartbeat_interval: 10s
  heartbeat_timeout: 30s
  circuit_breaker:
    failure_threshold: 5
    recovery_timeout: 30s
    half_open_max_calls: 1
```

---

### C3. [ARCHITECTURE] MCP Server Lifecycle Management

| รายละเอียด | |
|-------------|---|
| **ปัญหา** | ไม่มีใครกำหนดว่าใคร start/stop/restart MCP servers, ไม่มี health check |
| **ผลกระทบ** | ecolife-2 reboot แล้ว MCP servers ไม่กลับมาเอง |
| **แนวทางแก้ไข** | 3-layer: ① systemd user services (auto-start on boot) ② MCP Supervisor (JSON-RPC ping ทุก 30s) ③ Server `/health` endpoint |

```ini
# systemd template: ~/.config/systemd/user/mcp-server@.service
[Unit]
Description=MCP Server %i
After=network.target ollama.service

[Service]
Type=simple
ExecStart=%h/workspace/agent-toolkit/.venv/bin/python -m agent_toolkit.mcp_server.%i
Restart=always
RestartSec=5
Environment=AGENT_TOOLKIT_MAX_MEMORY_MB=24000

[Install]
WantedBy=default.target
```

---

### C4. [DOMAIN] Inverter API Architecture ไม่ได้ระบุ

| รายละเอียด | |
|-------------|---|
| **ปัญหา** | Solar domain บอกแค่ "CSV/JSON (irradiance, power, inverter data)" แต่ไม่ระบุว่าข้อมูลมาจากไหน |
| **ผลกระทบ** | ทีมพัฒนาไม่รู้จะ integrate กับ inverter ยี่ห้อไหนอย่างไร — SMA? Huawei? Fronius? SolarEdge? |
| **แนวทางแก้ไข** | กำหนด Pluggable Connector Architecture + ระบุ priority inverter brands |

```yaml
# เพิ่มใน Section 2 (Domain Requirements)
solar_ingestion:
  connector_type: pluggable  # adapter pattern
  priority_sources:
    - sma_webconnect      # REST API
    - solaredge_monitoring # REST API with rate limits
    - huawei_fusionsolar  # REST API
    - fronius_solarweb    # REST API
    - modbus_tcp          # Direct for legacy
  data_interval: 5min      # Polling frequency
  buffer_strategy: sqlite_local  # 7 days offline storage
```

---

### C5. [DOMAIN] IRR Ambiguity

| รายละเอียด | |
|-------------|---|
| **ปัญหา** | "Calculations: IRR" — ไม่ชัดว่าหมายถึง Internal Rate of Return (financial) หรือ Instant Radiation Rate (solar) |
| **ผลกระทบ** | ออกแบบ calculation module ไม่ได้จนกว่าจะ clarify |
| **แนวทางแก้ไข** | ระบุชัดเจนใน requirements ถ้าเป็น financial IRR ต้องเพิ่ม inputs (CAPEX, OPEX, energy price) |

---

### C6. [DOMAIN] LINE Notify ปิดให้บริการแล้ว

| รายละเอียด | |
|-------------|---|
| **ปัญหา** | Health domain ใช้ `send_line_notify` แต่ LINE Notify API ปิดให้บริการมีนาคม 2025 |
| **ผลกระทบ** | ระบบจะส่ง notification ไม่ได้เลย |
| **แนวทางแก้ไข** | ย้ายเป็น **LINE Messaging API** หรือ **LINE Notify v2** หรือ alternatives (Telegram Bot, Slack Webhook) |

```yaml
# แก้ไขใน Section 2
health_notifications:
  primary: line_messaging_api  # แทน line_notify
  channel_access_token: ${LINE_CHANNEL_ACCESS_TOKEN}
  fallback: telegram_bot
  rate_limit: 1000msg/min
```

---

### C7. [DOMAIN] POS System ไม่ได้ระบุ

| รายละเอียด | |
|-------------|---|
| **ปัญหา** | Health domain บอก "POS transaction logs" แต่ไม่ระบุ POS system คืออะไร |
| **ผลกระทบ**** | ไม่รู้จะ parse log อย่างไร — Thai POS? FoodStory? ZenDesk? หรือ Excel export? |
| **แนวทางแก้ไข** | ระบุ POS system + integration method (API vs file-based vs manual export) |

---

### C8. [DOMAIN] ขาด Data Schema Standardization

| รายละเอียด | |
|-------------|---|
| **ปัญหา** | Solar data "CSV/JSON" กำกวมมาก — POA vs GHI? UTC vs local time? W vs kW? |
| **ผลกระทบ** | PR calculation จะผิดถ้าใช้ GHI แทน POA (ตาม IEC 61724 ต้องใช้ POA) |
| **แนวทางแก้ไข** | กำหนด canonical schema ด้วย Pydantic + auto-conversion |

```python
# SolarDataRecord (canonical schema)
class SolarDataRecord(BaseModel):
    timestamp_utc: datetime
    timestamp_local: datetime  # Asia/Bangkok
    irradiance_poa_w_m2: float   # ต้องใช้ POA สำหรับ PR
    irradiance_ghi_w_m2: Optional[float]
    power_dc_kw: float
    power_ac_kw: float
    energy_daily_kwh: float
    module_temp_c: float
    ambient_temp_c: float
    inverter_id: str
    string_id: Optional[str]
```

---

### C9. [SECURITY] ไม่มี Production Secret Manager

| รายละเอียด | |
|-------------|---|
| **ปัญหา** | .env ไม่ใช่ production-grade — ไม่มี rotation, audit, access control |
| **ผลกระทบ** | API key ถูก compromise ได้ง่าย, ไม่รู้ว่าใครใช้ key เมื่อไหร่ |
| **แนวทางแก้ไข** | ระยะสั้น: Infisical/Doppler → ระยะยาว: HashiCorp Vault + rotation ทุก 90 วัน |

---

### C10. [SECURITY] ไม่มี Network Authentication

| รายละเอียด | |
|-------------|---|
| **ปัญหา** | ecolife-2:3001-3010 เปิดบน LAN ใคร connect ก็ได้, ไม่มี TLS |
| **ผลกระทบ** | Insider threat — คนอื่นใน LAN อาจเรียก MCP tools ได้ |
| **แนวทางแก้ไข** | Firewall IP allowlist + API key auth + WireGuard tunnel |

---

### C11. [SECURITY] ไม่มี Emergency Bypass

| รายละเอียด | |
|-------------|---|
| **ปัญหา** | Human-in-the-loop เป็น single point of failure — ถ้าคนไม่อยู่ ระบบค้าง |
| **ผลกระทบ** | กลางคืน/วันหยุด มี incident แต่ไม่มีคน approve → ระบบเสียหายทวีคูณ |
| **แนวทางแก้ไข** | Escalation ladder + break-glass mode + out-of-band notification |

```yaml
# เพิ่มใน Section 7 (Safety)
emergency_bypass:
  escalation_ladder:
    - level_1: primary_user    (wait 10min)
    - level_2: secondary_user  (wait 10min)
    - level_3: auto_approve_with_full_audit_log
  break_glass_code: ${BREAK_GLASS_CODE}  # one-time use, rotated after use
  out_of_band: telegram_sms  # ส่ง SMS ถ้า critical alert
```

---

## ส่วนที่ 2: สิ่งที่ควรเพิ่มเติม (High-Value Additions)

> เพิ่มแล้วระบบ robust, scalable, และ maintainable มากขึ้น

### H1. [ARCHITECTURE] Domain Plugin Architecture

ปัญหา: เพิ่ม domain ใหม่ต้องแก้ core code ทุกครั้ง  
แนวทาง: ใช้ `DomainPlugin` abstract base class — แต่ละ domain implement plugin → register tools + port range + schedules

```python
class DomainPlugin(ABC):
    @abstractmethod
    def name(self) -> str
    @abstractmethod  
    def register_tools(self) -> list[Tool]
    @abstractmethod
    def register_workflows(self) -> list[Workflow]
    @abstractmethod
    def port_range(self) -> tuple[int, int]
```

---

### H2. [ARCHITECTURE] Service Registry

ปัญหา: Hardcoded ports ไม่ scale  
แนวทาง: เริ่มจาก JSON file-based registry (zero dependency) → ค่อย upgrade เป็น HTTP registry

```json
{
  "services": {
    "solar-analyzer": {"port": 3001, "health": "/health", "version": "1.0.0"},
    "health-franchise": {"port": 3002, "health": "/health", "version": "1.0.0"},
    "rag-retriever": {"port": 3003, "health": "/health", "version": "1.0.0"}
  }
}
```

---

### H3. [OBSERVABILITY] ระบบ Monitoring & Alerting

ปัญหา: Swarm prompt ไม่มี monitoring/alerting ใดๆ — ถ้า MCP server ค้างหรือ OOM ไม่มีใครรู้  
แนวทาง: เพิ่ม 4 ส่วน:

```yaml
# เพิ่ม Section ใหม่: Observability
observability:
  metrics:           # Prometheus-compatible
    - mcp_request_latency
    - mcp_error_rate
    - ollama_token_throughput
    - memory_usage_percent
    - queue_depth
  
  logging:
    format: json
    levels: [DEBUG, INFO, WARN, ERROR, FATAL]
    retention: 30days
    
  alerting:
    channels: [telegram, email]
    rules:
      - condition: "memory_usage > 85%"
        severity: warning
      - condition: "mcp_error_rate > 10%"
        severity: critical
      - condition: "ecolife_2_heartbeat_timeout > 30s"
        severity: critical
        
  tracing:
    correlation_id: true  # ติดตาม request ข้าม machines
```

**Quick wins (ทำวันนี้ได้):**
- `agent status` bash alias → query SQLite + curl Ollama health
- Watchdog cron ทุก 5 นาทีบน lean
- Correlation ID UUID ตอนเริ่ม request

---

### H4. [OBSERVABILITY] Distributed Tracing

ปัญหา: Request จาก lean → ecolife-2 ติดตามไม่ได้ ไม่รู้ว่าติดค้างตรงไหน  
แนวทาง: Correlation ID + structured logs ที่ทุก component inject เข้าไป

---

### H5. [PERSONA] เพิ่ม Personas ที่ขาดหายไป

ปัญหา: มี 4 personas แต่ขาด critical roles  
แนวทาง: เพิ่ม 4 personas:

| Persona | หน้าที่ | ความจำเป็น |
|---------|---------|-----------|
| `oncall-engineer` | Incident response owner | CRITICAL — ต้องมีคนรับผิดชอบเวลามี incident |
| `data-analyst` | Ad-hoc analysis, trend discovery | HIGH — คำถามที่ไม่ใช่ routine |
| `migration-specialist` | Migrate จาก agent-hub เก่า | HIGH — constraint #9 บอกต้อง migrate |
| `testing-qa` | Automated testing, validation | HIGH — ตรวจสอบว่าทุกอย่างทำงานถูกต้อง |

---

### H6. [SKILL] Skill Versioning

ปัญหา: Skill schema เปลี่ยนไม่ได้ (breaking changes ไม่มีการจัดการ)  
แนวทาง: Semantic versioning สำหรับ skills + backward compatibility

```yaml
skill_registry:
  versioning: semantic  # major.minor.patch
  compatibility: backward_compatible_for_2_versions
  deprecation_policy: warn_30days_before_remove
```

---

### H7. [WORKFLOW] Incident Response Workflow

ปัญหา: ไม่มี workflow สำหรับจัดการ incident — เมื่อ PR < 80% หรือ inverter fail ทำยังไง?  
แนวทาง: เพิ่ม `workflows/incident-response.yaml`

```yaml
# incident-response.yaml
steps:
  - id: detect
    skill: flag_anomalies
    persona: solar-expert
  - id: assess
    skill: assess_severity
    persona: oncall-engineer
    depends_on: [detect]
  - id: notify
    skill: escalate_incident
    persona: oncall-engineer
    depends_on: [assess]
    require_approval: true  # HITL สำหรับ severity > critical
  - id: auto_mitigate
    skill: run_diagnostic
    persona: solar-expert
    depends_on: [assess]
    condition: "severity <= high"  # conditional branching
```

---

### H8. [MEMORY] Context Pruning Algorithm

ปัญหา: "Auto-summarize when token budget exceeded" — ไม่มี algorithm ชัดเจน  
แนวทาง: กำหนด 3-tier strategy:

```python
context_pruning:
  strategy: three_tier
  tier_1_truncation: 80%_token_budget  # ตัดข้อความเก่าสุดออก
  tier_2_summarization: 90%_token_budget  # สรุป conversation เป็น summary
  tier_3_archive: 95%_token_budget  # archive old threads ออกจาก active context
  summarization_model: gemma4:31b  # local model ไม่มีค่าใช้จ่าย
```

---

### H9. [MEMORY] Long-term vs Short-term Memory Split

ปัญหา: Memory เป็นระบบเดียว ไม่แยกระหว่าง context ระยะสั้น vs knowledge ระยะยาว  
แนวทาง: แยกเป็น 2 ระบบ (ตาม best practices):

| ระบบ | ใช้สำหรับ | Technology |
|------|-----------|------------|
| **Short-term** (session) | Conversation context ปัจจุบัน | SQLite checkpointing |
| **Long-term** (cross-session) | User preferences, learned facts, project knowledge | Mem0 + Qdrant (self-hosted) |

---

### H10. [MEMORY] Full-Text Search บน Context

ปัญหา: ค้นหา context ย้อนหลังไม่ได้ (ต้อง browse ทีละ thread)  
แนวทาง: เพิ่ม FTS5 index บน SQLite

```sql
-- FTS5 สำหรับ conversation search
CREATE VIRTUAL TABLE messages_fts USING fts5(
    thread_id, persona, content, 
    tokenize='porter'
);
```

---

### H11. [WORKFLOW] Conditional Branching & Loop Patterns

ปัญหา: Workflow spec รองรับแค่ DAG แบบ static ไม่มี if-else, loop, event-driven  
แนวทาง: เพิ่ม control flow patterns:

```yaml
# conditional branching
condition: "step_assess.severity == 'critical'"
branch_true: [escalate, notify_manager]
branch_false: [auto_mitigate]

# loop pattern  
loop:
  condition: "retry_count < 3 AND status != 'success'"
  body: [retry_step]

# event-driven trigger
trigger:
  type: event  # แทน schedule
  source: ollama_metrics
  condition: "memory_usage > 90%"
```

---

### H12. [INFRA] Graceful Degradation

ปัญหา: ถ้า ecolife-2 ไม่พร้อม lean ทำอะไรไม่ได้เลย  
แนวทาง: กำหนด degraded mode — ทำงานที่ทำได้บน lean ได้ (file ops, git, local analysis) ส่วนที่ต้อง Ollama ให้ queue ไว้แล้ว retry

---

### H13. [INFRA] Priority Queue + Dead Letter Queue

ปัญหา: Job queue ไม่มี priority — job สำคัญ (incident) ต้องรอคิวเท่ากับ job ธรรมดา  
แนวทาง:

```yaml
job_queue:
  priorities: [critical, high, normal, low]
  max_retries: 3
  dead_letter:
    after_retries: move_to_dlq
    retention: 7days
    alert_on_dlq: true
```

---

## ส่วนที่ 3: การปรับปรุงโครงสร้าง Swarm Prompt (Structural Improvements)

### S1. เพิ่ม Section: "7. OBSERVABILITY & MONITORING"

Swarm prompt ปัจจุบันมี 6 sections + checklist แต่ไม่มี observability ใดๆ ควรเพิ่มเป็น Section 7:

```
7. OBSERVABILITY & MONITORING (All Agents Must Implement)
- Metrics collection (latency, error rate, token usage, memory)
- Structured JSON logging with correlation IDs
- Health check endpoints สำหรับทุก MCP server
- Alerting rules และ channels
- Resource monitoring (RAM, disk, GPU)
```

---

### S2. เพิ่ม Section: "8. DISASTER RECOVERY"

แยกจาก Infrastructure เป็น section ของตัวเอง:

```
8. DISASTER RECOVERY PLAYBOOKS
- ecolife-2 unexpected reboot → recovery steps
- Ollama OOM/crash → restart + model reload
- Data corruption → restore from backup + verify
- Network partition → degraded mode + queue & retry
- Secret compromise → rotation procedure
```

---

### S3. แก้ไข Agent 10 (Orchestration) — ให้รวม Job Queue + Worker + State Machine

ปัจจุบัน Agent 10 กำหนดดีแล้วแต่ขาดรายละเอียด:

```yaml
# เพิ่มใน Agent 10 deliverables
- parallel_execution_matrix:  # อันไหนทำ concurrently ได้
    solar_daily_report + health_inventory_check: parallel
    code_review + safe_deploy: sequential
- timeout_defaults:
    file_ops: 5min
    ollama_inference: 10min
    data_analysis: 15min
    deploy: 20min
```

---

### S4. แก้ไข Reviewer (Agent 11) — เพิ่ม Checklist Items

```
Reviewer (Agent 11) Additional Checks:
- [ ] Every MCP server has /health endpoint
- [ ] Every cross-machine call has circuit breaker
- [ ] Every workflow has timeout and fallback
- [ ] Every domain has data schema defined
- [ ] Every secret uses secret manager (not .env in production)
- [ ] Every destructive op has audit trail
- [ ] Every persona has escalation path
```

---

### S5. เพิ่ม "Testing Strategy" ใน Universal Constraints

```
11. TESTING REQUIRED
- Unit tests สำหรับทุก MCP tool
- Integration tests สำหรับ cross-machine calls
- Dry-run tests สำหรับ destructive workflows
- Load tests สำหรับ Ollama (max concurrent requests)
```

---

## ส่วนที่ 4: ข้อเสนอแนะจาก Best Practices ใน Ecosystem

### B1. พิจารณาใช้ LangGraph สำหรับ Workflow Orchestration

จากการค้นคว้า LangGraph เป็นตัวเลือกอันดับ 1 สำหรับ production multi-agent orchestration เพราะ:
- Graph-based state machine (deterministic execution)
- Built-in checkpointing และ human-in-the-loop
- รองรับ conditional branching, loops, parallel execution
- สำหรับระบบที่ต้อง fault tolerance + long-running workflows

> **ข้อควรระวัง:** เพิ่ม complexity — ถ้าทีมเล็กอาจเริ่มจาก custom YAML workflow ก่อน แล้วค่อย migrate

---

### B2. พิจารณาใช้ LiteLLM Proxy แทน Custom Model Router

ปัจจุบัน Agent 6 (Model Router) ต้อง implement fallback logic เอง  
LiteLLM Proxy รองรับ:
- 11000+ models จาก 100+ providers
- Built-in fallback chains, circuit breaker, load balancing
- Budget management + cost tracking
- Ollama integration โดยตรง

```yaml
# LiteLLM config (แทน custom router)
model_list:
  - model_name: default
    litellm_params:
      model: ollama/gemma4:31b
      api_base: http://ecolife-2:11434
  fallbacks:
    - ollama/gemma4:31b: ["openai/gpt-4o-mini"]
  router_settings:
    routing_strategy: latency-based
    timeout: 30
```

---

### B3. พิจารณาใช้ Mem0 สำหรับ Long-term Memory

ปัจจุบัน memory architecture เป็น SQLite อย่างเดียว  
Mem0 ให้:
- 0.200s p95 latency สำหรับ memory retrieval
- 66.9% recall accuracy
- Self-hosted ได้ด้วย Qdrant/ChromaDB
- User preference learning

---

### B4. Ollama Configuration ที่แนะนำสำหรับ 32GB RAM

```bash
# .env สำหรับ ecolife-2
OLLAMA_KEEP_ALIVE=-1           # เก็บ model ไว้ตลอด (ลด cold start)
OLLAMA_MAX_LOADED_MODELS=1     # โหลด model เดียว (ไม่ OOM)
OLLAMA_NUM_PARALLEL=2          # 2 concurrent requests
OLLAMA_FLASH_ATTENTION=1       # ประหยัด memory
OLLAMA_KV_CACHE_TYPE=q4_0      # ลด RAM usage 30%
```

Multi-model strategy (ถ้าต้อง):
- phi4 (~8GB) สำหรับงานง่าย (summarization, classification)
- gemma4:31b (~22GB) สำหรับงานซับซ้อน (analysis, code review)
- Unload/load อัตโนมัติตาม queue

---

### B5. Anti-Patterns ที่ต้องหลีกเลี่ยง

| Anti-Pattern | แนวทางที่ถูกต้อง |
|-------------|------------------|
| ใช้ SSE (deprecated) | Streamable HTTP |
| stdio บน multi-client environment | Streamable HTTP + Gateway |
| Embed credentials ใน prompt | Secret manager + env var |
| Hard-code endpoints | Service registry |
| ไม่มี timeout | Timeout ทุก LLM call |
| Synchronous blocking ทุก operation | Async + queue |
| โหลด model หลายตัวพร้อมกัน | LRU model swap |

---

## ส่วนที่ 5: แผนการดำเนินงานแนะนำ (Recommended Roadmap)

### Phase 1: Foundation (สัปดาห์ 1-2) — "Survival"
ทำให้ระบบไม่พัง + มองเห็นปัญหาได้

| งาน | Agent ที่เกี่ยวข้อง |
|-----|---------------------|
| เปลี่ยน SSE → Streamable HTTP | Architect |
| แก้ LINE Notify → Messaging API | Domain |
| Clarify IRR definition + POS system | Domain |
| Implement heartbeat + circuit breaker | Architect |
| MCP server systemd auto-start | Infra |
| Ollama memory-aware config | Infra |
| Structured logging + correlation ID | Infra |
| `agent status` CLI command | Infra |

### Phase 2: Safety & Domain (สัปดาห์ 3-4) — "Secure"
ปลอดภัย + domain logic ถูกต้อง

| งาน | Agent ที่เกี่ยวข้อง |
|-----|---------------------|
| กำหนด inverter API + data schema | Domain |
| Implement input validation (Pydantic) | Safety |
| Emergency bypass + escalation ladder | Safety |
| Secret manager (Infisical) | Safety |
| Network auth (IP allowlist + TLS) | Safety |
| Incident response workflow | Workflow |
| Oncall engineer persona | Persona |
| Escalation incident skill | Skill |

### Phase 3: Observability & Intelligence (สัปดาห์ 5-6) — "Visible"
มองเห็นทุกอย่าง + ระบบฉลาดขึ้น

| งาน | Agent ที่เกี่ยวข้อง |
|-----|---------------------|
| Prometheus metrics endpoint | Infra |
| Alerting rules + Telegram channel | Infra |
| Dashboard (CLI-based) | Infra |
| Context pruning algorithm | Memory |
| Long-term/short-term memory split | Memory |
| FTS5 search บน conversations | Memory |
| Priority queue + dead letter queue | Infra |
| Skill versioning | Skill |

### Phase 4: Scale & Polish (สัปดาห์ 7+) — "Scale"
ขยายได้ + ใช้งานสะดวก

| งาน | Agent ที่เกี่ยวข้อง |
|-----|---------------------|
| Domain plugin architecture | Architect |
| Service registry | Architect |
| Conditional branching + loops ใน workflow | Workflow |
| Workflow composition (nesting) | Workflow |
| Graceful degradation mode | Infra |
| LiteLLM Proxy integration (optional) | Architect |
| Mem0 long-term memory (optional) | Memory |
| Load testing + performance tuning | Infra |

---

## ภาคผนวก: รายการไฟล์รายงานฉบับเต็มจากแต่ละ Specialist

| Specialist | ไฟล์รายงาน | จำนวน Gaps |
|-----------|-----------|-------------|
| System Architect | `/mnt/agents/output/agent-toolkit-gap-analysis.md` | 17 |
| Domain Analyst | `/mnt/agents/output/domain_gap_analysis_report.md` | 23 |
| Workflow Designer | `/mnt/agents/output/gap-analysis-report.md` | 27 |
| Infra Engineer | `/mnt/agents/output/agent-toolkit-infra-gap-analysis.md` | 23 |
| Security Officer | `/mnt/agents/output/security-safety-compliance-gap-analysis.md` | 20 |
| Best Practices Researcher | `/mnt/agents/output/mcp-multi-agent-best-practices-report.md` | 5 insights |

---

*รายงานนี้สรุปจากการวิเคราะห์ของ multi-agent swarm 6 specialists รวม 110+ gaps/insights พร้อม proposed solutions และ implementation roadmap*
