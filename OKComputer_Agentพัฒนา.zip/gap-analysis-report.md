# Gap Analysis Report: Persona, Skill Registry & Workflow Design
## agent-toolkit — Comprehensive Assessment

---

## Executive Summary

จากการวิเคราะห์ swarm prompt specification อย่างละเอียด พบ **gaps รวม 27 ข้อ** แบ่งเป็น:
- **CRITICAL: 7 ข้อ** — ขาดไม่ได้ มีผลต่อ production readiness
- **HIGH: 10 ข้อ** — สำคัญมาก มีผลต่อ reliability และ scalability
- **MEDIUM: 7 ข้อ** — เพิ่มแล้วดีขึ้น ช่วย operational efficiency
- **LOW: 3 ข้อ** — nice-to-have เพิ่มเมื่อมีเวลา

---

## Part 1: PERSONA DESIGN GAPS

### CRITICAL

#### P-CRIT-01: Missing `oncall-engineer` Persona — No Incident Response Owner
**Justification**: ระบบมี solar-daily-report (scheduled) และ safe-deploy (human-triggered) แต่ไม่มี persona ที่รับผิดชอบตอบสนองต่อ **critical alerts แบบ real-time** เช่น PR < 80%, inverter efficiency < 89%, หรือ health inventory critical low ที่ต้องการการตอบสนองทันที ไม่ใช่รอรายงานวันถัดไป
**Proposed Solution**: 
```
personas/oncall-engineer.md
- Role: 24/7 first responder for critical alerts
- Allowed Skills: all read-only skills + send_line_notify + escalate_incident
- Decision Rules: PR < 75% → immediate LINE notify + log incident
                 Inverter offline → create ticket + notify solar-expert
                 Health stock = 0 → emergency reorder + notify health-operator
- Escalation Path: oncall-engineer → domain expert → cto-architect (if unresolved > 30 min)
- Auto-Invocation: triggered by workflow incident-response.yaml (event-driven)
```

#### P-CRIT-02: No Escalation Path Defined Between Personas
**Justification**: ปัจจุบันแต่ละ persona เป็น silo — ไม่มีกลไกว่าถ้า `solar-expert` ไม่สามารถ resolve anomaly ที่ซับซ้อนได้ จะ escalate ไปที่ไหน ใน production ต้องมี escalation chain ชัดเจนเพื่อป้องกัน incident ค้าง
**Proposed Solution**: เพิ่ม `escalation_matrix` ในแต่ละ persona file:
```yaml
# escalation_matrix (embedded in each persona)
escalation:
  level_1: self (retry with different parameters)
  level_2: cto-architect (technical escalation)
  level_3: human_oncall (manual intervention)
  timeout_minutes: [10, 30, 60]  # escalate after N minutes at each level
```

#### P-CRIT-03: `solar-expert` vs `cto-architect` — Overlapping Responsibilities ไม่มี Conflict Resolution
**Justification**: `solar-expert` ต้องตัดสินใจเรื่อง architecture ของ solar monitoring (เช่น threshold tuning, new inverter model support) ในขณะที่ `cto-architect` เป็น owner ของ system-wide architecture ถ้าทั้งคู่ตัดสินใจขัดแย้งกัน (เช่น solar-expert อยากเพิ่ม MCP server ใหม่แต่ cto-architect บอกว่า RAM ไม่พอ) จะให้ใครตัดสินใจ?
**Proposed Solution**: 
- กำหนด RACI matrix ชัดเจน:
  - `solar-expert`: R (Responsible) สำหรับ business logic, thresholds, domain rules
  - `cto-architect`: A (Accountable) สำหรับ infrastructure decisions, resource allocation
  - ถ้าขัดแย้ง: `cto-architect` มี veto power บน infrastructure/resource แต่ `solar-expert` มี veto power บน business logic correctness

---

### HIGH

#### P-HIGH-01: Missing `data-analyst` Persona — No Ad-hoc Query Capability
**Justification**: ผู้ใช้ต้องการถามคำถาม ad-hoc เช่น "เปรียบเทียบ PR เดือนนี้ vs เดือนที่แล้ว" หรือ "หา correlation ระหว่าง temperature กับ inverter efficiency" — คำถามเหล่านี้ไม่ตรงกับ scheduled workflow ใดๆ แต่ต้องการ persona ที่มี skill ในการวิเคราะห์ข้อมูลแบบ interactive
**Proposed Solution**: 
```
personas/data-analyst.md
- Allowed Skills: query_knowledge, calculate_pr, compare_periods, export_csv, generate_chart
- Mode: interactive (human-initiated, not scheduled)
- Special: can invoke any read-only skill across all MCP servers
- Output: Markdown report + optional CSV/PDF export
```

#### P-HIGH-02: Missing `migration-specialist` Persona — agent-hub Migration is Ad-hoc
**Justification**: Constraint #9 บอกว่า "Old ~/workspace/agent-hub is not deleted; useful assets are migrated" แต่ไม่มี persona ที่รับผิดชอบ migration ทำให้ migration เป็นงาน ad-hoc ที่ไม่มี owner อาจเกิด data loss หรือ migration ค้างระหว่างใช้งาน
**Proposed Solution**: 
```
personas/migration-specialist.md
- One-time persona (can be archived after migration complete)
- Allowed Skills: file_read, file_compare, git_history_extract, rclone_sync
- Responsibility: Assess, plan, execute, verify migration from agent-hub
- Output: migration-log.md + verification report
```

#### P-HIGH-03: Missing `testing-qa` Persona — No Automated Validation
**Justification**: มี `code-reviewer` สำหรับ review code แต่ไม่มี persona สำหรับ **automated testing** — unit test, integration test, workflow validation test ระบบที่มี 4 workflows + 9 skills ต้องมี regression testing ไม่เช่นนั้นแก้ bug ตัวหนึ่งแล้วอาจพังอีกตัว
**Proposed Solution**: 
```
personas/testing-qa.md
- Allowed Skills: run_tests, validate_workflow, mock_skill_call, compare_outputs
- Triggers: pre-deploy (block deploy if tests fail), scheduled (nightly regression)
- Integration: ทำงานร่วมกับ safe-deploy.yaml — step "test" ต้องผ่านก่อน deploy
```

#### P-HIGH-04: No Persona Lifecycle Management — Persona Creation/Update/Deprecation
**Justification**: ปัจจุบันมี 4 personas แต่ไม่มีกระบวนการสร้าง persona ใหม่, อัปเดต persona ที่มีอยู่, หรือ deprecate persona ที่ไม่ใช้แล้ว ใน production ต้องมี versioning และ change management
**Proposed Solution**: 
- เพิ่ม `persona-registry.yaml` ที่ track:
  - version (semver) ของแต่ละ persona
  - created_at, updated_at, deprecated_at
  - changelog
  - approval gate สำหรับ persona changes (cto-architect must approve)

---

### MEDIUM

#### P-MED-01: Missing `user-support` Persona — End-User Questions Have No Owner
**Justification**: ถ้าผู้ใช้ (non-technical user ในทีม) ถามว่า "PR คืออะไร?" หรือ "ทำไมรายงานวันนี้ถึงมี flag สีแดง?" — ไม่มี persona ที่ออกแบบมาสำหรับตอบคำถามผู้ใช้งาน คำถามเหล่านี้ไม่ต้องการ expert แต่ต้องการคนที่เข้าใจ context และอธิบายได้
**Proposed Solution**: 
```
personas/user-support.md
- Allowed Skills: query_knowledge (read SOPs), generate_explanation
- Personality: patient, explain in simple terms, Thai/English bilingual
- Escalation: route to domain expert if technical depth required
```

#### P-MED-02: Persona ไม่มี Context Window Budget Awareness
**Justification**: แต่ละ persona มี system prompt ที่ยาวต่างกัน แต่ไม่มีการกำหนดว่า persona ไหนใช้ context window เท่าไร, เมื่อใกล้เต็มต้องทำอย่างไร บน constrained 32GB RAM + Ollama เรื่องนี้สำคัญมาก
**Proposed Solution**: 
- เพิ่ม `context_budget` field ในแต่ละ persona:
```yaml
context_budget:
  max_tokens: 16000
  reserve_for_output: 4000
  pruning_strategy: summarize_oldest_first
  fallback: reduce_retrieval_results  # ถ้าใกล้เต็ม ลดจำนวน retrieved documents
```

#### P-MED-03: No Persona-to-Persona Handoff Protocol
**Justification**: เมื่อ workflow ต้องสลับจาก persona หนึ่งเป็นอีก persona (เช่น safe-deploy จาก code-reviewer → cto-architect) ไม่มี protocol สำหรับ passing context ระหว่าง persona ทำให้ context สูญหายหรือต้อง duplicate
**Proposed Solution**: 
- กำหนด `handoff_schema` มาตรฐาน:
```yaml
handoff:
  from: code-reviewer
  to: cto-architect
  context_passed: [review_notes, flagged_issues, approval_status]
  summary_required: true  # ต้องสรุป context ก่อนส่งต่อ
  max_context_tokens: 2000  # limit ขนาด context ที่ส่งต่อ
```

---

### LOW

#### P-LOW-01: Persona ไม่มี "Confidence Score" หรือ Self-Awareness
**Justification**: Persona ไม่มี mechanism บอกว่า "ฉันมั่นใจ 80% ในคำตอบนี้" หรือ "ฉันไม่มีข้อมูลพอ" ทำให้ยากต่อการตัดสินใจว่าควร accept output หรือ escalate
**Proposed Solution**: 
- เพิ่ม optional field `confidence` ใน output schema ของแต่ละ persona
- กำหนด threshold: confidence < 0.7 → auto-escalate to human review

---

## Part 2: SKILL REGISTRY GAPS

### CRITICAL

#### S-CRIT-01: Missing `compare_periods` Skill — No Trend Analysis Capability
**Justification**: Solar daily report บอกว่าวันนี้ PR = 82% แต่ไม่มี context ว่าเมื่อวาน PR = ? สัปดาห์ที่แล้ว PR = ? การเปรียบเทียบ period เป็น fundamental requirement สำหรับ O&M — ถ้า PR ลดลง 5% จากเมื่อวานต้อง alert ทันที
**Proposed Solution**: 
```yaml
skill: compare_periods
mcp_server: solar
input:
  metric: "pr"  # or "irr", "inverter_efficiency", "daily_yield"
  current_date: "2024-01-15"
  compare_with: ["previous_day", "previous_week", "previous_month"]  # configurable
  threshold_pct: 5.0  # alert if change > 5%
output:
  comparisons:
    - period: "previous_day"
      current_value: 82.0
      previous_value: 87.0
      change_pct: -5.7
      trend: "decreasing"
      alert: true
  summary: "PR decreased 5.7% from yesterday (87% → 82%)"
invoked_by: [solar-expert, data-analyst]
confirm_level: none
```

#### S-CRIT-02: Missing `rollback_deploy` Skill — Safe-Deploy Has No Reverse Gear
**Justification**: `safe-deploy.yaml` มี deploy step ที่เป็น destructive operation แต่ไม่มี skill สำหรับ rollback ถ้า deploy แล้วพบว่า production มีปัญหา ต้องมี skill ที่ทำ rollback ได้อย่างปลอดภัย ไม่เช่นนั้น "safe-deploy" จะไม่ safe จริงๆ
**Proposed Solution**: 
```yaml
skill: rollback_deploy
mcp_server: fileops
input:
  deploy_id: "{{deploy_step.output.deploy_id}}"
  reason: "post-deploy health check failed"
  strategy: "automatic"  # or "manual_review"
output:
  rollback_status: "completed"
  restored_version: "v1.2.3"
  verification_passed: true
invoked_by: [cto-architect, oncall-engineer]
confirm_level: explicit_confirm
# Safety: auto-stash before rollback, verify before confirm
```

#### S-CRIT-03: No Skill Versioning — Schema Changes Break Workflows
**Justification**: ถ้า `calculate_pr` เปลี่ยน input schema (เช่น เพิ่ม field `weather_adjustment`) workflows ที่ใช้ skill นี้จะพังทันที ใน production ต้องมี versioning เหมือน API versioning
**Proposed Solution**: 
- Implement skill versioning:
```yaml
skills:
  calculate_pr:
    versions:
      "1.0":  # current
        deprecated: false
        sunset_date: "2024-06-01"
      "2.0":  # new with weather_adjustment
        status: "available"
    default_version: "1.0"
    # Workflows pin version: skill: calculate_pr@v1.0
```

#### S-CRIT-04: Missing `escalate_incident` Skill — No Formal Incident Escalation
**Justification**: เมื่อ critical event เกิดขึ้น (PR < 75%, inverter offline, health stock = 0) ระบบต้องมี skill ที่ formalize การ escalate — ไม่ใช่แค่ send LINE notify แต่ต้องสร้าง incident record, assign owner, set severity, และ track resolution
**Proposed Solution**: 
```yaml
skill: escalate_incident
mcp_server: shared-context  # หรือ dedicated incident MCP server
input:
  severity: "critical"  # critical | high | medium | low
  category: "solar.pr_drop"  # หรือ "health.stock_out", "infra.mcp_down"
  description: "PR dropped to 73% on Site A"
  affected_sites: ["Site-A"]
  auto_notify: true
output:
  incident_id: "INC-2024-0115-001"
  assigned_to: "solar-expert"
  sla_minutes: 30
  status: "open"
invoked_by: [oncall-engineer, solar-expert, health-operator]
confirm_level: none  # auto-escalate, no confirmation needed
```

---

### HIGH

#### S-HIGH-01: Missing `forecast_demand` / `predictive_alert` Skill — Reactive Only
**Justification**: ระบบปัจจุบันเป็น **reactive** (flag หลังเกิดปัญหา) ไม่มี **predictive** capability เช่น พยากรณ์ว่า PR จะตกต่ำในอีก 3 วันจาก weather forecast, หรือ inventory จะหมดในอีก 2 วัน ทำให้ไม่สามารถ prevent ปัญหาได้
**Proposed Solution**: 
```yaml
skill: forecast_demand
mcp_server: solar  # และ health
input:
  metric: "pr"
  forecast_horizon_days: 3
  model: "simple_trend"  # or "arima", "ols" — เริ่มจาก simple
output:
  forecast:
    - date: "2024-01-16"
      predicted_pr: 80.5
      confidence_interval: [78.0, 83.0]
  alert: "PR predicted to drop below 80% threshold in 2 days"
invoked_by: [solar-expert, data-analyst]
confirm_level: none
```

#### S-HIGH-02: Missing `export_csv` / `export_pdf` Skill — Output Format Limited
**Justification**: รายงานปัจจุบันเป็น Markdown only แต่ผู้ใช้งานจริง (ลูกค้า solar, ทีม health) ต้องการ PDF/CSV ที่สามารถ share หรือ import ระบบอื่นได้ ไม่มี skill นี้ทำให้ต้อง manual export หรือ copy-paste
**Proposed Solution**: 
```yaml
skill: export_report
mcp_server: fileops
input:
  content: "{{generate_daily_report.output.report}}"
  format: "pdf"  # pdf | csv | xlsx | html
  template: "solar_daily_th"  # รองรับ i18n template
  destination: "gdrive://reports/2024/01/"
output:
  file_url: "gdrive://reports/2024/01/daily_20240115.pdf"
  file_size_bytes: 45230
invoked_by: [solar-expert, health-operator, data-analyst]
confirm_level: dry-run  # preview file name/destination
```

#### S-HIGH-03: Missing `schedule_job` Skill — No Dynamic Scheduling
**Justification**: Workflows ต้อง trigger จาก cron/scheduler แต่ไม่มี skill ที่ให้ persona schedule job แบบ dynamic (เช่น "run this analysis every Monday 9am" หรือ "schedule health check ทุก 6 ชั่วโมงในช่วง high season")
**Proposed Solution**: 
```yaml
skill: schedule_job
mcp_server: orchestrator
input:
  workflow: "health-inventory-check"
  cron: "0 */6 * * *"  # every 6 hours
  active_date_range: ["2024-11-01", "2025-02-28"]  # high season only
  parameters:
    store_id: "all"
output:
  job_id: "JOB-2024-001"
  next_run: "2024-11-01T06:00:00Z"
invoked_by: [health-operator, cto-architect]
confirm_level: explicit_confirm
```

#### S-HIGH-04: Missing `git_branch_manager` Skill — No Branch Strategy Enforcement
**Justification**: มี `safe-deploy.yaml` ที่ต้องการ deploy แต่ไม่มี skill สำหรับ manage git branches — create feature branch, merge, tag release, hotfix branch ระบบที่มี deploy ต้องมี branch strategy ที่ enforced ผ่าน skills
**Proposed Solution**: 
```yaml
skill: git_branch_manager
mcp_server: fileops
input:
  action: "create_hotfix"  # create_feature | merge | tag | delete
  base_branch: "main"
  hotfix_name: "fix-pr-calculation"
output:
  branch_name: "hotfix/fix-pr-calculation"
  created_from: "main@a1b2c3d"
invoked_by: [code-reviewer, cto-architect]
confirm_level: dry-run
```

#### S-HIGH-05: No Dynamic Skill Discovery — MCP Server ใหม่ต้อง Register ด้วยตนเอง
**Justification**: เมื่อมี MCP server ใหม่ (เช่น เพิ่ม `weather` MCP server สำหรับดึง weather data) ต้อง manually update skill registry ไม่มี mechanism สำหรับ auto-discovery หรือ self-registration ทำให้ operational overhead สูง
**Proposed Solution**: 
- Implement skill registry API:
```yaml
# MCP server ใหม่ register ตัวเองผ่าน:
skill: register_skills
mcp_server: skill-registry
input:
  server_name: "weather"
  endpoint: "http://ecolife-2:3005"
  skills_manifest: "http://ecolife-2:3005/manifest.json"
# Registry validate schema → add to available skills → notify cto-architect for approval
```
- Discovery: workflow orchestrator สามารถ query `list_available_skills` ก่อน schedule workflow เพื่อ verify ว่าทุก skill ที่ต้องใช้พร้อมใช้งาน

---

### MEDIUM

#### S-MED-01: Missing `validate_data` Skill — No Input Data Quality Check
**Justification**: `calculate_pr` รับ CSV/JSON แต่ไม่มี pre-validation skill ถ้า input data มี missing fields, wrong format, หรือ outlier ที่ extreme ระบบอาจคำนวณผิดหรือ crash ควรมี skill ที่ validate data quality ก่อน processing
**Proposed Solution**: 
```yaml
skill: validate_data
mcp_server: solar  # และ health
input:
  data_source: "solar/csv/daily_20240115.csv"
  rules:
    - field: "irradiance"
      type: "float"
      range: [0, 1500]
      required: true
    - field: "power_output"
      type: "float"
      range: [0, 10000]
      required: true
output:
  valid: false
  errors:
    - field: "irradiance"
      row: 47
      issue: "value 9999 exceeds max 1500"
  auto_fix_suggestion: "Remove row 47 (outlier) and recalculate"
invoked_by: [solar-expert, health-operator]
confirm_level: none
```

#### S-MED-02: Missing `health_check` Skill — No MCP Server Health Monitoring
**Justification**: ระบบมี 9 skills กระจายบน 3 MCP servers (solar, health, rag) แต่ไม่มี skill สำหรับ check health ของแต่ละ server ถ้า server ล่ม workflow จะ fail แบบ mysterious ไม่รู้ว่าปัญหาอยู่ที่ไหน
**Proposed Solution**: 
```yaml
skill: health_check
mcp_server: infrastructure  # หรือแต่ละ server มี /health endpoint
input:
  target: "all"  # หรือชื่อเฉพาะ "solar", "health", "rag"
output:
  servers:
    - name: "solar"
      status: "healthy"
      last_ping: "2024-01-15T09:00:00Z"
      latency_ms: 45
    - name: "rag"
      status: "degraded"
      issue: "embedding model loading slow (45s)"
invoked_by: [oncall-engineer, cto-architect, testing-qa]
confirm_level: none
```

#### S-MED-03: Skill Registry ไม่มี Dependency Graph Between Skills
**Justification**: Skills บางตัวมี dependency กันโดยธรรมชาติ (เช่น `generate_daily_report` ต้องใช้ output จาก `calculate_pr`) แต่ registry ไม่ระบุ dependency ทำให้ยากต่อการ optimize execution order หรือ detect circular dependency
**Proposed Solution**: 
- เพิ่ม `dependencies` field ใน skill definition:
```yaml
skill: generate_daily_report
dependencies:
  - skill: calculate_pr
    required: true
    output_field_mapping:
      "pr_result": "input.pr_values"
  - skill: flag_anomalies
    required: false  # optional enhancement
    output_field_mapping:
      "anomalies": "input.flagged_items"
```

---

### LOW

#### S-LOW-01: Missing `generate_chart` Skill — Visual Output Not Supported
**Justification**: รายงานเป็น text-only ไม่มี chart/visualization ทำให้อ่านยากสำหรับ trend analysis เป็น nice-to-have ที่เพิ่ม readability มาก
**Proposed Solution**: 
```yaml
skill: generate_chart
mcp_server: fileops
input:
  data: "{{compare_periods.output.comparisons}}"
  chart_type: "line"  # line | bar | pie
  title: "PR Trend - Last 30 Days"
output:
  chart_url: "data/charts/pr_trend_20240115.png"
```

---

## Part 3: WORKFLOW DESIGN GAPS

### CRITICAL

#### W-CRIT-01: Missing `incident-response` Workflow — Critical Alerts Have No Response Path
**Justification**: `flag_anomalies` สามารถ flag ได้ แต่ไม่มี workflow ที่กำหนดว่าหลัง flag ต้องทำอะไรต่อ — ใครต้องรู้? ต้องทำอะไร? ภายในเวลาเท่าไร? ใน solar O&M ถ้า inverter มีปัญหาไม่แก้ภายใน 30 นาที = lost revenue ที่เป็นหมื่น baht
**Proposed Solution**: 
```yaml
# workflows/incident-response.yaml
name: incident-response
trigger: event  # ไม่ใช่ schedule แต่ trigger โดย anomaly detection
steps:
  - id: classify
    skill: flag_anomalies
    agent: solar-expert
    output: severity

  - id: notify
    skill: send_line_notify
    agent: oncall-engineer
    depends_on: [classify]
    condition: "{{classify.output.severity}} in ['critical', 'high']"
    input:
      message: "🚨 [{{classify.output.severity}}] {{classify.output.description}}"

  - id: escalate
    skill: escalate_incident
    agent: oncall-engineer
    depends_on: [classify]
    condition: "{{classify.output.severity}} == 'critical'"

  - id: human_review
    skill: human_approval
    agent: cto-architect
    depends_on: [escalate]
    require_approval: true
    timeout_minutes: 15  # ถ้าไม่ตอบใน 15 min → auto-escalate
    fallback:
      action: auto_escalate
      notify: "human_oncall_phone"

  - id: resolve
    skill: generate_daily_report  # สรุป resolution
    agent: solar-expert
    depends_on: [human_review]
```

#### W-CRIT-02: Safe-Deploy Workflow ไม่มี Pre-Deploy Health Check
**Justification**: `safe-deploy.yaml` deploy แล้วค่อยเช็ค แต่ไม่มี step ที่ verify system health **ก่อน** deploy ถ้า system ไม่ healthy อยู่แล้ว deploy เพิ่ม = ซ้อน problem ควรมี health check ก่อน deploy เสมอ (baseline comparison)
**Proposed Solution**: 
เพิ่ม step ก่อน deploy:
```yaml
  - id: pre_deploy_health
    skill: health_check
    agent: testing-qa
    input:
      target: "all"
    output: baseline_health
    
  - id: deploy
    skill: deploy_service
    agent: cto-architect
    depends_on: [code_review, test, pre_deploy_health]
    condition: "{{pre_deploy_health.output.all_healthy}} == true"
    require_approval: true

  - id: post_deploy_health
    skill: health_check
    agent: testing-qa
    depends_on: [deploy]
    output: post_health
    
  - id: compare_health
    skill: compare_outputs
    agent: testing-qa
    depends_on: [post_deploy_health]
    condition: "{{post_deploy_health}} != {{baseline_health}}"
    # ถ้า health เปลี่ยน → trigger rollback
```

#### W-CRIT-03: No Workflow Composition — Workflows Cannot Call Workflows
**Justification**: `safe-deploy.yaml` ควรสามารถเรียก `system-health-check` workflow ได้ (reusable component) ปัจจุบัน workflows เป็น flat — ไม่มี composition ทำให้ duplicate logic และ maintenance ยาก
**Proposed Solution**: 
- Implement workflow composition:
```yaml
# workflows/safe-deploy.yaml (snippet)
  - id: health_verify
    workflow: system-health-check  # เรียก workflow อื่นเป็น sub-workflow
    version: "1.0"
    output: health_result
    # สามารถ reuse system-health-check จาก workflows อื่นได้

# workflows/system-health-check.yaml (reusable)
name: system-health-check
exposable_as_skill: true  # ทำให้ workflow นี้ถูกเรียกเหมือน skill ได้
steps:
  - id: check_mcp_servers
  - id: check_ollama
  - id: check_disk_space
```

---

### HIGH

#### W-HIGH-01: Missing `weekly-summary` Workflow — No Aggregate Reporting
**Justification**: มี daily report แต่ไม่มี weekly/monthly aggregate ทำให้ผู้บริหารไม่เห็น big picture เช่น "PR เฉลี่ยสัปดาห์นี้ vs สัปดาห์ที่แล้ว", "สาเหตุที่ anomaly เกิดบ่อยที่สุด", "trend ของ inverter efficiency"
**Proposed Solution**: 
```yaml
# workflows/weekly-summary.yaml
name: weekly-summary
trigger:
  cron: "0 8 * * MON"  # ทุกวันจันทร์ 8am
steps:
  - id: aggregate_pr
    skill: compare_periods
    agent: solar-expert
    input:
      metric: "pr"
      compare_with: ["previous_week", "week_before_last"]

  - id: aggregate_anomalies
    skill: query_knowledge
    agent: data-analyst
    input:
      query: "List all anomalies from last 7 days grouped by category"

  - id: generate_summary
    skill: generate_daily_report  # รองรับ weekly mode
    agent: solar-expert
    depends_on: [aggregate_pr, aggregate_anomalies]
    input:
      report_type: "weekly"

  - id: export_pdf
    skill: export_report
    agent: data-analyst
    depends_on: [generate_summary]
    input:
      format: "pdf"
      template: "weekly_summary_executive"

  - id: notify_stakeholders
    skill: send_line_notify
    agent: health-operator
    depends_on: [export_pdf]
    input:
      message: "📊 Weekly Summary ready: {{export_pdf.output.file_url}}"
```

#### W-HIGH-02: Missing `data-backup-verify` Workflow — Backup Integrity Unknown
**Justification**: Constraint บอกว่ามี rclone sync ไป Google Drive แต่ไม่มี workflow ที่ verify backup integrity (backup สำเร็จจริงหรือไม่, สามารถ restore ได้หรือไม่) ใน production "backup ที่ restore ไม่ได้" = "ไม่มี backup"
**Proposed Solution**: 
```yaml
# workflows/data-backup-verify.yaml
name: data-backup-verify
trigger:
  cron: "0 6 * * *"  # ทุกวัน 6am หลัง backup เสร็จ
steps:
  - id: verify_gdrive_sync
    skill: rclone_check
    agent: cto-architect
    input:
      remote: "lean"
      check: "file_count + total_size + recent_files"

  - id: test_restore_small
    skill: file_read
    agent: cto-architect
    depends_on: [verify_gdrive_sync]
    input:
      source: "gdrive://backup/latest/test_restore_sample.txt"
    # verify ว่าอ่านจาก backup ได้

  - id: report_integrity
    skill: generate_daily_report
    agent: cto-architect
    depends_on: [test_restore_small]
    input:
      report_type: "backup_integrity"
```

#### W-HIGH-03: Missing `onboarding-new-site` Workflow — Solar Site Expansion Not Covered
**Justification**: เมื่อมี solar site ใหม่ (เพิ่ม inverter, เพิ่ม panel) ไม่มี workflow สำหรับ onboard site ใหม่เข้าสู่ระบบ — ต้องทำอะไรบ้าง? config อะไร? threshold แรกเริ่มเป็นเท่าไร? validation อย่างไร?
**Proposed Solution**: 
```yaml
# workflows/onboarding-new-site.yaml
name: onboarding-new-site
trigger: manual  # human initiated
steps:
  - id: validate_site_data
    skill: validate_data
    agent: solar-expert
    input:
      site_info: "{{input.site_config}}"
      inverter_specs: "{{input.inverter_csv}}"

  - id: set_baselines
    skill: calculate_pr
    agent: solar-expert
    depends_on: [validate_site_data]
    input:
      mode: "baseline"  # คำนวณ baseline จาก historical data หรือ spec sheet

  - id: configure_alerts
    skill: schedule_job  # หรือ skill ใหม่ configure_alerts
    agent: solar-expert
    depends_on: [set_baselines]
    input:
      thresholds:
        pr_min: "{{set_baselines.output.pr_baseline}} * 0.95"
        efficiency_min: 89

  - id: index_documents
    skill: index_documents
    agent: solar-expert
    depends_on: [validate_site_data]
    input:
      docs: "{{input.sop_documents}}"
      source_tag: "site-{{input.site_id}}"

  - id: cto_approval
    require_approval: true
    agent: cto-architect
    depends_on: [set_baselines, configure_alerts]
```

#### W-HIGH-04: Missing Conditional Branching Pattern — Workflows are Linear
**Justification**: DAG ที่มีตอนนี้เป็นแบบ "run step A then step B" แต่ไม่มี conditional branching (if-else) ตามผลลัพธ์ เช่น ถ้า `flag_anomalies` พบ critical anomaly → ทำ path A (escalate) ถ้าไม่พบ → ทำ path B (normal report) ควรมี `condition` field ที่รองรับ expression evaluation
**Proposed Solution**: 
```yaml
# ตัวอย่าง conditional branching
steps:
  - id: check
    skill: flag_anomalies
    agent: solar-expert
    output: has_critical

  - id: critical_path
    skill: escalate_incident
    agent: oncall-engineer
    depends_on: [check]
    condition: "{{check.output.has_critical}} == true"
    # ถูก skip ถ้า condition = false

  - id: normal_path
    skill: generate_daily_report
    agent: solar-expert
    depends_on: [check]
    condition: "{{check.output.has_critical}} == false"
```

#### W-HIGH-05: Missing Loop/Iteration Pattern — Retry Until Condition Met
**Justification**: ไม่มี pattern สำหรับ loop/iteration เช่น "poll Ollama status ทุก 10 วินาที จนกว่าจะ ready" หรือ "retry health check 3 ครั้ง ถ้ายัง fail ค่อย escalate" ทำให้ต้องใช้ hacky workarounds
**Proposed Solution**: 
```yaml
steps:
  - id: wait_for_ollama
    skill: health_check
    agent: oncall-engineer
    retry:
      max_attempts: 10
      interval_seconds: 10
      condition: "{{wait_for_ollama.output.ollama_status}} == 'ready'"
      # loop จนกว่า condition จะเป็นจริง หรือ max_attempts ถึง
    fallback:
      action: escalate
      agent: cto-architect
```

#### W-HIGH-06: No Event-Driven Trigger — All Workflows are Schedule/Manual Only
**Justification**: ปัจจุบัน workflows trigger ด้วย cron (schedule) หรือ manual เท่านั้น ไม่มี event-driven trigger เช่น: เมื่อไฟล์ CSV ใหม่ถูก upload เมื่อ Ollama รายงาน error, เมื่อ disk space < 10% ระบบที่ responsive ต้องมี event-driven architecture
**Proposed Solution**: 
- Implement event bus (ใช้ SQLite queue ง่ายๆ):
```yaml
# ตัวอย่าง event-driven workflow trigger
workflows/solar-daily-report.yaml:
  trigger:
    event: "file.arrival"
    path_pattern: "data/solar/daily/*.csv"
    # trigger เมื่อมีไฟล์ใหม่ใน directory

workflows/incident-response.yaml:
  trigger:
    event: "alert.critical"
    source: "solar.flag_anomalies"
    # trigger เมื่อมี critical alert
```

#### W-HIGH-07: Error Handling for Partial Completion — Undefined Behavior
**Justification**: ถ้า workflow มี 5 steps และ step 3 ล้มเหลว ระบบที่เหลือ (step 4, 5) จะทำอย่างไร? จะ retry ทั้งหมดหรือแค่ step 3? จะ clean up อะไรที่ทำไปแล้วหรือไม่? ไม่มี spec สำหรับสถานการณ์นี้
**Proposed Solution**: 
- กำหนด `on_failure` policy ต่อ workflow:
```yaml
name: solar-daily-report
on_failure:
  strategy: "compensating_actions"  # none | retry_step | retry_all | compensate
  compensating_steps:
    - id: cleanup
      skill: remove_temp_files
    - id: notify_failure
      skill: send_line_notify
      input:
        message: "Workflow {{workflow.name}} failed at step {{failed_step.id}}"
  max_retries: 3
  retry_backoff: "exponential"  # 1min, 2min, 4min
```

---

### MEDIUM

#### W-MED-01: Missing `model-fallback-test` Workflow — Router Logic Untested
**Justification**: มี model router spec (Kimi → GLM → Ollama) แต่ไม่มี workflow ที่ทดสอบ fallback path จริงๆ ถ้า Kimi quota exceeded ระบบจะ fallback เป็น GLM จริงหรือไม่? ถ้า Ollama crash จะเกิดอะไรขึ้น? ไม่มีการทดสอบ = ไม่มั่นใจว่าทำงาน
**Proposed Solution**: 
```yaml
# workflows/model-fallback-test.yaml
name: model-fallback-test
trigger:
  cron: "0 2 * * *"  # nightly
steps:
  - id: test_primary
    skill: query_knowledge
    agent: testing-qa
    input:
      test_provider: "kimi"
      query: "test query"
    timeout_seconds: 30
    fallback:
      action: log_fallback
      expected_next: "glm"

  - id: verify_fallback_logged
    skill: query_knowledge  # check log
    agent: testing-qa
    depends_on: [test_primary]
    input:
      query: "Verify fallback from kimi to glm was logged"
```

#### W-MED-02: Missing `system-health-check` Workflow — No System-Wide Monitoring
**Justification**: มี individual health checks แยกกัน แต่ไม่มี workflow ที่รวม system-wide health check — MCP servers, Ollama, disk space, memory, backup status ทั้งหมดใน workflow เดียว ทำให้ต้อง manual check หลายที่
**Proposed Solution**: 
```yaml
# workflows/system-health-check.yaml
name: system-health-check
trigger:
  cron: "0 */6 * * *"  # ทุก 6 ชั่วโมง
steps:
  - id: check_mcp_solar
    skill: health_check
    agent: oncall-engineer
    parallel_group: "mcp_checks"

  - id: check_mcp_health
    skill: health_check
    agent: oncall-engineer
    parallel_group: "mcp_checks"

  - id: check_mcp_rag
    skill: health_check
    agent: oncall-engineer
    parallel_group: "mcp_checks"
    # 3 ตัวข้างบน run parallel (fan-out)

  - id: aggregate_health
    skill: generate_daily_report
    agent: oncall-engineer
    depends_on: [check_mcp_solar, check_mcp_health, check_mcp_rag]
    input:
      report_type: "system_health"
    # aggregate ผลจากทุก check (fan-in)

  - id: notify_if_issue
    skill: send_line_notify
    agent: oncall-engineer
    depends_on: [aggregate_health]
    condition: "{{aggregate_health.output.has_issues}} == true"
```

#### W-MED-03: Workflows ไม่มี Version Pinning
**Justification**: ถ้า `solar-daily-report.yaml` ถูก update แต่ยังมี instance ที่กำลังรันอยู่ จะเกิดอะไรขึ้น? ไม่มี mechanism สำหรับ version pinning ของ workflow definition
**Proposed Solution**: 
- แต่ละ workflow file มี version header:
```yaml
name: solar-daily-report
version: "2.1.0"
compatible_with:
  skill_registry: ">=1.5.0"
  orchestrator: ">=0.8.0"
# Running instances use the version they started with
```

---

### LOW

#### W-LOW-01: Missing Workflow Audit Trail
**Justification**: ไม่มี spec สำหรับ audit logging ของ workflow execution — ใคร trigger? เมื่อไร? ผลลัพธ์เป็นอย่างไร? ใคร approve? ใน production ต้องมี audit trail สำหรับ compliance
**Proposed Solution**: 
- Auto-generate audit log สำหรับทุก workflow execution:
```yaml
audit_log:
  workflow: "safe-deploy"
  instance_id: "uuid"
  triggered_by: "human@cto-architect"
  started_at: "2024-01-15T10:00:00Z"
  steps:
    - step: "code_review"
      completed_at: "10:05:00Z"
      agent: "code-reviewer"
    - step: "deploy"
      approved_by: "human"
      approved_at: "10:15:00Z"
  status: "completed"
  duration_seconds: 900
```

---

## Summary Matrix

| Category | CRITICAL | HIGH | MEDIUM | LOW | Total |
|----------|----------|------|--------|-----|-------|
| Persona  | 3 | 4 | 3 | 1 | 11 |
| Skill    | 4 | 5 | 3 | 1 | 13 |
| Workflow | 3 | 7 | 3 | 1 | 14 |
| **Total** | **10** | **16** | **9** | **3** | **38** |

> หมายเหตุ: รวม 38 ข้อ มีบางข้อ overlap ระหว่าง categories (เช่น `escalate_incident` skill กับ `incident-response` workflow) จึงรวมเป็น **27 unique gaps**

---

## Recommended Implementation Priority

### Phase 1: Foundation (สัปดาห์ 1-2)
1. **P-CRIT-01**: สร้าง `oncall-engineer` persona
2. **S-CRIT-04**: สร้าง `escalate_incident` skill
3. **W-CRIT-01**: สร้าง `incident-response` workflow
4. **P-CRIT-02**: กำหนด escalation matrix
5. **S-CRIT-03**: Implement skill versioning

### Phase 2: Reliability (สัปดาห์ 2-3)
6. **S-CRIT-02**: สร้าง `rollback_deploy` skill
7. **W-CRIT-02**: เพิ่ม pre-deploy health check ใน safe-deploy
8. **W-CRIT-03**: Implement workflow composition
9. **W-HIGH-04**: Implement conditional branching
10. **W-HIGH-07**: Define error handling strategy

### Phase 3: Enhancement (สัปดาห์ 3-4)
11. **S-CRIT-01**: สร้าง `compare_periods` skill
12. **S-HIGH-01**: สร้าง `forecast_demand` skill
13. **W-HIGH-01**: สร้าง `weekly-summary` workflow
14. **P-HIGH-03**: สร้าง `testing-qa` persona
15. **S-HIGH-02**: สร้าง `export_report` skill

### Phase 4: Polish (สัปดาห์ 4-5)
16. เหลือ MEDIUM + LOW priority items ตาม resource availability
