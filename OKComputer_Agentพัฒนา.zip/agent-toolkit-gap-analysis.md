# Agent-Toolkit System Architecture — Gap Analysis Report

> **Analysis Date:** 2025-07  
> **Analyst:** System Architecture Specialist (Multi-Agent / MCP Infrastructure)  
> **Scope:** Transport Layer, Port Allocation, Module Structure, Scalability, SPOF, Cross-Machine Reliability, MCP Server Lifecycle  
> **Context:** Self-hosted multi-agent tooling infrastructure across 2 machines (lean@192.168.1.135 + ecolife-2) with Ollama 24/7, targeting Kimi/OpenCode/Goose CLI consumption via MCP protocol.

---

## Executive Summary

The agent-toolkit architecture has **7 critical gaps** and **5 high-priority gaps** that must be addressed before production deployment. The most urgent issues are:

1. **CRITICAL:** SSE transport specified in the architecture has been **deprecated by MCP spec since March 2025** — must migrate to Streamable HTTP
2. **CRITICAL:** No cross-machine failure detection (heartbeat) mechanism defined
3. **CRITICAL:** No MCP server lifecycle manager (supervisor/systemd integration)
4. **HIGH:** Port range 3001-3010 is insufficient for multi-domain scaling
5. **HIGH:** No service discovery/registry — hardcoded ports won't scale
6. **HIGH:** Ollama is a single point of failure with no warm standby
7. **HIGH:** No circuit breaker / retry logic defined for cross-machine calls

---

## 1. Transport Layer Decision

### Current Architecture Options
- **Option A:** stdio over persistent SSH tunnel
- **Option B:** SSE over LAN (ecolife-2:3001-3010)
- **Option C:** TCP sockets with reconnect logic

### CRITICAL: SSE Transport (Option B) is Deprecated

| Aspect | Assessment |
|--------|-----------|
| **Gap** | SSE (Server-Sent Events) transport was deprecated by MCP specification in version 2025-03-26 (March 2025). The current standard is **Streamable HTTP**. |
| **Impact** | Building on SSE = building on deprecated foundations. No future spec improvements. SDK support will gradually drop. |
| **Evidence** | MCP spec 2025-11-25: "Clients and servers can maintain backwards compatibility with the deprecated HTTP+SSE transport" — note "deprecated" [^21^][^23^]. Atlassian deprecated their SSE endpoint June 2026 [^22^]. |
| **Migration Complexity** | **LOW** — Streamable HTTP uses a single `/mcp` endpoint instead of dual `/sse` + `/messages` endpoints. SDKs since TypeScript 1.10.0 (April 2025) support it natively [^24^]. |

**Proposed Solution:** Replace Option B with **Streamable HTTP over LAN** — single endpoint per MCP server on ports 3001-3010, with automatic fallback detection pattern (POST first, fall back to SSE for legacy clients).

```python
# Transport detection pattern (per MCP spec)
async def detect_transport(server_url: str) -> str:
    # Try Streamable HTTP first
    response = await fetch(server_url, method="POST", body=initialize_request)
    if response.ok:
        return "streamable-http"
    # Fall back to SSE for legacy
    return "sse"
```

### Option Analysis: Revised for MCP 2025 Spec

| Option | Protocol | Latency | Complexity | MCP Spec Compliant | Recommendation |
|--------|----------|---------|-----------|-------------------|----------------|
| A | stdio over SSH tunnel | Medium (SSH overhead) | High (tunnel mgmt) | Yes (stdio) | Fallback only |
| **B (Revised)** | **Streamable HTTP** | **Low** | **Low-Medium** | **Yes (current standard)** | **PRIMARY** |
| C | Custom TCP sockets | Low | Very High (custom framing) | Custom (non-standard) | Not recommended |
| D1 | WebSocket | Low | Medium | Custom transport | Overkill for LAN |
| D2 | gRPC | Lowest | High | Custom transport | Too complex for 2-node setup |
| D3 | Unix socket over SSH | Very Low | High | No (not spec-compliant for remote) | Not applicable across machines |

### CRITICAL: Missing Circuit Breaker / Retry Logic

| Aspect | Assessment |
|--------|-----------|
| **Gap** | No retry, exponential backoff, or circuit breaker pattern defined for cross-machine MCP calls. |
| **Impact** | If ecolife-2 is temporarily unreachable or Ollama is swapping models, Kimi CLI on lean will hang or fail with cryptic errors. Cascading failures possible. |
| **Evidence** | Production MCP resilience patterns require: error rate thresholds (typically 50% within 60s), consecutive failure triggers (5-10), exponential backoff with jitter, half-open probe intervals [^40^][^41^]. |

**Proposed Solution:** Implement a **CircuitBreaker** wrapper for all cross-machine MCP client calls:

```python
class CircuitBreaker:
    """Circuit breaker for MCP cross-machine calls."""
    # States: CLOSED -> OPEN -> HALF_OPEN -> CLOSED
    # Config: failure_threshold=5, recovery_timeout=30s, half_open_max_calls=1
    
    async def call(self, request: McpRequest) -> McpResponse:
        if self.state == OPEN:
            if time_since_open < self.recovery_timeout:
                raise CircuitOpenError("ecolife-2 temporarily unavailable, using cached/local fallback")
            self.state = HALF_OPEN
        # Proceed with call + retry logic...
```

### CRITICAL: Missing Transport-Level Session Recovery

| Aspect | Assessment |
|--------|-----------|
| **Gap** | Streamable HTTP supports session IDs via `Mcp-Session-Id` header, but architecture has no session recovery strategy when ecolife-2 restarts. |
| **Impact** | After ecolife-2 restart, all in-flight sessions are lost. Clients must re-initialize from scratch, losing context. |
| **Evidence** | MCP spec 2025-11-25 supports session IDs for resumability. Future versions will enable redelivery of lost messages [^25^][^28^]. |

**Proposed Solution:** Client-side session cache with automatic re-initialization on session invalidation:

```python
class ResilientMcpClient:
    async def call_with_recovery(self, tool_name, params):
        try:
            return await self.client.call(tool_name, params)
        except SessionExpiredError:
            # Auto-reinitialize and retry once
            await self.client.initialize()
            return await self.client.call(tool_name, params)
```

---

## 2. Port Allocation Strategy

### HIGH: Port Range 3001-3010 is Insufficient

| Aspect | Assessment |
|--------|-----------|
| **Gap** | Only 10 ports allocated (3001-3010) for all MCP servers across all domains. |
| **Impact** | With 2 domains (Solar + Health) each needing ~3-4 MCP servers (data ingestion, analysis, alerting, reporting), plus shared infra (RAG, fileops, context, router), ports will exhaust before adding Domain 3. |
| **Calculation** | Current: 2 domains x 4 servers + 4 shared = 12 ports minimum. Already exceeds 10-port allocation. |

**Proposed Solution:**
- **Expand range** to 3001-3050 (50 ports)
- **Implement port allocation table** with reserved ranges:

```
3001-3005: Core infrastructure (router, context, fileops, monitor, daemon)
3011-3020: Solar O&M domain
3021-3030: Health Franchise domain
3031-3040: Reserved for Domain 3 (Real Estate / Logistics / etc.)
3041-3050: Shared cross-domain (RAG, reporting, analytics)
```

### HIGH: No Service Discovery / Registry

| Aspect | Assessment |
|--------|-----------|
| **Gap** | MCP server URLs are presumably hardcoded in client configs. No discovery mechanism for when servers change ports, restart on different ports, or new servers are added. |
| **Impact** | Every MCP server addition requires manual client reconfiguration. Kimi CLI config must be updated on lean every time ecolife-2 changes. |
| **Evidence** | `agentctl` and similar tools provide auto-discovery scanning well-known ports, MCP config files, and process signatures [^1^][^2^]. |

**Proposed Solution:** Lightweight **LAN service discovery** using one of:

**Option A: JSON Registry File (Simplest)**
```json
# /opt/agent-toolkit/etc/service-registry.json on ecolife-2
{
  "version": "2025-07-01T00:00:00Z",
  "services": {
    "solar-ingest": {"host": "ecolife-2", "port": 3011, "transport": "streamable-http", "health": "/health"},
    "solar-analysis": {"host": "ecolife-2", "port": 3012, "transport": "streamable-http"},
    "health-pos": {"host": "ecolife-2", "port": 3021, "transport": "streamable-http"},
    "rag-server": {"host": "ecolife-2", "port": 3004, "transport": "streamable-http"}
  }
}
```
- Lean pulls this file via SSH/HTTP on startup and refreshes every 60s
- Zero external dependencies

**Option B: mDNS/Bonjour (Zero-config)**
- MCP servers advertise themselves via Avahi/bonjour on LAN
- lean discovers them automatically
- More complex but truly zero-config after initial setup

**Option C: Lightweight HTTP Registry (Scalable)**
- Small registry service on ecolife-2:3000
- MCP servers register on startup (POST /register)
- Clients query for available services (GET /services)
- Supports health-based filtering

**Recommendation:** Start with **Option A (JSON file)** — simplest, no dependencies, works over existing SSH/HTTP. Migrate to Option C when scaling beyond 3 domains.

---

## 3. Module Structure Analysis

### MEDIUM: Module Structure Mostly Sound, Minor Gaps

**Current Structure:**
```
src/agent_toolkit/{solar,health,rag,fileops,context,router,daemon,monitor}/
```

| Module | Purpose | Assessment |
|--------|---------|-----------|
| `solar/` | IRR, PR, inverter monitoring, daily yield | ✅ Good — bounded context |
| `health/` | LINE POS, inventory, low-stock alerts | ✅ Good — bounded context |
| `rag/` | Retrieval augmented generation | ✅ Good — shared capability |
| `fileops/` | File operations | ✅ Good — shared utility |
| `context/` | Context management | ✅ Good — shared capability |
| `router/` | Request routing | ✅ Good — cross-cutting concern |
| `daemon/` | Background processes | ⚠️ Needs clarification (see below) |
| `monitor/` | Monitoring/observability | ⚠️ Needs expansion (see below) |

### MEDIUM: Missing `registry/` Module

| Aspect | Assessment |
|--------|-----------|
| **Gap** | No module for service discovery/registry logic. Port allocation, service metadata, and client-side service resolution need a home. |
| **Impact** | Registry logic ends up scattered across router/ and daemon/, creating coupling. |

**Proposed Solution:** Add `registry/` module:
```
src/agent_toolkit/registry/
  __init__.py
  models.py      # ServiceRecord, HealthStatus, PortAllocation
  registry.py    # In-memory + file-backed registry
  client.py      # Client-side service resolver (pull-based)
  allocator.py   # Port allocation logic with conflict detection
```

### MEDIUM: `daemon/` Module Scope Unclear

| Aspect | Assessment |
|--------|-----------|
| **Gap** | "daemon" is ambiguous — does it manage MCP server processes? Ollama? Background data ingestion? |
| **Impact** | Risk of becoming a "catch-all" module violating single-responsibility principle. |

**Proposed Solution:** Split `daemon/` into:
```
src/agent_toolkit/
  daemon/           # Generic daemon framework (keep-alive, signal handling)
  mcp_supervisor/   # MCP server lifecycle management (start/stop/health/restart)
  ollama_manager/   # Ollama model lifecycle (load/unload/switch, memory-aware)
  scheduler/        # Cron-like task scheduler for periodic jobs (daily reports, etc.)
```

### LOW: Missing `config/` Module

| Aspect | Assessment |
|--------|-----------|
| **Gap** | No centralized configuration management module. Cross-machine configs (which server on which port, Ollama model preferences, memory budgets) need structured management. |

**Proposed Solution:** Add `config/` module with environment-based config loading:
```python
# config/models.py
@dataclass
class AgentToolkitConfig:
    node_role: Literal["dev", "agent-host"]  # lean = dev, ecolife-2 = agent-host
    ollama: OllamaConfig
    mcp_servers: list[McpServerConfig]
    memory_budget: MemoryBudgetConfig
    network: NetworkConfig  # heartbeat intervals, retry policies, etc.
```

### Updated Module Structure

```
src/agent_toolkit/
  __init__.py
  config/           # Centralized configuration (NEW)
  registry/         # Service discovery & port allocation (NEW)
  router/           # Request routing between MCP servers
  context/          # Context/session management
  rag/              # Retrieval augmented generation
  fileops/          # File operations
  solar/            # Solar O&M domain tools
  health/           # Health franchise domain tools
  mcp_supervisor/   # MCP server lifecycle (RENAMED from daemon)
  ollama_manager/   # Ollama model memory management (NEW)
  scheduler/        # Periodic task scheduling (NEW)
  monitor/          # Health monitoring & observability
  shared/           # Common types, exceptions, utils
```

---

## 4. Scalability — Adding Domain 3 (e.g., Real Estate, Logistics)

### HIGH: Architecture Needs Structural Change for Domain 3+

| Aspect | Assessment |
|--------|-----------|
| **Gap** | Current structure assumes manual addition of domain modules. No plugin/registration pattern for new domains. Each domain addition requires code changes in router/, config, and port allocation. |
| **Impact** | Adding Domain 3 = touching multiple modules, risk of regressions. Not a "drop-in" new domain. |

**Proposed Solution:** Implement a **Domain Plugin Architecture**:

```python
# shared/domain_plugin.py
class DomainPlugin(ABC):
    @property
    @abstractmethod
    def domain_name(self) -> str: ...  # "solar", "health", "realestate"
    
    @property
    @abstractmethod
    def port_range(self) -> tuple[int, int]: ...  # (3011, 3020)
    
    @abstractmethod
    def register_tools(self, mcp_server: McpServer) -> None: ...
    
    @abstractmethod
    def register_schedules(self, scheduler: Scheduler) -> None: ...

# Each domain implements the plugin interface
class SolarPlugin(DomainPlugin):
    domain_name = "solar"
    port_range = (3011, 3020)
    def register_tools(self, server): ...
```

Benefits:
- Domain 3 = create new plugin class + register in config — **no changes to core code**
- Port allocation automatic based on `port_range`
- Router automatically discovers tools from all registered plugins
- MCP server startup script iterates over plugins to start domain-specific servers

**Scalability Decision Matrix:**

| Current Approach | Limit | Plugin Approach | Limit |
|-----------------|-------|----------------|-------|
| 2 domains, ~8 modules | Hard to add domain 3 | 2+ domains, plugin-based | 10+ domains |
| Manual port assignment | 10 ports max | Auto port range per domain | 50+ ports |
| Hardcoded routing | N² complexity | Dynamic plugin discovery | Linear complexity |
| Monolithic config | Merge conflicts | Per-domain config files | Isolated changes |

---

## 5. Single Points of Failure (SPOF)

### CRITICAL: Ollama on ecolife-2 is the Primary SPOF

| # | SPOF Component | Severity | Impact | Mitigation Strategy |
|---|---------------|----------|--------|-------------------|
| 1 | **ecolife-2 machine** | CRITICAL | All MCP servers, Ollama, heavy tools go offline | ❌ No mitigation defined |
| 2 | **Ollama service** | CRITICAL | All LLM-powered tools fail (RAG, analysis, summarization) | ❌ No mitigation defined |
| 3 | **Network between lean ↔ ecolife-2** | HIGH | Cannot reach MCP servers or Ollama | ❌ No fallback defined |
| 4 | **Single Ollama model loaded** | HIGH | 31B model swap time = 30-60s downtime per switch | ⚠️ Partial: OLLAMA_KEEP_ALIVE |
| 5 | **MCP server process crash** | MEDIUM | Specific domain tools unavailable | ⚠️ Partial: manual restart |
| 6 | **lean machine** | LOW | Development pauses, but ecolife-2 continues | ✅ Acceptable (dev only) |

### CRITICAL: No Ollama Warm Standby / Fallback

| Aspect | Assessment |
|--------|-----------|
| **Gap** | If Ollama on ecolife-2 crashes or is restarting, there's no fallback LLM provider. Offline-first requirement is violated. |
| **Impact** | All AI-powered operations halt. Solar yield analysis, health inventory insights, RAG queries — all fail. |
| **Evidence** | With 32GB RAM, ecolife-2 can hold one 13B Q4 model (~9GB) + one 7B Q4 model (~5GB) simultaneously [^35^]. A 31B model uses ~22GB, leaving room for only one model at a time. |

**Proposed Solution: Tiered Fallback Strategy**

```python
class LlmProviderChain:
    """Hierarchical LLM fallback chain."""
    tiers = [
        # Tier 1: Primary (ecolife-2 Ollama - best quality)
        {"provider": "ollama", "host": "ecolife-2:11434", "model": "qwen2.5:14b", "timeout": 30},
        # Tier 2: Smaller model on same host (faster, less capable)
        {"provider": "ollama", "host": "ecolife-2:11434", "model": "qwen2.5:7b", "timeout": 15},
        # Tier 3: Local Ollama on lean (if installed) — for critical ops only
        {"provider": "ollama", "host": "localhost:11434", "model": "qwen2.5:7b", "timeout": 60},
        # Tier 4: Offline cache — pre-computed responses for common queries
        {"provider": "cache", "fallback_only": True},
    ]
```

### HIGH: No Network Partition Handling

| Aspect | Assessment |
|--------|-----------|
| **Gap** | If LAN connection between lean and ecolife-2 drops, there's no defined behavior. Kimi CLI will receive connection errors. |

**Proposed Solution:**
1. **Client-side detection**: Ping ecolife-2 every 10s via lightweight HTTP probe
2. **Degraded mode announcement**: When partition detected, inform user: "ecolife-2 unreachable — switching to offline mode (limited functionality)"
3. **Offline cache**: Pre-compute and cache common responses (daily solar yield summary, current inventory status)
4. **Async queue**: Queue write operations locally, replay when connection restored

---

## 6. Cross-Machine Communication Reliability

### CRITICAL: No Heartbeat / Failure Detection Mechanism

| Aspect | Assessment |
|--------|-----------|
| **Gap** | Architecture defines no heartbeat, health probe, or failure detection between lean and ecolife-2. lean has no way to know if ecolife-2 is online, if Ollama is loaded, or if an MCP server has crashed. |
| **Impact** | Kimi CLI on lean sends requests to dead endpoints. Timeouts are slow (TCP default ~75s). User experience is terrible. |
| **Evidence** | Push-based heartbeats with 10s interval + 3-miss threshold = ~30s failure detection time is standard for LAN [^37^][^43^]. |

**Proposed Solution: Bidirectional Heartbeat System**

```
ecolife-2 (MCP Agent Host)          lean (Dev Machine / MCP Client)
---------------------------         -------------------------------
[Health Beacon] -------------->     [Health Monitor]
  POST /health every 10s              - Tracks last_seen timestamp
  Body: {                             - Declares "DOWN" after 3 misses (30s)
    "node": "ecolife-2",              - Triggers circuit breaker
    "ollama_status": "ready",         - Switches to degraded mode
    "loaded_models": ["qwen2.5:14b"],
    "mcp_servers": {
      "solar-ingest": {"status": "up", "port": 3011},
      "health-pos": {"status": "up", "port": 3021}
    },
    "memory_free_gb": 12.5
  }
```

Implementation on ecolife-2:
```python
# monitor/health_beacon.py
class HealthBeacon:
    """Sends periodic health beacons to lean."""
    async def start(self):
        while True:
            health = await self.gather_health()
            try:
                await self.post_to_lean(health)
            except NetworkError:
                self.logger.warning("Cannot reach lean — LAN partition?")
            await asyncio.sleep(self.interval)  # 10s
```

Implementation on lean:
```python
# monitor/node_watcher.py
class NodeWatcher:
    """Monitors ecolife-2 health from lean."""
    def __init__(self):
        self.last_seen: datetime | None = None
        self.state: Literal["UP", "DEGRADED", "DOWN"] = "DOWN"
    
    async def on_beacon(self, health: HealthReport):
        self.last_seen = datetime.now()
        self.state = "UP" if health.ollama_status == "ready" else "DEGRADED"
        self.emit("node_status_changed", self.state)
    
    async def check_timeout(self):
        if self.last_seen and (datetime.now() - self.last_seen).seconds > 30:
            self.state = "DOWN"
            self.emit("node_status_changed", "DOWN")
```

### HIGH: No Recovery Procedure for ecolife-2 Restart

| Aspect | Assessment |
|--------|-----------|
| **Gap** | If ecolife-2 restarts mid-operation (power outage, kernel update), there's no defined auto-recovery procedure. MCP servers must be manually restarted. Ollama models must be manually reloaded. |

**Proposed Solution: systemd-based Auto-Recovery**

```ini
# /etc/systemd/system/agent-toolkit-mcp@.service (template unit)
[Unit]
Description=Agent Toolkit MCP Server (%i)
After=network.target ollama.service
Wants=ollama.service

[Service]
Type=notify
ExecStart=/opt/agent-toolkit/bin/mcp-server %i
Restart=on-failure
RestartSec=10
StartLimitBurst=5
StartLimitIntervalSec=300
WatchdogSec=30
NotifyAccess=all

[Install]
WantedBy=multi-user.target
```

Start all MCP servers:
```bash
systemctl enable agent-toolkit-mcp@solar-ingest
systemctl enable agent-toolkit-mcp@solar-analysis
systemctl enable agent-toolkit-mcp@health-pos
# ... etc
```

Boot sequence:
```
1. ecolife-2 boots
2. systemd starts network.target
3. ollama.service starts (with OLLAMA_MAX_LOADED_MODELS=1)
4. agent-toolkit-mcp@*.service units start (parallel, after ollama)
5. Each MCP server registers with local registry
6. Health beacon starts, notifying lean that ecolife-2 is ready
7. lean detects beacon, marks ecolife-2 as UP, resumes normal operations
```

Recovery time target: **< 60 seconds** from boot to full service availability.

### HIGH: No Memory-Aware Ollama Orchestration

| Aspect | Assessment |
|--------|-----------|
| **Gap** | With 32GB RAM, loading two 31B models simultaneously causes OOM. Architecture has no model swap orchestration. |
| **Impact** | Ollama silently unloads models to load new ones. 30-60s cold-load latency per switch. Potential OOM kills. |
| **Evidence** | Ollama supports `OLLAMA_MAX_LOADED_MODELS` (default 3 or 3x GPU count) but with 32GB RAM and 31B models, practical limit is 1 [^38^]. Hot-swap orchestrators can manage LRU model caching [^36^]. |

**Proposed Solution: OllamaModelManager**

```python
# ollama_manager/model_manager.py
class OllamaModelManager:
    """Manages Ollama model loading with 32GB RAM constraint."""
    
    MEMORY_BUDGET_GB = 28  # Leave 4GB for OS + MCP servers
    
    MODEL_SIZES = {
        "qwen2.5:7b": 5.0,
        "qwen2.5:14b": 9.0,
        "qwen2.5:32b": 22.0,
        "nomic-embed-text": 0.7,
    }
    
    async def ensure_loaded(self, model: str):
        """Ensure model is loaded, evicting LRU models if needed."""
        needed = self.MODEL_SIZES[model]
        
        # Check if already loaded
        if model in self.loaded:
            self.loaded.move_to_end(model)  # Mark as recently used
            return
        
        # Check if we need to evict
        while self.used_gb + needed > self.MEMORY_BUDGET_GB and self.loaded:
            evict = next(iter(self.loaded))  # LRU
            await self.unload(evict)
        
        # Load requested model
        await self.load(model)
        self.loaded[model] = needed
    
    async def warmup_default(self):
        """Pre-load default model on startup."""
        await self.ensure_loaded(self.config.default_chat_model)
```

---

## 7. MCP Server Lifecycle Management

### CRITICAL: No MCP Server Supervisor

| Aspect | Assessment |
|--------|-----------|
| **Gap** | Architecture does not define WHO starts/stops/restarts MCP servers. No process manager integration. No health check mechanism beyond implicit TCP connection success. |
| **Impact** | MCP server crash = permanent outage until manual intervention. Kimi CLI users see tool failures with no explanation. |
| **Evidence** | `agentctl` tool provides registration, lifecycle management, health checks, and auto-discovery for exactly this problem [^1^]. Node-RED MCP server nodes provide start/stop/restart with health monitoring [^8^]. |

**Proposed Solution: Three-Layer Lifecycle Management**

```
┌─────────────────────────────────────────┐
│  Layer 3: systemd (OS-level)            │
│  - Auto-start on boot                   │
│  - Crash restart (Restart=on-failure)   │
│  - Resource limits (MemoryMax, CPUQuota)│
├─────────────────────────────────────────┤
│  Layer 2: MCP Supervisor (Python)       │
│  - JSON-RPC ping every 30s              │
│  - Port conflict detection              │
│  - Graceful shutdown on SIGTERM         │
│  - Startup dependency ordering          │
├─────────────────────────────────────────┤
│  Layer 1: MCP Server (User code)        │
│  - /health HTTP endpoint                │
│  - Readiness probe (DB connections OK)  │
│  - Liveness probe (not deadlocked)      │
└─────────────────────────────────────────┘
```

**MCP Supervisor Implementation:**

```python
# mcp_supervisor/supervisor.py
class McpSupervisor:
    """Manages lifecycle of all MCP servers on ecolife-2."""
    
    HEALTH_CHECK_INTERVAL = 30  # seconds
    PING_TIMEOUT = 5  # seconds
    RESTART_BACKOFF = [5, 10, 30, 60, 120]  # exponential
    
    async def start_all(self):
        """Start all configured MCP servers in dependency order."""
        for server in self.dependency_ordered_servers():
            await self.start(server)
            await self.wait_for_healthy(server)  # Blocking until ready
    
    async def health_check_loop(self):
        """Periodic health check for all managed servers."""
        while True:
            for server in self.running_servers:
                healthy = await self.ping(server)
                if not healthy:
                    await self.handle_unhealthy(server)
            await asyncio.sleep(self.HEALTH_CHECK_INTERVAL)
    
    async def ping(self, server: McpServer) -> bool:
        """Send JSON-RPC ping to MCP server."""
        try:
            response = await asyncio.wait_for(
                server.client.request({"method": "ping"}),
                timeout=self.PING_TIMEOUT
            )
            return response.get("result") == {}
        except (TimeoutError, ConnectionError):
            return False
    
    async def handle_unhealthy(self, server: McpServer):
        """Restart unhealthy server with backoff."""
        restart_count = server.restart_count
        delay = self.RESTART_BACKOFF[min(restart_count, len(self.RESTART_BACKOFF)-1)]
        
        self.logger.error(f"{server.name} unhealthy, restarting in {delay}s")
        await self.stop(server)
        await asyncio.sleep(delay)
        await self.start(server)
        server.restart_count += 1
```

### HIGH: Missing MCP Server Health Endpoint

| Aspect | Assessment |
|--------|-----------|
| **Gap** | MCP spec defines `ping` method for JSON-RPC health checks, but no standardized HTTP `/health` endpoint for pre-connection validation. |

**Proposed Solution:** Each MCP server exposes:
- `POST /health` (or use MCP `ping` method) — liveness check
- `GET /ready` — readiness check (DB connected, model loaded, dependencies ready)
- `GET /metrics` — optional Prometheus-style metrics for monitoring

---

## Gap Priority Summary

### CRITICAL (7 items) — System cannot operate reliably without these

| # | Gap | Area | Proposed Solution |
|---|-----|------|-------------------|
| C1 | **SSE transport deprecated** — Option B uses deprecated protocol | Transport | Migrate to **Streamable HTTP** (single `/mcp` endpoint) |
| C2 | **No cross-machine heartbeat** — lean cannot detect ecolife-2 failure | Reliability | Implement 10s heartbeat beacon from ecolife-2 + 30s timeout on lean |
| C3 | **No MCP server supervisor** — crashed servers stay down | Lifecycle | Three-layer: systemd + MCP Supervisor Python + server /health endpoints |
| C4 | **No circuit breaker** — cascading failures on network blips | Resilience | CircuitBreaker with 5-failure threshold, 30s recovery, exponential backoff |
| C5 | **No session recovery** — lost sessions on ecolife-2 restart | Transport | Client-side session cache with auto-reinitialize on `SessionExpiredError` |
| C6 | **Ollama SPOF with no fallback** — all AI ops fail if Ollama down | SPOF | Tiered LLM fallback chain: primary -> smaller model -> local -> cache |
| C7 | **No auto-recovery on boot** — manual restart after ecolife-2 reboot | Reliability | systemd template units with `Restart=on-failure`, boot-time service ordering |

### HIGH (5 items) — Significantly impact robustness and scalability

| # | Gap | Area | Proposed Solution |
|---|-----|------|-------------------|
| H1 | **Port range 3001-3010 insufficient** — 10 ports for 12+ services | Scaling | Expand to 3001-3050 with domain-based allocation ranges |
| H2 | **No service discovery** — hardcoded ports require manual config | Scaling | JSON registry file (start simple), pull-based from lean every 60s |
| H3 | **No domain plugin architecture** — adding Domain 3 touches core code | Scaling | DomainPlugin ABC with auto-registration, port range, tool registration |
| H4 | **No memory-aware model orchestration** — 32GB RAM constraint violated | Resource | OllamaModelManager with LRU eviction, pre-load default model |
| H5 | **No network partition handling** — undefined behavior on LAN drop | Reliability | Degraded mode with offline cache, async write queue, user notification |

### MEDIUM (3 items) — Improve maintainability and operational clarity

| # | Gap | Area | Proposed Solution |
|---|-----|------|-------------------|
| M1 | **`daemon/` scope unclear** — ambiguous responsibilities | Structure | Split into `mcp_supervisor/`, `ollama_manager/`, `scheduler/` |
| M2 | **Missing `registry/` module** — service discovery has no home | Structure | Add `registry/` with models, allocator, client resolver |
| M3 | **Missing `config/` module** — no centralized configuration | Structure | Add `config/` with dataclass-based env config loading |

### LOW (2 items) — Nice to have

| # | Gap | Area | Proposed Solution |
|---|-----|------|-------------------|
| L1 | **No `/metrics` endpoint** — cannot monitor MCP server performance | Observability | Add optional Prometheus metrics to each MCP server |
| L2 | **Missing `shared/` module** — common types scattered | Structure | Add `shared/` for common exceptions, types, utils |

---

## Recommended Implementation Order

```
Phase 1: Foundation (Week 1-2)
  ├─ [C1] Migrate transport: SSE → Streamable HTTP
  ├─ [C7] systemd template units for auto-start/restart
  ├─ [C3] Basic MCP Supervisor with health check loop
  └─ [H4] OllamaModelManager with RAM budgeting

Phase 2: Resilience (Week 3-4)
  ├─ [C2] Heartbeat beacon + NodeWatcher
  ├─ [C4] Circuit breaker for cross-machine calls
  ├─ [C5] Session recovery with auto-reinitialize
  └─ [C6] LLM fallback chain implementation

Phase 3: Scaling (Week 5-6)
  ├─ [H1] Expand port range + allocation table
  ├─ [H2] JSON service registry
  ├─ [H3] Domain plugin architecture
  └─ [M1-M3] Module restructuring

Phase 4: Polish (Week 7-8)
  ├─ [H5] Network partition handling + degraded mode
  ├─ [L1] Metrics endpoints
  └─ Integration testing across both machines
```

---

## Key Technical Decisions Summary

| Decision | Recommendation | Rationale |
|----------|---------------|-----------|
| **Primary Transport** | Streamable HTTP (single `/mcp` endpoint) | MCP 2025 current standard, 4x faster than SSE, infrastructure-friendly [^24^][^27^] |
| **Fallback Transport** | stdio over SSH tunnel | For when LAN is down but SSH works; stdio is most compatible [^4^] |
| **Port Allocation** | Domain-based ranges (3001-3050) | Allows 10 ports per domain x 5 domains with headroom |
| **Service Discovery** | JSON file (start) → HTTP registry (scale) | Zero dependency start, migrate when needed |
| **Failure Detection** | Push heartbeat 10s interval, 30s timeout | Fast enough for LAN, minimal overhead [^37^] |
| **Process Management** | systemd + Python supervisor | Proven, built-in to Linux, auto-restart, resource limits [^30^][^32^] |
| **Model Management** | LRU hot-swap with memory budgeting | Prevents OOM on 32GB, minimizes load latency [^36^] |
| **LLM Fallback** | 4-tier chain: primary → small → local → cache | Meets offline-first requirement with graceful degradation |

---

## References

- [^1^] agentctl — CLI for Managing AI Agents and MCP Servers (Conf42, 2026)
- [^3^] OpenTelemetry Semantic Conventions for MCP (2025-11-25)
- [^4^] Model Context Protocol Explained — Transport Overview (Codilime, 2026)
- [^21^] MCP Specification 2025-11-25 — Transports (Official)
- [^22^] Atlassian SSE Deprecation Notice (2026-03)
- [^23^] Why MCP Moved Away from SSE (Auth0, 2025-12)
- [^24^] SSE vs Streamable HTTP Migration Guide (2025-10)
- [^25^] SSE vs Streamable HTTP Comparison (BrightData, 2025-07)
- [^27^] Why MCP Deprecated SSE — Detailed Analysis (blog.fka.dev, 2025-06)
- [^28^] Streamable HTTP: The MCP Standard (Agent Factory, 2025-03)
- [^30^] Service Monitoring with systemd (CubePath)
- [^32^] systemd Watchdog Configuration (OneUptime, 2026-03)
- [^35^] Ollama RAM Requirements by Model Size (ServerMan, 2026-03)
- [^36^] Running Multiple Local Models: Memory Management (SitePoint, 2026-03)
- [^37^] How to Detect Node Failures in Distributed Systems (ByteByteGo)
- [^38^] Ollama FAQ — Concurrent Requests (Official)
- [^40^] MCP Performance Optimization — Circuit Breakers (CData, 2026-02)
- [^41^] 9 MCP Resilience Patterns for Production (dev.to, 2026-04)
- [^43^] System Design: Heart-Beats and Health-Checks (Medium, 2025-12)
