# Best Practices สำหรับ MCP-based Multi-Agent Systems
## รายงานสรุป Findings ล่าสุด (มิถุนายน 2025)

---

## 1. Key Insights (สิ่งสำคัญที่สุด 5 ข้อ)

### Insight 1: MCP กลายเป็น Transport Layer Standard สำหรับ AI Agents
- MCP (Model Context Protocol) ถูกพัฒนาโดย Anthropic และกลายเป็น open standard ที่ได้รับการรองรับอย่างกว้างขวาง (Claude, Cursor, Goose, Kimi, และอื่นๆ)
- **November 2025 Spec** เป็นจุดเปลี่ยนสำคัญ: รองรับ Async Tasks, OAuth 2.1 Authorization, และ Long-Running Workflows
- **Transport ที่แนะนำสำหรับ production:** Streamable HTTP (แทน SSE ที่ถูก deprecated)
- แหล่งอ้างอิง: [MCP November 2025 Spec](https://medium.com/@dave-patten/mcps-next-phase-inside-the-november-2025-specification-49f298502b03), [StackOverflow MCP Auth](https://stackoverflow.blog/2026/01/21/is-that-allowed-authentication-and-authorization-in-model-context-protocol/)

### Insight 2: LangGraph คือตัวเลือกอันดับ 1 สำหรับ Production Multi-Agent Orchestration
- **LangGraph** ให้การควบคุม workflow ระดับ enterprise (graph-based state machine, checkpointing, human-in-the-loop)
- **CrewAI** เหมาะสำหรับ rapid prototyping (lowest learning curve) แต่มีข้อจำกัดเรื่อง control flow
- **AutoGen** เหมาะสำหรับ iterative discussion/debate patterns (code generation, research) แต่ unpredictable execution
- สำหรับระบบที่ต้องการ determinism + fault tolerance + long-running workflows → **LangGraph เป็นตัวเลือกที่ดีที่สุด**
- แหล่งอ้างอิง: [LangGraph vs CrewAI vs AutoGen 2026](https://dev.to/pockit_tools/langgraph-vs-crewai-vs-autogen-the-complete-multi-agent-ai-orchestration-guide-for-2026-2d63), [AI Agent Frameworks Compared](https://www.developersdigest.tech/guides/ai-agent-frameworks-compared)

### Insight 3: LiteLLM Proxy เป็นมาตรฐาน de facto สำหรับ Multi-Model Routing
- LiteLLM รองรับ **11000+ models** จาก 100+ providers ผ่าน unified OpenAI-compatible API
- มี built-in **fallback chains, circuit breaker, load balancing, budget management**
- รองรับ **Ollama โดยตรง** ทำให้ integrate local LLM + cloud LLM ได้ seamlessly
- Cost optimization: routing strategy (cost-based, latency-based, usage-based) ช่วยลดค่าใช้จ่ายได้ 15-25%
- แหล่งอ้างอิง: [LiteLLM Complete Guide 2025](https://www.youngju.dev/blog/culture/2026-03-25-litellm-unified-llm-api-proxy-guide-2025.en), [LLM Routing with Ollama & LiteLLM](https://medium.com/@michael.hannecke/implementing-llm-model-routing-a-practical-guide-with-ollama-and-litellm-b62c1562f50f)

### Insight 4: Agent Memory แยกเป็น 2 ระบบชัดเจน (Short-term vs Long-term)
- **Short-term memory (session-based):** ใช้สำหรับ conversation context ภายใน session → ใช้ LangGraph checkpointing (SQLite/Postgres)
- **Long-term memory (cross-session):** ใช้สำหรับ user preferences, learned facts → ใช้ **Mem0** (0.200s p95 latency, 66.9% recall accuracy, self-hosted ได้ด้วย Qdrant/ChromaDB)
- การแยก memory ช่วยลด token consumption และทำให้ agent "เรียนรู้" จากประสบการณ์ก่อนหน้า
- แหล่งอ้างอิง: [Mem0 AI Agent Memory 2026](https://mem0.ai/blog/state-of-ai-agent-memory-2026), [How to Implement Long-Term Memory for AI Agents](https://atlan.com/know/how-to-implement-long-term-memory-ai-agents/)

### Insight 5: MCP Gateway จำเป็นสำหรับ Production Multi-Agent Systems
- โดย default MCP ไม่มี global registry หรือ centralized auth → ต้องสร้าง **MCP Gateway** เอง
- Gateway ทำหน้าที่: reverse proxy, service discovery, auth/authz, load balancing, observability
- Open-source options ที่น่าสนใจ: **Portkey MCP Gateway** (MIT), **IBM ContextForge** (Apache 2.0), **Docker MCP Gateway** (MIT)
- สำหรับ team ที่ต้องการควบคุมทุกอย่างเอง → สร้าง simple gateway ด้วย FastAPI/Express
- แหล่งอ้างอิง: [What It Takes to Run MCP in Production](https://bytebridge.medium.com/what-it-takes-to-run-mcp-model-context-protocol-in-production-3bbf19413f69), [Best MCP Gateways for Self-Hosted Deployments](https://www.mintmcp.com/blog/mcp-gateways-self-hosted-deployments)

---

## 2. Recommended Patterns (Patterns ที่ควรนำไปใช้)

### Pattern 1: MCP Transport Selection
| Scenario | Transport | เหตุผล |
|----------|-----------|--------|
| Local dev, single-user, filesystem tools | **stdio** | Zero config, lowest latency |
| Remote deployment, multi-client, production | **Streamable HTTP** | Single endpoint, concurrent support, Claude.ai native |
| Mixed environments (local + remote) | **Gateway** | จัดการ transport translation อัตโนมัติ |

> **ห้ามใช้ SSE สำหรับ project ใหม่** - SSE ถูก deprecated ใน MCP spec 2025 แล้ว

- แหล่งอ้างอิง: [MCP SSE vs Stdio vs Streamable HTTP](https://apigene.ai/blog/mcp-sse-vs-stdio), [MCP Transport Architecture](https://www.pgedge.com/blog/mcp-transport-architecture-boundaries-and-failure-modes)

### Pattern 2: Multi-Tier Model Routing (Local → Cloud Fallback)
```yaml
# LiteLLM 3-Tier Routing Config
model_list:
  - model_name: tier-1-fast
    litellm_params:
      model: ollama/gemma4:31b
      api_base: http://agent-machine:11434
  - model_name: tier-2-balanced
    litellm_params:
      model: ollama/phi4
      api_base: http://agent-machine:11434
  - model_name: tier-3-cloud
    litellm_params:
      model: openai/gpt-4o-mini
      api_key: os.environ/OPENAI_API_KEY

router_settings:
  routing_strategy: latency-based-routing
  fallbacks:
    - tier-1-fast: ["tier-2-balanced"]
    - tier-2-balanced: ["tier-3-cloud"]
  num_retries: 2
  timeout: 30
```

- แหล่งอ้างอิง: [LLM Routing with Ollama & LiteLLM](https://medium.com/@michael.hannecke/implementing-llm-model-routing-a-practical-guide-with-ollama-and-litellm-b62c1562f50f)

### Pattern 3: LangGraph Human-in-the-Loop with Interrupts
```python
# Static interrupt (compliance/approval gates)
graph = builder.compile(
    checkpointer=checkpointer,
    interrupt_before=["sensitive_action"],  # Pause ก่อน execute
    interrupt_after=["generate_response"]   # Pause หลัง generate เพื่อ review
)

# Dynamic interrupt (conditional)
def process_transaction(state):
    amount = state["transaction_amount"]
    if amount > 10000:
        human_decision = interrupt({
            "question": f"Approve transaction of ${amount}?",
            "details": state["details"]
        })
        if not human_decision.get("approved"):
            return {"status": "rejected"}
    return {"status": "approved"}
```

- แหล่งอ้างอิง: [LangGraph Human-in-the-Loop Docs](https://mintlify.com/langchain-ai/langgraph/concepts/human-in-the-loop), [Production-Ready HITL with LangGraph](https://dev.to/sreeni5018/beyond-input-building-production-ready-human-in-the-loop-ai-with-langgraph-2en9)

### Pattern 4: Degrading Circuit Breaker for LLM Providers
```python
class DegradingCircuitBreaker:
    def __init__(self, failure_threshold=5, recovery_timeout=60):
        self.degradation_levels = ["full", "partial", "minimal", "offline"]
        # full → ใช้ primary model
        # partial → ใช้ smaller/faster model
        # minimal → ใช้ cache/static response
        # offline → ใช้ local model only
```

- แหล่งอ้างอิง: [Graceful Degradation Patterns](https://docs.praison.ai/docs/best-practices/graceful-degradation), [Provider Fallbacks LLM Availability](https://www.statsig.com/perspectives/providerfallbacksllmavailability)

### Pattern 5: MCP Error Handling with Retry-Friendly Responses
```python
@mcp.tool()
async def fetch_api_data(endpoint: str, attempt: int = 1) -> dict:
    max_attempts = 3
    try:
        response = await client.get(endpoint)
        if response.status_code == 429:
            retry_after = int(response.headers.get("Retry-After", 60))
            return {
                "success": False,
                "error": {
                    "type": "rate_limited",
                    "retry": {
                        "should_retry": attempt < max_attempts,
                        "retry_after_seconds": retry_after,
                        "next_attempt": attempt + 1
                    },
                    "suggestion": f"Wait {retry_after}s, then retry"
                }
            }
    except httpx.TimeoutException:
        backoff = min(2 ** attempt, 30)
        return {
            "success": False,
            "error": {
                "type": "timeout",
                "retry": {"should_retry": True, "retry_after_seconds": backoff}
            }
        }
```

- แหล่งอ้างอิง: [MCP Error Handling Patterns](https://www.kaigritun.com/mcp/mcp-error-handling-patterns)

### Pattern 6: Ollama Multi-Model Memory Management (32GB RAM)
```bash
# Environment variables for production
export OLLAMA_KEEP_ALIVE=30m        # เก็บ model ไว้ 30 นาทีหลังใช้งาน
export OLLAMA_MAX_LOADED_MODELS=2    # โหลดสูงสุด 2 models พร้อมกัน
export OLLAMA_NUM_PARALLEL=2         # 2 concurrent requests
export OLLAMA_MAX_QUEUE=10           # Queue limit
export OLLAMA_FLASH_ATTENTION=1      # ลด memory สำหรับ long context
export OLLAMA_KV_CACHE_TYPE=q4_0     # KV cache quantization

# Preload model (eliminate cold start)
curl http://localhost:11434/api/generate -d '{"model": "gemma4:31b", "keep_alive": -1}'

# Warm-up cron (ทุก 10 นาที)
*/10 * * * * curl -s http://localhost:11434/api/generate -d '{"model": "gemma4:31b", "prompt": "hi", "keep_alive": -1}' > /dev/null
```

- แหล่งอ้างอิง: [Ollama Enterprise Deployment Guide](https://hyperion-consulting.io/en/insights/ollama-enterprise-deployment-guide-2026), [Ollama Model Quantization](https://mintlify.com/ollama/ollama/advanced/model-quantization)

---

## 3. Tools to Consider (เครื่องมือที่ควรพิจารณา)

### Tier 1: Core Infrastructure (ต้องมี)

| Tool | ใช้ทำอะไร | License | URL |
|------|-----------|---------|-----|
| **LiteLLM Proxy** | Unified LLM API, routing, fallback, budget | MIT (self-host free) | [GitHub](https://github.com/BerriAI/litellm) |
| **LangGraph** | Multi-agent orchestration, workflows, HITL | MIT | [GitHub](https://github.com/langchain-ai/langgraph) |
| **Mem0** | Long-term agent memory (cross-session) | Apache 2.0 | [GitHub](https://github.com/mem0ai/mem0) |
| **Ollama** | Local LLM runtime | MIT | [GitHub](https://github.com/ollama/ollama) |

### Tier 2: Observability & Monitoring

| Tool | ใช้ทำอะไร | License | URL |
|------|-----------|---------|-----|
| **Langfuse** | Open-source LLM observability (tracing, cost) | MIT (self-host free) | [GitHub](https://github.com/langfuse/langfuse) |
| **LangSmith** | LangChain-native observability | SaaS ($39/user/mo) | [Website](https://www.langchain.com/langsmith) |
| **Prometheus + Grafana** | Metrics dashboard for Ollama/LiteLLM | Apache 2.0 | - |

### Tier 3: MCP Infrastructure

| Tool | ใช้ทำอะไร | License | URL |
|------|-----------|---------|-----|
| **Portkey MCP Gateway** | MCP gateway + LLM routing unified | MIT | [Website](https://portkey.ai/features/mcp) |
| **IBM ContextForge** | Open-source MCP gateway, multi-transport | Apache 2.0 | [GitHub](https://github.com/IBM/context-forge) |
| **Dify** | Low-code AI agent platform (internal tools) | Apache 2.0 | [GitHub](https://github.com/langgenius/dify) |
| **n8n** | Workflow automation + AI agent nodes | Sustainable Use License | [Website](https://n8n.io) |

### Tier 4: Security & Governance

| Tool | ใช้ทำอะไร | License | URL |
|------|-----------|---------|-----|
| **Peta (Agent Vault)** | Zero-trust credential management for agents | Commercial | [Website](https://peta.io) |

---

## 4. Anti-Patterns to Avoid (สิ่งที่ไม่ควรทำ)

### Anti-Pattern 1: Hard-code Multiple MCP Server Endpoints
- **ปัญหา:** ไม่มี gateway → ต้อง config endpoint ทุก server ใน client → ยุ่งยาก, ไม่ scalable
- **แก้ไข:** ใช้ MCP Gateway เป็น single entry point (เช่น `mcp.company.lan`)
- แหล่งอ้างอิง: [MCP Production Best Practices](https://bytebridge.medium.com/what-it-takes-to-run-mcp-model-context-protocol-in-production-3bbf19413f69)

### Anti-Pattern 2: Embed Raw Credentials in Prompts/Agent Context
- **ปัญหา:** LLM อาจ leak credentials ผ่าน output หรือ context
- **แก้ไข:** ใช้ secure vault + tokenization (เช่น Peta) หรือ gateway inject credentials server-side
- แหล่งอ้างอิง: [MCP Security Best Practices](https://bytebridge.medium.com/what-it-takes-to-run-mcp-model-context-protocol-in-production-3bbf19413f69)

### Anti-Pattern 3: Build New MCP Servers with SSE Transport
- **ปัญหา:** SSE ถูก deprecated ใน MCP spec 2025 → client support จะลดลงเรื่อยๆ
- **แก้ไข:** ใช้ Streamable HTTP (single endpoint, รองรับทั้ง sync และ streaming)
- แหล่งอ้างอิง: [MCP Transport Options Explained](https://apigene.ai/blog/mcp-sse-vs-stdio)

### Anti-Pattern 4: Expose Too Many Granular Tools to LLM
- **ปัญหา:** Agent เรียกผิด tool บ่อย (tool confusion), context penalty สูง
- **แก้ไข:** ใช้ **Toolhost Pattern** - รวมหลาย operations ไว้ใน tool เดียว ด้วย dispatcher pattern
- แหล่งอ้างอิง: [MCP Toolhost Pattern](https://glassbead-tc.medium.com/design-patterns-in-mcp-toolhost-pattern-59e887885df3)

### Anti-Pattern 5: Mix Read and Write Operations in Same Tool
- **ปัญหา:** ทำให้ user ตัดสินใจเรื่อง permission ยาก (risk level ไม่ชัดเจน)
- **แก้ไข:** แยก tool เป็น read-only (low risk) และ non-read (high risk) ชัดเจน
- แหล่งอ้างอิง: [Block's Playbook for Designing MCP Servers](https://engineering.block.xyz/blog/blocks-playbook-for-designing-mcp-servers)

### Anti-Pattern 6: Use stdio for Multi-Client Production
- **ปัญหา:** stdio รองรับแค่ single client → 20/22 requests ล้มเหลว ที่ 20 concurrent connections
- **แก้ไข:** ใช้ Streamable HTTP สำหรับ multi-client, หรือใช้ gateway แปลง stdio → HTTP
- แหล่งอ้างอิง: [MCP SSE vs Stdio](https://apigene.ai/blog/mcp-sse-vs-stdio)

### Anti-Pattern 7: No Observability from Day One
- **ปัญหา:** Agent ทำงานผิด → ไม่รู้ว่าเกิดอะไรขึ้น → debug ยากมาก
- **แก้ไข:** ติดตั้ง tracing (Langfuse/OpenTelemetry) ตั้งแต่เริ่ม project
- แหล่งอ้างอิง: [AI Agent Observability Guide](https://medium.com/online-inference/mastering-ai-agent-observability-a-comprehensive-guide-b142ed3604b1)

---

## 5. Relevant Standards/Specs (มาตรฐานที่ควร Follow)

| มาตรฐาน | รายละเอียด | สถานะ |
|----------|-----------|--------|
| **MCP Specification (Nov 2025)** | รองรับ Async Tasks, OAuth 2.1, Streamable HTTP | Stable |
| **OAuth 2.1 (draft-ietf-oauth-v2-1)** | Authorization framework สำหรับ MCP | IETF Draft |
| **RFC 9728** - Protected Resource Metadata | MCP clients discover auth requirements from resource server | Standards Track (Apr 2025) |
| **RFC 9700** - OAuth 2.0 Security BCP | Security best practices สำหรับ OAuth | Best Current Practice (Jan 2025) |
| **OpenTelemetry GenAI Semantic Conventions** | มาตรฐาน tracing/observability สำหรับ AI systems | Draft |
| **A2A Protocol (Agent-to-Agent)** | มาตรฐานสื่อสารระหว่าง agents (สถานะยัง early) | Experimental |

### MCP Authorization Flow (June 2025+ Spec)
```
MCP Client → Authorization Server (IdP: Keycloak/Auth0/Azure AD)
     ↑                                          ↓
     ←←←←←←←←←←←←←←←←←←←←←←←←←←←← Access Token
     ↓
MCP Server (Resource Server) - ตรวจสอบ token, ไม่ issue token
```

- แหล่งอ้างอิง: [MCP Authorization Spec Deep Dive](https://kane.mx/posts/2025/mcp-authorization-oauth-rfc-deep-dive/), [MCP Auth Spec Overview](https://www.descope.com/blog/post/mcp-auth-spec)

---

## 6. Architecture Recommendation สำหรับระบบของคุณ

### High-Level Architecture
```
┌─────────────────────────────────────────────────────────────┐
│                    Dev Machine (lean)                        │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐                   │
│  │ Kimi CLI │  │OpenCode  │  │ Goose CLI│  (MCP Clients)    │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘                   │
│       └─────────────┴─────────────┘                           │
│                     │                                        │
│              ┌──────┴──────┐                                │
│              │ MCP Gateway  │ ← Single entry point           │
│              │ (ContextForge│    Reverse proxy + Auth        │
│              │  or custom)  │    Registry + Router           │
│              └──────┬──────┘                                │
└─────────────────────┼───────────────────────────────────────┘
                      │ LAN
┌─────────────────────┼───────────────────────────────────────┐
│              Agent Machine (ecolife-2)                       │
│                     │                                        │
│  ┌──────────────────┼──────────────────────────────────┐    │
│  │         LiteLLM Proxy (Port 4000)                   │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐         │    │
│  │  │ Ollama   │  │ Kimi K2.6│  │ GLM 5.1  │         │    │
│  │  │ gemma4:31│  │ (Cloud)  │  │(Fallback)│         │    │
│  │  │ ~22GB RAM│  │          │  │          │         │    │
│  │  └────┬─────┘  └────┬─────┘  └────┬─────┘         │    │
│  │       └─────────────┴─────────────┘                │    │
│  │  Routing: latency-based → fallback chain           │    │
│  └────────────────────────────────────────────────────┘    │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  MCP Servers (stdio via gateway bridge)             │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐            │   │
│  │  │ Filesystem│ │  Custom  │ │ External │            │   │
│  │  │  Server   │ │  Tools   │ │  APIs    │            │   │
│  │  └──────────┘ └──────────┘ └──────────┘            │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Memory Layer                                       │   │
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐            │   │
│  │  │ LangGraph│ │  Mem0    │ │ Postgres │            │   │
│  │  │Checkpoint│ │ (Qdrant) │ │ (Metadata)│           │   │
│  │  └──────────┘ └──────────┘ └──────────┘            │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Observability: Langfuse + Prometheus + Grafana     │   │
│  └─────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

### Recommended Stack

| Component | เครื่องมือที่แนะนำ | เหตุผล |
|-----------|-------------------|--------|
| **MCP Gateway** | IBM ContextForge หรือ custom FastAPI | Self-hosted, multi-transport, Apache 2.0 |
| **Agent Orchestration** | LangGraph | Best for complex, stateful, fault-tolerant workflows |
| **Model Routing** | LiteLLM Proxy | Unified API, fallback, budget management |
| **Local LLM** | Ollama + gemma4:31b (Q4_K_M) | ~22GB RAM, 95-97% quality |
| **Long-term Memory** | Mem0 + Qdrant (self-hosted) | 0.2s latency, 66.9% recall |
| **Observability** | Langfuse (self-hosted) | MIT license, full tracing |
| **Auth** | Keycloak หรือ simple JWT | รองรับ OAuth 2.1, PKCE |
| **Deployment** | Docker Compose + systemd | 24/7 reliable, auto-restart |

### Gemma 4 31B on 32GB RAM
- **Q4_K_M quantization:** ~22GB VRAM/RAM (8K context) - พอดีสำหรับ 32GB system
- **OLLAMA_MAX_LOADED_MODELS=1** - โหลด model เดียว (ใช้ primary model อย่างเดียวบน Ollama)
- **OLLAMA_NUM_PARALLEL=2** - รองรับ 2 concurrent requests
- **OLLAMA_KEEP_ALIVE=-1** - เก็บ model ไว้ตลอด (ไม่ unload)
- หากต้องการ multi-model → ใช้ model ขนาดเล็กร่วม (เช่น phi4 ~8GB สำหรับงานง่าย)

---

## 7. สรุปคำตอบสำหรับคำถามสำคัญ

### Q1: Patterns/Frameworks ไหนที่ควรใช้?
- **MCP Gateway Pattern** → IBM ContextForge หรือ custom gateway
- **LangGraph** สำหรับ orchestration (deterministic workflows + HITL)
- **LiteLLM Proxy** สำหรับ model routing & fallback
- **Mem0** สำหรับ long-term memory
- **Toolhost Pattern** สำหรับ MCP server design (ลด tool confusion)

### Q2: Anti-patterns ที่ควรหลีกเลี่ยง?
- ใช้ SSE (deprecated)
- ใช้ stdio สำหรับ multi-client production
- Embed credentials ใน prompts
- Hard-code MCP endpoints
- Expose too many granular tools
- ไม่มี observability

### Q3: Open-source tools ที่ควรพิจารณา?
| ระดับความสำคัญ | Tools |
|----------------|-------|
| ต้องมี | LiteLLM, LangGraph, Mem0, Ollama, Langfuse |
| ควรมี | MCP Gateway (ContextForge/Portkey), Qdrant, Keycloak |
| พิจารณา | Dify (low-code), n8n (workflows), Prometheus/Grafana |

### Q4: Standards/Specs ที่ควร follow?
- **MCP Specification November 2025** (ล่าสุด)
- **OAuth 2.1 with PKCE** (สำหรับ auth)
- **RFC 9728** Protected Resource Metadata
- **OpenTelemetry GenAI** conventions (สำหรับ observability)

---

## References (แหล่งอ้างอิงทั้งหมด)

1. [What It Takes to Run MCP in Production - ByteBridge](https://bytebridge.medium.com/what-it-takes-to-run-mcp-model-context-protocol-in-production-3bbf19413f69)
2. [MCP SSE vs Stdio vs Streamable HTTP - Apigene](https://apigene.ai/blog/mcp-sse-vs-stdio)
3. [MCP Transport Architecture - pgedge](https://www.pgedge.com/blog/mcp-transport-architecture-boundaries-and-failure-modes)
4. [MCP Authentication and Authorization - TrueFoundry](https://www.truefoundry.com/blog/mcp-authentication-and-authorization)
5. [MCP Auth in StackOverflow Blog](https://stackoverflow.blog/2026/01/21/is-that-allowed-authentication-and-authorization-in-model-context-protocol/)
6. [MCP November 2025 Spec - Dave Patten](https://medium.com/@dave-patten/mcps-next-phase-inside-the-november-2025-specification-49f298502b03)
7. [LangGraph vs CrewAI vs AutoGen 2026 - dev.to](https://dev.to/pockit_tools/langgraph-vs-crewai-vs-autogen-the-complete-multi-agent-ai-orchestration-guide-for-2026-2d63)
8. [AI Agent Frameworks Compared - Developers Digest](https://www.developersdigest.tech/guides/ai-agent-frameworks-compared)
9. [LiteLLM Complete Guide 2025 - youngju.dev](https://www.youngju.dev/blog/culture/2026-03-25-litellm-unified-llm-api-proxy-guide-2025.en)
10. [LLM Routing with Ollama & LiteLLM - Medium](https://medium.com/@michael.hannecke/implementing-llm-model-routing-a-practical-guide-with-ollama-and-litellm-b62c1562f50f)
11. [Provider Fallbacks LLM Availability - Statsig](https://www.statsig.com/perspectives/providerfallbacksllmavailability)
12. [State of AI Agent Memory 2026 - Mem0](https://mem0.ai/blog/state-of-ai-agent-memory-2026)
13. [Long-term Memory for AI Agents - Atlan](https://atlan.com/know/how-to-implement-long-term-memory-ai-agents/)
14. [Ollama Enterprise Deployment Guide - Hyperion](https://hyperion-consulting.io/en/insights/ollama-enterprise-deployment-guide-2026)
15. [Ollama VRAM Requirements - localllm.in](https://localllm.in/blog/ollama-vram-requirements-for-local-llms)
16. [LangGraph Human-in-the-Loop Docs](https://mintlify.com/langchain-ai/langgraph/concepts/human-in-the-loop)
17. [Production HITL with LangGraph - dev.to](https://dev.to/sreeni5018/beyond-input-building-production-ready-human-in-the-loop-ai-with-langgraph-2en9)
18. [Graceful Degradation Patterns - PraisonAI](https://docs.praison.ai/docs/best-practices/graceful-degradation)
19. [MCP Error Handling Patterns - kaigritun](https://www.kaigritun.com/mcp/mcp-error-handling-patterns)
20. [MCP Toolhost Pattern - glassBead](https://glassbead-tc.medium.com/design-patterns-in-mcp-toolhost-pattern-59e887885df3)
21. [Block's Playbook for MCP Servers](https://engineering.block.xyz/blog/blocks-playbook-for-designing-mcp-servers)
22. [Best MCP Gateways Self-Hosted - MintMCP](https://www.mintmcp.com/blog/mcp-gateways-self-hosted-deployments)
23. [Agent Communication Protocols - muthu.co](https://notes.muthu.co/2025/11/agent-communication-protocols-and-message-passing-patterns-for-coordination/)
24. [AI Agent Observability Guide - Medium](https://medium.com/online-inference/mastering-ai-agent-observability-a-comprehensive-guide-b142ed3604b1)
25. [MCP Auth Spec Deep Dive - kane.mx](https://kane.mx/posts/2025/mcp-authorization-oauth-rfc-deep-dive/)
26. [MCP Server Design Principles - matt-adams](https://www.matt-adams.co.uk/2025/08/30/mcp-design-principles.html)
27. [Ollama Model Quantization - Official Docs](https://mintlify.com/ollama/ollama/advanced/model-quantization)
28. [LangSmith Observability](https://www.langchain.com/langsmith/observability)
29. [Langfuse Open Source](https://langfuse.com)
30. [Top Agent Gateways 2025 - TrueFoundry](https://www.truefoundry.com/blog/top-agent-gateways)
31. [MCP Gateways Alternatives - ByteBridge](https://bytebridge.medium.com/exploring-mcp-gateways-alternatives-to-the-obot-gateway-62598357f5b3)
32. [LLMOps 1200 Deployments - ZenML](https://www.zenml.io/blog/what-1200-production-deployments-reveal-about-llmops-in-2025)
33. [Ollama RAM Requirements Guide](https://localaimaster.com/blog/ram-requirements-local-ai)
34. [MCP in Production - WaveSpeed](https://wavespeed.ai/blog/posts/mcp-model-context-protocol-production/)
35. [Intelligent LLM Routing - SWFTE](https://www.swfte.com/blog/intelligent-llm-routing-multi-model-ai)

---

*รายงานนี้รวบรวมข้อมูลล่าสุดจาก sources ต่างๆ ในปี 2025-2026*
