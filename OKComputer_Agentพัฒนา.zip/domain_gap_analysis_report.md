# Domain Requirements Gap Analysis Report
## agent-toolkit Multi-Agent System

**Date:** 2025-07-01
**Scope:** Solar Energy O&M, Health Food Franchise, RAG Retriever
**Analyst:** Business Domain Analysis Agent

---

## Executive Summary

After thorough analysis of the requirements across all three domains, this report identifies **23 gaps** categorized by severity:

| Priority | Count | Domains Affected |
|----------|-------|------------------|
| CRITICAL | 7 | Solar (3), Health Franchise (3), RAG (1) |
| HIGH | 9 | Solar (4), Health Franchise (3), RAG (2) |
| MEDIUM | 5 | Solar (2), Health Franchise (2), RAG (1) |
| LOW | 2 | Solar (1), RAG (1) |

**Key Finding:** The system currently assumes ideal data availability and clean integration points. In reality, all three domains face significant ambiguity in data sources, integration protocols, and operational edge cases that — if unaddressed — will cause system failures in production.

---

## Domain A: Solar Energy O&M — Gap Analysis

### A1. Data Ingestion & Source Connectivity

#### [CRITICAL] A1.1 — Inverter API & Data Source Architecture Undefined
**Gap:** Requirements state "CSV/JSON (irradiance, power, inverter data)" but do not specify:
- Which inverter manufacturers are targeted (SMA, Huawei, Fronius, SolarEdge, Sungrow, Growatt?)
- Whether data comes from inverter APIs, SCADA systems (e.g., GE PowerOn, Schneider EcoStruxure), or third-party monitoring platforms (e.g., AlsoEnergy, PowerFactors, Solar-Log)
- Authentication mechanisms (OAuth2, API keys, certificates)
- Real-time vs. batch ingestion mode
- Polling frequency (1-min, 5-min, 15-min intervals)

**Justification:** Each inverter brand has a different API spec. SMA uses Modbus/TCP or WebConnect API. SolarEdge has a REST API with specific endpoint limits. Huawei uses FusionSolar API. Without this definition, the ingestion module cannot be designed.

**Proposed Solution:**
```
1. Define a pluggable connector architecture with IngestionAdapter interface
2. Implement priority connectors: SMA WebConnect, SolarEdge Monitoring, 
   Huawei FusionSolar, Fronius Solar.web
3. Support Modbus TCP/RTU for direct inverter communication
4. Add SCADA protocol support (IEC 61850, DNP3) for utility-scale sites
5. Include API authentication manager (OAuth2 refresh token handling)
```

---

#### [CRITICAL] A1.2 — No Data Format Standardization / Schema Definition
**Gap:** "CSV/JSON" is too vague. Solar data has specific fields that must be standardized:
- Irradiance: POA (Plane of Array) vs. GHI (Global Horizontal) — which one for PR calc?
- Temperature: Module temperature vs. ambient temperature
- Power: DC power vs. AC power — which for inverter efficiency?
- Timestamps: UTC vs. local time (Thailand = UTC+7) — critical for daily yield aggregation
- Unit consistency (W vs. kW, Wh vs. kWh)

**Justification:** PR calculation per IEC 61724 requires specific inputs (POA irradiance, module temperature, AC energy output). Using GHI instead of POA will produce incorrect PR values. Timezone confusion will cause daily yield to be off by hours.

**Proposed Solution:**
```
1. Define canonical data schema: SolarDataRecord { timestamp_utc, timestamp_local, 
   irradiance_poa_w_m2, irradiance_ghi_w_m2, power_dc_kw, power_ac_kw, 
   energy_daily_kwh, module_temp_c, ambient_temp_c, inverter_id, string_id }
2. Implement schema validator with pydantic
3. Auto-convert units from source format to canonical schema
4. Enforce UTC for storage, local time (Asia/Bangkok) for reporting
```

---

#### [HIGH] A1.3 — No Data Ingestion Pipeline Resilience Design
**Gap:** No mention of:
- Retry logic for API failures
- Data buffering during network outages
- Handling partial data (some inverters online, others offline)
- Backfill capability for historical data gaps

**Justification:** Solar sites in Thailand often have unreliable 4G/LoRa connectivity. Inverters go offline during grid faults. Without resilience design, data gaps will accumulate and affect all downstream calculations.

**Proposed Solution:**
```
1. Implement ingestion pipeline with dead-letter queue for failed fetches
2. Add local SQLite buffer for edge buffering (store up to 7 days offline)
3. Backfill job that runs every 6 hours to fill gaps
4. Data completeness metric: track % data availability per inverter/day
```

---

### A2. Calculations & Methodology

#### [CRITICAL] A2.1 — "IRR" Ambiguity: Financial vs. Solar Irradiance
**Gap:** The requirement states "Calculations: IRR" but does not clarify which IRR:
- **Financial IRR:** Internal Rate of Return — a financial metric for investment analysis (requires cash flow data, OPEX, energy prices)
- **Solar IRR:** Instantaneous Radiation Rate or Incident Radiation Rate — sometimes used as shorthand in solar monitoring

**Justification:** These are completely different metrics. Financial IRR needs CAPEX, OPEX, energy revenue data. If the system is meant to calculate financial IRR, the current inputs (irradiance, power, inverter data) are insufficient. If it means solar irradiance rate, the naming is misleading.

**Proposed Solution:**
```
1. Clarify with stakeholders which IRR is intended
2. If Financial IRR: add financial model inputs (capex, opex, ppa_rate, 
   degradation_rate, project_lifetime_years)
3. If Solar IRR (irradiance-related): rename to "Irradiance Utilization Rate" 
   or similar to avoid confusion
4. Document calculation methodology in system spec
```

---

#### [HIGH] A2.2 — PR Calculation Missing IEC 61724 Compliance Details
**Gap:** "PR (Performance Ratio)" is listed without specifying:
- Reference conditions (STC: 1000 W/m², 25°C cell temperature)
- Temperature correction method (IEC 61724-1 Option A: measured module temp, or Option B: estimated)
- Time period for PR (instantaneous PR vs. daily/period PR — they differ significantly)
- Degradation adjustment (PR naturally degrades ~0.5%/year — should threshold account for this?)

**Justification:** A 5-year-old plant with 82% PR might actually be performing well (expected degradation from 85% to ~82.5%). Flagging it as "PR < 80% = alert" without age-adjustment creates false alarms.

**Proposed Solution:**
```
1. Implement PR per IEC 61724-1: PR = (E_actual / (H_POA * P_installed)) * 100%
2. Add temperature correction option (module temp coefficient required)
3. Implement age-adjusted PR threshold: threshold = base_threshold * (1 - degradation_rate)^years
4. Calculate both daily PR and period PR (rolling 30-day)
```

---

#### [HIGH] A2.3 — Inverter Efficiency Calculation Needs String-Level Detail
**Gap:** "Inverter efficiency" is mentioned without specifying:
- Efficiency formula: (AC_power / DC_power) * 100% at each time point, or energy-based?
- Whether to calculate per-inverter or aggregate plant-level
- Euro efficiency vs. CEC efficiency weighting
- Nighttime efficiency (inverters consume power at night — should this be in efficiency calc?)

**Justification:** A 10kW inverter running at 500W has much lower efficiency than at 5kW. Simple (AC/DC) ratio can show <89% at low load which is normal. Without load-weighted efficiency (like Euro efficiency), false flags will occur.

**Proposed Solution:**
```
1. Implement load-weighted inverter efficiency (Euro/CEC weighting)
2. Add operating range filter: only calculate efficiency when DC_power > 5% rated
3. Track both instantaneous efficiency and daily weighted average
4. Include nighttime consumption tracking as separate metric
```

---

#### [MEDIUM] A2.4 — Daily Yield Calculation Needs Multiple Time Granularities
**Gap:** "daily yield" is mentioned but:
- When does the "day" start/end? (Midnight local? Sunrise-to-sunset?)
- Is it per-inverter, per-string, or plant total?
- Should it include availability-adjusted yield (what the plant SHOULD have produced vs. actual)?

**Justification:** A plant with 50% availability due to maintenance might show "low daily yield" which is expected. Without availability context, the metric is misleading.

**Proposed Solution:**
```
1. Day boundary: 00:00-23:59 local time (Asia/Bangkok)
2. Calculate at 3 levels: per-string, per-inverter, plant-total
3. Add availability-adjusted yield = actual_yield / availability_factor
4. Track yield loss due to curtailment, outage, soiling separately
```

---

### A3. Thresholds & Alerting

#### [HIGH] A3.1 — Fixed Thresholds (80% PR, 89% INV) Are Not Site-Adaptive
**Gap:**
- The 80% PR threshold does not account for plant age, technology (mono PERC vs. thin-film), or climate zone
- The 89% inverter efficiency threshold does not account for inverter brand/model (some inverters spec 97.5% max, others 98.6%)
- No mention of threshold configuration per-site or per-inverter

**Justification:** A Thin-film CdTe plant in the desert with 78% PR might be performing normally (thin-film has lower temperature coefficient). A fixed 80% threshold would create false alarms.

**Proposed Solution:**
```
1. Replace fixed thresholds with configurable per-site baseline
2. Baseline auto-calculation: use first 30 days of operation as baseline
3. Support tiered alerts: WARNING (baseline - 5%), CRITICAL (baseline - 10%)
4. Allow per-inverter override for known underperformers
```

---

#### [MEDIUM] A3.2 — Missing Multi-Tier Alert Escalation
**Gap:** Simple binary alert (PR < 80% = alert) is insufficient for operational use:
- No severity levels (WARNING vs. CRITICAL vs. EMERGENCY)
- No alert fatigue prevention (repeated alerts for same issue)
- No escalation path (who gets notified? Ops team? Site manager? Customer?)
- No alert correlation (PR drop + inverter efficiency drop = likely soiling, not inverter failure)

**Proposed Solution:**
```
1. Implement 3-tier alerts: WARNING (deviation detected), CRITICAL (threshold breach),
   EMERGENCY (multiple inverters down)
2. Add alert deduplication and snoozing
3. Implement alert correlation rules
4. Add notification routing: internal team -> site manager -> customer
```

---

### A4. Anomaly Detection

#### [HIGH] A4.1 — flag_anomalies Tool Lacks Detection Methodology
**Gap:** "flag_anomalies" has no specification for:
- Detection method: rule-based (thresholds), statistical (z-score, IQR), or ML-based (isolation forest, LSTM)
- Seasonality handling (Thailand has distinct rainy/monsoon season — May-October)
- Soiling detection (gradual PR degradation over weeks)
- Clipping detection (inverter at max output — could indicate undersizing)
- Nighttime anomalies (inverters consuming excessive power at night)

**Justification:** Rule-based anomaly detection misses gradual degradation. Simple thresholding will false-flag during rainy season. A plant that drops 5% PR over 2 weeks may have soiling — a pattern that statistical methods catch but rules don't.

**Proposed Solution:**
```
1. Implement hybrid detection:
   - Rule-based: immediate flags (inverter offline, zero production at noon)
   - Statistical: z-score based on 30-day rolling mean per site
   - Seasonal: compare against same period last year (year-over-year)
2. Add specific detectors:
   - Soiling detector: gradual PR decline over 7+ days
   - Clipping detector: flat AC power at rated limit during peak hours
   - Nighttime vampire drain detector: high nighttime consumption
3. Include confidence score with each anomaly
```

---

#### [MEDIUM] A4.2 — No Seasonal Baseline Adjustment
**Gap:** Thailand's solar production varies significantly:
- Rainy season (May-Oct): ~30-40% less production
- Cool season (Nov-Feb): highest production
- Hot season (Mar-Apr): high irradiance but temperature derating

Current design has no seasonal adjustment for thresholds.

**Proposed Solution:**
```
1. Implement seasonal PR baselines using historical data
2. Use climate data (TMD - Thai Meteorological Department) for weather normalization
3. Add weather-adjusted PR: compare against clear-sky model (e.g., PVLib)
4. Season-specific threshold: different PR target for rainy vs. dry season
```

---

### A5. Reporting

#### [CRITICAL] A5.1 — Reporting Scope Too Limited (Daily Only)
**Gap:** Only "daily report" is specified. O&M operations need:
- **Weekly reports:** trend identification, maintenance scheduling
- **Monthly reports:** warranty claims, performance guarantees
- **Yearly reports:** degradation analysis, financial reporting
- **Ad-hoc reports:** for customer inquiries, audit requests
- **Comparative reports:** period-over-period, site-to-site

**Justification:** Monthly/yearly reports are standard requirements for solar asset management. Customers and financiers expect them. Without these, the system cannot support full O&M operations.

**Proposed Solution:**
```
1. Extend reporting to: daily, weekly, monthly, quarterly, yearly
2. Add trend analysis: rolling averages, regression lines
3. Include degradation rate calculation (%/year)
4. Add comparative mode: site vs. site, period vs. period
5. Support scheduled report generation (cron-based)
6. Export formats: Markdown (default), PDF, Excel
```

---

#### [HIGH] A5.2 — Bilingual Report Generation Needs Template System
**Gap:** "Thai internal, English customer" reports need:
- Bilingual template system
- Different content depth (internal = technical detail, customer = summary)
- Currency formatting (THB for internal, may need USD for international customers)
- Thai solar-specific terminology (e.g., "กำลังผลิตรายวัน", "อัตราส่วนประสิทธิภาพ")

**Proposed Solution:**
```
1. Implement Jinja2 template system with language switching
2. Create 2 template sets: internal_technical (TH), customer_summary (EN)
3. Add glossary mapping for technical terms Thai <-> English
4. Support unit conversion (kWh -> MWh for large plants in customer reports)
```

---

#### [LOW] A5.3 — No Report Distribution Mechanism
**Gap:** Reports are generated but no mechanism to deliver them:
- Email delivery?
- Upload to cloud storage (Google Drive, SharePoint)?
- Integration with customer portal?
- LINE delivery for Thai market?

**Proposed Solution:**
```
1. Add report_delivery tool with adapters: email (SMTP), LINE (Messaging API),
   cloud storage (S3/Google Drive)
2. Support scheduled delivery (e.g., monthly report auto-send on 5th of month)
3. Add delivery confirmation tracking
```

---

### A6. Missing Data & Edge Cases

#### [HIGH] A6.1 — No Data Quality Scoring
**Gap:** When inverter is offline or data is missing:
- How is PR calculated? (Exclude missing periods? Interpolate? Mark as unavailable?)
- Is partial-day data acceptable for daily reports?
- How to handle daylight saving transitions? (Thailand doesn't use DST, but system might be used in other countries)

**Proposed Solution:**
```
1. Data quality scoring per day: % complete, % valid, % interpolated
2. PR calculation rule: only calculate if >= 80% data completeness
3. Mark "Data Insufficient" in reports when quality < 80%
4. Track data availability as separate KPI
5. Handle DST gracefully (Thailand: no DST, but system should support it)
```

---

## Domain B: Health Food Franchise — Gap Analysis

### B1. POS Integration

#### [CRITICAL] B1.1 — POS System Identity & Integration Method Undefined
**Gap:** "POS transaction logs" without specifying:
- Which POS system: Thai POS (e.g., FoodStory, Lineman POS, Wongnai POS), international (Toast, Square, Clover), or custom-built?
- Integration method: API, database direct connection, file export/import, webhook?
- Real-time streaming vs. batch processing
- Data format: each POS system exports different schemas

**Justification:** FoodStory (popular in Thailand) has a specific API. Lineman POS has different endpoints. If the system must parse log files, the file format (CSV, JSON, XML) and schema must be known. Without this, integration is impossible.

**Proposed Solution:**
```
1. Support pluggable POS connectors: FoodStory, Lineman POS, custom CSV
2. Implement API-based real-time sync where available
3. Add file-based import (CSV/JSON) for POS systems without APIs
4. Define canonical transaction schema:
   { transaction_id, timestamp, branch_id, item_sku, item_name, quantity, 
     unit_price, total_amount, discount, payment_method, staff_id }
```

---

#### [HIGH] B1.2 — No Transaction Data Schema or Validation
**Gap:** POS data schema is undefined. Critical for food business:
- SKU/item code system (how are menu items identified?)
- Modifier handling (e.g., "salad with extra chicken, no dressing")
- Combo/Set meal decomposition (how is a set meal split into components?)
- Void/refund transaction handling (exclude from sales? flag separately?)
- Payment method breakdown (cash vs. QR code vs. credit card)

**Justification:** Inventory deduction depends on accurate item-level decomposition. A "Healthy Set A" might include 1 salad + 1 smoothie. If the system can't decompose the set, it can't accurately track inventory.

**Proposed Solution:**
```
1. Define recipe/bom (Bill of Materials) for each menu item
2. Implement combo decomposition engine
3. Add modifier impact tracking (extra chicken = +1 chicken portion)
4. Handle voids: separate table for voided transactions with reason code
5. Track payment mix for business intelligence
```

---

### B2. Inventory Logic

#### [CRITICAL] B2.1 — Inventory Model Lacks Critical Business Logic
**Gap:** "check_inventory" is too simplistic. Missing:
- **Par level calculation:** How is the target stock level determined? (Based on sales velocity? Fixed?)
- **Lead time per supplier:** Fresh produce (1 day) vs. imported supplements (2-4 weeks)
- **Shelf life / expiry tracking:** Critical for health food (fresh ingredients)
- **FIFO tracking:** First-in-first-out for perishable goods
- **Unit of measure conversions:** Order by kg, use by gram; order by case, use by piece
- **Safety stock:** Buffer for demand variability
- **ABC classification:** High-value items (imported protein) vs. low-value (disposable cups)

**Justification:** Fresh vegetables might have 2-day shelf life and need daily ordering. Imported whey protein might have 2-week lead time. A single "check_inventory" without these parameters will generate wrong reorder alerts.

**Proposed Solution:**
```
1. Implement full inventory model:
   - Item: { sku, name, category, uom_purchase, uom_usage, conversion_rate,
            shelf_life_days, supplier_id, lead_time_days, safety_stock_days,
            par_level_method: fixed|velocity_based }
   - StockRecord: { sku, branch_id, qty_on_hand, qty_reserved, expiry_date,
                   last_movement_date }
2. Par level = average_daily_usage * (lead_time_days + safety_stock_days)
3. Auto-adjust par level based on rolling 14-day sales velocity
4. Add expiry alert: flag items expiring within 48 hours
5. Implement FIFO consumption tracking
```

---

#### [HIGH] B2.2 — Recipe/Menu-to-Inventory Linkage Missing
**Gap:** No connection between menu items and inventory items:
- What ingredients does each menu item consume?
- Portion sizes (1 salad = 150g mixed greens, 80g chicken, etc.)
- Yield rates (e.g., 1kg whole chicken = 650g usable meat after prep)
- Wastage tracking (trimming waste, spoilage, expired items)

**Justification:** The inventory system cannot predict consumption without knowing which menu items consume which ingredients. This linkage is fundamental.

**Proposed Solution:**
```
1. Implement recipe management system:
   Recipe: { menu_item_sku, ingredients: [{ inv_sku, qty, uom, wastage_factor }] }
2. Auto-deduct inventory per transaction based on recipe
3. Add wastage logging (prep waste, spoilage, customer return)
4. Calculate theoretical vs. actual consumption variance
5. Flag high variance items (indicates portion control issues or theft)
```

---

#### [MEDIUM] B2.3 — No Multi-Location / Central Kitchen Support
**Gap:** For franchise chains:
- Is there a central kitchen that preps and distributes to branches?
- Branch-level vs. central kitchen inventory tracking
- Transfer orders between branches
- Each branch may have different par levels based on foot traffic

**Proposed Solution:**
```
1. Support inventory location hierarchy: central_kitchen -> branch
2. Track transfer orders with delivery confirmation
3. Per-branch par level configuration
4. Centralized procurement suggestions aggregated across branches
```

---

### B3. LINE Notification System

#### [CRITICAL] B3.1 — LINE Notify API Deprecation Impact
**Gap:** LINE Notify service was **officially discontinued** as of March 31, 2025. The requirement states "LINE notify messages" but:
- LINE Notify API is no longer available for new integrations
- Must migrate to **LINE Messaging API** or **LINE Official Account**
- Requires different authentication (channel access token vs. notify token)
- Rate limits differ: Messaging API has tier-based limits

**Justification:** Using LINE Notify will result in complete system failure. This is the most time-sensitive gap.

**Proposed Solution:**
```
1. Migrate from LINE Notify to LINE Messaging API immediately
2. Set up LINE Official Account for the business
3. Implement message queue with rate limiting (1000 msgs/min for free tier)
4. Add fallback notification channel (email, SMS via ThaiBulkSMS)
5. Support rich message formats (flex messages with buttons for approval)
```

---

#### [HIGH] B3.2 — Notification Recipient Management Missing
**Gap:**
- Who receives which notifications? (Branch manager gets low stock, owner gets daily summary)
- LINE group vs. individual messaging
- Subscription preferences (opt-in/opt-out per notification type)
- Time-based routing (don't alert at 3 AM unless emergency)

**Proposed Solution:**
```
1. Implement notification routing rules:
   { notification_type, recipient_role, delivery_method, quiet_hours }
2. Support LINE groups per branch
3. Add subscription management per user
4. Quiet hours: 22:00-07:00 unless CRITICAL priority
```

---

### B4. Multi-Branch Operations

#### [CRITICAL] B4.1 — Multi-Branch Architecture Not Defined
**Gap:** No clarity on:
- Single branch or multi-branch?
- Data isolation between branches (manager of Branch A shouldn't see Branch B data)
- Cross-branch aggregation for franchise owner view
- Branch identification in all data models

**Justification:** Even a "small" franchise typically has 3-5 branches within the first year. Designing for single-branch and retrofitting multi-branch later is expensive.

**Proposed Solution:**
```
1. Add branch_id to ALL data models from day one
2. Implement row-level security based on user-branch mapping
3. Support 3 view levels: branch_manager (own branch only),
   area_manager (assigned branches), owner (all branches)
4. Cross-branch comparison dashboard
```

---

#### [HIGH] B4.2 — No Franchise-Specific Business Intelligence
**Gap:** Franchise operations need:
- Same-store sales comparison (month-over-month)
- Branch ranking by revenue, profit margin, waste %
- Customer count and average ticket size trends
- Peak hour analysis for staffing optimization
- Menu item profitability analysis (which items make the most money?)

**Proposed Solution:**
```
1. Add franchise BI tools:
   - daily_sales_summary: extend with same-store comparison
   - menu_profitability: revenue - ingredient_cost per item
   - peak_hour_analysis: sales distribution by hour
   - branch_ranking: multi-dimensional scoring
2. Export capability for accountant/bookkeeper
```

---

#### [MEDIUM] B4.3 — No Staff/Shift Management Integration
**Gap:** Labor is a major cost for food franchises:
- No connection between sales data and staffing levels
- No labor cost tracking per shift
- No sales-per-labor-hour (SPLH) metric

**Proposed Solution:**
```
1. Add optional staff management module:
   - Shift schedule integration
   - Labor cost per hour tracking
   - SPLH calculation: revenue / labor_hours
   - Overtime alert
```

---

### B5. Supplier Integration

#### [MEDIUM] B5.1 — Reorder Workflow Ends at Alert (No Supplier Integration)
**Gap:** "reorder alerts" are generated but:
- Where does the alert go? (Email? LINE? Internal dashboard?)
- Is there a purchase order generation step?
- Does it connect to supplier systems? (Most Thai suppliers don't have APIs)
- Is there approval workflow? (Branch manager suggests, owner approves)

**Proposed Solution:**
```
1. Implement multi-step reorder workflow:
   ALERT -> PO DRAFT -> APPROVAL -> SUBMIT -> CONFIRMATION
2. PO generation with supplier details, item list, quantities
3. LINE approval workflow: owner receives flex message with PO summary,
   taps "Approve" or "Edit" button
4. Supplier integration adapters: email PO, LINE to supplier, or manual export
5. Track PO status: pending -> sent -> confirmed -> delivered -> invoiced
```

---

## Domain C: RAG Retriever — Gap Analysis

### C1. Document Type Support

#### [MEDIUM] C1.1 — Document Type Coverage Needs Clarification
**Gap:** "code repos, solar SOPs, health manuals" implies need for:
- **Code files:** .py, .js, .ts, etc. — requires special handling (AST parsing for better chunks)
- **PDFs:** Text-based PDFs vs. scanned/image PDFs (need OCR)
- **Word/Excel:** .docx, .xlsx parsing
- **Images:** Diagrams in SOPs (flowcharts, wiring diagrams)
- **Structured data:** Tables in manuals (cleaning schedules, parameter tables)

**Proposed Solution:**
```
1. Implement document parser pipeline with format-specific handlers:
   - Code: tree-sitter based parsing for structure-aware chunking
   - PDF: PyMuPDF for text, Tesseract/OCRmyPDF for scanned
   - Word: python-docx
   - Excel: pandas-based with table extraction
   - Images: OCR (Tesseract or cloud vision) + image captioning
2. Add document type detection (auto-detect from content, not just extension)
```

---

### C2. Chunking Strategy

#### [HIGH] C2.1 — Chunking Strategy Not Defined
**Gap:** "index_documents" with no chunking strategy specified. This is critical for RAG quality:
- Fixed-size chunking loses context (splits a procedure across chunks)
- No mention of overlap between chunks
- No mention of semantic chunking or structure-aware chunking
- Code requires different chunking (function-level, class-level)

**Justification:** Poor chunking is the #1 cause of bad RAG retrieval. A solar SOP that says "Step 1: Isolate inverter. Step 2: Wait 5 minutes. Step 3: Check DC voltage" split across chunks will be unretrievable.

**Proposed Solution:**
```
1. Implement multiple chunking strategies per document type:
   - Text docs: semantic chunking (LangChain SemanticChunker or similar)
   - SOPs/Procedures: structure-aware (by section/step)
   - Code: AST-based (function-level, class-level)
   - Tables: keep rows together, don't split mid-row
2. Configurable chunk size and overlap
3. Parent document retrieval: retrieve chunks but return parent context
4. Add chunking quality evaluation metric
```

---

#### [MEDIUM] C2.2 — No Document Metadata Extraction
**Gap:** Documents should be tagged with:
- Source (which repo, which manual version)
- Document type (SOP, troubleshooting, API reference)
- Domain (solar vs. health)
- Last updated date
- Author/creator

**Proposed Solution:**
```
1. Extract and store metadata with each document
2. Support metadata-based filtering in queries:
   query_knowledge(q="PR calculation", domain="solar", doc_type="SOP")
3. Version tracking for documents that update
4. Source attribution in responses (cite which document the answer came from)
```

---

### C3. Update Frequency & Indexing

#### [CRITICAL] C3.1 — No Incremental / Delta Indexing Strategy
**Gap:** When documents change:
- Does the system re-index everything? (inefficient for large repos)
- How to detect changes? (git hooks? polling? webhook?)
- How to handle deleted content?
- How to handle document versioning (SOP v1 vs. v2)?

**Justification:** For code repos with frequent commits, full re-indexing is impractical. A solar SOP update should not require re-indexing health food manuals.

**Proposed Solution:**
```
1. Implement delta indexing: track document checksums, only index changed docs
2. Git integration: use git diff to detect code changes
3. Add index versioning: maintain history of document versions
4. Soft delete: mark removed content, don't immediately purge
5. Schedule incremental indexing every 15 minutes for active repos
```

---

#### [HIGH] C3.2 — No Re-indexing Trigger Mechanism
**Gap:** No defined triggers for when to re-index:
- Manual trigger only?
- Scheduled (cron)?
- Event-driven (git push, file upload)?
- How to handle bulk updates?

**Proposed Solution:**
```
1. Support multiple triggers:
   - Git webhook for code repos
   - Scheduled polling for external documents (every 6 hours)
   - Manual trigger API
   - File watcher for local directories
2. Add indexing job queue with progress tracking
3. Indexing status dashboard
```

---

### C4. Multi-Language Support

#### [HIGH] C4.1 — Thai + English Mixed Content Handling
**Gap:**
- Solar SOPs are likely in Thai (internal) + English (equipment manuals)
- Health food manuals likely in Thai
- Code documentation in English
- Embedding models handle Thai differently — which model handles mixed content best?

**Justification:** Sentence boundaries in Thai are different from English (no spaces between words). A naive splitter will break Thai text mid-sentence. Embedding models trained primarily on English may underperform on Thai.

**Proposed Solution:**
```
1. Use Thai-aware embedding model:
   - Option A: sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2
   - Option B: WangChanBERTa-based embeddings (better for Thai)
   - Option C: Ollama with nomic-embed-text or similar multilingual model
2. Implement language detection per document (langdetect)
3. Use language-appropriate text splitters:
   - Thai: pythainlp-based segmentation before splitting
   - English: standard sentence/paragraph split
4. Test retrieval quality on Thai queries specifically
```

---

#### [LOW] C4.2 — No Query Language Detection
**Gap:** When user queries in Thai ("PR ต่ำเกินไป ทำยังไง"), the system should:
- Detect query language
- Route to appropriate embedding/retrieval pipeline
- Return results in the same language as the query

**Proposed Solution:**
```
1. Auto-detect query language
2. Prioritize documents in the same language as query
3. Return bilingual responses if relevant documents exist in both languages
```

---

## Cross-Domain Concerns

### CD1. Authentication & Authorization
**Gap:** No mention of:
- User authentication (who can access which domain?)
- Role-based access control (solar engineer vs. franchise manager vs. system admin)
- API key management for external integrations

**Priority: HIGH** — Multi-tenant system needs clear access control.

**Proposed Solution:**
```
Implement RBAC with roles: solar_engineer, franchise_manager, franchise_staff,
system_admin. Domain isolation: solar data and health data should be 
completely separate unless explicitly cross-domain queries are needed.
```

### CD2. Data Retention & Compliance
**Gap:** No mention of:
- How long to retain POS transaction data (Thai Revenue Department requires 5 years)
- Solar monitoring data retention (typically 10+ years for asset management)
- Personal data handling (PDPA compliance for Thailand)
- Data backup strategy

**Priority: HIGH** — Legal/compliance requirement.

**Proposed Solution:**
```
1. POS data: retain 7 years (Thai tax requirement + buffer)
2. Solar data: retain 15 years (asset lifetime + warranty)
3. Implement PDPA compliance: consent management, data deletion capability
4. Automated backup with point-in-time recovery
```

### CD3. Monitoring & Observability
**Gap:** The system monitors solar plants and franchises, but who monitors the system?
- Agent health monitoring
- Pipeline failure alerts
- API rate limit tracking (LINE, external APIs)
- Cost tracking (embedding API costs, storage costs)

**Priority: MEDIUM** — Operational necessity for production.

**Proposed Solution:**
```
Add system health dashboard: agent status, pipeline throughput, API quota usage,
error rates, cost per day. Integrate with alerting for system failures.
```

---

## Recommended Implementation Priority

### Phase 1 (Immediate — Week 1-2)
| ID | Item | Domain | Why |
|----|------|--------|-----|
| B3.1 | Migrate LINE Notify → Messaging API | Health | LINE Notify is dead — system will fail |
| A1.1 | Define inverter API architecture | Solar | Blocks all solar development |
| A2.1 | Clarify IRR definition | Solar | Blocks calculation module design |
| B1.1 | Define POS system & integration | Health | Blocks all POS development |

### Phase 2 (Critical — Week 3-4)
| ID | Item | Domain | Why |
|----|------|--------|-----|
| A5.1 | Extend reporting scope | Solar | Core O&M requirement |
| B2.1 | Full inventory model | Health | Core franchise requirement |
| B4.1 | Multi-branch architecture | Health | Must design from day one |
| C3.1 | Incremental indexing | RAG | Performance critical |
| A2.2 | IEC 61724 PR compliance | Solar | Industry standard |

### Phase 3 (Important — Week 5-8)
| ID | Item | Domain | Why |
|----|------|--------|-----|
| A4.1 | Anomaly detection methodology | Solar | Differentiates the product |
| A3.1 | Site-adaptive thresholds | Solar | Reduces false alarms |
| B2.2 | Recipe-inventory linkage | Health | Core for inventory accuracy |
| C2.1 | Chunking strategy | RAG | RAG quality depends on this |
| C4.1 | Thai+English handling | RAG | Market requirement |

### Phase 4 (Enhancement — Week 9-12)
| ID | Item | Domain | Why |
|----|------|--------|-----|
| A5.2 | Bilingual templates | Solar | Customer-facing feature |
| B5.1 | Supplier reorder workflow | Health | Complete the loop |
| A4.2 | Seasonal baseline | Solar | Accuracy improvement |
| CD2 | Data retention compliance | All | Legal requirement |

---

## Appendix A: Solar O&M Domain — Reference Standards

| Standard | Description | Relevance |
|----------|-------------|-----------|
| IEC 61724-1 | Photovoltaic system performance monitoring — Guidelines | PR calculation methodology |
| IEC 61215 | Crystalline silicon terrestrial PV modules | Module temperature coefficients |
| IEC 61683 | PV systems — Power conditioners — Procedure for measuring efficiency | Inverter efficiency measurement |
| ASTM E2848 | Standard test method for reporting photovoltaic non-concentrator system performance | US equivalent for PR |

## Appendix B: Thai Regulatory Context

| Regulation | Requirement | Impact |
|------------|-------------|--------|
| PDPA (Personal Data Protection Act) | Consent required for personal data collection | Customer data in POS system |
| Revenue Department | 5-year record retention for tax purposes | POS transaction storage |
| ERC (Energy Regulatory Commission) | Reporting requirements for solar farms | Solar reporting module |
| FDA Thailand | Food safety record keeping | Health food ingredient tracking |

## Appendix C: Technology Stack Recommendations

Based on gap analysis, recommended stack:

| Component | Recommendation | Rationale |
|-----------|----------------|-----------|
| Inverter API Client | Custom async connectors | Each brand has unique API |
| Time Series DB | TimescaleDB or InfluxDB | Efficient solar data storage |
| Vector Store | Qdrant (HTTP) | Better Thai support, flexible |
| Embedding Model | multilingual-e5-large or WangChanBERTa | Thai+English performance |
| Job Scheduler | APScheduler or Celery | Background indexing, reports |
| LINE Integration | LINE Messaging API | LINE Notify deprecated |
| OCR | Tesseract + Thai language pack | Thai document support |
| PDF Parsing | PyMuPDF | Handles complex layouts |

---

*End of Report*
