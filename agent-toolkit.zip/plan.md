# agent-toolkit Architecture & Planning Sprint — Execution Plan

## Objective
Produce complete, production-ready architecture & planning documentation for `agent-toolkit` — a self-hosted MCP Server Hub designed to provide specialized tools to Kimi CLI, OpenCode CLI, and Goose CLI via the Model Context Protocol.

## Deliverables (7 documents)
1. `ARCHITECTURE.md` — System architecture, module structure, data flow
2. `DOMAIN_REQUIREMENTS.md` — Business domain tool specs (Solar, Health, RAG)
3. `SAFETY_PROTOCOL.md` — Safety governance, dry-run, confirmation gates
4. `INTEGRATION_GUIDE.md` — External tool wiring + mcp.json templates
5. `ROADMAP.md` — 4-week phased execution plan
6. `AGENT_COGNITION_LAYER.md` — Self-improvement & meta-cognition layer (additional)
7. `MASTER_PLAN.md` — Consolidated final plan post-review

## Stage 1: Parallel Document Creation (Agents 1-5 + Agent 7)
Load `report-writing` skill. Deploy 6 parallel agents:
- **System_Architect** → ARCHITECTURE.md
- **Domain_Specialist** → DOMAIN_REQUIREMENTS.md
- **Safety_Governance_Officer** → SAFETY_PROTOCOL.md
- **Integration_Engineer** → INTEGRATION_GUIDE.md
- **Project_Planner** → ROADMAP.md
- **Cognition_Architect** → AGENT_COGNITION_LAYER.md (ผู้ใช้ขอให้คิดเพิ่มว่า agent จะพัฒนาตัวเองได้ยังไง)

All agents work in parallel with full project context.

## Stage 2: Review & Consolidation (Agent 6)
Load `report-writing` skill. Deploy **Master_Reviewer** to:
- Read all 6 deliverables
- Produce REVIEW_REPORT.md with fixes
- Produce final MASTER_PLAN.md consolidating everything

## Key Context to Propagate
- **Dev machine:** lean@192.168.1.135 (ssh/mosh, tmux)
- **Agent machine:** ecolife-2 (Ollama 24/7, 32GB RAM)
- **MCP CLIs served:** Kimi CLI, OpenCode CLI, Goose CLI
- **Business domains:** Solar O&M, Health Franchise Bangkok
- **Philosophy:** "Slow but safe" — dry-run, confirm, git safety net
- **Constraint:** 32GB RAM on agent machine (memory-aware)
