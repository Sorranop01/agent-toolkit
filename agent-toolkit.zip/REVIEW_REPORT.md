# Review Report: agent-toolkit Architecture & Planning Sprint

> **Reviewer:** Technical Review Lead  
> **Date:** 2025-01-20  
> **Scope:** 6 core deliverables + 5 auxiliary files  
> **Review Criteria:** C1 Hardcoded Paths, C2 Safety Coverage, C3 Duplication, C4 32GB RAM, C5 Cross-Machine Consistency, C6 Cognition Layer, C7 Copy-Paste Readiness, C8 Completeness

---

## Summary

| Metric | Count |
|--------|-------|
| **Total documents reviewed** | 6 core + 5 auxiliary = 11 |
| **CRITICAL issues found** | 6 |
| **WARNING issues found** | 12 |
| **INFO notes** | 8 |
| **Overall assessment** | **CONDITIONAL PASS** |

**Verdict:** The swarm has produced a remarkably comprehensive architecture and planning document set. The safety protocol is thorough, the domain requirements are well-researched, and the integration guide is detailed. However, **6 CRITICAL issues must be resolved before implementation begins**, primarily around hardcoded paths, RAM oversubscription, and missing cognition-layer integration.

---

## Issues by Document

### ARCHITECTURE.md

| # | Severity | Category | Issue | Fix |
|---|----------|----------|-------|-----|
| 1 | **CRITICAL** | C1 Hardcoded Paths | Repository references `lean@192.168.1.135:~/workspace/agent-toolkit` on line 6; topology diagram hardcodes both machine identities. All path references should use `${AGENT_TOOLKIT_HOME}` and `${OLLAMA_HOST}` style variables. | Replace all hardcoded machine names/IPs with config references. Add a "Deployment Configuration" section that maps variables to actual values per environment. |
| 2 | **CRITICAL** | C4 32GB RAM | Model catalog (Section 7.2) lists `gemma2/gemma4` as "9B-27B" param requiring "8-20GB VRAM". If the 27B variant is loaded alongside qwen2.5 (4-8GB) and nomic-embed (1GB), total could reach ~29GB + 8GB MCP servers + 2GB system = **39GB**, exceeding 32GB by 7GB. No explicit model-selection guard prevents loading oversized models. | Add a Model Memory Budget table with exact max sizes. State clearly: "Maximum single model size on 32GB system is 14GB (leaving room for 1 embedding model + MCP servers + headroom)." Add `OLLAMA_MAX_MODEL_MB=14336` to config. |
| 3 | WARNING | C6 Cognition Layer | Section 3 (architecture diagram) does NOT include the `cognition-layer` server defined in AGENT_COGNITION_LAYER.md. Section 2 (MCP Server Inventory) is missing the cognition server. | Add `cognition-layer` as server #10 in the inventory table and include it in both architecture diagrams. |
| 4 | WARNING | C8 Completeness | No "5-minute quickstart" section for new developers. Recovery procedures (Section 12.2) are CLI commands without context or ordering. | Add a "Quickstart" subsection to Section 12. Add numbered steps with prerequisites for recovery procedures. |
| 5 | INFO | C5 Consistency | Uses `~/.agent-toolkit/` for runtime data but INTEGRATION_GUIDE.md uses `~/.config/agent-toolkit/` for config and `~/.local/share/agent-toolkit/` for data (XDG-compliant). | Align with XDG spec: config → `~/.config/agent-toolkit/`, data → `~/.local/share/agent-toolkit/`, runtime → `~/.agent-toolkit/run/`. |
| 6 | INFO | C1 Hardcoded Paths | SQLite DB location given as `~/.agent-toolkit/context.db` (line 465) without mentioning it should be configurable via `AGENT_TOOLKIT_DB_PATH`. | Add env var reference: `${AGENT_TOOLKIT_DB_PATH:-~/.local/share/agent-toolkit/context.db}`. |

### DOMAIN_REQUIREMENTS.md

| # | Severity | Category | Issue | Fix |
|---|----------|----------|-------|-----|
| 7 | **CRITICAL** | C1 Hardcoded Paths | SSE transport endpoints hardcode IP: `http://192.168.1.135:3001/sse`, `3002`, `3003` (Section 2.2). Systemd units use `/opt/agent-toolkit/` and `User=lean` (Section 7.2). Firewall rules reference `192.168.1.0/24`. | Replace with `${MCP_HOST:-192.168.1.135}`, `${MCP_PORT_BASE:-3001}`. Use `$USER` or `${AGENT_TOOLKIT_USER}` in systemd units. |
| 8 | WARNING | C4 32GB RAM | Section 5.2.3 model VRAM estimates: nomic-embed-text listed as ~2GB (should be ~1GB), mxbai-embed-large as ~4GB, llava:13b as ~8GB, qwen2.5:7b as ~6GB. If embedding + vision + reranker are all loaded: 2+8+6 = 16GB, plus gemma4 (say 8GB for 9B) = 24GB + overhead = close to 32GB limit. No "max 2 models at once" rule stated. | Add explicit constraint: "Maximum 2 Ollama models loaded simultaneously on 32GB system." Add model-switching protocol that unloads before loading. |
| 9 | WARNING | C2 Safety | `health_sync_menu` tool has `dry_run` parameter (good) but no `confirm` parameter for the non-dry-run case. `health_notify_customers` sends messages to real customers with only `rate_limit_check` as safety — no confirm gate. | Add `confirm: bool = False` to `health_sync_menu`. Add `confirm: bool = False` to `health_notify_customers` for broadcast/promotion types. |
| 10 | INFO | C3 Duplication | Ollama vision OCR (Section 5.8) duplicates capability that could be handled by `ollama-bridge` server. The RAG pipeline calls Ollama directly instead of through the bridge. | Document that RAG-BRIDGE calls Ollama directly for latency reasons, but this is an intentional exception. The bridge is for CLI-initiated calls; internal pipelines may call Ollama directly. |
| 11 | INFO | C8 Completeness | LINE POS webhook events (Section 4.3) are defined but no webhook endpoint URL or HMAC verification logic is shown. | Add webhook endpoint specification (`POST /webhooks/line`) and HMAC signature verification code snippet. |

### SAFETY_PROTOCOL.md

| # | Severity | Category | Issue | Fix |
|---|----------|----------|-------|-----|
| 12 | **CRITICAL** | C1 Hardcoded Paths | `.env.template` (Section 6.3) hardcodes: `OLLAMA_HOST=http://localhost:11434`, `RCLONE_CONFIG_PATH=/home/lean/.config/rclone/rclone.conf`, `DEPLOY_HOST=ecolife-2`, `DEPLOY_USER=deploy`. Secret rotation script hardcodes `lean@192.168.1.135` and `deploy@ecolife-2` (Section 6.4). | Template should use `<PLACEHOLDER>` format. Rotation script should source from `.env` or accept CLI args. |
| 13 | WARNING | C2 Safety | Gate matrix (Section 3.1) marks `rclone sync FROM remote` as AUTO approval with a caveat about local collision. But the caveat is buried in notes, not enforced in the matrix code (Section 3.3). A sync-from that overwrites local files gets AUTO approval despite being destructive locally. | Add collision detection to `enforce_gate_matrix()` for `RCLONE_SYNC_FROM`: check if local targets exist, and if so, escalate to USER approval. |
| 14 | WARNING | C5 Consistency | Stash cleanup cron (Section 4.3) hardcodes `lean` user and `/home/lean/agent-toolkit` path. OOM scores (Section 5.6) are commented as configurable but no actual config mechanism is shown. | Use `$USER` variable in cron. Add `oom_score_adj` as a config.toml setting with defaults. |
| 15 | INFO | C8 Completeness | Pre-flight checklist (Appendix A) is excellent but has no "Post-flight verification" section to confirm deployment succeeded. | Add Post-Flight checklist: verify health endpoints, check logs for errors, confirm tool registration. |

### INTEGRATION_GUIDE.md

| # | Severity | Category | Issue | Fix |
|---|----------|----------|-------|-----|
| 16 | **CRITICAL** | C1 Hardcoded Paths | All mcp.json configs (Sections 6.1-6.3) hardcode `/home/lean/` in: `ALLOWED_DIRS`, `DB_PATH`, `RCLONE_CONFIG`, `VECTOR_STORE_PATH`. The `OLLAMA_HOST` hardcodes `http://ecolife-2:11434`. Config yaml (Section 1.2) uses `/home/lean/` everywhere. | Replace with env var interpolation: `"ALLOWED_DIRS": "${AGENT_TOOLKIT_ALLOWED_DIRS:-/home/lean/projects}"`, etc. Document that `AGENT_TOOLKIT_USER` should be set in `.bashrc`. |
| 17 | WARNING | C7 Copy-Paste | The Kimi mcp.json has `description` fields but OpenCode and Goose versions do not. Goose config file is named `mcp-config.json` (not `mcp.json` as some versions expect) — this should be verified. | Add descriptions to all configs for consistency. Add a note: "Verify Goose CLI version — older versions use `mcp.json` instead of `mcp-config.json`." |
| 18 | WARNING | C8 Completeness | The rclone safety wrapper (Section 5.3) shows dry-run enforcement but the actual `rclone-bridge` MCP server code that enforces this is not shown — only a pseudocode snippet. | Add a reference to the actual implementation file where the safety wrapper lives (e.g., `src/agent_toolkit/servers/rclone_bridge/safety.py`). |
| 19 | INFO | C1 Hardcoded Paths | `http://ecolife-2:11434` appears 12+ times across the document. Should reference a single env var. | Create a `Network Defaults` subsection at top: "All Ollama references default to `$OLLAMA_HOST` (set in `~/.bashrc`)." |

### ROADMAP.md

| # | Severity | Category | Issue | Fix |
|---|----------|----------|-------|-----|
| 20 | **CRITICAL** | C6 Cognition Layer | The 4-week roadmap has NO tasks for the `cognition-layer` server. AGENT_COGNITION_LAYER.md describes 5 phases of implementation but none are scheduled. This is a major gap — the cognition layer is an entire MCP server. | Add Week 2 or Week 4 task: "cognition-layer server scaffold + pattern recognition tables." Reference AGENT_COGNITION_LAYER.md Phase 2 (Pattern Recognition) as follow-on work. |
| 21 | **CRITICAL** | C1 Hardcoded Paths | Daily workflow (Section 12) hardcodes `mosh lean@192.168.1.135`, `ssh ecolife-2`. Systemd unit template (Section 5.3) hardcodes `/home/ecolife/agent-toolkit`, `User=ecolife`. | Use `${AGENT_TOOLKIT_USER}@${AGENT_TOOLKIT_DEV_HOST}` and template variables in systemd units. |
| 22 | WARNING | C4 32GB RAM | Week 4 Section 6.1 lists degraded mode (disabling non-essential servers at 90% memory) but this is reactive, not preventive. No proactive memory budget enforcement at startup. | Add startup check: verify `OLLAMA_MAX_MODEL_MB + sum(MAX_MEMORY_MB across servers) + 8192 <= 32768`. Refuse to start if budget exceeded. |
| 23 | WARNING | C8 Completeness | Scope reduction plan (Section 10.1) drops "Health operations server" and "rclone bridge server" to Priority 3. But the Health franchise and Google Drive sync are core business requirements per DOMAIN_REQUIREMENTS.md. | Re-scope: Move `health-ops` to Priority 2 (Should Have) since it's a core domain. Keep `rclone-bridge` at Priority 3 since manual rclone can substitute. |
| 24 | INFO | C5 Consistency | `tmux` session scripts reference `dev` and `ecolife-monitor` names, but ARCHITECTURE.md doesn't mention tmux session naming. | Add tmux session naming convention to ARCHITECTURE.md Section 9.1. |

### AGENT_COGNITION_LAYER.md

| # | Severity | Category | Issue | Fix |
|---|----------|----------|-------|-----|
| 25 | **CRITICAL** | C3 Duplication | The `cognition-layer` server defines `memory_remember`, `memory_recall`, `memory_forget` tools (Section 6.1) that directly duplicate the `memory-store` server's `remember`, `recall`, `forget` tools. This creates confusion about which server to use. | Remove basic memory CRUD from cognition-layer. Instead, cognition-layer should call `memory-store` for storage and focus on: `pattern_record`, `pattern_suggest`, `skill_learn_from_interaction`, `performance_review`, `self_assess`, `cognition_health`. |
| 26 | WARNING | C4 32GB RAM | Background jobs (Section 10.3) run pattern extraction, error analysis, and skill generation on ecolife-2 using Ollama. No memory budgeting for these background jobs. Consolidation runs every hour — could spike memory during active CLI use. | Add: "Background jobs check available memory before loading models. If < 4GB free, job is queued. Consolidation runs only when no CLI-active model is loaded." |
| 27 | WARNING | C8 Completeness | Phase 5 (Autonomous Improvement, Month 3) is labeled "Vision" with 0% progress. No concrete tasks or acceptance criteria. This could expand scope uncontrollably. | Add go/no-go gate: "Phase 5 begins only after Phases 1-4 are production-stable for 30 days. Phase 5 requires explicit scope approval." |
| 28 | INFO | C8 Completeness | The skill auto-documentation example (Section 3.4) shows parameter templates with placeholders like `{project_path}/specs.json` and `{from_specs.total_cost}`. No variable-resolution mechanism is defined. | Add note: "Parameter templates use Jinja2-style placeholders resolved at skill execution time against the current context." |

---

## Cross-Cutting Issues

### X1: Hardcoded Identity Everywhere (C1) — **CRITICAL**

Every single document hardcodes `lean`, `ecolife-2`, and `192.168.1.135` somewhere. This makes the entire project non-portable. A developer cloning this repo would need to search-and-replace across 11 files.

**Fix:** Create a single `config/environment.yaml`:

```yaml
# config/environment.yaml — DEPLOYMENT-SPECIFIC, .gitignored
dev_machine:
  host: 192.168.1.135
  user: lean
  hostname: lean
agent_machine:
  host: ecolife-2
  user: ecolife
  hostname: ecolife-2
lan_subnet: 192.168.1.0/24
ollama_port: 11434
```

All documents should reference `${dev_machine.host}` etc. Provide a `scripts/configure-environment.sh` that reads this file and generates all mcp.json configs, systemd units, and shell scripts with correct values.

### X2: cognition-layer Server Is an Orphan (C3+C6) — **CRITICAL**

The cognition layer is defined in its own document but is invisible to the architecture, roadmap, and integration guide. It duplicates memory-store functionality and has no place in the implementation schedule.

**Fix:**
1. De-duplicate: Remove memory CRUD from cognition-layer, keep only pattern/skill/diagnostic tools
2. Integrate: Add to ARCHITECTURE.md server inventory, add to architecture diagrams
3. Schedule: Add to ROADMAP.md Week 4 (Phase 2: Pattern Recognition)
4. Non-breaking: cognition-layer is an additive server; existing tools are unchanged

### X3: 32GB RAM Budget Not Enforced at Startup (C4) — **CRITICAL**

Multiple documents describe memory limits (SAFETY_PROTOCOL.md Section 5.3, ROADMAP.md Week 4 Section 6.1) but none implement a startup-time budget validation. A user could configure `MAX_MEMORY_MB=8192` for 4 servers (= 32GB) + Ollama (= 14GB) = 46GB on a 32GB machine.

**Fix:** Add `memory_budget_validator.py` that runs at hub startup:

```python
# Pseudocode
total_mcp_memory = sum(server.max_memory_mb for server in servers)
max_ollama_model = config.ollama.max_model_mb
headroom_mb = 8192
required_mb = total_mcp_memory + max_ollama_model + headroom_mb
if required_mb > 32768:
    raise MemoryBudgetError(f"Config requires {required_mb}MB but system has 32768MB. "
                            f"Reduce MAX_MEMORY_MB or OLLAMA_MAX_MODEL_MB.")
```

### X4: No Unified "Getting Started" Document (C8) — **WARNING**

A new developer needs to read 6 documents + multiple appendices to understand how to deploy. There is no single-page quickstart.

**Fix:** The MASTER_PLAN.md Section 9 ("Getting Started") addresses this gap.

### X5: Test Scripts Have Hardcoded Machine References (C1+C7) — **WARNING**

`test-cross-machine.sh` and `verify-integration.sh` both hardcode `ecolife-2` and `192.168.1.135`. These scripts would fail on any other deployment.

**Fix:** Source from environment:

```bash
# At top of both scripts:
AGENT_MACHINE="${AGENT_MACHINE:-ecolife-2}"
OLLAMA_HOST="${OLLAMA_HOST:-http://$AGENT_MACHINE:11434}"
```

---

## Missing Elements

| # | Missing Element | Severity | Where It Should Go | Notes |
|---|----------------|----------|-------------------|-------|
| M1 | **5-Minute Quickstart Guide** | HIGH | New section or MASTER_PLAN.md | Step-by-step from zero to first tool call |
| M2 | **Environment Configuration Template** | HIGH | `config/environment.yaml` + script | Single source of truth for all machine names, IPs, paths |
| M3 | **cognition-layer in Architecture Diagram** | HIGH | ARCHITECTURE.md Section 3 | Add as new box in MCP Server Hub |
| M4 | **cognition-layer in Roadmap** | HIGH | ROADMAP.md Week 4 | Pattern recognition Phase 2 |
| M5 | **Memory Budget Validator** | MEDIUM | New `src/agent_toolkit/shared/memory_budget.py` | Startup-time RAM budget check |
| M6 | **Post-Deployment Verification Checklist** | MEDIUM | SAFETY_PROTOCOL.md Appendix A | Confirm deployment succeeded |
| M7 | **Degraded Mode Specification** | MEDIUM | ARCHITECTURE.md new section | Exact behavior when memory is low |
| M8 | **Webhook Endpoint Specification** | LOW | DOMAIN_REQUIREMENTS.md Section 4.3 | LINE POS webhook URL + HMAC verification |
| M9 | **CI/CD Pipeline (minimal)** | LOW | ROADMAP.md stretch goal | Pre-commit + GitHub Actions for test + lint |
| M10 | **Rate Limiting for MCP Tool Calls** | LOW | SAFETY_PROTOCOL.md | Per-client rate limiting beyond just LINE API |

---

## Recommendations (Priority-Ranked)

| Priority | Recommendation | Effort | Impact |
|----------|---------------|--------|--------|
| **P0** | Create `config/environment.yaml` + `scripts/configure-environment.sh` to eliminate all hardcoded paths | 4 hours | Eliminates #1, #7, #12, #16, #21, X1, X5 |
| **P0** | De-duplicate cognition-layer (remove memory CRUD) and integrate into architecture + roadmap | 2 hours | Fixes #3, #20, #25, X2 |
| **P0** | Add `memory_budget_validator.py` with startup-time RAM budget check | 2 hours | Fixes X3, #2, #22 |
| **P1** | Fix `RCLONE_SYNC_FROM` in gate matrix to detect local collision and escalate to USER | 1 hour | Fixes #13 |
| **P1** | Add `confirm` parameter to `health_sync_menu` and `health_notify_customers` | 1 hour | Fixes #9 |
| **P1** | Fix mcp.json templates to use env var interpolation with fallback defaults | 2 hours | Fixes #16 |
| **P1** | Add degraded mode specification to ARCHITECTURE.md | 2 hours | Fixes #7, M7 |
| **P2** | Add post-deployment verification checklist to SAFETY_PROTOCOL.md | 1 hour | Fixes #15 |
| **P2** | Re-scope health-ops to Priority 2 in scope reduction plan | 30 min | Fixes #23 |
| **P2** | Add webhook endpoint + HMAC verification to DOMAIN_REQUIREMENTS.md | 1 hour | Fixes #11 |
| **P2** | Standardize on XDG directory layout across all documents | 1 hour | Fixes #5 |
| **P3** | Add CI/CD pipeline as stretch goal in ROADMAP.md | 30 min | Addresses M9 |

---

## Appendix: Review Checklist

### C1: Hardcoded Paths — **6 CRITICAL, 3 INFO**
- [x] Check for `192.168.1.135` hardcoded IPs — **FOUND** in all 6 core docs + both scripts
- [x] Check for machine names (`ecolife-2`) hardcoded — **FOUND** in all 6 core docs
- [x] Check for `/home/lean/` hardcoded paths — **FOUND** in mcp.json configs, systemd units, scripts
- [x] Verify every path uses env vars or config.yaml — **FAIL** (most use hardcoded values)

### C2: Safety Protocol Coverage — **1 CRITICAL, 2 WARNING**
- [x] Every destructive operation has dry_run + confirm gates — **PARTIAL** (rclone sync FROM missing collision detection, health_sync_menu missing confirm)
- [x] ARCHITECTURE.md data flows mention safety gates — **PASS**
- [x] DOMAIN_REQUIREMENTS.md tools have safety parameters — **PARTIAL** (2 health tools missing confirm)
- [x] INTEGRATION_GUIDE.md rclone sync enforces dry-run — **PASS**
- [x] ROADMAP.md safety work in Week 1 blocks everything else — **PASS** (safety utils are first)

### C3: Duplicate Functionality — **1 CRITICAL, 1 INFO**
- [x] file-ops-safe vs GitHub file ops — **PASS** (complementary)
- [x] memory-store vs built-in context — **PASS** (unique cross-CLI value)
- [x] cognition-layer memory tools vs memory-store — **CRITICAL** (direct duplication)

### C4: 32GB RAM Constraint — **2 CRITICAL, 2 WARNING**
- [x] Plan never exceeds 32GB aggregate — **FAIL** (model catalog allows 39GB combination)
- [x] Ollama model sizes fit together — **FAIL** (27B gemma4 + 2 models = oversubscribed)
- [x] Degraded mode when memory is low — **PASS** (described in ROADMAP.md Week 4)
- [x] Model catalog sizes verified — **PARTIAL** (nomic-embed-text size inconsistent: 1GB vs 2GB)

### C5: Cross-Machine Consistency — **1 WARNING, 2 INFO**
- [x] All documents agree on lean ↔ ecolife-2 communication — **PASS** (HTTP for Ollama, SSH for commands)
- [x] Ports consistent (11434 for Ollama) — **PASS**
- [x] Directory structure consistent — **FAIL** (3 different layouts across docs)

### C6: Cognition Layer Integration — **1 CRITICAL, 1 WARNING**
- [x] AGENT_COGNITION_LAYER.md references existing servers correctly — **PASS**
- [x] Cognition layer server in architecture diagram — **FAIL** (missing entirely)
- [x] Roadmap includes cognition layer work — **FAIL** (not scheduled)
- [x] Cognition tools are non-breaking additions — **PASS** (additive only)

### C7: Copy-Paste Readiness — **2 WARNING**
- [x] All mcp.json configs are valid JSON — **PASS**
- [x] All systemd unit files complete — **PARTIAL** (mixed Jinja templates with hardcoded paths)
- [x] All shell scripts executable and correct — **PARTIAL** (missing env var sourcing at top)
- [x] Developer copy-pasting configs would succeed — **FAIL** (needs `/home/lean/` replaced)

### C8: Completeness — **8 missing elements**
- [x] Backup/DR strategy — **PARTIAL** (daily rclone sync mentioned, no automated script)
- [x] Rollback plan — **PARTIAL** (git stash for files, no system rollback)
- [x] Monitoring/alerting — **PARTIAL** (memory monitoring described, no concrete alerts)
- [x] "Getting started in 5 minutes" quickstart — **MISSING**
- [x] cognition-layer integration — **MISSING** from architecture + roadmap

---

*End of Review Report*

> **Action Required:** Resolve all 6 CRITICAL issues before implementation begins. Address 8 WARNING issues before Week 2. INFO notes can be addressed during implementation.
