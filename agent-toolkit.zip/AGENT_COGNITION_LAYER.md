# AGENT_COGNITION_LAYER.md — Agent Self-Improvement & Meta-Cognition Architecture

**Version:** 1.0  
**Date:** 2025-01-20  
**Project:** agent-toolkit — Self-Hosted MCP Server Hub  
**Author:** Cognition Architect  
**Status:** Design Specification — Visionary but Implementable  

> **Mission:** Design the missing cognitive layer that transforms agent-toolkit from a static tool registry into a living, learning system — where agents reflect on their performance, remember what works, discover new patterns, and genuinely improve over time.

> **Thai Context:** เอกสารนี้ตอบคำถาม "โปรเจคนี้ยังขาดอะไรไปอีกบ้าง ที่จะทำให้ agent ทำงานได้มีประสิทธิภาพสูงที่สุด และ คิดเองได้ดีขึ้น ทำงานได้ดีขึ้น รวมถึงมีการเรียนรู้พัฒนาตัวเองได้ด้วย"

---

## Table of Contents

1. [Meta-Cognition Architecture](#1-meta-cognition-architecture)
2. [Memory Systems (Three-Tier)](#2-memory-systems-beyond-basic-mcp)
3. [Skill Evolution Mechanism](#3-skill-evolution-mechanism)
4. [Feedback Collection System](#4-feedback-collection-system)
5. [Learning Triggers](#5-learning-triggers)
6. [Self-Improvement MCP Tools](#6-self-improvement-mcp-tools)
7. [Project Health & Self-Diagnostics](#7-project-health--self-diagnostics)
8. [Knowledge Accumulation](#8-knowledge-accumulation)
9. [Implementation Roadmap](#9-implementation-roadmap)
10. [Technical Architecture](#10-technical-architecture)

---

## 1. Meta-Cognition Architecture

### 1.1 The Core Problem: Agents That Don't Learn

Today's MCP servers are **stateless execution engines**. When Kimi CLI calls `solar-calc.calculate_roi`, it gets a result — but nothing is learned. The next time a similar calculation is needed, the agent starts from zero. There is no accumulation of expertise, no reflection on what approaches worked best, no "muscle memory" for common workflows.

This is equivalent to a human employee who takes amnesia pills after every task.

### 1.2 The Solution: Reflective Cognitive Loop

The Meta-Cognition Architecture introduces a **continuous feedback cycle** where every tool execution becomes a learning opportunity:

```
┌─────────────────────────────────────────────────────────────────────────────────────┐
│                         META-COGNITION FEEDBACK LOOP                                 │
│                                                                                      │
│   ┌──────────────┐     ┌──────────────┐     ┌──────────────┐     ┌──────────────┐   │
│   │   OBSERVE    │────▶│   REFLECT    │────▶│   LEARN      │────▶│   ADAPT      │   │
│   │              │     │              │     │              │     │              │   │
│   │ Watch every  │     │ After task:  │     │ Extract      │     │ Apply new    │   │
│   │ tool call,   │     │ What worked? │     │ patterns,    │     │ knowledge to │   │
│   │ result,      │     │ What failed? │     │ store fixes, │     │ future tool  │   │
│   │ timing,      │     │ What would I │     │ update skill │     │ selections & │   │
│   │ error        │     │ do differently?│   │ rankings     │     │ parameters   │   │
│   └──────────────┘     └──────┬───────┘     └──────┬───────┘     └──────┬───────┘   │
│          ▲                    │                    │                    │          │
│          │                    │                    │                    │          │
│          └────────────────────┴────────────────────┴────────────────────┘          │
│                                                                                      │
│   TRIGGER CONDITIONS:                                                                │
│   • After every N tool calls      → Update short-term patterns                       │
│   • After task completion         → Reflection + quality assessment                  │
│   • After error                   → Error categorization + fix storage               │
│   • After human override          → Capture preferred approach                       │
│   • Periodic (every hour)         → Long-term pattern consolidation                  │
│                                                                                      │
└─────────────────────────────────────────────────────────────────────────────────────┘
```

### 1.3 The Four Cognitive Functions

#### 1.3.1 Reflection Loop

After each significant task (defined as: >3 tool calls, or a tool call that takes >30s, or any error), the agent enters **reflection mode**:

```python
class ReflectionEngine:
    """Post-task cognitive analysis"""

    def reflect(self, task_trace: TaskTrace) -> Reflection:
        """
        Analyze a completed task and produce structured reflection.
        Called automatically after task completion.
        """
        reflection = Reflection(
            task_id=task_trace.id,
            timestamp=datetime.now(),
            tool_count=len(task_trace.tool_calls),
            total_duration_ms=task_trace.duration_ms,

            # What was attempted?
            task_summary=self.summarize_goal(task_trace),

            # What worked?
            successful_steps=[
                step for step in task_trace.steps
                if step.status == 'success'
            ],

            # What failed?
            failures=[
                FailureAnalysis(
                    step=step,
                    error_category=self.categorize_error(step.error),
                    root_cause=self.infer_root_cause(step, task_trace),
                    fix_applied=step.retry_result
                )
                for step in task_trace.steps
                if step.status == 'error'
            ],

            # What would I do differently?
            counterfactual=self.generate_counterfactual(task_trace),

            # Efficiency assessment
            efficiency_score=self.calculate_efficiency(task_trace),

            # Quality self-assessment
            quality_score=self.assess_output_quality(task_trace)
        )

        return reflection
```

**Reflection outputs are stored in the `reflections` table** and become part of the agent's searchable experience.

#### 1.3.2 Pattern Recognition

The agent continuously scans recent tool usage for recurring sequences:

```
┌──────────────────────────────────────────────────────────────────────┐
│                    PATTERN RECOGNITION PIPELINE                       │
│                                                                      │
│  Input: Tool call sequences from the last N interactions             │
│                                                                      │
│  Step 1: Sequence Extraction                                         │
│    [file-ops-safe.safe_read → solar-calc.calculate_roi]              │
│    [file-ops-safe.safe_read → solar-calc.calculate_roi]              │
│    [file-ops-safe.safe_read → solar-calc.calculate_roi]  ← repeat!  │
│                                                                      │
│  Step 2: Abstraction                                                 │
│    "Read project file → Calculate solar ROI"                         │
│    Generalized: {read_data} → {domain_calculation}                   │
│                                                                      │
│  Step 3: Confidence Scoring                                          │
│    Frequency: 8 occurrences in 20 tasks (40%)                        │
│    Success rate: 100% (all succeeded)                                │
│    Avg duration: 2.3s                                                │
│    Confidence score: 0.95 → PROMOTE TO PATTERN                       │
│                                                                      │
│  Step 4: Pattern Storage                                             │
│    INSERT INTO patterns (name, sequence, confidence, ...)            │
│    Name: "solar_roi_analysis_workflow"                                │
│                                                                      │
└──────────────────────────────────────────────────────────────────────┘
```

Pattern recognition runs as a **background job on ecolife-2**, analyzing tool call sequences from the SQLite database. It uses Ollama (Gemma 4) for semantic pattern abstraction when simple frequency analysis isn't sufficient.

#### 1.3.3 Error Analysis & Muscle Memory

Every error is an opportunity. The Error Analysis Engine:

1. **Categorizes** the error (API failure, wrong parameters, missing data, timeout, etc.)
2. **Stores the fix** that resolved it
3. **Creates "muscle memory"** — a cached response for similar future errors
4. **Updates tool rankings** — if a tool fails often, suggest alternatives

```python
class ErrorAnalysisEngine:
    """Transform errors into institutional knowledge"""

    def analyze_error(self, tool_call: ToolCall) -> ErrorLesson:
        error_signature = self.extract_signature(tool_call.error_message)

        # Check if we've seen this error before
        similar_lessons = self.find_similar_errors(error_signature)

        if similar_lessons:
            # Build cumulative knowledge
            lesson = ErrorLesson(
                error_signature=error_signature,
                frequency=len(similar_lessons) + 1,
                tool_name=tool_call.tool_name,
                typical_causes=[l.cause for l in similar_lessons],
                proven_fixes=[l.fix for l in similar_lessons],
                best_fix=self.rank_fixes_by_success_rate(similar_lessons),
                preventive_params=self.extract_preventive_params(similar_lessons)
            )
        else:
            # New error type — create initial lesson
            lesson = ErrorLesson(
                error_signature=error_signature,
                frequency=1,
                tool_name=tool_call.tool_name,
                typical_causes=[self.infer_cause(tool_call)],
                proven_fixes=[],
                best_fix=None,
                preventive_params={}
            )

        return lesson
```

### 1.4 Meta-Cognition Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              META-COGNITION ARCHITECTURE                                 │
│                                                                                          │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │                         EXECUTION LAYER (Real-time)                              │    │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐          │    │
│  │  │ CLI sends│  │ Tool     │  │ Tool     │  │ Result   │  │ Next     │          │    │
│  │  │ request  │→ │ selected │→ │ executes │→ │ returned │→ │ action?  │          │    │
│  │  └────┬─────┘  └──────────┘  └──────────┘  └────┬─────┘  └────┬─────┘          │    │
│  │       │                                          │            │                  │    │
│  │       └──────────────────────────────────────────┴────────────┘                  │    │
│  │                                                  │                                │    │
│  │                                           ┌──────▼──────┐                         │    │
│  │                                           │  TRIGGER    │                         │    │
│  │                                           │  CHECK:     │                         │    │
│  │                                           │  Error? Done?│                        │    │
│  │                                           │  N calls?   │                         │    │
│  │                                           └──────┬──────┘                         │    │
│  └──────────────────────────────────────────────────┼────────────────────────────────┘    │
│                                                     │                                     │
│                                                     ▼                                     │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │                      REFLECTION LAYER (Post-task)                                │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │    │
│  │  │  Task Trace  │  │  Reflection  │  │  Pattern     │  │  Error       │         │    │
│  │  │  Capture     │→ │  Generation  │→ │  Detection   │→ │  Analysis    │         │    │
│  │  │              │  │  (Ollama)    │  │              │  │              │         │    │
│  │  └──────────────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘         │    │
│  │                           │                  │                  │                 │    │
│  │                           └──────────────────┼──────────────────┘                 │    │
│  │                                              │                                    │    │
│  │                                              ▼                                    │    │
│  │                                    ┌─────────────────┐                            │    │
│  │                                    │  LEARNED OUTPUT │                            │    │
│  │                                    │  • Reflection   │                            │    │
│  │                                    │  • Pattern      │                            │    │
│  │                                    │  • Error Lesson │                            │    │
│  │                                    └────────┬────────┘                            │    │
│  └─────────────────────────────────────────────┼─────────────────────────────────────┘    │
│                                                │                                          │
│                                                ▼                                          │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │                      MEMORY LAYER (Persistent Storage)                           │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐         │    │
│  │  │  Working     │  │  Short-term  │  │  Long-term   │  │  Skill       │         │    │
│  │  │  Memory      │  │  Memory      │  │  Memory      │  │  Registry    │         │    │
│  │  │  (context)   │  │  (patterns)  │  │  (patterns)  │  │  (abilities) │         │    │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘         │    │
│  └─────────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 2. Memory Systems (Beyond Basic MCP)

### 2.1 The Three-Tier Memory Model

Human cognition operates with multiple memory tiers — working memory (seconds), short-term memory (minutes to hours), and long-term memory (years). The agent cognition layer mirrors this architecture:

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                           THREE-TIER MEMORY ARCHITECTURE                                 │
│                                                                                          │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │  TIER 1: WORKING MEMORY                                                         │    │
│  │  ─────────────────────────────────────────────────────────────────────────────── │    │
│  │  Scope:     Current conversation turn                                           │    │
│  │  Lifetime:  Seconds to minutes                                                  │    │
│  │  Capacity:  ~10-20 tool calls of context                                        │    │
│  │  Storage:   LLM context window (provided by CLI client)                         │    │
│  │  Content:   Recent messages, active tool results, current goal                  │    │
│  │                                                                                  │    │
│  │  This is STANDARD MCP — the CLI provides conversation context.                  │    │
│  │  agent-toolkit DOES NOT manage this tier.                                        │    │
│  └─────────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                          │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │  TIER 2: SHORT-TERM MEMORY                                                      │    │
│  │  ─────────────────────────────────────────────────────────────────────────────── │    │
│  │  Scope:     Recent interactions (last N sessions)                               │    │
│  │  Lifetime:  Hours to days                                                       │    │
│  │  Capacity:  ~1,000 recent tool calls, ~100 patterns                             │    │
│  │  Storage:   SQLite — `recent_patterns`, `session_cache` tables                  │    │
│  │  Content:   Successful tool sequences, recent errors, active preferences        │    │
│  │                                                                                  │    │
│  │  Used for:  Contextual suggestions, recent error avoidance, hot patterns        │    │
│  └─────────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                          │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │  TIER 3: LONG-TERM MEMORY                                                       │    │
│  │  ─────────────────────────────────────────────────────────────────────────────── │    │
│  │  Scope:     All historical interactions                                         │    │
│  │  Lifetime:  Permanent (with versioning)                                         │    │
│  │  Capacity:  Unlimited (archived periodically)                                   │    │
│  │  Storage:   SQLite + Vector search (via Ollama embeddings)                      │    │
│  │  Content:   Learned patterns, domain knowledge, skills, error lessons           │    │
│  │             Project conventions, user preferences, workflow templates             │    │
│  │                                                                                  │    │
│  │  Used for:  Semantic recall, skill retrieval, deep pattern matching             │    │
│  └─────────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Short-Term Memory Implementation

Short-term memory captures recent tool usage patterns for fast retrieval:

```sql
-- Recent Patterns: Hot tool sequences for contextual suggestions
CREATE TABLE recent_patterns (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern_hash    TEXT NOT NULL UNIQUE,          -- SHA256 of normalized sequence
    tool_sequence   TEXT NOT NULL,                -- JSON array: ["tool_a", "tool_b", "tool_c"]
    normalized_sequence TEXT,                     -- Abstracted: ["read", "calc", "write"]
    frequency       INTEGER NOT NULL DEFAULT 1,   -- How many times seen recently
    last_triggered  DATETIME NOT NULL,            -- When last used
    avg_duration_ms INTEGER,                      -- Average execution time
    success_rate    REAL NOT NULL DEFAULT 1.0,    -- 0.0 to 1.0
    source_sessions TEXT,                         -- JSON array of session IDs
    is_active       BOOLEAN NOT NULL DEFAULT TRUE, -- False when promoted to long-term
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Automatically expire old short-term memories
    expires_at      DATETIME NOT NULL DEFAULT (datetime('now', '+7 days'))
);

CREATE INDEX idx_recent_patterns_hash ON recent_patterns(pattern_hash);
CREATE INDEX idx_recent_patterns_frequency ON recent_patterns(frequency);
CREATE INDEX idx_recent_patterns_expires ON recent_patterns(expires_at);

-- Session Cache: Fast lookup of recent context
CREATE TABLE session_cache (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER NOT NULL REFERENCES sessions(id),
    cache_key       TEXT NOT NULL,                -- 'recent_tools' | 'active_projects' | 'last_errors'
    cache_value     TEXT NOT NULL,                -- JSON data
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    expires_at      DATETIME NOT NULL DEFAULT (datetime('now', '+24 hours')),
    UNIQUE(session_id, cache_key)
);

CREATE INDEX idx_session_cache_expires ON session_cache(expires_at);
```

### 2.3 Long-Term Memory with Vector Search

Long-term memory stores learned knowledge with semantic embeddings for retrieval:

```sql
-- Learned Patterns: Mature, validated tool sequences
CREATE TABLE learned_patterns (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern_name    TEXT NOT NULL UNIQUE,         -- Human-readable: "solar_roi_analysis"
    description     TEXT NOT NULL,                -- What this pattern does
    tool_sequence   TEXT NOT NULL,                -- JSON array of exact tool names
    parameter_template TEXT,                      -- JSON: default parameters for each step
    trigger_keywords TEXT,                        -- JSON: keywords that suggest this pattern
    success_count   INTEGER NOT NULL DEFAULT 0,
    failure_count   INTEGER NOT NULL DEFAULT 0,
    success_rate    REAL NOT NULL DEFAULT 1.0,
    avg_duration_ms INTEGER,
    confidence_score REAL NOT NULL DEFAULT 0.5,   -- 0.0 to 1.0, increases with validation
    category        TEXT,                         -- 'domain_workflow' | 'utility' | 'creative'
    origin          TEXT NOT NULL DEFAULT 'auto',  -- 'auto' | 'human_created' | 'imported'
    is_deprecated   BOOLEAN NOT NULL DEFAULT FALSE,
    deprecated_by   INTEGER REFERENCES learned_patterns(id),

    -- Semantic search via embeddings (stored as BLOB, indexed via sqlite-vec)
    description_embedding BLOB,                   -- 768-dim vector from Ollama

    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_used_at    DATETIME
);

CREATE INDEX idx_learned_patterns_name ON learned_patterns(pattern_name);
CREATE INDEX idx_learned_patterns_category ON learned_patterns(category);
CREATE INDEX idx_learned_patterns_confidence ON learned_patterns(confidence_score);

-- Use sqlite-vec virtual table for vector similarity search:
-- CREATE VIRTUAL TABLE vec_patterns USING vec0(description_embedding float[768]);

-- Error Lessons: Institutional knowledge from failures
CREATE TABLE error_lessons (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    error_signature TEXT NOT NULL,                -- Normalized error fingerprint
    error_category  TEXT NOT NULL,                -- 'api_failure' | 'wrong_params' | 'timeout' | etc.
    tool_name       TEXT NOT NULL,                -- Which tool generated this error
    frequency       INTEGER NOT NULL DEFAULT 1,   -- How many times encountered
    typical_causes  TEXT,                         -- JSON array of likely causes
    proven_fixes    TEXT,                         -- JSON array of {fix, success_count}
    best_fix        TEXT,                         -- The fix with highest success rate
    preventive_params TEXT,                       -- JSON: parameters to avoid the error
    severity        TEXT NOT NULL DEFAULT 'warning', -- 'info' | 'warning' | 'critical'

    -- Semantic search
    description_embedding BLOB,                   -- 768-dim vector

    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_encountered DATETIME
);

CREATE INDEX idx_error_lessons_signature ON error_lessons(error_signature);
CREATE INDEX idx_error_lessons_tool ON error_lessons(tool_name);
CREATE INDEX idx_error_lessons_category ON error_lessons(error_category);

-- Reflections: Post-task cognitive analysis
CREATE TABLE reflections (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER NOT NULL REFERENCES sessions(id),
    task_summary    TEXT NOT NULL,                -- What was the task?
    tool_count      INTEGER NOT NULL,
    total_duration_ms INTEGER NOT NULL,
    efficiency_score REAL,                        -- 0.0 to 1.0
    quality_score   REAL,                         -- 0.0 to 1.0 (self-assessed)
    what_worked     TEXT,                         -- JSON array
    what_failed     TEXT,                         -- JSON array
    what_different  TEXT,                         -- Counterfactual analysis
    lessons_learned TEXT,                         -- JSON array of key takeaways

    -- Semantic search
    content_embedding BLOB,                       -- 768-dim vector of full reflection

    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_reflections_session ON reflections(session_id);
CREATE INDEX idx_reflections_quality ON reflections(quality_score);
```

### 2.4 Memory Retrieval Strategy

When the agent needs to recall something, it uses a **multi-modal retrieval** approach:

```python
class MemoryRetrievalEngine:
    """Multi-modal memory retrieval with semantic + keyword + recency scoring"""

    def recall(self, query: str, context: dict, limit: int = 5) -> list[Memory]:
        # 1. Get embedding for query via Ollama on ecolife-2
        query_embedding = self.embed(query)

        # 2. Search multiple memory types simultaneously
        semantic_results = self.vector_search(query_embedding, limit * 3)
        keyword_results = self.keyword_search(query, limit * 2)
        recent_results = self.recency_search(context, limit * 2)

        # 3. Merge and rerank using weighted scoring
        all_results = self.merge_results(
            semantic_results, keyword_results, recent_results,
            weights={'semantic': 0.5, 'keyword': 0.3, 'recency': 0.2}
        )

        # 4. Apply context filters (current project, active domain, etc.)
        filtered = self.apply_context_filters(all_results, context)

        return filtered[:limit]
```

---

## 3. Skill Evolution Mechanism

### 3.1 What is a "Skill"?

In the agent-toolkit cognition layer, a **skill** is a reusable, validated, and documented capability that the agent has learned through experience:

```python
@dataclass
class Skill:
    """A learned skill — reusable knowledge about how to accomplish tasks"""
    name: str                    # "solar_roi_report_generation"
    description: str             # "Generate complete solar ROI reports from raw project data"
    version: int                 # Incremented when skill is refined
    domain: str                  # "solar" | "health" | "general"
    trigger_conditions: list     # When to apply this skill
    workflow: list[WorkflowStep] # Ordered steps with parameter templates
    quality_metrics: dict        # Expected accuracy, typical duration
    documentation: str           # Auto-generated markdown documentation
    success_history: list        # Record of successful applications
    created_at: datetime
    updated_at: datetime

@dataclass
class WorkflowStep:
    tool_name: str
    purpose: str                 # Why this step is needed
    parameter_template: dict     # Default params (with placeholders)
    fallback_tools: list         # Alternative tools if primary fails
    validation_check: str        # How to verify this step succeeded
```

### 3.2 Skill Discovery: Tool Composition

The most powerful form of learning is **discovering that combining tools in sequence creates new capabilities**:

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                         SKILL DISCOVERY PIPELINE                                         │
│                                                                                          │
│  Step 1: SEQUENCE MINING                                                                 │
│  ─────────────────────                                                                   │
│  Analyze tool call graphs from session history:                                          │
│                                                                                          │
│    Session A:  read → calc_roi → write_report                                           │
│    Session B:  read → calc_roi → write_report                                           │
│    Session C:  read → calc_degradation → calc_roi → write_report                        │
│    Session D:  read → calc_roi → write_report                                           │
│                                                                                          │
│  Step 2: FREQUENT PATTERN EXTRACTION                                                     │
│  ─────────────────────────────────                                                       │
│  Core pattern found: "read → calc_roi → write_report" (frequency: 3/4 = 75%)           │
│  Extended variant: "read → calc_degradation → calc_roi → write_report" (25%)           │
│                                                                                          │
│  Step 3: ABSTRACT WORKFLOW GENERATION                                                    │
│  ───────────────────────────────────                                                     │
│  Using Ollama on ecolife-2:                                                              │
│                                                                                          │
│  Prompt: "Given these tool sequences, what's the general workflow?"                     │
│  Response: "Solar ROI analysis: read project data → calculate financials → generate     │
│            formatted report with charts and recommendations"                            │
│                                                                                          │
│  Step 4: SKILL CREATION                                                                  │
│  ─────────────────────                                                                   │
│  Create Skill object with:                                                               │
│    • Name: "solar_roi_report_generation"                                                 │
│    • Trigger: task contains "solar" + "ROI" + "report"                                  │
│    • Workflow: 3 steps with parameter templates                                          │
│    • Documentation: auto-generated from abstraction                                      │
│                                                                                          │
│  Step 5: VALIDATION                                                                      │
│  ───────────────                                                                         │
│  Track usage over next N tasks:                                                          │
│    • Applied correctly? → increment confidence                                           │
│    • Human override? → capture correction, update skill                                  │
│    • Unused for 30 days? → mark for review                                               │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 3.3 Parameter Optimization

As the agent uses tools repeatedly, it learns which parameters work best:

```sql
-- Parameter performance tracking
CREATE TABLE parameter_performance (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tool_name       TEXT NOT NULL,
    parameter_set   TEXT NOT NULL,                -- JSON: {param: value}
    context_hash    TEXT,                         -- Context in which used
    success         BOOLEAN NOT NULL,
    duration_ms     INTEGER,
    quality_score   REAL,                         -- If assessable
    use_count       INTEGER NOT NULL DEFAULT 1,

    -- Ranking: higher score = better parameter set
    composite_score REAL GENERATED ALWAYS AS (
        (success_rate * 0.4) + (1.0 / log(duration_ms + 1)) * 0.3 + (quality_score * 0.3)
    ) STORED
);
```

Over time, the agent builds a **parameter performance map** that guides future tool invocations toward optimal configurations.

### 3.4 Auto-Generated Skill Documentation

Every learned skill gets auto-generated documentation:

```markdown
<!-- Auto-generated by cognition-layer v1.0 -->
# Skill: Solar ROI Report Generation

**Domain:** solar  
**Version:** 3  
**Confidence:** 0.94  
**Success Rate:** 92% (23/25 applications)  
**Typical Duration:** 4.2s  

## When to Use

Apply this skill when the user asks for:
- "ROI report" + any solar-related term
- Financial analysis of solar installation
- Payback period or NPV calculation with formatting

## Workflow

### Step 1: Read Project Data
**Tool:** `file-ops-safe.safe_read`  
**Purpose:** Load solar project specifications  
**Parameters:**
```json
{
  "file_path": "{project_path}/specs.json",
  "max_size_mb": 10
}
```
**Validation:** File exists and contains valid JSON with `panel_specs` field.

### Step 2: Calculate ROI
**Tool:** `solar-calc.calculate_roi`  
**Purpose:** Compute financial return metrics  
**Parameters:**
```json
{
  "system_cost": "{from_specs.total_cost}",
  "energy_price": "{from_specs.energy_price_baht_per_kwh}",
  "production": "{from_specs.annual_production_kwh}",
  "years": 25
}
```
**Optimal parameters learned:** energy_price=4.5 for Bangkok residential

### Step 3: Write Report
**Tool:** `file-ops-safe.safe_write`  
**Purpose:** Save formatted report  
**Parameters:**
```json
{
  "file_path": "{project_path}/reports/roi_report_{date}.md",
  "content": "# Solar ROI Report\n\n{roi_result.formatted}"
}
```

## Common Variations

### With Degradation Analysis
Add `solar-calc.calculate_degradation` between Step 1 and Step 2 when the project specs include `installation_date`.

### Multi-Location Comparison
Wrap Steps 1-2 in a loop when `specs.json` contains `locations[]` array.

## Known Issues

| Issue | Fix |
|-------|-----|
| Missing energy_price | Default to 4.5 THB/kWh for Bangkok |
| Very large projects (>10MW) | Increase `years` parameter to 30 |
```

---

## 4. Feedback Collection System

### 4.1 Four Feedback Channels

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                           FEEDBACK COLLECTION SYSTEM                                     │
│                                                                                          │
│  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐ │
│  │ EXPLICIT         │  │ IMPLICIT         │  │ SELF-ASSESSMENT  │  │ HUMAN CORRECTION │ │
│  │ ──────────────── │  │ ──────────────── │  │ ──────────────── │  │ ──────────────── │ │
│  │                  │  │                  │  │                  │  │                  │ │
│  │ "That was        │  │ Task completion  │  │ Agent rates its  │  │ Human edits      │ │
│  │ helpful"         │  │ time trends      │  │ own output:      │  │ agent output —   │ │
│  │                  │  │                  │  │                  │  │ delta is         │ │
│  │ "Not what        │  │ Retry counts     │  │ "I rate this     │  │ captured:        │ │
│  │ I wanted"        │  │                  │  │ output 7/10      │  │                  │ │
│  │                  │  │ Error rates      │  │ because..."      │  │ "Expected X,     │ │
│  │ Collected via:   │  │ per tool         │  │                  │  │ got Y, fix is Z" │ │
│  │ • Natural        │  │                  │  │ Collected via:   │  │                  │ │
│  │   language in    │  │ Collected        │  │ • Structured     │  │ Collected via:   │ │
│  │   conversation   │  │ automatically    │  │   reflection     │  │ • File diff      │ │
│  │ • Explicit       │  │ after every      │  │   template       │  │   detection      │ │
│  │   feedback tool  │  │ tool call        │  │ • Confidence     │  │ • Override       │ │
│  │                  │  │                  │  │   scoring on     │  │   logging        │ │
│  │ Weight: HIGH     │  │ Weight: MEDIUM   │  │   every output   │  │                  │ │
│  │ (direct signal)  │  │ (behavioral)     │  │                  │  │ Weight: HIGHEST  │ │
│  │                  │  │                  │  │ Weight: LOW      │  │ (ground truth)   │ │
│  │                  │  │                  │  │ (biased)         │  │                  │ │
│  └──────────────────┘  └──────────────────┘  └──────────────────┘  └──────────────────┘ │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 4.2 Explicit Feedback

Users can provide feedback naturally in conversation or via dedicated tools:

```python
# Via natural language detection
@tool
def detect_explicit_feedback(user_message: str) -> Feedback | None:
    """
    Scan user messages for feedback signals.
    Runs on every user message via lightweight pattern matching.
    """
    positive_signals = [
        "that was helpful", "perfect", "exactly what i needed",
        "thanks that worked", "great job", " precisely",
        "ดีมาก", "ถูกต้อง", "ตรงนี้แหละ", "เยี่ยม"
    ]
    negative_signals = [
        "that's not what i wanted", "wrong", "incorrect",
        "try again", "that's not right", "no, i meant",
        "ไม่ใช่", "ผิด", "ลองใหม่", "ไม่ถูก"
    ]

    message_lower = user_message.lower()
    for signal in positive_signals:
        if signal in message_lower:
            return Feedback(type='explicit', sentiment='positive', raw=message_lower)
    for signal in negative_signals:
        if signal in message_lower:
            return Feedback(type='explicit', sentiment='negative', raw=message_lower)
    return None

# Via dedicated feedback tool
@tool
def submit_feedback(
    rating: int,           # 1-10 scale
    category: str,         # 'accuracy' | 'speed' | 'relevance' | 'clarity'
    comment: str,          # Free text
    task_reference: str    # Optional: reference to specific task
) -> None:
    """Submit structured feedback about agent performance."""
    store_feedback(Feedback(
        type='explicit_structured',
        rating=rating,
        category=category,
        comment=comment,
        task_reference=task_reference,
        timestamp=datetime.now()
    ))
```

### 4.3 Implicit Feedback Signals

Every interaction generates behavioral data:

```sql
CREATE TABLE implicit_feedback (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER NOT NULL,
    task_id         TEXT NOT NULL,

    -- Timing signals
    task_duration_ms INTEGER,                   -- Total time to complete
    tool_latency_ms  INTEGER,                   -- Individual tool response time
    think_time_ms    INTEGER,                   -- Time between user message and first tool call

    -- Behavioral signals
    retry_count      INTEGER DEFAULT 0,          -- How many retries needed
    correction_count INTEGER DEFAULT 0,          -- Human corrections applied
    override_count   INTEGER DEFAULT 0,          -- Human overrode agent decision
    tool_switches    INTEGER DEFAULT 0,          -- Agent switched tools mid-task

    -- Derived score (higher = better performance)
    implicit_score   REAL GENERATED ALWAYS AS (
        1.0 / (1 + retry_count * 0.3 + correction_count * 0.5 + override_count * 0.7)
    ) STORED,

    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

### 4.4 Human Correction Logging

When a human edits agent output, the **delta is the most valuable training signal**:

```python
class CorrectionLogger:
    """Capture human corrections as high-value learning signals"""

    def detect_correction(self, original_output: str, final_output: str) -> Correction | None:
        """
        Detect when human has modified agent output.
        Triggers on file write after agent-generated content.
        """
        if original_output == final_output:
            return None

        # Compute diff
        diff = unified_diff(original_output, final_output)

        return Correction(
            original=original_output,
            corrected=final_output,
            diff=diff,
            diff_summary=self.summarize_diff(diff),
            correction_type=self.classify_correction(diff),
            tools_used=self.get_tools_for_output(original_output),
            timestamp=datetime.now()
        )

    def classify_correction(self, diff: Diff) -> str:
        """Classify the type of correction for targeted learning"""
        if self.is_format_correction(diff):
            return 'formatting'
        elif self.is_factual_correction(diff):
            return 'factual'
        elif self.is_completeness_correction(diff):
            return 'completeness'
        elif self.is_approach_correction(diff):
            return 'approach_change'
        return 'other'
```

---

## 5. Learning Triggers

### 5.1 When Should the Agent Learn?

Learning is expensive (requires LLM inference on ecolife-2). We trigger learning strategically:

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                           LEARNING TRIGGER MATRIX                                        │
│                                                                                          │
│  TRIGGER                    │ THRESHOLD          │ ACTION                    │ PRIORITY │
│  ───────────────────────────┼────────────────────┼───────────────────────────┼──────────│
│  N similar tasks completed  │ N >= 3             │ Extract pattern           │ HIGH     │
│  Error encountered          │ Any error          │ Store error lesson        │ HIGH     │
│  Human override             │ Any override       │ Capture preferred approach│ CRITICAL │
│  Human correction           │ Any correction     │ Store correction delta    │ CRITICAL │
│  Explicit negative feedback │ Rating <= 4/10     │ Deep analysis + retrain   │ CRITICAL │
│  Explicit positive feedback │ Rating >= 8/10     │ Reinforce pattern         │ HIGH     │
│  Periodic review            │ Every 1 hour       │ Consolidate patterns      │ MEDIUM   │
│  Skill unused               │ 30 days            │ Mark for review           │ LOW      │
│  Confidence threshold       │ Confidence > 0.9   │ Promote to skill          │ HIGH     │
│  Error frequency spike      │ Error rate > 20%   │ Alert + deep analysis     │ HIGH     │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 5.2 Learning Pipeline

```python
class LearningOrchestrator:
    """Decides when and what to learn"""

    async def evaluate_learning_opportunity(self, event: LearningEvent) -> LearningJob | None:
        """
        Evaluate if an event warrants a learning cycle.
        Runs on ecolife-2 to avoid blocking the dev machine.
        """
        match event.type:
            case 'task_complete':
                recent_similar = await self.count_similar_tasks(event.task, hours=24)
                if recent_similar >= 3:
                    return LearningJob(
                        type='pattern_extraction',
                        priority='HIGH',
                        payload={'task_ids': recent_similar.task_ids}
                    )

            case 'error':
                return LearningJob(
                    type='error_lesson',
                    priority='HIGH',
                    payload={'error': event.error, 'context': event.context}
                )

            case 'human_override':
                return LearningJob(
                    type='correction_capture',
                    priority='CRITICAL',
                    payload={'original': event.original, 'override': event.override}
                )

            case 'periodic_review':
                return LearningJob(
                    type='consolidation',
                    priority='MEDIUM',
                    payload={'since': event.last_review_time}
                )

        return None  # No learning needed

    async def execute_learning_job(self, job: LearningJob) -> LearningResult:
        """Execute learning on ecolife-2 via Ollama"""
        match job.type:
            case 'pattern_extraction':
                return await self.extract_pattern(job.payload)
            case 'error_lesson':
                return await self.learn_from_error(job.payload)
            case 'correction_capture':
                return await self.learn_from_correction(job.payload)
            case 'consolidation':
                return await self.consolidate_memories(job.payload)
```

### 5.3 Periodic Consolidation

Every hour, a background job on ecolife-2 runs consolidation:

```
Consolidation Process (runs on ecolife-2 every hour):
├── 1. Collect short-term patterns from last hour
├── 2. Compare with existing long-term patterns
│   ├── If similar pattern exists → merge, increment confidence
│   ├── If new pattern with high confidence → promote to long-term
│   └── If old pattern unused → decrement confidence, mark for review
├── 3. Consolidate error lessons
│   ├── Merge duplicate error signatures
│   └── Update best_fix rankings
├── 4. Update skill rankings
│   ├── Recalculate success rates
│   ├── Update parameter performance scores
│   └── Deprecate skills with <0.3 confidence
└── 5. Generate performance digest
    └── Store in reflections for future retrieval
```

---

## 6. Self-Improvement MCP Tools

### 6.1 New MCP Server: `cognition-layer`

A new MCP server that exposes learning and cognition capabilities:

```python
# servers/cognition_layer/server.py
from fastmcp import FastMCP

mcp = FastMCP("cognition-layer")

# ─────────────────────────────────────────────────────────
# MEMORY TOOLS
# ─────────────────────────────────────────────────────────

@mcp.tool()
def memory_remember(
    key: str,
    value: str,
    importance: int = 5,
    category: str = "general",
    context: str = "",
    ttl_hours: int | None = None
) -> dict:
    """
    Store a lesson learned, observation, or insight for future retrieval.

    Args:
        key: Human-readable identifier (e.g., "solar_bangkok_energy_price")
        value: The actual knowledge to store
        importance: 1-10 scale (10 = critical, never forget)
        category: "lesson" | "pattern" | "preference" | "fact" | "error_fix"
        context: Optional context about when this applies
        ttl_hours: Auto-expire after N hours (None = permanent)

    Returns:
        {"memory_id": int, "status": "stored", "embedding_generated": bool}

    Example:
        memory_remember(
            key="solar_bangkok_default_energy_price",
            value="Bangkok residential energy price is 4.5 THB/kWh",
            importance=8,
            category="fact",
            context="solar ROI calculations for Bangkok residential"
        )
    """
    embedding = generate_embedding(f"{key}: {value} {context}")
    memory_id = db.insert_memory(key, value, importance, category, context, ttl_hours, embedding)
    return {"memory_id": memory_id, "status": "stored", "embedding_generated": True}


@mcp.tool()
def memory_recall(
    query: str,
    context: str = "",
    category: str | None = None,
    limit: int = 5,
    min_importance: int = 1
) -> list[dict]:
    """
    Retrieve relevant past experiences and learned knowledge.
    Uses semantic search (vector similarity) combined with keyword matching.

    Args:
        query: Natural language query (e.g., "how to calculate solar ROI")
        context: Current task context for filtering
        category: Filter by category (None = all)
        limit: Maximum results
        min_importance: Minimum importance level (1-10)

    Returns:
        List of memories with relevance scores

    Example:
        memory_recall("Bangkok solar energy price", context="solar-calc tool")
        → [{"key": "solar_bangkok_default_energy_price", "value": "4.5 THB/kWh", "score": 0.95}]
    """
    query_embedding = generate_embedding(query)
    memories = db.vector_search(query_embedding, context, category, limit, min_importance)
    return [{"id": m.id, "key": m.key, "value": m.value, "score": m.score} for m in memories]


@mcp.tool()
def memory_forget(memory_id: int) -> dict:
    """Remove a specific memory. Use when a memory is outdated or incorrect."""
    db.delete_memory(memory_id)
    return {"status": "forgotten", "memory_id": memory_id}


# ─────────────────────────────────────────────────────────
# PATTERN TOOLS
# ─────────────────────────────────────────────────────────

@mcp.tool()
def pattern_record(
    pattern_name: str,
    tool_sequence: list[str],
    description: str,
    trigger_keywords: list[str] | None = None,
    parameter_template: dict | None = None
) -> dict:
    """
    Record a successful tool sequence as a reusable pattern.

    Args:
        pattern_name: Human-readable name (e.g., "solar_roi_workflow")
        tool_sequence: Ordered list of tool names
        description: What this pattern accomplishes
        trigger_keywords: Keywords that suggest this pattern
        parameter_template: Default parameters for each step

    Returns:
        {"pattern_id": int, "status": "recorded"}
    """
    pattern_id = db.insert_pattern(pattern_name, tool_sequence, description,
                                    trigger_keywords, parameter_template)
    return {"pattern_id": pattern_id, "status": "recorded"}


@mcp.tool()
def pattern_suggest(task_description: str, context: str = "") -> list[dict]:
    """
    Suggest known patterns for a given task.
    Uses semantic matching to find relevant workflows.

    Args:
        task_description: What the agent needs to accomplish
        context: Current project/domain context

    Returns:
        List of matching patterns with confidence scores

    Example:
        pattern_suggest("Calculate solar ROI for Bangkok residential project")
        → [{
            "name": "solar_roi_workflow",
            "sequence": ["file-ops-safe.safe_read", "solar-calc.calculate_roi", "file-ops-safe.safe_write"],
            "confidence": 0.94,
            "success_rate": 0.92
        }]
    """
    task_embedding = generate_embedding(task_description)
    patterns = db.find_patterns(task_embedding, context)
    return [{
        "name": p.name,
        "sequence": p.sequence,
        "confidence": p.confidence,
        "success_rate": p.success_rate,
        "avg_duration_ms": p.avg_duration_ms
    } for p in patterns]


# ─────────────────────────────────────────────────────────
# PERFORMANCE TOOLS
# ─────────────────────────────────────────────────────────

@mcp.tool()
def performance_review(time_period: str = "24h") -> dict:
    """
    Analyze recent performance and suggest improvements.

    Args:
        time_period: "1h" | "24h" | "7d" | "30d"

    Returns:
        Performance report with metrics and suggestions

    Example output:
    {
        "period": "24h",
        "total_tasks": 47,
        "success_rate": 0.94,
        "avg_task_duration_ms": 3200,
        "most_used_tools": [
            {"tool": "solar-calc.calculate_roi", "calls": 23},
            {"tool": "file-ops-safe.safe_read", "calls": 18}
        ],
        "errors": [
            {"tool": "solar-calc.calculate_roi", "count": 2, "category": "missing_params"}
        ],
        "suggestions": [
            "You often read then calculate ROI then write — create a workflow?",
            "solar-calc.calculate_roi missing energy_price 40% of the time"
        ],
        "top_skills_used": ["solar_roi_report"],
        "reflections_generated": 12
    }
    """
    return generate_performance_report(time_period)


@mcp.tool()
def self_assess(task_output: str, task_goal: str) -> dict:
    """
    Rate the quality of agent output against the intended goal.
    Uses Ollama on ecolife-2 for assessment.

    Args:
        task_output: The output being assessed
        task_goal: What the output was supposed to accomplish

    Returns:
        {"score": float, "assessment": str, "improvements": list[str]}
    """
    assessment = ollama_assess(task_output, task_goal)
    return {
        "score": assessment.score,
        "assessment": assessment.text,
        "improvements": assessment.suggestions
    }


# ─────────────────────────────────────────────────────────
# SKILL TOOLS
# ─────────────────────────────────────────────────────────

@mcp.tool()
def skill_list(domain: str | None = None) -> list[dict]:
    """
    List all learned skills, optionally filtered by domain.

    Returns:
        [{"name": str, "domain": str, "version": int, "confidence": float, "success_rate": float}]
    """
    skills = db.get_skills(domain)
    return [{
        "name": s.name,
        "domain": s.domain,
        "version": s.version,
        "confidence": s.confidence,
        "success_rate": s.success_rate,
        "description": s.description
    } for s in skills]


@mcp.tool()
def skill_learn_from_interaction(
    session_id: int | None = None,
    pattern_name: str | None = None
) -> dict:
    """
    Extract a skill from recent conversation history.
    Analyzes tool usage patterns and generates a reusable skill.

    Args:
        session_id: Specific session to analyze (None = current session)
        pattern_name: Suggested name for the new skill

    Returns:
        {"skill_id": int, "skill_name": str, "tools_learned": int, "confidence": float}
    """
    session = session_id or get_current_session()
    trace = extract_task_trace(session)
    skill = generate_skill_from_trace(trace, pattern_name)
    skill_id = db.store_skill(skill)
    return {
        "skill_id": skill_id,
        "skill_name": skill.name,
        "tools_learned": len(skill.workflow),
        "confidence": skill.confidence
    }


# ─────────────────────────────────────────────────────────
# HEALTH & DIAGNOSTICS
# ─────────────────────────────────────────────────────────

@mcp.tool()
def cognition_health() -> dict:
    """
    Get health status of the cognition layer itself.

    Returns:
        {
            "memory_count": int,
            "pattern_count": int,
            "skill_count": int,
            "reflection_count": int,
            "error_lesson_count": int,
            "database_size_mb": float,
            "embedding_cache_hit_rate": float,
            "last_consolidation": str,
            "ollama_connection": bool,
            "status": "healthy" | "degraded" | "critical"
        }
    """
    return generate_health_report()


---

## 7. Project Health & Self-Diagnostics

### 7.1 Philosophy: The System Must Watch Itself

An agent that cannot monitor its own health is fragile. The self-diagnostics layer provides continuous visibility into how the system is performing, where it's struggling, and what could be improved.

### 7.2 Tool Usage Analytics

```sql
-- Tool usage statistics (materialized view, refreshed hourly)
CREATE TABLE tool_usage_stats (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tool_name       TEXT NOT NULL,
    server_name     TEXT NOT NULL,
    period_start    DATETIME NOT NULL,
    period_end      DATETIME NOT NULL,
    call_count      INTEGER NOT NULL DEFAULT 0,
    success_count   INTEGER NOT NULL DEFAULT 0,
    error_count     INTEGER NOT NULL DEFAULT 0,
    avg_duration_ms INTEGER,
    p95_duration_ms INTEGER,                    -- 95th percentile latency
    p99_duration_ms INTEGER,                    -- 99th percentile latency
    retry_count     INTEGER DEFAULT 0,

    PRIMARY KEY (tool_name, period_start)
);

-- Unused tools (tools that haven't been called recently)
CREATE VIEW unused_tools AS
SELECT
    tool_name,
    server_name,
    MAX(period_end) as last_used,
    julianday('now') - julianday(MAX(period_end)) as days_unused
FROM tool_usage_stats
GROUP BY tool_name
HAVING days_unused > 7;

-- Error trending (are errors increasing or decreasing?)
CREATE VIEW error_trends AS
SELECT
    tool_name,
    period_start,
    CAST(error_count AS REAL) / NULLIF(call_count, 0) * 100 as error_rate_pct,
    LAG(CAST(error_count AS REAL) / NULLIF(call_count, 0)) OVER (
        PARTITION BY tool_name ORDER BY period_start
    ) * 100 as prev_error_rate_pct
FROM tool_usage_stats
WHERE call_count > 0
ORDER BY tool_name, period_start;
```

### 7.3 Performance Metrics Dashboard

```python
class DiagnosticsEngine:
    """Generate health reports and improvement suggestions"""

    def generate_health_dashboard(self) -> str:
        """
        Generate a text-based health dashboard.
        Called via `cognition_health` tool or displayed on startup.
        """
        report = []

        # ── System Status ──
        report.append("═" * 60)
        report.append("  AGENT-TOOLKIT COGNITION HEALTH DASHBOARD")
        report.append("═" * 60)

        # Database health
        db_size = self.get_db_size_mb()
        db_status = "🟢" if db_size < 500 else "🟡" if db_size < 1000 else "🔴"
        report.append(f"\n  📦 Database: {db_size:.1f} MB {db_status}")
        report.append(f"     Tables: {self.count_tables()} rows: ~{self.count_rows():,}")

        # Memory health
        mem_count = self.count_memories()
        recent_memories = self.count_memories(hours=24)
        report.append(f"\n  🧠 Memories: {mem_count:,} total ({recent_memories:,} in last 24h)")

        # Pattern health
        active_patterns = self.count_active_patterns()
        recent_patterns = self.count_patterns(hours=24)
        report.append(f"  📋 Patterns: {active_patterns:,} active ({recent_patterns:,} new in 24h)")

        # Skill health
        skills = self.count_skills()
        deprecated = self.count_deprecated_skills()
        report.append(f"  🎓 Skills: {skills:,} learned ({deprecated:,} deprecated)")

        # Tool usage
        report.append(f"\n  🔧 Tool Usage (last 24h):")
        for tool_stat in self.get_top_tools(limit=5):
            bar = "█" * int(tool_stat.call_count / 5)
            report.append(f"     {tool_stat.tool_name:30s} {tool_stat.call_count:4d} calls {bar}")

        # Error summary
        recent_errors = self.get_recent_errors(hours=24)
        if recent_errors:
            report.append(f"\n  ⚠️  Errors (last 24h): {len(recent_errors)}")
            for err in recent_errors[:5]:
                report.append(f"     {err.tool_name}: {err.category} ({err.count}x)")

        # Suggestions
        suggestions = self.generate_suggestions()
        if suggestions:
            report.append(f"\n  💡 Suggestions:")
            for i, suggestion in enumerate(suggestions[:5], 1):
                report.append(f"     {i}. {suggestion}")

        report.append(f"\n  Ollama: {'🟢 Connected' if self.ollama_healthy() else '🔴 Unavailable'}")
        report.append(f"  Last consolidation: {self.get_last_consolidation()}")
        report.append("═" * 60)

        return "\n".join(report)

    def generate_suggestions(self) -> list[str]:
        """
        Generate improvement suggestions based on usage analytics.
        This is where the system gets creative about its own improvement.
        """
        suggestions = []

        # Suggestion 1: Unused tools
        unused = self.get_unused_tools(days=7)
        for tool in unused:
            suggestions.append(
                f"Tool '{tool.name}' hasn't been used in {tool.days_unused:.0f} days. "
                f"Consider: {tool.suggestion}"
            )

        # Suggestion 2: Frequent tool combinations
        frequent_combos = self.find_frequent_combinations(min_frequency=3)
        for combo in frequent_combos:
            if not combo.has_pattern:
                suggestions.append(
                    f"You often use {' → '.join(combo.tools)} ({combo.count}x). "
                    f"Create a combined workflow?"
                )

        # Suggestion 3: Error-prone parameters
        error_params = self.find_error_prone_parameters()
        for ep in error_params:
            suggestions.append(
                f"Tool '{ep.tool_name}' fails {ep.error_rate:.0%} of the time "
                f"with parameter '{ep.param_name}={ep.param_value}'. "
                f"Consider defaulting to '{ep.suggested_value}'."
            )

        # Suggestion 4: Slow tools
        slow_tools = self.find_slow_tools(threshold_ms=5000)
        for tool in slow_tools:
            suggestions.append(
                f"Tool '{tool.name}' averages {tool.avg_duration_ms/1000:.1f}s. "
                f"Consider: {tool.optimization_suggestion}"
            )

        return suggestions
```

### 7.4 Suggestion Engine

The suggestion engine continuously looks for opportunities to improve:

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                           SUGGESTION ENGINE                                             │
│                                                                                          │
│  Analyzes:                                          Produces:                            │
│  ─────────                                          ────────                             │
│  • Tool call sequences    ──────────────────────▶   "Create workflow for X+Y+Z"         │
│  • Error patterns         ──────────────────────▶   "Add default parameter for P"       │
│  • Unused tools           ──────────────────────▶   "Tool T seems unused — document it  │
│  • Parameter performance  ──────────────────────▶   "Parameter A=B has 95% success rate"│
│  • Human corrections      ──────────────────────▶   "You often fix X — auto-apply?"     │
│  • Timing patterns        ──────────────────────▶   "Cache results for tool C"          │
│                                                                                          │
│  Suggestion lifecycle:                                                                   │
│  1. Generated (background analysis)                                                      │
│  2. Stored with confidence score                                                         │
│  3. Presented to agent via `pattern_suggest` or `performance_review`                    │
│  4. If agent implements → track outcome, adjust confidence                               │
│  5. If agent ignores 3x → deprioritize or remove                                         │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## 8. Knowledge Accumulation

### 8.1 Domain Knowledge Bases

Beyond procedural learning (patterns, skills), the agent needs **declarative knowledge** — facts, formulas, standards, and conventions specific to each domain.

#### Solar O&M Domain Knowledge

```python
SOLAR_DOMAIN_KNOWLEDGE = {
    "thailand_energy_prices": {
        "bangkok_residential": 4.5,      # THB/kWh
        "bangkok_commercial": 5.2,
        "bangkok_industrial": 4.8,
        "provincial_residential": 3.8,
        "pea_rate": 3.5,                  # Provincial Electricity Authority
        "mea_rate": 4.5,                  # Metropolitan Electricity Authority
        "time_of_use_peak_multiplier": 1.5,
        "source": "PEA/MEA 2024 tariffs",
        "updated": "2025-01-15"
    },

    "degradation_rates": {
        "monocrystalline": 0.005,        # 0.5% per year
        "polycrystalline": 0.007,
        "thin_film": 0.006,
        "source": "IEC 61215 standard",
        "note": "Thailand's tropical climate may accelerate by 10-15%"
    },

    "thai_regulations": {
        "net_metering_max_kw": 10000,     # Maximum system size for net metering (kW)
        "solar_rooftop_permit_required_above_kw": 10,
        "eia_required_above_mw": 50,     # Environmental Impact Assessment
        "building_permit_always_required": True,
        "fire_department_approval_required": True,
        "min_rooftop_area_per_kw": 6.5,   # m² per kW (including spacing)
    },

    "irradiance_bangkok": {
        "annual_average_kwh_m2": 1575,    # kWh/m²/year (GHI)
        "peak_month": "April",             # ~175 kWh/m²/month
        "lowest_month": "August",          # ~120 kWh/m²/month (monsoon)
        "optimal_tilt": 13,               # degrees from horizontal
        "optimal_azimuth": 180,            # South-facing
        "source": "NASA SSE / SolarGIS"
    },

    "performance_ratios": {
        "residential_typical": 0.78,
        "commercial_typical": 0.82,
        "utility_scale_typical": 0.85,
        "factors": {
            "temperature_derating": -0.004,  # per °C above 25°C
            "dust_loss_bangkok": 0.05,      # 5% annual average
            "inverter_efficiency": 0.97,
            "cable_losses": 0.02,
            "mismatch_losses": 0.02
        }
    }
}
```

#### Health Franchise Domain Knowledge

```python
HEALTH_DOMAIN_KNOWLEDGE = {
    "thai_healthcare_regulations": {
        "clinic_license_types": [
            "Type 1: General practice (อนุบาล)",
            "Type 2: Specialty clinic (เฉพาะทาง)",
            "Type 3: Dental clinic",
            "Type 4: Traditional medicine"
        ],
        "license_renewal_years": 3,
        "doctor_requirements": {
            "type1": "MD license + 1 year experience",
            "type2": "Specialist certification",
            "minimum_doctors": 1
        },
        "required_insurance": {
            "medical_malpractice": "minimum 1M THB coverage",
            "property": "recommended",
        },
        "data_privacy": "PDPA compliance required (effective since 2022)",
    },

    "bangkok_clinic_benchmarks": {
        "avg_monthly_visits_small": 300,     # < 3 doctors
        "avg_monthly_visits_medium": 800,    # 3-5 doctors
        "avg_monthly_visits_large": 1500,    # > 5 doctors
        "avg_revenue_per_visit_thb": 1200,
        "avg_operational_cost_pct": 0.65,
        "staff_cost_pct": 0.35,
        "rent_cost_pct_bangkok": 0.15,
        "target_profit_margin": 0.20,
    },

    "kpi_benchmarks": {
        "patient_satisfaction_target": 4.2,   # out of 5
        "repeat_visit_rate_target": 0.60,
        "appointment_show_rate_target": 0.85,
        "avg_consultation_time_min": 15,
        "inventory_turnover_target": 6,       # times per year
        "staff_utilization_target": 0.75,
    },

    "seasonal_patterns": {
        "flu_season_peak": ["June", "July", "August"],  # Rainy season
        "dengue_season_peak": ["June", "July", "September"],
        "allergy_season_peak": ["January", "February", "March"],
        "holiday_dip": ["April"],  # Songkran
        "tourist_high_season_boost": ["November", "December", "January"],
    }
}
```

### 8.2 Cross-Domain Pattern Transfer

One of the most powerful capabilities is **transferring patterns across domains**:

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                      CROSS-DOMAIN PATTERN TRANSFER                                      │
│                                                                                          │
│  Pattern in Solar Domain:                                                                │
│  ┌─────────────────────────────────────────────────────┐                                 │
│  │  1. Read raw data (irradiance, panel specs)          │                                 │
│  │  2. Calculate financial metrics (ROI, NPV)           │                                 │
│  │  3. Generate report with charts and recommendations   │                                 │
│  │  4. Save to project directory                        │                                 │
│  └─────────────────────────────────────────────────────┘                                 │
│                         │                                                                │
│                         │ ABSTRACT: "Read → Calculate → Report → Save"                  │
│                         ▼                                                                │
│  ┌─────────────────────────────────────────────────────┐                                 │
│  │  Pattern in Health Domain:                           │                                 │
│  │  1. Read raw data (visit logs, revenue)              │                                 │
│  │  2. Calculate KPIs (revenue per visit, margins)      │                                 │
│  │  3. Generate dashboard with trends and alerts        │                                 │
│  │  4. Save to shared drive                             │                                 │
│  └─────────────────────────────────────────────────────┘                                 │
│                                                                                          │
│  LEARNING: The abstract pattern {read → calc → report → save} is domain-agnostic.       │
│  When the agent encounters a new domain, it can apply this pattern immediately.          │
│                                                                                          │
│  Cross-domain transfer is enabled by:                                                    │
│  • Semantic pattern abstraction (Ollama on ecolife-2)                                    │
│  • Normalized tool role classification                                                   │
│  • Pattern inheritance with domain-specific parameter overrides                          │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 8.3 Knowledge Versioning and Deprecation

Knowledge changes. Energy prices update. Regulations change. The system must handle this:

```sql
-- Knowledge versioning
CREATE TABLE domain_knowledge (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    domain          TEXT NOT NULL,                -- 'solar' | 'health' | 'general'
    key             TEXT NOT NULL,
    value           TEXT NOT NULL,                -- JSON value
    value_type      TEXT NOT NULL,                -- 'scalar' | 'formula' | 'reference' | 'list'
    source          TEXT,                         -- Where this came from
    source_url      TEXT,
    version         INTEGER NOT NULL DEFAULT 1,
    is_current      BOOLEAN NOT NULL DEFAULT TRUE,

    -- Previous versions are kept for audit
    replaced_by     INTEGER REFERENCES domain_knowledge(id),

    -- Auto-deprecation
    valid_from      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    valid_until     DATETIME,                     -- NULL = current
    auto_deprecate  TEXT,                         -- '1 year' | '6 months' | NULL

    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE(domain, key, version)
);

-- Knowledge change history
CREATE TABLE knowledge_changes (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    knowledge_id    INTEGER NOT NULL REFERENCES domain_knowledge(id),
    change_type     TEXT NOT NULL,                -- 'created' | 'updated' | 'deprecated'
    old_value       TEXT,
    new_value       TEXT,
    reason          TEXT,
    changed_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);
```

---

## 9. Implementation Roadmap

### 9.1 Five-Phase Implementation

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                      IMPLEMENTATION ROADMAP                                              │
│                                                                                          │
│  PHASE 1: BASIC MEMORY (Week 2)                  ████████████████████  100% Foundation │
│  ───────────────────────────────                                                         │
│  Status: Foundation already in ARCHITECTURE.md                                          │
│  • SQLite database with conversations, tool_calls, memories tables                      │
│  • Basic remember/recall via memory-store MCP server                                    │
│  • Session tracking across CLI clients                                                  │
│  • Tool call logging                                                                    │
│  Deliverable: Working memory-store server                                               │
│                                                                                          │
│  PHASE 2: PATTERN RECOGNITION (Week 3-4)         ░░░░░░░░░░░░░░░░░░░░   0% In Progress │
│  ────────────────────────────────────────                                                │
│  New tables: recent_patterns, learned_patterns, error_lessons                           │
│  • Tool sequence mining from tool_calls history                                         │
│  • Error categorization and lesson storage                                              │
│  • Short-term pattern detection (frequency-based)                                       │
│  • pattern_record and pattern_suggest MCP tools                                         │
│  • Background job: pattern extraction (runs on ecolife-2)                               │
│  Deliverable: Agent can suggest patterns for common tasks                               │
│                                                                                          │
│  PHASE 3: SKILL EVOLUTION (Month 2)              ░░░░░░░░░░░░░░░░░░░░   0% Planned      │
│  ─────────────────────────────────                                                       │
│  New tables: skills, parameter_performance                                              │
│  • Skill discovery from repeated tool sequences                                         │
│  • Workflow template generation                                                         │
│  • Parameter optimization tracking                                                      │
│  • Auto-generated skill documentation                                                   │
│  • Cross-domain pattern transfer                                                        │
│  • skill_list and skill_learn_from_interaction MCP tools                                │
│  Deliverable: Agent auto-creates skills from repeated patterns                          │
│                                                                                          │
│  PHASE 4: SELF-DIAGNOSTICS (Month 2)             ░░░░░░░░░░░░░░░░░░░░   0% Planned      │
│  ──────────────────────────────────                                                      │
│  New tables: tool_usage_stats, implicit_feedback, corrections                           │
│  • Performance metrics collection                                                       │
│  • Error rate trending                                                                  │
│  • Suggestion engine (unused tools, frequent combinations)                              │
│  • Text-based health dashboard                                                          │
│  • cognition_health MCP tool                                                            │
│  Deliverable: Agent can report on its own health and suggest improvements               │
│                                                                                          │
│  PHASE 5: AUTONOMOUS IMPROVEMENT (Month 3)       ░░░░░░░░░░░░░░░░░░░░   0% Vision       │
│  ─────────────────────────────────────────                                               │
│  • Self-assessment of output quality                                                    │
│  • Automatic skill refinement from feedback                                             │
│  • Proactive pattern suggestions                                                        │
│  • Human correction integration                                                         │
│  • Knowledge accumulation with auto-deprecation                                         │
│  • Full reflection generation (what worked, what didn't)                                │
│  Deliverable: Agent genuinely improves with experience                                  │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 9.2 Phase 2 Detail: Pattern Recognition (Week 3-4)

**Week 3: Pattern Detection**
- Day 1-2: Create `recent_patterns` table and indexing
- Day 3-4: Implement sequence mining algorithm (SQL-based frequency analysis)
- Day 5-6: Build pattern confidence scoring
- Day 7: Integration testing

**Week 4: Error Learning & Tool Exposure**
- Day 1-2: Create `error_lessons` table
- Day 3-4: Implement error categorization and signature extraction
- Day 5-6: Build `pattern_record`, `pattern_suggest`, `memory_remember`, `memory_recall` tools
- Day 7: End-to-end testing with simulated errors

### 9.3 Resource Requirements per Phase

```
┌──────────────────────────────────────────────────────────────┐
│  PHASE    │ DEV TIME  │ ECOLIFE-2 USAGE  │ COMPLEXITY       │
│  ────────┼───────────┼──────────────────┼───────────────── │
│  Phase 1  │ 3 days   │ None             │ Low (in place)   │
│  Phase 2  │ 10 days  │ Light (embed)    │ Medium           │
│  Phase 3  │ 15 days  │ Medium (reason)  │ High             │
│  Phase 4  │ 10 days  │ Light (analysis) │ Medium           │
│  Phase 5  │ 20 days  │ Heavy (reflect)  │ Very High        │
│  ────────┼───────────┼──────────────────┼───────────────── │
│  TOTAL    │ ~58 days │ ~12 weeks        │ Graduated        │
└──────────────────────────────────────────────────────────────┘
```

---

## 10. Technical Architecture

### 10.1 Complete Database Schema

```sql
-- ============================================================
-- COGNITION LAYER SCHEMA (extends ARCHITECTURE.md core schema)
-- ============================================================

-- 1. REFLECTIONS: Post-task cognitive analysis
CREATE TABLE reflections (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER NOT NULL REFERENCES sessions(id),
    task_summary    TEXT NOT NULL,
    tool_count      INTEGER NOT NULL,
    total_duration_ms INTEGER NOT NULL,
    efficiency_score REAL,                         -- 0.0 to 1.0
    quality_score   REAL,                          -- 0.0 to 1.0 (self-assessed)
    what_worked     TEXT,                          -- JSON array
    what_failed     TEXT,                          -- JSON array
    what_different  TEXT,                          -- Counterfactual analysis
    lessons_learned TEXT,                          -- JSON array of key takeaways
    content_embedding BLOB,                        -- 768-dim vector for semantic search
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_reflections_session ON reflections(session_id);
CREATE INDEX idx_reflections_quality ON reflections(quality_score);
CREATE INDEX idx_reflections_created ON reflections(created_at);

-- 2. RECENT PATTERNS: Short-term hot tool sequences
CREATE TABLE recent_patterns (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern_hash    TEXT NOT NULL UNIQUE,
    tool_sequence   TEXT NOT NULL,                -- JSON array
    normalized_sequence TEXT,                     -- Abstracted roles
    frequency       INTEGER NOT NULL DEFAULT 1,
    last_triggered  DATETIME NOT NULL,
    avg_duration_ms INTEGER,
    success_rate    REAL NOT NULL DEFAULT 1.0,
    source_sessions TEXT,                         -- JSON array
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    expires_at      DATETIME NOT NULL DEFAULT (datetime('now', '+7 days')),
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_recent_patterns_hash ON recent_patterns(pattern_hash);
CREATE INDEX idx_recent_patterns_expires ON recent_patterns(expires_at);
CREATE INDEX idx_recent_patterns_active ON recent_patterns(is_active);

-- 3. LEARNED PATTERNS: Long-term validated workflows
CREATE TABLE learned_patterns (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    pattern_name    TEXT NOT NULL UNIQUE,
    description     TEXT NOT NULL,
    tool_sequence   TEXT NOT NULL,
    parameter_template TEXT,                      -- JSON
    trigger_keywords TEXT,                        -- JSON array
    success_count   INTEGER NOT NULL DEFAULT 0,
    failure_count   INTEGER NOT NULL DEFAULT 0,
    success_rate    REAL NOT NULL DEFAULT 1.0,
    avg_duration_ms INTEGER,
    confidence_score REAL NOT NULL DEFAULT 0.5,
    category        TEXT,                         -- 'domain_workflow' | 'utility' | 'creative'
    origin          TEXT NOT NULL DEFAULT 'auto',  -- 'auto' | 'human' | 'imported'
    is_deprecated   BOOLEAN NOT NULL DEFAULT FALSE,
    deprecated_by   INTEGER REFERENCES learned_patterns(id),
    description_embedding BLOB,                   -- 768-dim vector
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_used_at    DATETIME
);

CREATE INDEX idx_learned_patterns_name ON learned_patterns(pattern_name);
CREATE INDEX idx_learned_patterns_category ON learned_patterns(category);
CREATE INDEX idx_learned_patterns_confidence ON learned_patterns(confidence_score);

-- Virtual table for vector search (sqlite-vec)
-- CREATE VIRTUAL TABLE vec_learned_patterns USING vec0(description_embedding float[768]);

-- 4. ERROR LESSONS: Institutional knowledge from failures
CREATE TABLE error_lessons (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    error_signature TEXT NOT NULL,
    error_category  TEXT NOT NULL,
    tool_name       TEXT NOT NULL,
    frequency       INTEGER NOT NULL DEFAULT 1,
    typical_causes  TEXT,                         -- JSON array
    proven_fixes    TEXT,                         -- JSON array of {fix, success_count}
    best_fix        TEXT,
    preventive_params TEXT,                       -- JSON
    severity        TEXT NOT NULL DEFAULT 'warning',
    description_embedding BLOB,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_encountered DATETIME
);

CREATE INDEX idx_error_lessons_signature ON error_lessons(error_signature);
CREATE INDEX idx_error_lessons_tool ON error_lessons(tool_name);
CREATE INDEX idx_error_lessons_category ON error_lessons(error_category);

-- 5. SKILLS: Learned reusable capabilities
CREATE TABLE skills (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL UNIQUE,
    description     TEXT NOT NULL,
    version         INTEGER NOT NULL DEFAULT 1,
    domain          TEXT NOT NULL DEFAULT 'general',
    trigger_conditions TEXT,                      -- JSON array
    workflow        TEXT NOT NULL,                -- JSON array of WorkflowStep
    quality_metrics TEXT,                         -- JSON
    documentation   TEXT,                         -- Markdown
    success_history TEXT,                         -- JSON array
    confidence      REAL NOT NULL DEFAULT 0.5,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    replaced_by     INTEGER REFERENCES skills(id),
    description_embedding BLOB,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_used_at    DATETIME
);

CREATE INDEX idx_skills_domain ON skills(domain);
CREATE INDEX idx_skills_active ON skills(is_active);
CREATE INDEX idx_skills_confidence ON skills(confidence);

-- 6. PARAMETER PERFORMANCE: Which parameters work best
CREATE TABLE parameter_performance (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tool_name       TEXT NOT NULL,
    parameter_set   TEXT NOT NULL,                -- JSON
    context_hash    TEXT,
    success         BOOLEAN NOT NULL,
    duration_ms     INTEGER,
    quality_score   REAL,
    use_count       INTEGER NOT NULL DEFAULT 1,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_param_perf_tool ON parameter_performance(tool_name);
CREATE INDEX idx_param_perf_success ON parameter_performance(success);

-- 7. EXPLICIT FEEDBACK: User-provided ratings
CREATE TABLE explicit_feedback (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id),
    rating          INTEGER NOT NULL,             -- 1-10
    category        TEXT,                         -- 'accuracy' | 'speed' | 'relevance' | 'clarity'
    comment         TEXT,
    task_reference  TEXT,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_explicit_feedback_session ON explicit_feedback(session_id);

-- 8. IMPLICIT FEEDBACK: Behavioral signals
CREATE TABLE implicit_feedback (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER NOT NULL,
    task_id         TEXT NOT NULL,
    task_duration_ms INTEGER,
    tool_latency_ms INTEGER,
    think_time_ms   INTEGER,
    retry_count     INTEGER DEFAULT 0,
    correction_count INTEGER DEFAULT 0,
    override_count  INTEGER DEFAULT 0,
    tool_switches   INTEGER DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_implicit_feedback_session ON implicit_feedback(session_id);
CREATE INDEX idx_implicit_feedback_task ON implicit_feedback(task_id);

-- 9. CORRECTIONS: Human edits to agent output
CREATE TABLE corrections (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER NOT NULL REFERENCES sessions(id),
    original_output TEXT NOT NULL,
    corrected_output TEXT NOT NULL,
    diff_summary    TEXT NOT NULL,
    correction_type TEXT NOT NULL,                -- 'formatting' | 'factual' | 'completeness' | 'approach'
    tools_used      TEXT,                         -- JSON array
    learned         BOOLEAN NOT NULL DEFAULT FALSE,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_corrections_session ON corrections(session_id);
CREATE INDEX idx_corrections_type ON corrections(correction_type);

-- 10. DOMAIN KNOWLEDGE: Structured domain expertise
CREATE TABLE domain_knowledge (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    domain          TEXT NOT NULL,
    key             TEXT NOT NULL,
    value           TEXT NOT NULL,
    value_type      TEXT NOT NULL DEFAULT 'scalar',
    source          TEXT,
    source_url      TEXT,
    version         INTEGER NOT NULL DEFAULT 1,
    is_current      BOOLEAN NOT NULL DEFAULT TRUE,
    replaced_by     INTEGER REFERENCES domain_knowledge(id),
    valid_from      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    valid_until     DATETIME,
    auto_deprecate  TEXT,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(domain, key, version)
);

CREATE INDEX idx_domain_knowledge_domain ON domain_knowledge(domain);
CREATE INDEX idx_domain_knowledge_current ON domain_knowledge(is_current);
CREATE INDEX idx_domain_knowledge_key ON domain_knowledge(key);

-- 11. TOOL USAGE STATS: Materialized analytics
CREATE TABLE tool_usage_stats (
    tool_name       TEXT NOT NULL,
    server_name     TEXT NOT NULL,
    period_start    DATETIME NOT NULL,
    period_end      DATETIME NOT NULL,
    call_count      INTEGER NOT NULL DEFAULT 0,
    success_count   INTEGER NOT NULL DEFAULT 0,
    error_count     INTEGER NOT NULL DEFAULT 0,
    avg_duration_ms INTEGER,
    p95_duration_ms INTEGER,
    p99_duration_ms INTEGER,
    retry_count     INTEGER DEFAULT 0,
    PRIMARY KEY (tool_name, period_start)
) WITHOUT ROWID;

CREATE INDEX idx_tool_stats_period ON tool_usage_stats(period_start);
CREATE INDEX idx_tool_stats_server ON tool_usage_stats(server_name);

-- 12. SUGGESTIONS: Generated improvement ideas
CREATE TABLE suggestions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    suggestion_type TEXT NOT NULL,                -- 'workflow' | 'parameter' | 'tool_combination' | 'deprecation'
    title           TEXT NOT NULL,
    description     TEXT NOT NULL,
    confidence      REAL NOT NULL DEFAULT 0.5,
    implemented     BOOLEAN NOT NULL DEFAULT FALSE,
    implementation_result TEXT,                   -- JSON: {success, outcome}
    times_presented INTEGER DEFAULT 0,
    times_ignored   INTEGER DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    resolved_at     DATETIME
);

CREATE INDEX idx_suggestions_type ON suggestions(suggestion_type);
CREATE INDEX idx_suggestions_confidence ON suggestions(confidence);
```

### 10.2 Embedding Strategy

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                           EMBEDDING STRATEGY                                             │
│                                                                                          │
│  Model: nomic-embed-text (via Ollama on ecolife-2)                                     │
│  Dimensions: 768                                                                         │
│  Storage: BLOB in SQLite tables + sqlite-vec virtual table for ANN search               │
│                                                                                          │
│  What gets embedded:                                                                     │
│  ┌──────────────────────────┬───────────────────────────────────────────────────────┐    │
│  │ Table                    │ Embedding Text                                        │    │
│  ├──────────────────────────┼───────────────────────────────────────────────────────┤    │
│  │ reflections              │ task_summary + what_worked + what_failed + lessons   │    │
│  │ learned_patterns         │ pattern_name + description + trigger_keywords         │    │
│  │ error_lessons            │ error_signature + error_category + typical_causes     │    │
│  │ skills                   │ name + description + trigger_conditions               │    │
│  │ domain_knowledge         │ domain + key + value (for semantic KB search)         │    │
│  └──────────────────────────┴───────────────────────────────────────────────────────┘    │
│                                                                                          │
│  Embedding generation flow:                                                              │
│  1. Write row to table (with NULL embedding)                                             │
│  2. Queue embedding job to ecolife-2                                                     │
│  3. Background worker generates embedding via Ollama                                     │
│  4. Update row with embedding BLOB                                                       │
│  5. Sync to sqlite-vec virtual table                                                     │
│                                                                                          │
│  Cache strategy:                                                                         │
│  • embeddings_cache table prevents redundant generation                                  │
│  • Hash of text → check cache → generate only if miss                                   │
│  • Cache invalidated when source model changes                                           │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 10.3 Background Jobs Architecture

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                      BACKGROUND JOB ARCHITECTURE                                         │
│                                                                                          │
│  Dev Machine (lean@192.168.1.135)                    Agent Machine (ecolife-2)           │
│  ─────────────────────────────────                   ─────────────────────────           │
│                                                                                          │
│  ┌──────────────────────────────┐                     ┌──────────────────────────────┐   │
│  │  Job Queue (SQLite)          │                     │  Ollama Service              │   │
│  │  ├── pattern_extraction      │────────────────────▶│  ├── Embed (nomic-embed)     │   │
│  │  ├── error_analysis          │  HTTP API calls     │  ├── Reason (Gemma 4)        │   │
│  │  ├── skill_generation        │                     │  └── Assess quality          │   │
│  │  ├── consolidation           │                     │                              │   │
│  │  └── diagnostics             │                     │  Job Workers (Python)        │   │
│  └──────────────┬───────────────┘                     │  ├── Embed worker             │   │
│                 │                                       │  ├── Pattern abstractor      │   │
│                 │  SSH trigger                          │  └── Reflection generator    │   │
│                 └──────────────────────────────────────▶│                              │   │
│                                                         └──────────────────────────────┘   │
│                                                                                          │
│  Job execution flow:                                                                     │
│  1. Trigger condition met (error, N tasks, periodic)                                     │
│  2. Job queued in SQLite on dev machine                                                  │
│  3. SSH notification sent to ecolife-2 job worker                                        │
│  4. Worker reads job, calls Ollama for inference                                         │
│  5. Results written back to dev machine SQLite                                           │
│  6. Job marked complete                                                                  │
│                                                                                          │
│  Why run on ecolife-2?                                                                   │
│  • 32GB RAM available (vs limited on dev machine)                                        │
│  • Ollama already running 24/7                                                           │
│  • Prevents cognition jobs from blocking interactive tool calls                          │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 10.4 API Design for Cognition Tools

The `cognition-layer` MCP server exposes these tools:

| Tool | Category | Phase |
|------|----------|-------|
| `memory_remember` | Memory | 1 (extends memory-store) |
| `memory_recall` | Memory | 1 (extends memory-store) |
| `memory_forget` | Memory | 1 |
| `pattern_record` | Pattern | 2 |
| `pattern_suggest` | Pattern | 2 |
| `pattern_list` | Pattern | 2 |
| `pattern_delete` | Pattern | 2 |
| `skill_list` | Skill | 3 |
| `skill_learn_from_interaction` | Skill | 3 |
| `skill_get_documentation` | Skill | 3 |
| `performance_review` | Diagnostics | 4 |
| `self_assess` | Diagnostics | 4 |
| `cognition_health` | Diagnostics | 4 |
| `submit_feedback` | Feedback | 2 |
| `knowledge_query` | Knowledge | 3 |
| `knowledge_update` | Knowledge | 3 |

### 10.5 Privacy Considerations

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                           PRIVACY & RETENTION MODEL                                      │
│                                                                                          │
│  What IS stored:                                                                         │
│  • Tool call sequences and parameters (no PII)                                          │
│  • Error messages (anonymized)                                                          │
│  • User preferences and project conventions                                             │
│  • Reflections on task performance                                                      │
│  • Human corrections to agent output                                                    │
│                                                                                          │
│  What is NOT stored:                                                                     │
│  • File contents (only paths and metadata)                                              │
│  • Conversation content beyond task summaries                                            │
│  • API keys or credentials                                                              │
│  • Personal data                                                                        │
│                                                                                          │
│  Retention policy:                                                                       │
│  ┌────────────────────────┬────────────────┬─────────────────────────────────────────┐   │
│  │ Data type              │ Retention      │ Cleanup strategy                        │   │
│  ├────────────────────────┼────────────────┼─────────────────────────────────────────┤   │
│  │ Tool calls             │ 30 days active │ Nightly: compress >7d to weekly stats   │   │
│  │ Short-term patterns    │ 7 days         │ Automatic expiration                    │   │
│  │ Long-term patterns     │ Permanent      │ Deprecation flagging, manual review     │   │
│  │ Error lessons          │ Permanent      │ Merge duplicates, archive <0.1 freq     │   │
│  │ Reflections            │ 90 days        │ Summarize old, keep lessons only        │   │
│  │ Corrections            │ 90 days        │ Extract patterns, archive raw data      │   │
│  │ Domain knowledge       │ Versioned      │ Auto-deprecate after validity period    │   │
│  │ Suggestions            │ 30 days        │ Archive implemented/ignored             │   │
│  │ Tool usage stats       │ 1 year         │ Monthly aggregation                     │   │
│  └────────────────────────┴────────────────┴─────────────────────────────────────────┘   │
│                                                                                          │
│  All data stays on local machines (lean + ecolife-2). Never leaves the LAN.             │
│  Backups via rclone to user's own Google Drive only.                                    │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 10.6 Integration with Existing Architecture

The cognition layer integrates cleanly with the existing agent-toolkit architecture:

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                    COGNITION LAYER INTEGRATION                                           │
│                                                                                          │
│  Existing servers:                          New cognition-layer server:                  │
│  ┌──────────────┐  ┌──────────────┐         ┌──────────────────────────────────────┐    │
│  │ memory-store │  │ solar-calc   │         │ cognition-layer                      │    │
│  │ (Week 2)     │  │ (domain)     │         │ ──────────────────                   │    │
│  └──────┬───────┘  └──────┬───────┘         │ • Extends memory with semantic search│    │
│         │                  │                  │ • Adds pattern recognition           │    │
│         └──────────────────┘                  │ • Adds skill evolution               │    │
│                    │                          │ • Adds self-diagnostics              │    │
│                    ▼                          │ • Adds feedback collection           │    │
│         ┌──────────────────┐                 │ • Adds knowledge accumulation        │    │
│         │  Shared SQLite   │                 └──────────────────┬───────────────────┘    │
│         │  (~/.agent-toolkit/context.db)                         │                      │
│         │  (existing tables)                                     │                      │
│         │  + reflections                                         │ reads/writes         │
│         │  + recent_patterns                                     │                      │
│         │  + learned_patterns                                    │                      │
│         │  + error_lessons                                       │                      │
│         │  + skills                                              │                      │
│         │  + parameter_performance                               │                      │
│         │  + corrections                                         │                      │
│         │  + domain_knowledge                                    │                      │
│         │  + suggestions                                         │                      │
│         └──────────────────┘                                     │                      │
│                    ▲                                             │                      │
│                    │                                             │ HTTP API              │
│         ┌──────────┴──────────┐                                  │                      │
│         │  ollama-bridge      │◄─────────────────────────────────┘                      │
│         │  (existing)         │  Embeddings + Reasoning via ecolife-2                     │
│         └─────────────────────┘                                                          │
│                                                                                          │
│  The cognition-layer server is a new MCP server that reads from and writes to the       │
│  same SQLite database as memory-store. It extends, rather than replaces, the existing   │
│  infrastructure. It calls ollama-bridge for embedding generation and reasoning tasks.   │
│                                                                                          │
│  CLI clients see new tools automatically through MCP discovery.                         │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 10.7 Performance Considerations

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                           PERFORMANCE OPTIMIZATIONS                                      │
│                                                                                          │
│  1. LAZY EMBEDDING                                                                       │
│     • Don't generate embeddings synchronously on every write                             │
│     • Queue embedding jobs, process in background on ecolife-2                           │
│     • Return immediately with embedding_generated=false, update later                    │
│                                                                                          │
│  2. CACHED SIMILARITY SEARCH                                                             │
│     • Cache frequent queries (LRU cache, 1000 entries)                                   │
│     • Invalidate cache on pattern/skill updates                                          │
│     • Use exact match for common lookups before vector search                            │
│                                                                                          │
│  3. BATCHED CONSOLIDATION                                                                │
│     • Don't analyze after every tool call                                                │
│     • Batch: process every 10 tool calls or every 5 minutes                              │
│     • Consolidation runs on ecolife-2, never blocks interactive use                      │
│                                                                                          │
│  4. SELECTIVE LEARNING                                                                   │
│     • Only learn from tasks with >0.6 quality score (avoid learning bad habits)          │
│     • Weight by implicit_score (high-retry tasks are unreliable teachers)                │
│     • Require minimum 3 occurrences for pattern promotion                                │
│                                                                                          │
│  5. MEMORY BUDGET                                                                        │
│     • Target: < 500MB SQLite + embeddings on dev machine                                 │
│     • Auto-archive: weekly compression of old tool calls                                 │
│     • Auto-vacuum: nightly VACUUM after archiving                                        │
│     • Vector storage: use sqlite-vec with IVFFlat index for ANN (approximate search)     │
│                                                                                          │
│  6. OLLAMA RESOURCE MANAGEMENT                                                           │
│     • cognition-layer jobs queue behind interactive requests                             │
│     • Batch embedding requests (max 50 texts per call)                                   │
│     • Use smaller model (nomic-embed) for embeddings, larger (Gemma) for reasoning       │
│     • Auto-scale: if ecolife-2 is busy, defer non-critical learning                      │
│                                                                                          │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## Summary: The Vision

The agent-toolkit cognition layer transforms AI agents from **stateless executors** into **learning systems**. After implementing all five phases:

1. **Agents remember** — Every tool call, every success, every failure is stored and retrievable
2. **Agents recognize patterns** — Common workflows are identified and suggested automatically
3. **Agents develop skills** — Repeated patterns become documented, reusable skills with optimized parameters
4. **Agents self-assess** — Performance is continuously monitored, with automatic improvement suggestions
5. **Agents accumulate knowledge** — Domain expertise grows over time, with versioning and cross-domain transfer
6. **Agents learn from humans** — Corrections and overrides are the highest-value training signals

The result: An agent that gets smarter with every interaction. One that doesn't repeat the same mistakes. One that knows your preferences, your projects, your patterns. An agent that feels less like a tool and more like a colleague who learns.

> **Key principle:** The agent doesn't need to be perfect. It needs to be *improving*. Every mistake is data. Every correction is a lesson. Every repeated task is a pattern waiting to be discovered.

---

**End of Document**
