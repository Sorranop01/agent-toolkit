# SAFETY_PROTOCOL.md — Agent-Toolkit Safety & Governance Protocol

> **Document Classification:** REQUIRED READING — ALL CONTRIBUTORS  
> **Version:** 1.0.0  
> **Last Updated:** 2025-01-01  
> **Owner:** AI Safety & Governance Officer  
> **Enforcement Status:** NON-NEGOTIABLE — Zero exceptions, zero exemptions, zero emergency overrides.  
> **Philosophy:** *"Slow but safe."*  

---

## TABLE OF CONTENTS

1. [Non-Negotiable Core Safety Principles](#1-core-safety-principles)
2. [Dry-Run Mode Specification](#2-dry-run-mode-specification)
3. [Confirmation Gate Matrix](#3-confirmation-gate-matrix)
4. [Git Safety Net](#4-git-safety-net)
5. [Memory Limits & Resource Governance](#5-memory-limits--resource-governance)
6. [Secret Management](#6-secret-management)
7. [Safety Implementation Rules](#7-safety-implementation-rules)
8. [Approval Levels](#8-approval-levels)
9. [Audit Trail](#9-audit-trail)
10. [Appendix A: Pre-Flight Checklist](#appendix-a-pre-flight-checklist)
11. [Appendix B: Emergency Procedures](#appendix-b-emergency-procedures)
12. [Appendix C: Glossary](#appendix-c-glossary)

---

## PREAMBLE

**Agent-toolkit** is a self-hosted MCP (Model Context Protocol) Server Hub deployed across:

| Environment | Host | Role | Resources |
|-------------|------|------|-----------|
| Development | `lean@192.168.1.135` | Dev server, testing, staging | Local dev |
| Production Workloads | `ecolife-2` | MCP server runtime, Ollama inference | 32 GB RAM |
| Consumers | Kimi, OpenCode, Goose | CLI-based LLM agents | N/A |

**Business Context:** This toolkit supports Solar O&M (Operations & Maintenance) and Health Franchise operations in Bangkok, Thailand. A mistaken file deletion, erroneous database update, or botched deployment has **direct financial impact** — lost service revenue, corrupted customer records, or downed monitoring systems. We do not have the luxury of "move fast and break things."

**Governance Scope:** Every tool registered via `@mcp.tool()`, every rclone sync, every database query, every model inference call, and every service deployment falls under this protocol. No exceptions. No shortcuts. No "just this once."

---

## 1. CORE SAFETY PRINCIPLES

These five principles are the non-negotiable foundation of all engineering work on agent-toolkit. They override convenience, speed, and personal preference in every decision.

### 1.1 Defense in Depth

> No single safety mechanism shall be the only thing preventing catastrophe.

Every destructive operation must pass **at least two independent safety checks** before execution. Examples of defense layers:

| Layer | Mechanism | What It Prevents |
|-------|-----------|------------------|
| 1 | `dry_run` default | Accidental execution by forgetful callers |
| 2 | `confirm` flag requirement | Scripts/LLMs auto-confirming without review |
| 3 | Git auto-stash | Irreversible data loss from file mutations |
| 4 | Approval level enforcement | Unauthorized operations by compromised agents |
| 5 | Audit logging | Undetected malicious or erroneous actions |
| 6 | Memory limits | Resource exhaustion / OOM cascading failures |

If a tool developer proposes a destructive tool with only one safety layer, the pull request is **automatically rejected** — no discussion, no exceptions.

### 1.2 Fail-Safe Defaults

> The default state of every parameter, configuration, and environment must be the SAFEST possible state.

Concrete rules:

- `dry_run: bool = True` — destructive tools default to simulation mode.
- `confirm: bool = False` — destructive tools default to REFUSING execution.
- `auto_stash: bool = True` — file mutations default to creating recovery points.
- `max_memory_mb` — defaults to the LOWEST safe value, not the highest available.
- `.env` variables — if a secret is missing, the server **fails to start** rather than running with a placeholder.
- Log level — defaults to `DEBUG` in development, `INFO` in production. Never `WARNING` or higher by default (we want visibility).

### 1.3 Explicit Confirmation for Irreversible Actions

> Any operation that cannot be undone with a single command must require explicit, named confirmation.

Irreversible actions include but are not limited to:

- File deletion (even to trash/recycle bin — we treat `rm` as permanent)
- Database `DELETE` or `DROP` operations
- Database `UPDATE` without a `WHERE` clause (or with a broad `WHERE`)
- `rclone sync` to remote (overwrites destination)
- Service deployment / restart (interrupts active users)
- Git push to protected branches
- Model configuration changes that affect inference output

The confirmation **must not** be a generic `"Are you sure?"` prompt. It must name the specific operation, the specific targets, and the blast radius estimate.

### 1.4 Opt-In Dangerous

> No tool shall be dangerous by accident. Danger must be an explicit, conscious, documented choice.

Every tool that can cause harm must:

1. Be explicitly tagged with `dangerous=True` in the safety registry.
2. Have its blast radius documented in the docstring.
3. Require the caller to set `dry_run=False` AND `confirm=True` — two explicit opt-in gestures.
4. Log at `WARNING` level on every call, even dry runs.
5. Be listed in the "Dangerous Tools Inventory" section of server startup logs.

A tool that mutates state without being registered as dangerous is a **critical bug**, regardless of whether it has caused harm yet.

### 1.5 Blast Radius Reduction

> Every operation must affect the minimum necessary scope. When in doubt, refuse.

Concrete rules:

- **File patterns:** `*` and `**` glob patterns require `user+git` approval level, no exceptions.
- **Database queries:** `UPDATE` and `DELETE` without explicit `WHERE` clauses are **rejected at the tool boundary** — the tool must build the `WHERE` clause from provided filters, never accept raw SQL.
- **rclone operations:** `--include` and `--exclude` filters are mandatory. No unfiltered syncs.
- **Service restarts:** Must target a specific service by exact name. No "restart all" operation exists.
- **Memory allocation:** Each MCP server has a hard `MAX_MEMORY_MB` ceiling. The sum of all ceilings must leave at least 8 GB headroom on `ecolife-2`.

---

## 2. DRY-RUN MODE SPECIFICATION

### 2.1 Universal Dry-Run Requirement

**Every destructive tool MUST implement a `dry_run: bool = True` parameter.** This is the first and most important line of defense. Dry-run mode shows exactly what WOULD happen without executing the operation.

### 2.2 What Constitutes "Destructive"

A tool is **destructive** if it:

- Creates, modifies, moves, or deletes files or directories
- Inserts, updates, or deletes database records
- Modifies running service state (start, stop, restart, deploy)
- Transfers data to remote destinations (rclone sync, push, copy)
- Modifies Git state (commit, push, merge, rebase, reset)
- Consumes significant memory or CPU (model loading, batch inference)

**A tool is NON-destructive only if it:**

- Reads files or data without modification
- Lists directory contents
- Queries (but does not modify) databases
- Generates text or code without writing to disk
- Sends read-only informational notifications

### 2.3 Dry-Run Output Format

Dry-run output MUST follow the colored diff convention:

| Color | Meaning | JSON Field |
|-------|---------|------------|
| 🔴 Red | Would be DELETED | `"would_delete": [...]` |
| 🟢 Green | Would be CREATED | `"would_create": [...]` |
| 🟡 Yellow | Would be MODIFIED | `"would_modify": [...]` |
| 🔵 Blue | Would be READ (for reference) | `"would_read": [...]` |
| ⚪ Gray | No change | `"unchanged": [...]` |

### 2.4 Implementation Pattern (Python)

```python
"""
Safety Protocol Implementation Pattern
Every destructive MCP tool must follow this exact pattern.
"""

from dataclasses import dataclass
from enum import Enum
from typing import List, Dict, Any, Optional
import glob
import json
from datetime import datetime


class SafetyError(Exception):
    """Raised when a safety check fails. Operation is aborted."""
    pass


class BlastRadius(str, Enum):
    NONE = "none"           # Read-only, no risk
    LOW = "low"             # Single file, easily recoverable
    MEDIUM = "medium"       # Multiple files or one important file
    HIGH = "high"           # Directory, database table, or service
    CRITICAL = "critical"   # Broad pattern, entire database, production service


@dataclass
class DryRunResult:
    """Standardized dry-run output structure."""
    would_create: List[str]
    would_delete: List[str]
    would_modify: List[str]
    would_read: List[str]
    unchanged: List[str]
    blast_radius: BlastRadius
    estimated_recovery_time_minutes: int
    summary: str

    def to_dict(self) -> Dict[str, Any]:
        return {
            "would_create": self.would_create,
            "would_delete": self.would_delete,
            "would_modify": self.would_modify,
            "would_read": self.would_read,
            "unchanged": self.unchanged,
            "blast_radius": self.blast_radius.value,
            "estimated_recovery_time_minutes": self.estimated_recovery_time_minutes,
            "summary": self.summary,
        }


# ---------------------------------------------------------------------------
# PATTERN: Destructive tool with mandatory dry-run
# ---------------------------------------------------------------------------

@mcp.tool()
def delete_files(
    pattern: str,
    dry_run: bool = True,      # SAFE DEFAULT: simulate only
    confirm: bool = False,      # SAFE DEFAULT: refuse unless explicitly confirmed
    git_checkpoint: bool = True # SAFE DEFAULT: stash before any mutation
) -> Dict[str, Any]:
    """
    Delete files matching a glob pattern.

    BLAST RADIUS: HIGH — File deletion is irreversible without git recovery.
    AFFECTED: Filesystem state.
    RECOVERY: Git stash pop (if checkpointed) or backup restore.

    Args:
        pattern: Glob pattern of files to delete (e.g., "*.tmp", "logs/*")
        dry_run: If True (default), show what would be deleted without deleting.
        confirm: Must be True for actual deletion. SafetyError raised otherwise.
        git_checkpoint: If True (default), auto-stash before deletion.

    Returns:
        Dry-run report or execution result with deleted file list.
    """
    # ---- STEP 1: Enumerate targets (always) ------------------------------
    targets = glob.glob(pattern, recursive=True)

    # ---- STEP 2: Blast radius assessment ---------------------------------
    blast_radius = (
        BlastRadius.CRITICAL if "**" in pattern or "*" in pattern
        else BlastRadius.HIGH if len(targets) > 10
        else BlastRadius.MEDIUM if len(targets) > 1
        else BlastRadius.LOW
    )

    # CRITICAL blast radius requires user+git approval
    if blast_radius == BlastRadius.CRITICAL:
        required_level = ApprovalLevel.USER_PLUS_GIT
    elif blast_radius == BlastRadius.HIGH:
        required_level = ApprovalLevel.USER
    else:
        required_level = ApprovalLevel.USER

    # ---- STEP 3: DRY RUN (default path) ----------------------------------
    if dry_run:
        return {
            "mode": "DRY_RUN",
            "pattern": pattern,
            "matches": len(targets),
            "targets": targets,
            "blast_radius": blast_radius.value,
            "required_approval": required_level.value,
            "message": f"Would delete {len(targets)} file(s) matching '{pattern}'",
            "detail": DryRunResult(
                would_create=[],
                would_delete=targets,
                would_modify=[],
                would_read=[],
                unchanged=[],
                blast_radius=blast_radius,
                estimated_recovery_time_minutes=30 if targets else 0,
                summary=f"DELETE operation: {len(targets)} file(s) matched pattern '{pattern}'"
            ).to_dict()
        }

    # ---- STEP 4: CONFIRMATION GATE ---------------------------------------
    if not confirm:
        raise SafetyError(
            f"CONFIRMATION REQUIRED: delete_files(pattern='{pattern}') "
            f"would affect {len(targets)} file(s). "
            f"Set confirm=True to proceed. "
            f"Run with dry_run=True first to preview."
        )

    # ---- STEP 5: GIT SAFETY NET ------------------------------------------
    if git_checkpoint:
        stash_hash = _auto_stash(f"pre-delete-{pattern}-{datetime.utcnow().isoformat()}")
    else:
        stash_hash = None
        # Log warning: git checkpoint skipped
        audit_log.warning("delete_files: git_checkpoint=False, proceeding without stash")

    # ---- STEP 6: EXECUTE (only after all gates pass) ---------------------
    deleted = []
    failed = []
    for path in targets:
        try:
            _safe_delete(path)  # Your actual deletion logic
            deleted.append(path)
        except Exception as e:
            failed.append({"path": path, "error": str(e)})

    # ---- STEP 7: AUDIT LOG -----------------------------------------------
    audit.record(
        tool="delete_files",
        parameters={"pattern": pattern, "dry_run": False, "confirm": True},
        targets=targets,
        result={"deleted": deleted, "failed": failed},
        stash_hash=stash_hash,
        timestamp=datetime.utcnow(),
    )

    return {
        "mode": "EXECUTED",
        "deleted": deleted,
        "failed": failed,
        "count": len(deleted),
        "stash_hash": stash_hash,
        "recovery_command": f"git stash pop {stash_hash}" if stash_hash else "No stash created"
    }
```

### 2.5 Dry-Run Checklist for Tool Developers

- [ ] Does the tool have `dry_run: bool = True` parameter?
- [ ] Does dry-run enumerate ALL targets before any action?
- [ ] Does dry-run output include blast radius assessment?
- [ ] Does dry-run output use the colored diff format (would_create/would_delete/would_modify)?
- [ ] Does dry-run include estimated recovery time?
- [ ] Is the dry-run result returned as a structured dict (not just printed)?
- [ ] If no targets match, does dry-run say so explicitly (not silently return empty)?
- [ ] Is the dry-run path tested with at least 3 unit tests (zero matches, single match, broad pattern)?

---

## 3. CONFIRMATION GATE MATRIX

The following matrix is **law**. Every tool must be classified against this matrix at registration time. The safety wrapper enforces these gates automatically.

### 3.1 The Matrix

| Operation Type | Dry-Run Required | Confirm Required | Git Safety | Approval Level | Rationale |
|:--------------|:----------------:|:----------------:|:----------:|:--------------|:----------|
| File read | No | No | No | `auto` | Read-only, zero blast radius |
| File write (new) | Yes | No | Yes | `auto` | Creates but doesn't destroy; git recovers if overwrite occurs |
| File overwrite | Yes | **Yes** | Yes | `user` | Destroys existing content; requires explicit consent |
| File delete | Yes | **Yes** | Yes | `user+git` | Irreversible without backup; double protection required |
| DB insert | Yes | No | Yes | `auto` | Additive only; rollback via transaction log if needed |
| DB update | Yes | **Yes** | Yes | `user` | Modifies existing data; confirmation prevents bad WHERE clause |
| DB delete | Yes | **Yes** | Yes | `user+git` | Irreversible; strictest protection |
| DB schema change | Yes | **Yes** | **Yes** | `user+git` | Can destroy tables/columns; manual approval only |
| Deploy / restart service | Yes | **Yes** | No | `user` | Service interruption; affects active users |
| Service stop (no restart) | Yes | **Yes** | No | `user` | Explicit downtime; must be intentional |
| rclone sync TO remote | Yes | **Yes** | No | `user` | Overwrites destination; data loss on remote side |
| rclone sync FROM remote | Yes | No | No | `auto` | Read-only for remote; note: still destructive locally if target exists |
| rclone copy (any direction) | Yes | No | No | `auto` | Non-destructive; destination files preserved |
| Git commit | No | No | auto-stash | `auto` | Local only; auto-stash for recovery |
| Git push | No | **Yes** | No | `user` | Published to shared history; requires explicit intent |
| Git reset / checkout | Yes | **Yes** | **Yes** | `user+git` | Can destroy uncommitted work |
| Send notification | No | No | No | `auto` | Read-only informational; no state mutation |
| LLM inference | No | No | No | `auto` | Computational only; memory limit enforced separately |
| LLM model load | No | No | No | `auto` | Memory guardrail enforced; unload-before-load policy |
| Environment variable change | Yes | **Yes** | No | `user` | Affects all subsequent operations |
| User / permission change | Yes | **Yes** | **Yes** | `user+git` | Security-critical; highest protection |

### 3.2 Notes on the Matrix

**"rclone sync FROM remote" caveat:** While reading from remote is non-destructive to the remote, it CAN overwrite local files. If the local target directory contains existing files that would be overwritten, the operation is elevated to `user` approval level. The safety wrapper must detect this collision and upgrade the gate.

**"Git commit" auto-stash:** Before any file mutation that triggers a git commit, an auto-stash is created with the message `pre-commit-auto-<timestamp>`. This stash is NOT popped automatically — it remains as a recovery point for 30 days.

**"DB schema change" definition:** Any operation that modifies table structure — `CREATE TABLE`, `ALTER TABLE`, `DROP TABLE`, `CREATE INDEX`, `DROP INDEX`, etc. These are the most dangerous database operations and require the highest protection level.

### 3.3 Matrix Enforcement in Code

```python
# ---------------------------------------------------------------------------
# Safety gate enforcement — used by the centralized safety wrapper
# ---------------------------------------------------------------------------

from enum import Enum
from typing import Callable, Any
from functools import wraps


class ApprovalLevel(str, Enum):
    AUTO = "auto"              # No human intervention
    USER = "user"              # CLI user must confirm
    USER_PLUS_GIT = "user+git" # User confirm + git checkpoint required


class OperationCategory(str, Enum):
    FILE_READ = "file_read"
    FILE_WRITE_NEW = "file_write_new"
    FILE_OVERWRITE = "file_overwrite"
    FILE_DELETE = "file_delete"
    DB_INSERT = "db_insert"
    DB_UPDATE = "db_update"
    DB_DELETE = "db_delete"
    DB_SCHEMA_CHANGE = "db_schema_change"
    DEPLOY_RESTART = "deploy_restart"
    SERVICE_STOP = "service_stop"
    RCLONE_SYNC_TO = "rclone_sync_to"
    RCLONE_SYNC_FROM = "rclone_sync_from"
    RCLONE_COPY = "rclone_copy"
    GIT_COMMIT = "git_commit"
    GIT_PUSH = "git_push"
    GIT_RESET = "git_reset"
    SEND_NOTIFICATION = "send_notification"
    LLM_INFERENCE = "llm_inference"
    LLM_MODEL_LOAD = "llm_model_load"
    ENV_CHANGE = "env_change"
    USER_PERMISSION_CHANGE = "user_permission_change"


# The matrix as machine-enforceable configuration
GATE_MATRIX: dict[OperationCategory, dict[str, Any]] = {
    OperationCategory.FILE_READ: {
        "dry_run_required": False,
        "confirm_required": False,
        "git_safety": False,
        "approval_level": ApprovalLevel.AUTO,
    },
    OperationCategory.FILE_WRITE_NEW: {
        "dry_run_required": True,
        "confirm_required": False,
        "git_safety": True,
        "approval_level": ApprovalLevel.AUTO,
    },
    OperationCategory.FILE_OVERWRITE: {
        "dry_run_required": True,
        "confirm_required": True,
        "git_safety": True,
        "approval_level": ApprovalLevel.USER,
    },
    OperationCategory.FILE_DELETE: {
        "dry_run_required": True,
        "confirm_required": True,
        "git_safety": True,
        "approval_level": ApprovalLevel.USER_PLUS_GIT,
    },
    OperationCategory.DB_INSERT: {
        "dry_run_required": True,
        "confirm_required": False,
        "git_safety": True,
        "approval_level": ApprovalLevel.AUTO,
    },
    OperationCategory.DB_UPDATE: {
        "dry_run_required": True,
        "confirm_required": True,
        "git_safety": True,
        "approval_level": ApprovalLevel.USER,
    },
    OperationCategory.DB_DELETE: {
        "dry_run_required": True,
        "confirm_required": True,
        "git_safety": True,
        "approval_level": ApprovalLevel.USER_PLUS_GIT,
    },
    OperationCategory.DB_SCHEMA_CHANGE: {
        "dry_run_required": True,
        "confirm_required": True,
        "git_safety": True,
        "approval_level": ApprovalLevel.USER_PLUS_GIT,
    },
    OperationCategory.DEPLOY_RESTART: {
        "dry_run_required": True,
        "confirm_required": True,
        "git_safety": False,
        "approval_level": ApprovalLevel.USER,
    },
    OperationCategory.SERVICE_STOP: {
        "dry_run_required": True,
        "confirm_required": True,
        "git_safety": False,
        "approval_level": ApprovalLevel.USER,
    },
    OperationCategory.RCLONE_SYNC_TO: {
        "dry_run_required": True,
        "confirm_required": True,
        "git_safety": False,
        "approval_level": ApprovalLevel.USER,
    },
    OperationCategory.RCLONE_SYNC_FROM: {
        "dry_run_required": True,
        "confirm_required": False,
        "git_safety": False,
        "approval_level": ApprovalLevel.AUTO,
        # NOTE: Elevated to USER if local collision detected
    },
    OperationCategory.RCLONE_COPY: {
        "dry_run_required": True,
        "confirm_required": False,
        "git_safety": False,
        "approval_level": ApprovalLevel.AUTO,
    },
    OperationCategory.GIT_COMMIT: {
        "dry_run_required": False,
        "confirm_required": False,
        "git_safety": True,  # auto-stash
        "approval_level": ApprovalLevel.AUTO,
    },
    OperationCategory.GIT_PUSH: {
        "dry_run_required": False,
        "confirm_required": True,
        "git_safety": False,
        "approval_level": ApprovalLevel.USER,
    },
    OperationCategory.GIT_RESET: {
        "dry_run_required": True,
        "confirm_required": True,
        "git_safety": True,
        "approval_level": ApprovalLevel.USER_PLUS_GIT,
    },
    OperationCategory.SEND_NOTIFICATION: {
        "dry_run_required": False,
        "confirm_required": False,
        "git_safety": False,
        "approval_level": ApprovalLevel.AUTO,
    },
    OperationCategory.LLM_INFERENCE: {
        "dry_run_required": False,
        "confirm_required": False,
        "git_safety": False,
        "approval_level": ApprovalLevel.AUTO,
    },
    OperationCategory.LLM_MODEL_LOAD: {
        "dry_run_required": False,
        "confirm_required": False,
        "git_safety": False,
        "approval_level": ApprovalLevel.AUTO,
    },
    OperationCategory.ENV_CHANGE: {
        "dry_run_required": True,
        "confirm_required": True,
        "git_safety": False,
        "approval_level": ApprovalLevel.USER,
    },
    OperationCategory.USER_PERMISSION_CHANGE: {
        "dry_run_required": True,
        "confirm_required": True,
        "git_safety": True,
        "approval_level": ApprovalLevel.USER_PLUS_GIT,
    },
}


def enforce_gate_matrix(category: OperationCategory, **call_params) -> None:
    """
    Enforce the confirmation gate matrix for a given operation.
    Called automatically by the safety wrapper before tool execution.
    Raises SafetyError if any gate check fails.
    """
    config = GATE_MATRIX.get(category)
    if not config:
        raise SafetyError(f"Unknown operation category: {category}")

    # Check dry-run requirement
    if config["dry_run_required"] and call_params.get("dry_run", True):
        raise SafetyError(
            f"{category.value}: dry_run=True required for first call. "
            "Review the dry-run output, then call again with dry_run=False."
        )

    # Check confirmation requirement
    if config["confirm_required"] and not call_params.get("confirm", False):
        raise SafetyError(
            f"{category.value}: confirm=True required. "
            "This is a destructive operation. Review the dry-run output and confirm."
        )

    # Check git safety
    if config["git_safety"] and not call_params.get("git_checkpoint", True):
        # This is a warning-level enforcement — we still allow override but log loudly
        audit_log.warning(
            f"{category.value}: git_checkpoint=False — proceeding without safety net"
        )
```

---

## 4. GIT SAFETY NET

### 4.1 Philosophy

> Every file mutation creates a recoverable checkpoint. No exception.

Git is our safety net of last resort. Before any tool modifies, deletes, or overwrites a file under Git tracking, an automatic stash is created. This is not optional. It is not configurable at the tool level. It happens automatically in the safety wrapper.

### 4.2 Auto-Stash Protocol

```python
import subprocess
import hashlib
from datetime import datetime
from typing import Optional


def _auto_stash(context: str) -> Optional[str]:
    """
    Create a git stash checkpoint before file mutation.
    Returns the stash hash for recovery, or None if not in a git repo.
    """
    # Check if we're in a git repository
    result = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],
        capture_output=True, text=True
    )
    if result.returncode != 0:
        return None  # Not a git repo — skip stash but log warning

    # Generate a descriptive stash message
    timestamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
    stash_message = f"auto-stash-{context}-{timestamp}"

    # Stash ALL changes including untracked files
    stash_result = subprocess.run(
        ["git", "stash", "push", "-u", "-m", stash_message],
        capture_output=True, text=True
    )

    if stash_result.returncode != 0:
        raise SafetyError(f"Auto-stash failed: {stash_result.stderr}")

    # Get the stash hash for recovery reference
    hash_result = subprocess.run(
        ["git", "rev-parse", "refs/stash"],
        capture_output=True, text=True
    )
    stash_hash = hash_result.stdout.strip() if hash_result.returncode == 0 else None

    # Log the checkpoint
    audit_log.info(f"Git checkpoint created: {stash_message} (hash: {stash_hash})")

    return stash_hash


def recover_from_stash(stash_hash: str) -> dict:
    """
    Recover files from a previous stash.
    This is the undo button for any file mutation.
    """
    # Pop the specific stash
    result = subprocess.run(
        ["git", "stash", "pop", stash_hash],
        capture_output=True, text=True
    )

    success = result.returncode == 0
    return {
        "recovered": success,
        "stash_hash": stash_hash,
        "output": result.stdout if success else result.stderr,
        "timestamp": datetime.utcnow().isoformat(),
    }
```

### 4.3 Stash Retention Policy

| Environment | Retention | Cleanup Command | Notes |
|-------------|-----------|-----------------|-------|
| Development (`lean@192.168.1.135`) | 7 days | `git stash clear` on Sundays at 00:00 | Aggressive cleanup — dev churn is high |
| Production (`ecolife-2`) | 30 days | Manual review + purge | Conservative — these are real changes |
| CI/CD | 0 days (immediate) | N/A | CI uses temp repos; stashes not needed |

**Automatic cleanup cron:**

```bash
# /etc/cron.d/agent-toolkit-stash-cleanup
# Runs every Sunday at midnight
0 0 * * 0 lean cd /home/lean/agent-toolkit && git stash list --format='%H %gd %ci' | \
    awk '$3 < "'$(date -d '7 days ago' +%Y-%m-%d)'" {print $1}' | \
    xargs -r -I {} git stash drop {}
```

### 4.4 Branch Protection Recommendations

```
Repository: agent-toolkit
Branch: main (production)

Protection Rules:
- Require pull request reviews before merging: 1 reviewer minimum
- Require status checks to pass before merging: tests + safety-check
- Require conversation resolution before merging
- Include administrators in restrictions: YES (no one is above the rules)
- Allow force pushes: NEVER
- Allow deletions: NEVER
- Require signed commits: RECOMMENDED (for production deployments)

Branch: develop (integration)
- Require pull request reviews: 1 reviewer
- Require status checks: tests only
- Allow force pushes: NO
- Allow deletions: NO
```

### 4.5 Recovery Procedures

**Scenario 1: Accidental file deletion by MCP tool**

```bash
# Step 1: Identify the stash
$ git stash list
stash@{0}: auto-stash-pre-delete-logs/*.log-20250101-120000
stash@{1}: auto-stash-pre-commit-20250101-110000

# Step 2: Inspect before recovering
$ git stash show -p stash@{0} | head -20

# Step 3: Recover
$ git stash pop stash@{0}

# Step 4: Verify
$ ls -la recovered-files/
```

**Scenario 2: MCP tool overwrite corrupts working files**

```bash
# Step 1: Stop all MCP servers immediately
$ ./scripts/emergency-stop.sh

# Step 2: Recover from stash
$ git stash pop

# Step 3: Inspect changes
$ git status
$ git diff

# Step 4: Restart MCP servers
$ ./scripts/start-servers.sh --with-safety-checks
```

**Scenario 3: Git stash itself is corrupted or missing**

```bash
# Last resort: use git reflog
$ git reflog | head -20
# Find the commit hash before the mutation
$ git reset --hard <commit-hash>
```

### 4.6 Git Safety Checklist

- [ ] Auto-stash is called in the safety wrapper before EVERY file mutation?
- [ ] Stash includes untracked files (`-u` flag)?
- [ ] Stash message is descriptive (includes tool name, timestamp, context)?
- [ ] Stash hash is returned to caller and logged to audit trail?
- [ ] Recovery procedure is documented and tested monthly?
- [ ] Branch protection rules are active on `main`?
- [ ] `main` branch force-push is physically impossible?
- [ ] Stash cleanup cron is active and monitored?
- [ ] Emergency stop script is tested and known to all operators?

---

## 5. MEMORY LIMITS & RESOURCE GOVERNANCE

### 5.1 Hardware Context

`ecolife-2` runs ALL MCP servers plus Ollama inference with **32 GB RAM**. This is generous but not infinite. A single unconstrained model load can consume 16+ GB, leaving the system starved.

### 5.2 MAX_MEMORY_MB Environment Variable

Every MCP server MUST read a `MAX_MEMORY_MB` environment variable at startup. If unset, the server **fails to start** (fail-safe default is to refuse, not to guess).

```python
import os
import psutil


def get_memory_limit() -> int:
    """
    Read the hard memory ceiling for this MCP server.
    Fails if not set — no guessing, no defaults.
    """
    max_memory = os.environ.get("MAX_MEMORY_MB")
    if not max_memory:
        raise SafetyError(
            "MAX_MEMORY_MB is not set. Server refused to start. "
            "Set MAX_MEMORY_MB in .env file (see .env.template). "
            "Example: MAX_MEMORY_MB=2048"
        )
    try:
        return int(max_memory)
    except ValueError:
        raise SafetyError(f"MAX_MEMORY_MB must be an integer, got: {max_memory}")


def enforce_memory_limit(limit_mb: int) -> None:
    """
    Set a hard memory limit using Linux cgroups / rlimit.
    Called at server startup.
    """
    import resource
    limit_bytes = limit_mb * 1024 * 1024
    resource.setrlimit(resource.RLIMIT_AS, (limit_bytes, limit_bytes))
    audit_log.info(f"Memory limit set: {limit_mb} MB ({limit_bytes} bytes)")
```

### 5.3 Ollama Model Loading Constraints

**Total system memory budget for `ecolife-2` (32 GB):**

| Allocation | Memory | Notes |
|------------|--------|-------|
| System overhead | 2 GB | OS, SSH, monitoring agents |
| MCP servers (combined) | 8 GB | All running MCP servers at MAX_MEMORY_MB |
| Ollama headroom | 8 GB | Reserved, never allocated |
| Ollama active model | up to 14 GB | One model at a time |
| **Total** | **32 GB** | Hard ceiling |

**The 8 GB headroom is sacred.** It is never allocated. It exists to prevent OOM kills during memory spikes, temporary file caching, and concurrent operations.

### 5.4 Model Switching Strategy

```python
import subprocess
import time


def switch_model(new_model: str) -> dict:
    """
    Atomic model switch: unload current, then load new.
    Never load two models simultaneously.
    """
    # Step 1: Check available memory
    available = get_available_memory_mb()
    required = get_model_memory_requirement(new_model)

    if available + get_current_model_memory_mb() < required + 1024:  # 1 GB buffer
        raise SafetyError(
            f"Cannot switch to {new_model}: requires ~{required} MB, "
            f"but only ~{available + get_current_model_memory_mb()} MB "
            f"would be available after unload. Need 1 GB buffer."
        )

    # Step 2: Unload current model FIRST
    current = get_loaded_model()
    if current:
        audit_log.info(f"Unloading model: {current}")
        subprocess.run(["ollama", "rm", current], check=False)
        # Wait for memory to be freed
        time.sleep(2)
        _wait_for_memory(target_mb=required + 8192, timeout=60)  # headroom check

    # Step 3: Load new model
    audit_log.info(f"Loading model: {new_model}")
    subprocess.run(["ollama", "pull", new_model], check=True)
    load_result = subprocess.run(
        ["ollama", "run", new_model, "--quiet", "echo 'model loaded'"],
        capture_output=True, text=True, timeout=300
    )

    if load_result.returncode != 0:
        raise SafetyError(f"Model {new_model} failed to load: {load_result.stderr}")

    return {
        "previous_model": current,
        "new_model": new_model,
        "memory_used_mb": get_model_memory_requirement(new_model),
        "available_mb": get_available_memory_mb(),
    }


def get_available_memory_mb() -> int:
    """Get currently available system memory in MB."""
    mem = psutil.virtual_memory()
    return int(mem.available / 1024 / 1024)


def _wait_for_memory(target_mb: int, timeout: int = 60) -> bool:
    """Wait until available memory reaches target."""
    for _ in range(timeout):
        if get_available_memory_mb() >= target_mb:
            return True
        time.sleep(1)
    raise SafetyError(f"Memory did not free up to {target_mb} MB within {timeout}s")
```

### 5.5 Memory Monitoring & Alerting

```python
import threading
import time


def memory_monitor_daemon(check_interval_sec: int = 10):
    """
    Background thread that monitors system memory.
    Triggers alerts at warning and critical thresholds.
    """
    while True:
        mem = psutil.virtual_memory()
        available_mb = mem.available / 1024 / 1024
        total_mb = mem.total / 1024 / 1024
        used_percent = mem.percent

        # Alert at 85% usage
        if used_percent > 85:
            audit_log.warning(
                f"MEMORY WARNING: {used_percent:.1f}% used "
                f"({available_mb:.0f} MB available of {total_mb:.0f} MB)"
            )
            # Notify operators
            send_alert(f"Memory usage at {used_percent:.1f}% on ecolife-2")

        # Critical at 92% — trigger emergency unload
        if used_percent > 92:
            audit_log.critical(
                f"MEMORY CRITICAL: {used_percent:.1f}% used! "
                f"Triggering emergency model unload."
            )
            emergency_memory_release()

        time.sleep(check_interval_sec)


def emergency_memory_release():
    """
    Emergency procedure: unload the current Ollama model immediately
    to free memory and prevent system OOM.
    """
    current = get_loaded_model()
    if current:
        audit_log.critical(f"EMERGENCY: Unloading model {current} to free memory")
        subprocess.run(["ollama", "rm", current], check=False)
        # Also trigger garbage collection in Python processes
        import gc
        gc.collect()
```

### 5.6 OOM Killer Precedence Configuration

The Linux OOM killer must prioritize killing MCP tool processes over system services and Ollama. Configure via `/proc` or systemd:

```bash
# /etc/sysctl.d/99-agent-toolkit-oom.conf
# Lower score = less likely to be killed
# Higher score = more likely to be killed

# System services: untouchable
vm.oom_kill_allocating_task = 0

# Process OOM scores (configured via systemd or /proc/[pid]/oom_score_adj)
# sshd: -1000 (never kill)
# ollama: -500 (strongly prefer survival)
# monitoring: -100
# mcp-servers: 100 (preferential kill target if memory exhausted)
# mcp-tools: 500 (first to die in OOM situation)
```

```systemd
# /etc/systemd/system/mcp-server@.service
[Service]
OOMScoreAdjust=100
MemoryMax={{ MAX_MEMORY_MB }}M
MemorySwapMax=0
# No swap — we want OOM to kill the process, not swap-thrash the system
```

### 5.7 Memory Limits Checklist

- [ ] Every MCP server reads `MAX_MEMORY_MB` at startup and refuses to start if unset?
- [ ] Sum of all `MAX_MEMORY_MB` values across servers is <= 8 GB (leaving 8 GB headroom + 14 GB for Ollama + 2 GB system)?
- [ ] Model switching unloads BEFORE loading (never two models simultaneously)?
- [ ] Memory monitor daemon runs on `ecolife-2` with 10-second checks?
- [ ] Alert fires at 85% memory usage?
- [ ] Emergency unload triggers at 92% memory usage?
- [ ] OOM scores configured so MCP tool processes die before Ollama and system services?
- [ ] Swap is disabled or severely limited to prevent thrashing?
- [ ] `psutil` is available in all MCP server Python environments?

---

## 6. SECRET MANAGEMENT

### 6.1 Zero Hardcoded Secrets — EVER

> The presence of a hardcoded secret in source code is a **Severity-1 security incident**.

This is absolute. No exceptions for "development convenience," no `TODO: move to env var`, no `placeholder_key_123` that somehow makes it to production. A hardcoded secret means:

1. Immediate PR rejection
2. Incident report filed
3. Secret is considered compromised and MUST be rotated
4. Contributor receives documented warning

### 6.2 .env File Strategy

```
Repository Structure:
agent-toolkit/
├── .env                  # NEVER COMMITTED — .gitignored
├── .env.template         # COMMITTED — shows all required variables
├── .env.example          # COMMITTED — example values (not real secrets)
├── .gitignore            # MUST include .env and *.env
└── src/
    └── config.py         # Loads from .env via python-dotenv
```

### 6.3 .env.template (Reference Document)

```bash
# =============================================================================
# AGENT-TOOLKIT ENVIRONMENT CONFIGURATION
# =============================================================================
# Copy this file to .env and fill in real values.
# NEVER commit .env to Git.
# =============================================================================

# ---------------------------------------------------------------------------
# MEMORY GOVERNANCE
# ---------------------------------------------------------------------------
# Hard memory ceiling for this MCP server instance (MB)
# Sum across all servers must leave 8 GB headroom on ecolife-2 (32 GB total)
# Example: 2048 = 2 GB per server
MAX_MEMORY_MB=2048

# ---------------------------------------------------------------------------
# OLLAMA CONFIGURATION
# ---------------------------------------------------------------------------
# Host where Ollama is running
OLLAMA_HOST=http://localhost:11434
# Default model for inference (must be pulled before use)
OLLAMA_DEFAULT_MODEL=llama3.2
# Maximum model memory footprint (MB) — prevents loading oversized models
OLLAMA_MAX_MODEL_MB=14336

# ---------------------------------------------------------------------------
# DATABASE CONNECTION
# ---------------------------------------------------------------------------
# Database connection string — use least-privilege user
# Format: postgresql://user:password@host:port/database
# WARNING: This connection should have read-only permissions unless
# the server is explicitly authorized for mutations.
DATABASE_URL=postgresql://mcp_readonly:CHANGEME@localhost:5432/agent_toolkit
# For write-enabled servers:
DATABASE_WRITE_URL=postgresql://mcp_write:CHANGEME@localhost:5432/agent_toolkit

# ---------------------------------------------------------------------------
# RCLONE / CLOUD STORAGE
# ---------------------------------------------------------------------------
# rclone remote name (configured via `rclone config`)
RCLONE_REMOTE_NAME=my-remote
# rclone remote path prefix
RCLONE_REMOTE_PREFIX=backups/agent-toolkit
# rclone bandwidth limit (e.g., "1M" for 1 MB/s)
RCLONE_BANDWIDTH_LIMIT=1M
# rclone config file path (if non-default)
RCLONE_CONFIG_PATH=/home/lean/.config/rclone/rclone.conf

# ---------------------------------------------------------------------------
# API KEYS & AUTHENTICATION
# ---------------------------------------------------------------------------
# MCP Server authentication (if enabled)
MCP_API_KEY=sk-atk-CHANGEME-64CHAR-RANDOM-STRING-HERE
# Admin API key (for sensitive operations)
MCP_ADMIN_API_KEY=sk-admin-CHANGEME-64CHAR-RANDOM-STRING-HERE

# ---------------------------------------------------------------------------
# NOTIFICATION SERVICES
# ---------------------------------------------------------------------------
# Slack webhook for alerts
SLACK_WEBHOOK_URL=https://hooks.slack.com/services/T00000000/B00000000/CHANGEME
# Email notification (SMTP)
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=alerts@yourdomain.com
SMTP_PASSWORD=CHANGEME
ALERT_RECIPIENT=ops@yourdomain.com

# ---------------------------------------------------------------------------
# MONITORING
# ---------------------------------------------------------------------------
# Audit log database path
AUDIT_LOG_PATH=/var/lib/agent-toolkit/audit.db
# Log level: DEBUG | INFO | WARNING | ERROR
LOG_LEVEL=INFO
# Log file path
LOG_FILE_PATH=/var/log/agent-toolkit/server.log

# ---------------------------------------------------------------------------
# DEPLOYMENT
# ---------------------------------------------------------------------------
# Deployment target host
DEPLOY_HOST=ecolife-2
DEPLOY_USER=deploy
DEPLOY_SSH_KEY_PATH=/home/lean/.ssh/deploy_ecolife2
# Service name for systemd operations
SYSTEMD_SERVICE_NAME=agent-toolkit
```

### 6.4 Secret Rotation Procedures

**Rotation Event Triggers:**

1. Any secret found in Git history (even if later removed)
2. Any contributor with secret access leaves the team
3. Every 90 days (scheduled rotation)
4. Any indication of unauthorized access
5. After any security incident

**Rotation Procedure:**

```bash
#!/bin/bash
# secret-rotate.sh — Procedure for rotating compromised secrets

STEP=1
SECRET_NAME=$1
OLD_VALUE=$2
NEW_VALUE=$3

echo "[$STEP] Generating new secret..."; ((STEP++))
NEW_SECRET=$(openssl rand -hex 32)

echo "[$STEP] Updating .env on dev (lean@192.168.1.135)..."; ((STEP++))
ssh lean@192.168.1.135 "sed -i 's/${OLD_VALUE}/${NEW_SECRET}/' ~/agent-toolkit/.env"

echo "[$STEP] Updating .env on prod (ecolife-2)..."; ((STEP++))
ssh deploy@ecolife-2 "sed -i 's/${OLD_VALUE}/${NEW_SECRET}/' /opt/agent-toolkit/.env"

echo "[$STEP] Restarting MCP servers..."; ((STEP++))
ssh deploy@ecolife-2 "sudo systemctl restart agent-toolkit@*"

echo "[$STEP] Verifying new secret is active..."; ((STEP++))
curl -H "Authorization: Bearer ${NEW_SECRET}" http://ecolife-2:8080/health

echo "[$STEP] Revoking old secret at external services..."; ((STEP++))
# e.g., rotate database password, regenerate API keys

echo "[$STEP] Recording rotation in audit log..."; ((STEP++))
echo "Secret ${SECRET_NAME} rotated at $(date)" >> /var/log/agent-toolkit/secret-rotations.log

echo "[$STEP] NOTIFICATION: Sending rotation alert..."; ((STEP++))
curl -X POST "$SLACK_WEBHOOK_URL" \
    -d '{"text":"Secret '"${SECRET_NAME}"' rotated at '$(date)'"}'
```

### 6.5 Secret Scanning in Pre-Commit Hooks

```yaml
# .pre-commit-config.yaml
repos:
  - repo: https://github.com/Yelp/detect-secrets
    rev: v1.5.0
    hooks:
      - id: detect-secrets
        args: ['--baseline', '.secrets.baseline']
        exclude: package.lock.json

  - repo: https://github.com/pre-commit/pre-commit-hooks
    rev: v4.5.0
    hooks:
      - id: check-added-large-files
      - id: check-merge-conflict
      - id: detect-private-key

  # Custom hook: scan for .env files
  - repo: local
    hooks:
      - id: no-env-files
        name: Prevent .env files from being committed
        entry: Found .env file — NEVER commit secrets!
        language: fail
        files: '\.env$'

      - id: no-hardcoded-passwords
        name: Scan for hardcoded password patterns
        entry: python scripts/scan_for_passwords.py
        language: system
        types: [python]
```

```python
# scripts/scan_for_passwords.py — Custom password scanner
import re
import sys

FORBIDDEN_PATTERNS = [
    r'password\s*=\s*["\'][^"\']+["\']',      # password = "something"
    r'api_key\s*=\s*["\'][^"\']+["\']',        # api_key = "something"
    r'secret\s*=\s*["\'][^"\']+["\']',         # secret = "something"
    r'token\s*=\s*["\'][^"\']+["\']',           # token = "something"
    r'sk-[a-zA-Z0-9]{20,}',                      # OpenAI-style key
    r'AKIA[0-9A-Z]{16}',                          # AWS access key
    r'ghp_[a-zA-Z0-9]{36}',                       # GitHub personal token
    r'xox[baprs]-[0-9a-zA-Z]{10,}',               # Slack token
]


def scan_file(path: str) -> list:
    """Scan a single file for hardcoded secrets."""
    findings = []
    with open(path, 'r') as f:
        for line_no, line in enumerate(f, 1):
            for pattern in FORBIDDEN_PATTERNS:
                if re.search(pattern, line, re.IGNORECASE):
                    findings.append((path, line_no, line.strip(), pattern))
    return findings


if __name__ == "__main__":
    findings = []
    for file_path in sys.argv[1:]:
        findings.extend(scan_file(file_path))

    if findings:
        print("SECRET VIOLATION: Hardcoded secrets detected!")
        for path, line_no, line, pattern in findings:
            print(f"  {path}:{line_no}: {line}")
        sys.exit(1)
    sys.exit(0)
```

### 6.6 Secret Management Checklist

- [ ] `.env` is in `.gitignore` and has NEVER been committed?
- [ ] `.env.template` exists and lists ALL required variables?
- [ ] `.env.template` has been updated when new variables are added?
- [ ] `python-dotenv` is used to load secrets at runtime?
- [ ] Application FAILS to start if a required secret is missing?
- [ ] Pre-commit hooks block commits of `.env` files?
- [ ] Pre-commit hooks scan for hardcoded secret patterns?
- [ ] Secret rotation is performed every 90 days on schedule?
- [ ] Secret rotation procedure is documented and tested?
- [ ] Former contributors' access has been rotated out?
- [ ] No secrets appear in Git history (verified with `git log --all -p | grep -i password`)?

---

## 7. SAFETY IMPLEMENTATION RULES

### 7.1 The Safety Wrapper Architecture

Every `@mcp.tool()` decorator MUST pass through a centralized safety wrapper. This wrapper enforces ALL safety rules automatically — tool developers cannot opt out.

```python
"""
Centralized Safety Wrapper for agent-toolkit MCP tools.
This is the enforcement engine. No tool bypasses it.
"""

import functools
import inspect
import time
from typing import Callable, Any, Dict
from dataclasses import dataclass, asdict
from datetime import datetime


@dataclass
class ToolRegistration:
    """Registry entry for every MCP tool."""
    name: str
    category: OperationCategory
    dangerous: bool
    blast_radius: BlastRadius
    description: str
    registered_at: datetime
    approval_level: ApprovalLevel


class SafetyRegistry:
    """
    Central registry of all MCP tools with their safety classifications.
    Populated at server startup, validated before accepting connections.
    """
    _tools: Dict[str, ToolRegistration] = {}
    _audit: AuditLogger = AuditLogger()

    @classmethod
    def register(cls, name: str, category: OperationCategory,
                 dangerous: bool = False,
                 blast_radius: BlastRadius = BlastRadius.NONE,
                 description: str = "") -> Callable:
        """
        Decorator factory: wraps an MCP tool with safety enforcement.
        Usage:
            @mcp.tool()
            @SafetyRegistry.register(
                name="delete_files",
                category=OperationCategory.FILE_DELETE,
                dangerous=True,
                blast_radius=BlastRadius.HIGH,
                description="Delete files matching a glob pattern"
            )
            def delete_files(pattern: str, dry_run: bool = True, confirm: bool = False):
                ...
        """
        def decorator(func: Callable) -> Callable:
            # Validate the tool has required parameters
            sig = inspect.signature(func)
            params = list(sig.parameters.keys())

            if category != OperationCategory.FILE_READ and "dry_run" not in params:
                raise SafetyError(
                    f"Tool '{name}' is classified as {category.value} "
                    f"but is missing required 'dry_run' parameter. "
                    f"Parameters found: {params}"
                )

            if category != OperationCategory.FILE_READ and "confirm" not in params:
                raise SafetyError(
                    f"Tool '{name}' is classified as {category.value} "
                    f"but is missing required 'confirm' parameter. "
                    f"Parameters found: {params}"
                )

            # Register the tool
            approval_level = GATE_MATRIX[category]["approval_level"]
            cls._tools[name] = ToolRegistration(
                name=name,
                category=category,
                dangerous=dangerous,
                blast_radius=blast_radius,
                description=description,
                registered_at=datetime.utcnow(),
                approval_level=approval_level,
            )

            @functools.wraps(func)
            def wrapper(*args, **kwargs):
                return cls._execute_with_safety(name, func, *args, **kwargs)

            return wrapper
        return decorator

    @classmethod
    def _execute_with_safety(cls, name: str, func: Callable,
                             *args, **kwargs) -> Any:
        """
        Execute a tool with full safety enforcement.
        This is the critical path — every tool call goes through here.
        """
        tool = cls._tools.get(name)
        if not tool:
            raise SafetyError(f"Tool '{name}' not registered in safety registry")

        start_time = time.time()
        dry_run = kwargs.get("dry_run", True)
        confirm = kwargs.get("confirm", False)

        # Log the call attempt (always)
        cls._audit.log_attempt(
            tool=name,
            parameters=kwargs,
            category=tool.category.value,
            dry_run=dry_run,
        )

        # Enforce dangerous tool tagging
        if tool.dangerous:
            cls._audit.log_warning(
                f"Dangerous tool called: {name} "
                f"(blast_radius: {tool.blast_radius.value})"
            )

        # Enforce gate matrix
        enforce_gate_matrix(tool.category, **kwargs)

        # Execute the tool
        try:
            result = func(*args, **kwargs)
            execution_time_ms = (time.time() - start_time) * 1000

            # Log success
            cls._audit.log_success(
                tool=name,
                parameters=kwargs,
                result=result,
                execution_time_ms=execution_time_ms,
            )

            return result

        except Exception as e:
            # Log failure
            cls._audit.log_failure(
                tool=name,
                parameters=kwargs,
                error=str(e),
            )
            raise

    @classmethod
    def list_dangerous_tools(cls) -> Dict[str, ToolRegistration]:
        """Return all tools classified as dangerous."""
        return {name: reg for name, reg in cls._tools.items() if reg.dangerous}

    @classmethod
    def validate_all_tools(cls) -> list:
        """
        Validate all registered tools against safety rules.
        Returns list of violations. Empty list = all clear.
        Called at server startup.
        """
        violations = []
        for name, reg in cls._tools.items():
            if reg.dangerous and reg.blast_radius == BlastRadius.NONE:
                violations.append(
                    f"{name}: Marked dangerous but blast_radius is NONE"
                )
            if reg.category in GATE_MATRIX:
                required = GATE_MATRIX[reg.category]["approval_level"]
                if reg.approval_level != required:
                    violations.append(
                        f"{name}: Approval level mismatch. "
                        f"Registered: {reg.approval_level.value}, "
                        f"Required: {required.value}"
                    )
        return violations
```

### 7.2 Server Startup Safety Validation

```python
def startup_safety_check() -> dict:
    """
    Mandatory safety validation run at every server startup.
    The server refuses to start if any check fails.
    """
    results = {
        "passed": [],
        "failed": [],
        "warnings": [],
        "startup_allowed": False,
    }

    # Check 1: All tools registered
    if not SafetyRegistry._tools:
        results["failed"].append("No tools registered in safety registry")
    else:
        results["passed"].append(f"{len(SafetyRegistry._tools)} tools registered")

    # Check 2: No dangerous tool violations
    violations = SafetyRegistry.validate_all_tools()
    if violations:
        results["failed"].extend(violations)
    else:
        results["passed"].append("All tools pass safety validation")

    # Check 3: Required environment variables
    required_env = ["MAX_MEMORY_MB", "LOG_LEVEL", "AUDIT_LOG_PATH"]
    for env_var in required_env:
        if not os.environ.get(env_var):
            results["failed"].append(f"Required env var missing: {env_var}")
        else:
            results["passed"].append(f"Env var set: {env_var}")

    # Check 4: Audit log writable
    audit_path = os.environ.get("AUDIT_LOG_PATH", "/var/lib/agent-toolkit/audit.db")
    audit_dir = os.path.dirname(audit_path)
    if os.access(audit_dir, os.W_OK):
        results["passed"].append(f"Audit log directory writable: {audit_dir}")
    else:
        results["failed"].append(f"Audit log directory NOT writable: {audit_dir}")

    # Check 5: Git safety available
    git_check = subprocess.run(
        ["git", "--version"], capture_output=True
    )
    if git_check.returncode == 0:
        results["passed"].append("Git available for safety net")
    else:
        results["warnings"].append("Git not available — file mutation safety net disabled")

    # Check 6: Dangerous tools inventory logged
    dangerous = SafetyRegistry.list_dangerous_tools()
    if dangerous:
        results["warnings"].append(
            f"DANGEROUS TOOLS INVENTORY: "
            f"{len(dangerous)} tools classified as dangerous: "
            f"{', '.join(dangerous.keys())}"
        )
    else:
        results["passed"].append("No dangerous tools registered")

    # Final verdict
    results["startup_allowed"] = len(results["failed"]) == 0

    # Log results
    for check in results["passed"]:
        audit_log.info(f"[PASS] {check}")
    for check in results["warnings"]:
        audit_log.warning(f"[WARN] {check}")
    for check in results["failed"]:
        audit_log.error(f"[FAIL] {check}")

    return results
```

### 7.3 Emergency Stop Mechanism (Kill Switch)

Every MCP server MUST expose an emergency stop endpoint that immediately terminates all operations:

```python
# ---------------------------------------------------------------------------
# EMERGENCY STOP — The nuclear option
# ---------------------------------------------------------------------------

import os
import signal
import threading

# Global emergency stop flag
_emergency_stop = threading.Event()


@mcp.tool()
def emergency_stop(
    reason: str,
    confirm: bool = False,
    stop_all_servers: bool = True
) -> Dict[str, Any]:
    """
    EMERGENCY STOP — Immediately halt all MCP server operations.

    This is the kill switch. Use it when:
    - A tool is behaving dangerously or unexpectedly
    - System resources are critically exhausted
    - A security incident is detected
    - Any situation where "stop everything NOW" is the right answer

    BLAST RADIUS: HIGH — Stops all active operations. In-flight requests lost.
    RECOVERY: Restart individual servers after root cause addressed.

    Args:
        reason: Why the emergency stop is being triggered (logged, required)
        confirm: Must be True. Prevents accidental invocation.
        stop_all_servers: If True (default), signals all sibling servers to stop.
    """
    if not confirm:
        raise SafetyError(
            "EMERGENCY STOP requires confirm=True. "
            "This will immediately terminate all operations. "
            f"Reason provided: '{reason}'"
        )

    # Log at CRITICAL level
    audit_log.critical(
        f"EMERGENCY STOP TRIGGERED. Reason: {reason}. "
        f"Caller: {get_current_caller()}. "
        f"Timestamp: {datetime.utcnow().isoformat()}"
    )

    # Set the emergency flag — all running tools check this periodically
    _emergency_stop.set()

    # Notify sibling servers if requested
    if stop_all_servers:
        _broadcast_emergency_stop(reason)

    # Graceful shutdown: give in-flight operations 5 seconds to clean up
    time.sleep(5)

    # Forceful shutdown of this server
    os.kill(os.getpid(), signal.SIGTERM)

    return {
        "status": "EMERGENCY_STOP_INITIATED",
        "reason": reason,
        "timestamp": datetime.utcnow().isoformat(),
        "affected_servers": "all" if stop_all_servers else "self",
    }


def _broadcast_emergency_stop(reason: str) -> None:
    """Signal all sibling MCP servers to enter emergency stop."""
    # Implementation depends on your IPC mechanism
    # Options: Redis pub/sub, filesystem sentinel, systemd signals
    # Example using a sentinel file:
    sentinel_path = "/tmp/agent-toolkit-emergency-stop"
    with open(sentinel_path, "w") as f:
        f.write(f"EMERGENCY_STOP|{reason}|{datetime.utcnow().isoformat()}")


def check_emergency_stop() -> None:
    """
    Call this inside long-running tools to enable cooperative cancellation.
    Raises EmergencyStopError if emergency stop has been triggered.
    """
    if _emergency_stop.is_set():
        raise SafetyError(
            "EMERGENCY STOP ACTIVE: Operation cancelled. "
            "The server is shutting down."
        )


# Example: Tool that cooperatively checks for emergency stop
@mcp.tool()
@SafetyRegistry.register(name="long_running_task", category=OperationCategory.LLM_INFERENCE)
def long_running_task(iterations: int = 100) -> Dict[str, Any]:
    """A long-running task that respects emergency stop."""
    results = []
    for i in range(iterations):
        check_emergency_stop()  # Check every iteration
        # ... do work ...
        results.append(i)
    return {"completed": len(results)}
```

### 7.4 Safety Implementation Checklist

- [ ] Every `@mcp.tool()` passes through `@SafetyRegistry.register()`?
- [ ] The safety wrapper validates `dry_run` and `confirm` parameters exist?
- [ ] The safety wrapper enforces the Confirmation Gate Matrix?
- [ ] Dangerous tools are logged at WARNING level on every call?
- [ ] Startup safety check runs before accepting connections?
- [ ] Server refuses to start if any safety check fails?
- [ ] Emergency stop tool is registered and tested monthly?
- [ ] Emergency stop requires `confirm=True` (double protection)?
- [ ] Emergency stop broadcasts to all sibling servers?
- [ ] All long-running tools check `_emergency_stop` flag periodically?
- [ ] Safety registry validation finds zero violations at startup?
- [ ] Dangerous tools inventory is printed to startup logs?

---

## 8. APPROVAL LEVELS

### 8.1 Level Definitions

| Level | Name | Enforcement | Human Action Required | Use Case |
|-------|------|-------------|----------------------|----------|
| `auto` | Automatic | Safety wrapper allows immediately | None | Read-only operations, non-destructive writes |
| `user` | User Confirmed | Safety wrapper blocks until CLI user confirms | Type "confirm=True" or interactive "y/N" | Destructive operations that modify but don't delete |
| `user+git` | User + Git Checkpoint | Requires BOTH user confirmation AND successful git stash | Confirm + verify stash created | Destructive operations that delete data |

### 8.2 Implementation by Level

```python
class ApprovalLevel(str, Enum):
    AUTO = "auto"
    USER = "user"
    USER_PLUS_GIT = "user+git"


def enforce_approval(level: ApprovalLevel, tool_name: str, **kwargs) -> dict:
    """
    Enforce the approval level for a tool call.
    Returns approval metadata if granted, raises SafetyError if denied.
    """
    caller = get_current_caller()
    timestamp = datetime.utcnow()

    if level == ApprovalLevel.AUTO:
        # No human intervention — just log and proceed
        return {
            "approved": True,
            "level": "auto",
            "by": "system",
            "timestamp": timestamp.isoformat(),
        }

    if level == ApprovalLevel.USER:
        # Requires confirm=True in parameters
        if not kwargs.get("confirm", False):
            raise SafetyError(
                f"APPROVAL REQUIRED [{tool_name}]:\n"
                f"  Operation: {tool_name}\n"
                f"  Approval Level: user\n"
                f"  Required: Set confirm=True to proceed.\n"
                f"  Recommended: Run with dry_run=True first.\n"
                f"  Caller: {caller}\n"
                f"  Time: {timestamp.isoformat()}"
            )
        return {
            "approved": True,
            "level": "user",
            "by": caller,
            "confirmed_at": timestamp.isoformat(),
        }

    if level == ApprovalLevel.USER_PLUS_GIT:
        # Requires BOTH confirm=True AND successful git checkpoint
        if not kwargs.get("confirm", False):
            raise SafetyError(
                f"APPROVAL REQUIRED [{tool_name}]:\n"
                f"  Operation: {tool_name}\n"
                f"  Approval Level: user+git\n"
                f"  Required:\n"
                f"    1. Set confirm=True\n"
                f"    2. Ensure git_checkpoint=True (default)\n"
                f"  Recommended: Run with dry_run=True first.\n"
                f"  Caller: {caller}\n"
                f"  Time: {timestamp.isoformat()}"
            )

        # Verify git checkpoint was created
        if not kwargs.get("git_checkpoint", True):
            raise SafetyError(
                f"GIT CHECKPOINT MANDATORY [{tool_name}]:\n"
                f"  git_checkpoint=True is required for approval level 'user+git'.\n"
                f"  This operation is destructive and requires a recovery point."
            )

        # Create the checkpoint and verify
        stash_hash = _auto_stash(f"approval-{tool_name}-{timestamp.isoformat()}")
        if not stash_hash:
            raise SafetyError(
                f"GIT CHECKPOINT FAILED [{tool_name}]:\n"
                f"  Could not create git stash. Operation aborted.\n"
                f"  Ensure you are in a git repository with no uncommitted conflicts."
            )

        return {
            "approved": True,
            "level": "user+git",
            "by": caller,
            "confirmed_at": timestamp.isoformat(),
            "stash_hash": stash_hash,
            "recovery_command": f"git stash pop {stash_hash}",
        }

    raise SafetyError(f"Unknown approval level: {level}")
```

### 8.3 Approval Audit Record

Every approval decision is recorded:

```python
@dataclass
class ApprovalRecord:
    tool: str
    level: ApprovalLevel
    granted: bool
    caller: str
    timestamp: datetime
    dry_run: bool
    confirm: bool
    stash_hash: Optional[str] = None
    denial_reason: Optional[str] = None
```

### 8.4 Approval Levels Checklist

- [ ] Every tool has an assigned approval level at registration time?
- [ ] Approval level is derived from the Confirmation Gate Matrix (not arbitrary)?
- [ ] `user` level requires explicit `confirm=True` — no exceptions?
- [ ] `user+git` level creates and verifies a git stash before execution?
- [ ] Failed approval is logged to audit trail with full context?
- [ ] Approval records are queryable by tool, caller, and time range?

---

## 9. AUDIT TRAIL

### 9.1 Audit Log Schema

Every tool call — successful or failed, dry-run or executed — is recorded in a durable SQLite audit log.

```sql
-- =============================================================================
-- AUDIT LOG SCHEMA
-- =============================================================================

CREATE TABLE IF NOT EXISTS audit_log (
    -- Identity
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    tool            TEXT NOT NULL,
    category        TEXT NOT NULL,

    -- Call details
    parameters      TEXT NOT NULL,           -- JSON-encoded kwargs
    caller          TEXT NOT NULL,           -- Who called it (CLI identity)
    client_ip       TEXT,                    -- Source IP if available

    -- Timing
    timestamp       TEXT NOT NULL,           -- ISO 8601 UTC
    execution_ms    INTEGER,                 -- Duration in milliseconds

    -- Safety state
    dry_run         INTEGER NOT NULL,        -- 0=false, 1=true
    confirmed       INTEGER NOT NULL,        -- 0=false, 1=true
    approval_level  TEXT NOT NULL,           -- auto, user, user+git

    -- Result
    result          TEXT,                    -- JSON-encoded result (success)
    error           TEXT,                    -- Error message (failure)
    stash_hash      TEXT,                    -- Git stash if created

    -- Classification
    dangerous       INTEGER NOT NULL,        -- 0=false, 1=true
    blast_radius    TEXT,                    -- none, low, medium, high, critical

    -- Metadata
    server_version  TEXT,                    -- agent-toolkit version
    host            TEXT                     -- hostname where executed
);

-- Indexes for common queries
CREATE INDEX IF NOT EXISTS idx_audit_tool ON audit_log(tool);
CREATE INDEX IF NOT EXISTS idx_audit_timestamp ON audit_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_audit_caller ON audit_log(caller);
CREATE INDEX IF NOT EXISTS idx_audit_dangerous ON audit_log(dangerous);
CREATE INDEX IF NOT EXISTS idx_audit_category ON audit_log(category);

-- =============================================================================
-- AUDIT SUMMARY VIEW (for dashboards)
-- =============================================================================

CREATE VIEW IF NOT EXISTS audit_summary AS
SELECT
    tool,
    category,
    COUNT(*) as total_calls,
    SUM(CASE WHEN dry_run = 1 THEN 1 ELSE 0 END) as dry_run_calls,
    SUM(CASE WHEN dry_run = 0 THEN 1 ELSE 0 END) as live_calls,
    SUM(CASE WHEN error IS NOT NULL THEN 1 ELSE 0 END) as failed_calls,
    SUM(CASE WHEN dangerous = 1 THEN 1 ELSE 0 END) as dangerous_calls,
    MAX(timestamp) as last_called,
    AVG(execution_ms) as avg_execution_ms
FROM audit_log
GROUP BY tool, category;

-- =============================================================================
-- ALERTS VIEW (for monitoring suspicious activity)
-- =============================================================================

CREATE VIEW IF NOT EXISTS audit_alerts AS
SELECT
    *,
    CASE
        WHEN dangerous = 1 AND dry_run = 0 AND confirmed = 0
            THEN 'CRITICAL: Dangerous tool executed without confirmation!'
        WHEN blast_radius = 'critical' AND dry_run = 0
            THEN 'WARNING: Critical blast radius operation executed'
        WHEN error IS NOT NULL AND dangerous = 1
            THEN 'WARNING: Dangerous tool failed — investigate'
        ELSE 'OK'
    END as alert_status
FROM audit_log
WHERE dry_run = 0  -- Only alert on live operations
ORDER BY timestamp DESC;
```

### 9.2 Audit Logger Implementation

```python
import sqlite3
import json
import socket
from contextlib import contextmanager
from datetime import datetime
from typing import Optional, Any, Dict


class AuditLogger:
    """
    Durable audit logger for all MCP tool operations.
    Uses SQLite for local durability. Supports export to external systems.
    """

    def __init__(self, db_path: str = None):
        self.db_path = db_path or os.environ.get(
            "AUDIT_LOG_PATH", "/var/lib/agent-toolkit/audit.db"
        )
        self.hostname = socket.gethostname()
        self.version = "1.0.0"  # agent-toolkit version
        self._init_db()

    def _init_db(self) -> None:
        """Initialize the audit database with schema."""
        with self._connect() as conn:
            conn.executescript(SCHEMA_SQL)  # Schema from section 9.1
            conn.commit()

    @contextmanager
    def _connect(self):
        conn = sqlite3.connect(self.db_path, timeout=10)
        try:
            yield conn
        finally:
            conn.close()

    def _insert(self, record: Dict[str, Any]) -> int:
        """Insert an audit record. Returns the row ID."""
        with self._connect() as conn:
            cursor = conn.execute("""
                INSERT INTO audit_log (
                    tool, category, parameters, caller, client_ip,
                    timestamp, execution_ms, dry_run, confirmed,
                    approval_level, result, error, stash_hash,
                    dangerous, blast_radius, server_version, host
                ) VALUES (
                    :tool, :category, :parameters, :caller, :client_ip,
                    :timestamp, :execution_ms, :dry_run, :confirmed,
                    :approval_level, :result, :error, :stash_hash,
                    :dangerous, :blast_radius, :server_version, :host
                )
            """, {
                **record,
                "server_version": self.version,
                "host": self.hostname,
            })
            conn.commit()
            return cursor.lastrowid

    # -----------------------------------------------------------------------
    # Public logging methods
    # -----------------------------------------------------------------------

    def log_attempt(self, tool: str, parameters: dict,
                    category: str, dry_run: bool) -> int:
        """Log a tool call attempt."""
        return self._insert({
            "tool": tool,
            "category": category,
            "parameters": json.dumps(parameters, default=str),
            "caller": get_current_caller(),
            "client_ip": get_client_ip(),
            "timestamp": datetime.utcnow().isoformat(),
            "execution_ms": None,
            "dry_run": 1 if dry_run else 0,
            "confirmed": parameters.get("confirm", False),
            "approval_level": GATE_MATRIX.get(
                OperationCategory(category), {}
            ).get("approval_level", ApprovalLevel.AUTO).value,
            "result": None,
            "error": None,
            "stash_hash": None,
            "dangerous": tool in SafetyRegistry.list_dangerous_tools(),
            "blast_radius": SafetyRegistry._tools.get(
                tool, ToolRegistration("", OperationCategory.FILE_READ, False,
                                        BlastRadius.NONE, "", datetime.now(),
                                        ApprovalLevel.AUTO)
            ).blast_radius.value,
        })

    def log_success(self, tool: str, parameters: dict,
                    result: Any, execution_time_ms: float) -> None:
        """Update the audit record with success result."""
        # Implementation: update the most recent record for this tool+caller
        with self._connect() as conn:
            conn.execute("""
                UPDATE audit_log
                SET result = :result,
                    execution_ms = :execution_ms,
                    confirmed = :confirmed
                WHERE tool = :tool
                  AND caller = :caller
                ORDER BY id DESC
                LIMIT 1
            """, {
                "result": json.dumps(result, default=str) if result else None,
                "execution_ms": int(execution_time_ms),
                "confirmed": 1 if parameters.get("confirm", False) else 0,
                "tool": tool,
                "caller": get_current_caller(),
            })
            conn.commit()

    def log_failure(self, tool: str, parameters: dict, error: str) -> None:
        """Update the audit record with failure details."""
        with self._connect() as conn:
            conn.execute("""
                UPDATE audit_log
                SET error = :error,
                    confirmed = :confirmed
                WHERE tool = :tool
                  AND caller = :caller
                ORDER BY id DESC
                LIMIT 1
            """, {
                "error": error,
                "confirmed": 1 if parameters.get("confirm", False) else 0,
                "tool": tool,
                "caller": get_current_caller(),
            })
            conn.commit()

    def log_warning(self, message: str) -> None:
        """Log a warning message to both audit log and standard logging."""
        import logging
        logging.warning(message)
        # Also insert as a special "_system" tool record
        self._insert({
            "tool": "_system",
            "category": "warning",
            "parameters": json.dumps({"message": message}),
            "caller": get_current_caller(),
            "client_ip": get_client_ip(),
            "timestamp": datetime.utcnow().isoformat(),
            "execution_ms": 0,
            "dry_run": 0,
            "confirmed": 0,
            "approval_level": "auto",
            "result": None,
            "error": message,
            "stash_hash": None,
            "dangerous": 0,
            "blast_radius": "none",
        })

    # -----------------------------------------------------------------------
    # Query and export
    # -----------------------------------------------------------------------

    def query(self, tool: str = None, caller: str = None,
              start: str = None, end: str = None,
              dangerous_only: bool = False,
              limit: int = 100) -> list:
        """Query audit records with filters."""
        conditions = []
        params = {}

        if tool:
            conditions.append("tool = :tool")
            params["tool"] = tool
        if caller:
            conditions.append("caller = :caller")
            params["caller"] = caller
        if start:
            conditions.append("timestamp >= :start")
            params["start"] = start
        if end:
            conditions.append("timestamp <= :end")
            params["end"] = end
        if dangerous_only:
            conditions.append("dangerous = 1")

        where = " AND ".join(conditions) if conditions else "1=1"

        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute(
                f"SELECT * FROM audit_log WHERE {where} ORDER BY timestamp DESC LIMIT :limit",
                {**params, "limit": limit}
            ).fetchall()
            return [dict(row) for row in rows]

    def export_to_json(self, filepath: str, **filters) -> int:
        """Export filtered audit records to JSON file."""
        records = self.query(**filters)
        with open(filepath, "w") as f:
            json.dump(records, f, indent=2, default=str)
        return len(records)

    def get_summary(self) -> list:
        """Get the audit summary view."""
        with self._connect() as conn:
            conn.row_factory = sqlite3.Row
            rows = conn.execute("SELECT * FROM audit_summary").fetchall()
            return [dict(row) for row in rows]
```

### 9.3 Retention Policy

| Environment | Retention | Storage Limit | Action at Limit |
|-------------|-----------|---------------|-----------------|
| `lean@192.168.1.135` (dev) | 14 days | 1 GB | Delete oldest records |
| `ecolife-2` (prod) | 90 days | 10 GB | Archive to compressed JSON, then delete |
| Archive | 2 years | 50 GB | Manual review before deletion |

```python
def enforce_retention() -> dict:
    """Enforce audit log retention policy. Run daily via cron."""
    import sqlite3

    env = os.environ.get("ENV", "dev")
    retention_days = 14 if env == "dev" else 90
    cutoff = (datetime.utcnow() - timedelta(days=retention_days)).isoformat()

    with sqlite3.connect(os.environ.get("AUDIT_LOG_PATH")) as conn:
        # Count what will be deleted
        count = conn.execute(
            "SELECT COUNT(*) FROM audit_log WHERE timestamp < ?",
            (cutoff,)
        ).fetchone()[0]

        if count > 0:
            # Archive before deletion (production only)
            if env == "prod":
                archive_path = f"/backup/audit/archive-{datetime.utcnow().strftime('%Y%m%d')}.json"
                audit.export_to_json(archive_path, end=cutoff)

            # Delete old records
            conn.execute("DELETE FROM audit_log WHERE timestamp < ?", (cutoff,))
            conn.commit()

        return {
            "environment": env,
            "retention_days": retention_days,
            "cutoff": cutoff,
            "records_deleted": count,
            "archived_to": archive_path if env == "prod" and count > 0 else None,
        }
```

### 9.4 Audit Trail Checklist

- [ ] SQLite audit database is initialized with full schema at server startup?
- [ ] Every tool call (attempt + result) is recorded — no exceptions?
- [ ] Dry-run calls are logged (distinguishable from live calls)?
- [ ] Failed calls log the full error message?
- [ ] Git stash hashes are recorded for recoverable operations?
- [ ] The `audit_alerts` view flags critical security events?
- [ ] Retention policy is enforced automatically via daily cron?
- [ ] Production records are archived before deletion?
- [ ] Export to JSON function works and produces valid output?
- [ ] Audit log storage is monitored and alerts at 80% capacity?

---

## APPENDIX A: PRE-FLIGHT CHECKLIST

Use this checklist before EVERY deployment, EVERY model switch, and EVERY session where MCP tools will be used for destructive operations.

### A.1 Deployment Pre-Flight

- [ ] All changes reviewed in pull request with at least 1 approver?
- [ ] All unit tests pass (run `pytest -xvs tests/`)?
- [ ] Safety validation passes (run `python -m safety.validate`)?
- [ ] No dangerous tools added without approval from safety officer?
- [ ] `.env` variables verified against `.env.template`?
- [ ] Database migrations tested in staging?
- [ ] Rollback procedure documented and tested?
- [ ] Backup of production data completed?
- [ ] Maintenance window communicated to users?
- [ ] Emergency stop procedure verified (run `python -m safety.test-killswitch`)?

### A.2 Model Switch Pre-Flight

- [ ] Target model memory requirement known and documented?
- [ ] Available memory + current model memory >= target model memory + 1 GB buffer?
- [ ] Current inference queue is empty (no active requests)?
- [ ] 8 GB headroom will remain after switch?
- [ ] Rollback model identified (in case of compatibility issues)?
- [ ] Model tested on development server first?

### A.3 Destructive Operation Pre-Flight

- [ ] Dry-run executed and output reviewed carefully?
- [ ] Target scope is MINIMAL (no `*`, no `**`, no broad patterns)?
- [ ] Git checkpoint will be created (verify `git status` is clean)?
- [ ] Recovery procedure identified and documented?
- [ ] Second person has reviewed the dry-run output?
- [ ] Business impact assessed and accepted?
- [ ] Operation window avoids peak usage hours?
- [ ] Rollback tested and confirmed working?

---

## APPENDIX B: EMERGENCY PROCEDURES

### B.1 Emergency Stop (Kill Switch)

```bash
# Method 1: Via MCP tool call (from any connected CLI)
# Kimi / OpenCode / Goose can call:
# emergency_stop(reason="Data corruption detected", confirm=True)

# Method 2: Via sentinel file (any user on the server)
$ echo "EMERGENCY_STOP|manual-trigger|$(date -Iseconds)" > /tmp/agent-toolkit-emergency-stop

# Method 3: Via systemd (immediate)
$ sudo systemctl stop agent-toolkit@

# Method 4: Nuclear option (if all else fails)
$ sudo pkill -f "mcp.server"
```

### B.2 Post-Emergency Recovery

```bash
# Step 1: Identify why emergency stop was triggered
$ cat /tmp/agent-toolkit-emergency-stop
$ journalctl -u agent-toolkit@* --since "10 minutes ago"

# Step 2: Assess system state
$ free -h                                    # Memory status
$ df -h                                      # Disk status
$ systemctl status agent-toolkit@*           # Service status

# Step 3: Recover from git stash if needed
$ git stash list
$ git stash pop stash@{0}

# Step 4: Review audit log for the incident
$ sqlite3 /var/lib/agent-toolkit/audit.db \
    "SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT 20;"

# Step 5: Fix root cause before restarting
# ... address the issue ...

# Step 6: Clear emergency sentinel
$ rm -f /tmp/agent-toolkit-emergency-stop

# Step 7: Restart servers ONE AT A TIME with safety checks
$ ./scripts/start-servers.sh --with-safety-checks --rolling-restart

# Step 8: Verify health
$ curl http://ecolife-2:8080/health
$ ./scripts/verify-all-servers.sh
```

### B.3 OOM (Out of Memory) Recovery

```bash
# Step 1: Check what was killed
$ dmesg | grep -i "killed process"
$ journalctl -k | grep -i "oom"

# Step 2: Check current memory state
$ free -h
$ cat /proc/meminfo | grep -E "MemTotal|MemFree|MemAvailable"

# Step 3: If Ollama was killed, check if model needs reload
$ ollama ps
$ ollama list

# Step 4: If memory is still tight, unload the model temporarily
$ ollama stop <model_name>

# Step 5: Restart MCP servers with conservative memory limits
$ MAX_MEMORY_MB=512 ./scripts/start-servers.sh

# Step 6: Reload model when memory is available
# (Use the model switching tool, which enforces unload-before-load)
```

### B.4 Security Incident Response

```
1. DETECT: Unusual pattern in audit log (via audit_alerts view)
2. ISOLATE: Trigger emergency_stop immediately
3. PRESERVE: Copy audit database before anything else
   $ cp /var/lib/agent-toolkit/audit.db /backup/incident-$(date +%Y%m%d-%H%M%S).db
4. ANALYZE: Query audit log for incident scope
5. ROTATE: All secrets potentially compromised
6. PATCH: Fix vulnerability
7. VERIFY: Re-run safety validation
8. RESTART: Rolling restart with monitoring
9. DOCUMENT: Incident report within 24 hours
```

---

## APPENDIX C: GLOSSARY

| Term | Definition |
|------|------------|
| **Agent-toolkit** | The self-hosted MCP Server Hub project this protocol governs |
| **Blast radius** | The scope of potential damage from an operation (none/low/medium/high/critical) |
| **CLI** | Command-line interface: Kimi, OpenCode, Goose — the LLM agents that call MCP tools |
| **Confirmation gate** | A required approval step before a destructive operation executes |
| **Defense in depth** | Multiple independent safety layers so no single failure causes catastrophe |
| **Dry run** | Simulation mode that shows what WOULD happen without actually executing |
| **ECOlife-2** | Production server (32 GB RAM) hosting MCP servers and Ollama |
| **Fail-safe default** | The default state of every parameter is the SAFEST possible state |
| **Git checkpoint** | An automatic git stash created before file mutations for recovery |
| **Kill switch** | The emergency_stop tool that immediately halts all MCP operations |
| **Lean** | Development server (`lean@192.168.1.135`) for testing and staging |
| **MCP** | Model Context Protocol — the protocol these tools implement |
| **OOM** | Out of Memory — when system RAM is exhausted |
| **Opt-in dangerous** | Destructive tools require explicit confirmation to execute |
| **Safety wrapper** | The centralized enforcement layer that wraps every MCP tool |
| **User+git approval** | Requires both human confirmation AND a successful git checkpoint |

---

## DOCUMENT CONTROL

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | 2025-01-01 | AI Safety & Governance Officer | Initial release |

**Review Schedule:** This document is reviewed monthly and updated as needed.  
**Next Review:** 2025-02-01  
**Approval:** Required from project lead before implementation of any changes.

---

> **Remember: "Slow but safe."** Every shortcut is a potential incident. Every bypass is a potential outage. Every unchecked operation is a potential financial loss for Solar O&M and Health Franchise operations in Bangkok. Safety is not a feature — it is the foundation.
