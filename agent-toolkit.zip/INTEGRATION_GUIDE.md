# agent-toolkit Integration Guide

> **Version:** 1.0.0 | **Last Updated:** 2025-01-20
>
> This guide documents the complete integration architecture for `agent-toolkit` — a self-hosted MCP (Model Context Protocol) Server Hub that unifies GitHub, Supabase, Ollama, rclone, and local tool servers under a single discoverable registry.

---

## Table of Contents

1. [MCP Hub Architecture](#1-mcp-hub-architecture)
2. [GitHub MCP Integration](#2-github-mcp-integration)
3. [Supabase Integration](#3-supabase-integration)
4. [Ollama LAN Configuration](#4-ollama-lan-configuration)
5. [rclone Bridge](#5-rclone-bridge)
6. [MCP.json Templates](#6-mcpjson-templates)
7. [Cross-Machine Setup](#7-cross-machine-setup)
8. [Health Check & Monitoring](#8-health-check--monitoring)

---

## 1. MCP Hub Architecture

### 1.1 Design Philosophy

`agent-toolkit` follows a **hub-and-spoke** model. A central lightweight registry (the Hub) maintains the catalog of available MCP servers. Each server is a standalone Python process exposing tools via the Model Context Protocol over stdio or HTTP. The Hub handles lifecycle, health checking, and configuration injection — while each server remains independently deployable and testable.

**Why this matters:** When you add a new capability (e.g., GitHub repository management), you write a new server module, register it in `config.yaml`, and every connected CLI (Kimi, OpenCode, Goose) immediately sees the new tools without individual reconfiguration.

### 1.2 Registry & Discovery

Servers are registered in `/home/lean/.config/agent-toolkit/config.yaml`:

```yaml
# ~/.config/agent-toolkit/config.yaml
hub:
  version: "1.0"
  log_level: INFO
  health_check_interval: 30  # seconds

servers:
  file-ops-safe:
    module: agent_toolkit.servers.file_ops_safe
    command: python -m agent_toolkit.servers.file_ops_safe
    transport: stdio
    enabled: true
    timeout: 30
    env:
      ALLOWED_DIRS: "/home/lean/projects,/home/lean/documents"
      REQUIRE_CONFIRM: "true"

  solar-calc:
    module: agent_toolkit.servers.solar_calc
    command: python -m agent_toolkit.servers.solar_calc
    transport: stdio
    enabled: true
    timeout: 10

  health-ops:
    module: agent_toolkit.servers.health_ops
    command: python -m agent_toolkit.servers.health_ops
    transport: stdio
    enabled: true
    timeout: 10

  rag-bridge:
    module: agent_toolkit.servers.rag_bridge
    command: python -m agent_toolkit.servers.rag_bridge
    transport: stdio
    enabled: true
    timeout: 120
    env:
      OLLAMA_HOST: "http://ecolife-2:11434"
      EMBED_MODEL: "nomic-embed-text"

  memory-store:
    module: agent_toolkit.servers.memory_store
    command: python -m agent_toolkit.servers.memory_store
    transport: stdio
    enabled: true
    timeout: 10
    env:
      DB_PATH: "/home/lean/.local/share/agent-toolkit/memory.db"

  ollama-bridge:
    module: agent_toolkit.servers.ollama_bridge
    command: python -m agent_toolkit.servers.ollama_bridge
    transport: stdio
    enabled: true
    timeout: 300
    env:
      OLLAMA_HOST: "http://ecolife-2:11434"
      DEFAULT_MODEL: "gemma4"

  rclone-bridge:
    module: agent_toolkit.servers.rclone_bridge
    command: python -m agent_toolkit.servers.rclone_bridge
    transport: stdio
    enabled: true
    timeout: 300
    env:
      RCLONE_REMOTE: "lean"
      RCLONE_CONFIG: "/home/lean/.config/rclone/rclone.conf"

  github:
    module: agent_toolkit.servers.github_mcp
    command: python -m agent_toolkit.servers.github_mcp
    transport: stdio
    enabled: true
    timeout: 60
    env:
      GITHUB_TOKEN: "${GITHUB_TOKEN}"  # pulled from shell env

  supabase:
    module: agent_toolkit.servers.supabase_mcp
    command: python -m agent_toolkit.servers.supabase_mcp
    transport: stdio
    enabled: false  # enable when cloud sync needed
    timeout: 60
    env:
      SUPABASE_URL: "${SUPABASE_URL}"
      SUPABASE_KEY: "${SUPABASE_KEY}"
```

### 1.3 Server Lifecycle

```
                    +------------------+
                    |   MCP Hub        |
                    |   (registry)     |
                    +--------+---------+
                             |
              +--------------+--------------+
              |              |              |
        [start]          [stop]        [health]
              |              |              |
    +---------v--+  +--------v----+  +-------v-------+
    |  Spawn     |  |  SIGTERM    |  |  HTTP GET    |
    |  subprocess|  |  / SIGKILL  |  |  /health     |
    +---------+--+  +--------+----+  +-------+-------+
              |              |              |
              v              v              v
       +----------+   +-----------+  +-------------+
       | RUNNING  |   | STOPPED   |  |  HEALTHY /  |
       |          |   |           |  |  UNHEALTHY  |
       +----------+   +-----------+  +-------------+
```

**Lifecycle commands (via CLI):**

```bash
# Start all enabled servers
agent-toolkit start

# Start a specific server
agent-toolkit start ollama-bridge

# Stop a server
agent-toolkit stop github

# Restart with new config
agent-toolkit restart --config ~/.config/agent-toolkit/config.yaml

# View status of all servers
agent-toolkit status

# Expected output:
# NAME            STATUS    PID    UPTIME    HEALTH   TOOLS
# file-ops-safe   running   1234   2h 15m    ok       8
# solar-calc      running   1235   2h 15m    ok       4
# health-ops      running   1236   2h 15m    ok       6
# rag-bridge      running   1237   2h 14m    ok       3
# memory-store    running   1238   2h 15m    ok       5
# ollama-bridge   running   1239   2h 14m    ok       4
# rclone-bridge   running   1240   2h 15m    ok       6
# github          running   1241   2h 10m    ok       12
```

### 1.4 Configuration Resolution Order

Configuration values are resolved with the following precedence (highest first):

1. **Environment variables** — `export GITHUB_TOKEN=ghp_xxx`
2. **CLI flags** — `--github-token ghp_xxx`
3. **Config file** — `~/.config/agent-toolkit/config.yaml`
4. **Defaults** — hardcoded in each server module

**Best practice:** Store secrets in environment variables (via `.bashrc` or a `.env` file), keep `config.yaml` in version control with `${VAR}` placeholders.

### 1.5 Transport Layer

All servers in this architecture use **stdio transport** — the MCP standard where the server reads JSON-RPC requests from stdin and writes responses to stdout. This is the most reliable transport for CLI-based AI assistants because:

- No port conflicts between servers
- Automatic process isolation
- Clean shutdown via pipe close
- Works across SSH sessions

For debugging, any server can be started manually:

```bash
python -m agent_toolkit.servers.ollama_bridge
# Then paste JSON-RPC requests to stdin
```

---

## 2. GitHub MCP Integration

### 2.1 Server Selection

We use the **official GitHub MCP server** from the `github/github-mcp-server` repository. This is the authoritative implementation maintained by GitHub and provides comprehensive repository, issue, PR, and search capabilities.

**Installation:**

```bash
# Option A: Install from Smithery (recommended — auto-updates)
npx -y @smithery/cli@latest install github-mcp-server --client generic

# Option B: Install from source
pip install github-mcp-server

# Option C: Direct module (our hub wraps this)
pip install PyGithub  # underlying library
```

### 2.2 Authentication

The GitHub MCP server requires a **Personal Access Token (classic)** with these scopes:

| Scope | Purpose |
|-------|---------|
| `repo` | Full repository access (read/write) |
| `workflow` | Trigger and read workflow runs |
| `read:org` | Read organization membership |
| `gist` | Create and read gists |

**Create token:** https://github.com/settings/tokens/new

**Set environment variable:**

```bash
# ~/.bashrc or ~/.bash_profile
export GITHUB_TOKEN="ghp_your_token_here"
```

**Verify token works:**

```bash
curl -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/user | jq .login
```

### 2.3 Available Tools

The GitHub MCP server exposes these tools to connected AI agents:

| Tool | Description | Example Use |
|------|-------------|-------------|
| `github_search_repositories` | Search repos by query | "Find all my Python projects" |
| `github_get_repository` | Get repo metadata | "Get details for agent-toolkit" |
| `github_create_repository` | Create a new repository | "Create a new repo for my app" |
| `github_fork_repository` | Fork a repository | "Fork tensorflow/tensorflow" |
| `github_search_issues` | Search issues across repos | "Find all open bugs labeled 'urgent'" |
| `github_get_issue` | Get issue details | "Get issue #42 details" |
| `github_create_issue` | Create a new issue | "File a bug report" |
| `github_update_issue` | Update issue state/labels | "Close issue #42 as completed" |
| `github_list_commits` | List commits on a branch | "Show recent commits to main" |
| `github_get_commit` | Get a specific commit | "Get details of commit abc123" |
| `github_create_pull_request` | Open a new PR | "Create PR from feature branch" |
| `github_merge_pull_request` | Merge an open PR | "Merge PR #7 with squash" |
| `github_search_code` | Search code across repos | "Find where 'config.yaml' is read" |
| `github_list_branches` | List branches in a repo | "Show all branches" |
| `github_create_branch` | Create a new branch | "Create branch 'feature/auth' from main" |

### 2.4 Wiring into the Hub

The hub wraps the GitHub MCP server as `agent_toolkit.servers.github_mcp`. This thin wrapper:

1. Validates `GITHUB_TOKEN` is present at startup
2. Handles token refresh if using a GitHub App installation token
3. Provides graceful error messages for rate limit (403) and auth (401) failures
4. Adds a local caching layer for repeated repo metadata queries

**Server module structure:**

```
agent_toolkit/servers/github_mcp/
  __init__.py
  __main__.py              # Entry point: python -m agent_toolkit.servers.github_mcp
  server.py                # MCP server setup
  tools.py                 # Tool implementations
  cache.py                 # Local LRU cache for API responses
```

### 2.5 mcp.json Snippet for GitHub

```json
{
  "mcpServers": {
    "github": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.github_mcp"],
      "env": {
        "GITHUB_TOKEN": "${GITHUB_TOKEN}",
        "GITHUB_CACHE_TTL": "300",
        "GITHUB_API_BASE": "https://api.github.com"
      },
      "timeout": 60,
      "description": "GitHub repository, issue, PR, and code search operations"
    }
  }
}
```

### 2.6 Rate Limiting

GitHub API has a 5,000 requests/hour limit for authenticated users. The wrapper handles this by:

- Caching repo metadata for 5 minutes (`GITHUB_CACHE_TTL`)
- Exposing `github_get_rate_limit()` tool so agents can check remaining quota
- Automatic retry with exponential backoff on `403` rate-limit responses

```python
# Check rate limit before batch operations
remaining = await tools.github_get_rate_limit()
if remaining < 100:
    print("WARNING: Approaching GitHub rate limit. Pausing operations.")
```

---

## 3. Supabase Integration

### 3.1 Decision Matrix: Supabase vs. SQLite

| Criterion | Local SQLite | Supabase Cloud |
|-----------|-------------|----------------|
| **Latency** | <1ms (local file) | 50-200ms (network) |
| **Multi-device sync** | Manual (copy .db file) | Automatic real-time |
| **Backup** | rclone to Google Drive | Point-in-time restore |
| **Schema changes** | Anytime, no migration | Migration scripts required |
| **Offline use** | Full functionality | Requires connectivity |
| **Cost** | Free | Free tier: 500MB |
| **Auth/RLS** | None (single user) | Row-level security |
| **Setup complexity** | Zero | Account + project + keys |

**Rule of thumb:**
- **SQLite** for the `memory-store`, `health-ops`, and `solar-calc` servers — data that is machine-specific and latency-sensitive.
- **Supabase** for the `rag-bridge` document index when you need to search across multiple machines, or for shared project data that must survive device loss.

### 3.2 Supabase MCP Server Setup

When cloud sync is needed, enable the Supabase server in `config.yaml`:

```yaml
servers:
  supabase:
    module: agent_toolkit.servers.supabase_mcp
    command: python -m agent_toolkit.servers.supabase_mcp
    transport: stdio
    enabled: true
    timeout: 60
    env:
      SUPABASE_URL: "https://your-project.supabase.co"
      SUPABASE_KEY: "eyJhbG...your-anon-key"
```

**Get credentials:**
1. Create project at https://supabase.com
2. Project Settings > API > Project URL (`SUPABASE_URL`)
3. Project Settings > API > `anon` `public` key (`SUPABASE_KEY`)

### 3.3 Schema Design for agent-toolkit

When using Supabase, create these tables:

```sql
-- Documents table (for RAG vector search)
CREATE TABLE documents (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    source      text NOT NULL,           -- file path or URL
    content     text NOT NULL,
    embedding   vector(768),             -- matches nomic-embed-text
    metadata    jsonb DEFAULT '{}',
    created_at  timestamptz DEFAULT now(),
    machine_id  text                     -- which device uploaded this
);

-- Create vector index for similarity search
CREATE INDEX ON documents USING ivfflat (embedding vector_cosine_ops);

-- Conversations table (for cross-device memory)
CREATE TABLE conversations (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id  text NOT NULL,
    role        text NOT NULL CHECK (role IN ('user', 'assistant', 'system')),
    content     text NOT NULL,
    tools_used  jsonb DEFAULT '[]',
    created_at  timestamptz DEFAULT now(),
    machine_id  text
);

-- Project state table (for shared project data)
CREATE TABLE project_state (
    id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
    project     text NOT NULL,
    key         text NOT NULL,
    value       jsonb NOT NULL,
    updated_at  timestamptz DEFAULT now(),
    UNIQUE(project, key)
);

-- Enable Row Level Security (optional, for multi-user)
ALTER TABLE documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE project_state ENABLE ROW LEVEL SECURITY;

-- Simple policy: only authenticated users can access their own data
CREATE POLICY documents_isolation ON documents
    FOR ALL USING (auth.uid()::text = machine_id);
```

### 3.4 Supabase Tools Exposed

| Tool | Description |
|------|-------------|
| `supabase_query` | Run SELECT against any table |
| `supabase_insert` | Insert records |
| `supabase_update` | Update records by filter |
| `supabase_delete` | Delete records by filter |
| `supabase_vector_search` | Semantic search on documents.embedding |
| `supabase_upsert` | Upsert records (insert or update) |

### 3.5 Switching Between SQLite and Supabase

The `memory-store` and `rag-bridge` servers auto-detect the backend:

```python
# In each server module
if os.environ.get("SUPABASE_URL"):
    backend = SupabaseBackend()
else:
    backend = SQLiteBackend()
```

To switch a server from local to cloud:

```bash
# 1. Set Supabase credentials
export SUPABASE_URL="https://your-project.supabase.co"
export SUPABASE_KEY="eyJhbG..."

# 2. Restart the specific server
agent-toolkit restart rag-bridge

# 3. Verify it's using Supabase
agent-toolkit status rag-bridge
# Should show: backend: supabase
```

---

## 4. Ollama LAN Configuration

### 4.1 Network Topology

```
+-------------------------+           LAN (192.168.1.0/24)
|   lean @ 192.168.1.135  |<------->+--------------------------+
|   (dev machine)         |          |  ecolife-2 :11434       |
|                         |          |  (Ollama inference)      |
|  MCP servers run here   |          |  32GB RAM                |
|  Kimi/OpenCode/Goose    |          |  Gemma4, nomic-embed, etc|
+-------------------------+          +--------------------------+
                                         ^
                                         |
                                    Firewall: port 11434 open
```

### 4.2 Ollama Configuration on ecolife-2

On the `ecolife-2` machine, configure Ollama to listen on all interfaces:

```bash
# /etc/systemd/system/ollama.service.d/override.conf
# Create this directory and file if they don't exist
sudo mkdir -p /etc/systemd/system/ollama.service.d
sudo tee /etc/systemd/system/ollama.service.d/override.conf << 'EOF'
[Service]
Environment="OLLAMA_HOST=0.0.0.0:11434"
Environment="OLLAMA_ORIGINS=*"
EOF

# Reload and restart
sudo systemctl daemon-reload
sudo systemctl restart ollama

# Verify it's listening on all interfaces
ss -tlnp | grep 11434
# Expected: LISTEN 0.0.0.0:11434
```

**Alternative** (if not using systemd): Add to `~/.bashrc` on ecolife-2:

```bash
export OLLAMA_HOST=0.0.0.0:11434
export OLLAMA_ORIGINS=*
```

Then restart Ollama manually.

### 4.3 Client Configuration on lean

On the `lean` development machine:

```bash
# ~/.bashrc
export OLLAMA_HOST=http://ecolife-2:11434
```

**Verify connectivity:**

```bash
# From lean machine
curl http://ecolife-2:11434/api/tags | jq .

# Should return a JSON list of available models
```

### 4.4 Model Catalog

Available models on ecolife-2 (pre-configured):

| Model | Size | Purpose | VRAM Required |
|-------|------|---------|---------------|
| `gemma4` | ~4B parameters | General chat, coding | ~8GB |
| `nomic-embed-text` | ~137M parameters | Document embeddings | ~1GB |
| `llama3.1` | 8B parameters | Complex reasoning | ~16GB |
| `codellama` | 7B parameters | Code completion | ~14GB |
| `mistral` | 7B parameters | Fast general queries | ~14GB |

**Pull additional models:**

```bash
# From lean machine (uses OLLAMA_HOST automatically)
ollama pull gemma4
ollama pull nomic-embed-text
ollama pull llama3.1
```

**List installed models:**

```bash
ollama list
```

### 4.5 Model Switching

The `ollama-bridge` server supports dynamic model selection:

```python
# Agent requests a specific model
await tools.ollama_generate(
    model="gemma4",
    prompt="Explain quantum computing",
    options={"temperature": 0.7}
)

# Or use embeddings model
await tools.ollama_embed(
    model="nomic-embed-text",
    text="Document content to embed"
)
```

**Default model** is set via environment variable:

```yaml
# config.yaml
servers:
  ollama-bridge:
    env:
      OLLAMA_HOST: "http://ecolife-2:11434"
      DEFAULT_MODEL: "gemma4"
      EMBED_MODEL: "nomic-embed-text"
```

### 4.6 Performance Tuning for 32GB RAM

On `ecolife-2`, optimize Ollama for the available 32GB:

```bash
# /etc/systemd/system/ollama.service.d/performance.conf
sudo tee /etc/systemd/system/ollama.service.d/performance.conf << 'EOF'
[Service]
# Allow larger context windows
Environment="OLLAMA_CONTEXT_LENGTH=8192"

# Enable GPU layers if CUDA/ROCm available (auto-detected)
# For CPU-only, Ollama uses all available cores

# Increase file descriptor limits
LimitNOFILE=65536
EOF

sudo systemctl daemon-reload
sudo systemctl restart ollama
```

**Monitor resource usage:**

```bash
# On ecolife-2
watch -n 2 'free -h && echo "---" && ps aux | grep ollama | grep -v grep'
```

**Expected performance:**
- gemma4: ~30-50 tokens/sec (CPU), ~80-120 tokens/sec (GPU)
- nomic-embed-text: ~100 docs/sec embedding

### 4.7 Health Check Endpoint

The Ollama server itself provides a health endpoint:

```bash
curl http://ecolife-2:11434/api/tags
# HTTP 200 + JSON model list = healthy
# Connection refused = Ollama not running
# Timeout = network/firewall issue
```

The `ollama-bridge` MCP server exposes:

```python
# Tool: ollama_health_check
{
  "status": "healthy",
  "host": "ecolife-2:11434",
  "models_loaded": ["gemma4", "nomic-embed-text"],
  "default_model": "gemma4",
  "latency_ms": 12
}
```

---

## 5. rclone Bridge

### 5.1 Remote Configuration

The Google Drive remote `lean` is pre-configured in rclone:

```bash
# ~/.config/rclone/rclone.conf — verify it exists:
cat ~/.config/rclone/rclone.conf

# Expected output:
# [lean]
# type = drive
# client_id = your_client_id.apps.googleusercontent.com
# client_secret = your_client_secret
# token = {"access_token":"...","token_type":"Bearer","refresh_token":"...","expiry":"..."}
# scope = drive
```

**Verify the remote works:**

```bash
rclone lsf lean: | head -20
```

### 5.2 Common Operations Reference

| Operation | rclone Command | Purpose |
|-----------|---------------|---------|
| List files | `rclone lsf lean:path` | See what's in a folder |
| Copy up | `rclone copy local lean:remote` | Upload files |
| Copy down | `rclone copy lean:remote local` | Download files |
| Sync up | `rclone sync local lean:remote` | Make remote match local (destructive) |
| Sync down | `rclone sync lean:remote local` | Make local match remote (destructive) |
| Mount | `rclone mount lean: ~/gdrive` | Access as filesystem |
| Check | `rclone check local lean:remote` | Compare without changing |
| Size | `rclone size lean:path` | Show total size |

### 5.3 Safety Wrapper — Dry-Run First

**CRITICAL:** Every write operation must use `--dry-run` first.

The `rclone-bridge` MCP server enforces this pattern:

```python
async def gdrive_sync_local_to_remote(local_path: str, remote_path: str):
    """
    1. Runs `rclone sync --dry-run` and captures output
    2. Returns proposed changes to the agent
    3. Agent must call `gdrive_confirm_sync()` to execute
    """
    dry_run_result = await run_rclone(
        "sync", local_path, f"lean:{remote_path}",
        "--dry-run", "--stats-one-line", "-v"
    )
    return {
        "dry_run": True,
        "changes": parse_changes(dry_run_result),
        "confirm_required": True,
        "confirm_token": generate_token()
    }
```

### 5.4 MCP Tools for rclone

The `rclone-bridge` server exposes these tools to AI agents:

#### `gdrive_list(path)`

```python
# List files in a Google Drive path
result = await tools.gdrive_list("projects/agent-toolkit")
# Returns:
# [
#   {"name": "README.md", "size": 15234, "mod_time": "2025-01-15T10:30:00Z", "is_dir": false},
#   {"name": "src", "size": 0, "mod_time": "2025-01-15T10:30:00Z", "is_dir": true}
# ]
```

#### `gdrive_sync_local_to_remote(local_path, remote_path)`

```python
# Step 1: Dry run
preview = await tools.gdrive_sync_local_to_remote(
    local_path="/home/lean/projects/agent-toolkit",
    remote_path="backups/agent-toolkit/2025-01-20"
)
# Returns: {dry_run: true, changes: [...files to upload...], confirm_token: "abc123"}

# Step 2: Confirm (if changes look correct)
result = await tools.gdrive_confirm_sync(confirm_token="abc123")
# Returns: {success: true, files_transferred: 42, bytes_transferred: 1048576}
```

#### `gdrive_sync_remote_to_local(remote_path, local_path)`

```python
# Download from Google Drive to local (same dry-run pattern)
preview = await tools.gdrive_sync_remote_to_local(
    remote_path="templates/python-project",
    local_path="/home/lean/projects/new-project"
)
```

#### `gdrive_backup(project_name)` — Automated Backup Pattern

```python
# Intelligent backup with timestamp and retention
result = await tools.gdrive_backup("agent-toolkit")

# This executes:
# 1. rclone sync --dry-run /home/lean/projects/agent-toolkit lean:backups/agent-toolkit/2025-01-20_143022/
# 2. If confirmed: actual sync
# 3. Cleanup: keep only last 10 backups (configurable)
# 4. Return: {backup_path, files_count, size_bytes, retention_kept}
```

### 5.5 rclone-bridge Environment Variables

```yaml
# config.yaml snippet
servers:
  rclone-bridge:
    command: python -m agent_toolkit.servers.rclone_bridge
    env:
      RCLONE_REMOTE: "lean"
      RCLONE_CONFIG: "/home/lean/.config/rclone/rclone.conf"
      RCLONE_BACKUP_RETENTION: "10"       # keep last N backups
      RCLONE_DRY_RUN_REQUIRED: "true"     # enforce safety wrapper
      RCLONE_DEFAULT_BACKUP_ROOT: "backups"
      RCLONE_TRANSFERS: "4"               # parallel transfers
      RCLONE_CHECKERS: "8"                # parallel checkers
      RCLONE_FAST_LIST: "true"            # use Google Drive batch API
```

### 5.6 Manual rclone Commands (for debugging)

```bash
# List top-level files
rclone lsf lean: | head -20

# Check disk usage of a folder
rclone size lean:backups/agent-toolkit

# Compare local and remote (no changes made)
rclone check /home/lean/projects/agent-toolkit lean:backups/agent-toolkit/latest

# Mount Google Drive (read-only, for inspection)
mkdir -p ~/gdrive
rclone mount lean: ~/gdrive --read-only --daemon
ls ~/gdrive
fusermount -u ~/gdrive  # unmount

# Perform a manual dry-run sync
rclone sync /home/lean/projects/agent-toolkit lean:backups/agent-toolkit-test \
  --dry-run -v --stats-one-line
```

---

## 6. MCP.json Templates

### 6.1 For Kimi CLI

Kimi CLI reads MCP configuration from `~/.config/kimi/mcp.json`:

```json
{
  "mcpServers": {
    "file-ops-safe": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.file_ops_safe"],
      "env": {
        "ALLOWED_DIRS": "/home/lean/projects,/home/lean/documents",
        "REQUIRE_CONFIRM": "true",
        "MAX_FILE_SIZE_MB": "50"
      },
      "timeout": 30,
      "description": "Safe file operations with path validation and confirmation gates"
    },
    "solar-calc": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.solar_calc"],
      "env": {},
      "timeout": 10,
      "description": "Solar position, irradiance, and daylight calculations"
    },
    "health-ops": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.health_ops"],
      "env": {
        "DB_PATH": "/home/lean/.local/share/agent-toolkit/health.db"
      },
      "timeout": 10,
      "description": "Health metrics logging, trends, and analysis"
    },
    "rag-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rag_bridge"],
      "env": {
        "OLLAMA_HOST": "http://ecolife-2:11434",
        "EMBED_MODEL": "nomic-embed-text",
        "CHUNK_SIZE": "512",
        "CHUNK_OVERLAP": "64",
        "VECTOR_STORE_PATH": "/home/lean/.local/share/agent-toolkit/vectors"
      },
      "timeout": 120,
      "description": "RAG pipeline: document ingestion, embedding, and semantic search"
    },
    "memory-store": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.memory_store"],
      "env": {
        "DB_PATH": "/home/lean/.local/share/agent-toolkit/memory.db",
        "MAX_CONTEXT_MESSAGES": "50"
      },
      "timeout": 10,
      "description": "Persistent conversation memory and key-value storage"
    },
    "ollama-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.ollama_bridge"],
      "env": {
        "OLLAMA_HOST": "http://ecolife-2:11434",
        "DEFAULT_MODEL": "gemma4",
        "EMBED_MODEL": "nomic-embed-text",
        "MAX_CONTEXT_LENGTH": "8192",
        "REQUEST_TIMEOUT": "300"
      },
      "timeout": 300,
      "description": "Ollama inference bridge for text generation and embeddings"
    },
    "rclone-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rclone_bridge"],
      "env": {
        "RCLONE_REMOTE": "lean",
        "RCLONE_CONFIG": "/home/lean/.config/rclone/rclone.conf",
        "RCLONE_BACKUP_RETENTION": "10",
        "RCLONE_DRY_RUN_REQUIRED": "true",
        "RCLONE_DEFAULT_BACKUP_ROOT": "backups",
        "RCLONE_TRANSFERS": "4",
        "RCLONE_CHECKERS": "8",
        "RCLONE_FAST_LIST": "true"
      },
      "timeout": 300,
      "description": "Google Drive integration via rclone with dry-run safety"
    },
    "github": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.github_mcp"],
      "env": {
        "GITHUB_TOKEN": "${GITHUB_TOKEN}",
        "GITHUB_CACHE_TTL": "300",
        "GITHUB_API_BASE": "https://api.github.com"
      },
      "timeout": 60,
      "description": "GitHub repository, issue, PR, and code search operations"
    },
    "supabase": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.supabase_mcp"],
      "env": {
        "SUPABASE_URL": "${SUPABASE_URL}",
        "SUPABASE_KEY": "${SUPABASE_KEY}"
      },
      "timeout": 60,
      "description": "Supabase cloud database operations (optional)"
    }
  }
}
```

### 6.2 For OpenCode CLI

OpenCode CLI reads MCP configuration from `~/.config/opencode/mcp.json`:

```json
{
  "mcpServers": {
    "file-ops-safe": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.file_ops_safe"],
      "env": {
        "ALLOWED_DIRS": "/home/lean/projects,/home/lean/documents",
        "REQUIRE_CONFIRM": "true",
        "MAX_FILE_SIZE_MB": "50"
      },
      "timeout": 30
    },
    "solar-calc": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.solar_calc"],
      "env": {},
      "timeout": 10
    },
    "health-ops": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.health_ops"],
      "env": {
        "DB_PATH": "/home/lean/.local/share/agent-toolkit/health.db"
      },
      "timeout": 10
    },
    "rag-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rag_bridge"],
      "env": {
        "OLLAMA_HOST": "http://ecolife-2:11434",
        "EMBED_MODEL": "nomic-embed-text",
        "CHUNK_SIZE": "512",
        "CHUNK_OVERLAP": "64",
        "VECTOR_STORE_PATH": "/home/lean/.local/share/agent-toolkit/vectors"
      },
      "timeout": 120
    },
    "memory-store": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.memory_store"],
      "env": {
        "DB_PATH": "/home/lean/.local/share/agent-toolkit/memory.db",
        "MAX_CONTEXT_MESSAGES": "50"
      },
      "timeout": 10
    },
    "ollama-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.ollama_bridge"],
      "env": {
        "OLLAMA_HOST": "http://ecolife-2:11434",
        "DEFAULT_MODEL": "gemma4",
        "EMBED_MODEL": "nomic-embed-text",
        "MAX_CONTEXT_LENGTH": "8192",
        "REQUEST_TIMEOUT": "300"
      },
      "timeout": 300
    },
    "rclone-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rclone_bridge"],
      "env": {
        "RCLONE_REMOTE": "lean",
        "RCLONE_CONFIG": "/home/lean/.config/rclone/rclone.conf",
        "RCLONE_BACKUP_RETENTION": "10",
        "RCLONE_DRY_RUN_REQUIRED": "true",
        "RCLONE_DEFAULT_BACKUP_ROOT": "backups",
        "RCLONE_TRANSFERS": "4",
        "RCLONE_CHECKERS": "8",
        "RCLONE_FAST_LIST": "true"
      },
      "timeout": 300
    },
    "github": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.github_mcp"],
      "env": {
        "GITHUB_TOKEN": "${GITHUB_TOKEN}",
        "GITHUB_CACHE_TTL": "300",
        "GITHUB_API_BASE": "https://api.github.com"
      },
      "timeout": 60
    },
    "supabase": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.supabase_mcp"],
      "env": {
        "SUPABASE_URL": "${SUPABASE_URL}",
        "SUPABASE_KEY": "${SUPABASE_KEY}"
      },
      "timeout": 60
    }
  }
}
```

### 6.3 For Goose CLI

Goose CLI reads MCP configuration from `~/.config/goose/mcp-config.json`:

```json
{
  "mcpServers": {
    "file-ops-safe": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.file_ops_safe"],
      "env": {
        "ALLOWED_DIRS": "/home/lean/projects,/home/lean/documents",
        "REQUIRE_CONFIRM": "true",
        "MAX_FILE_SIZE_MB": "50"
      },
      "timeout": 30
    },
    "solar-calc": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.solar_calc"],
      "env": {},
      "timeout": 10
    },
    "health-ops": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.health_ops"],
      "env": {
        "DB_PATH": "/home/lean/.local/share/agent-toolkit/health.db"
      },
      "timeout": 10
    },
    "rag-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rag_bridge"],
      "env": {
        "OLLAMA_HOST": "http://ecolife-2:11434",
        "EMBED_MODEL": "nomic-embed-text",
        "CHUNK_SIZE": "512",
        "CHUNK_OVERLAP": "64",
        "VECTOR_STORE_PATH": "/home/lean/.local/share/agent-toolkit/vectors"
      },
      "timeout": 120
    },
    "memory-store": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.memory_store"],
      "env": {
        "DB_PATH": "/home/lean/.local/share/agent-toolkit/memory.db",
        "MAX_CONTEXT_MESSAGES": "50"
      },
      "timeout": 10
    },
    "ollama-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.ollama_bridge"],
      "env": {
        "OLLAMA_HOST": "http://ecolife-2:11434",
        "DEFAULT_MODEL": "gemma4",
        "EMBED_MODEL": "nomic-embed-text",
        "MAX_CONTEXT_LENGTH": "8192",
        "REQUEST_TIMEOUT": "300"
      },
      "timeout": 300
    },
    "rclone-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rclone_bridge"],
      "env": {
        "RCLONE_REMOTE": "lean",
        "RCLONE_CONFIG": "/home/lean/.config/rclone/rclone.conf",
        "RCLONE_BACKUP_RETENTION": "10",
        "RCLONE_DRY_RUN_REQUIRED": "true",
        "RCLONE_DEFAULT_BACKUP_ROOT": "backups",
        "RCLONE_TRANSFERS": "4",
        "RCLONE_CHECKERS": "8",
        "RCLONE_FAST_LIST": "true"
      },
      "timeout": 300
    },
    "github": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.github_mcp"],
      "env": {
        "GITHUB_TOKEN": "${GITHUB_TOKEN}",
        "GITHUB_CACHE_TTL": "300",
        "GITHUB_API_BASE": "https://api.github.com"
      },
      "timeout": 60
    },
    "supabase": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.supabase_mcp"],
      "env": {
        "SUPABASE_URL": "${SUPABASE_URL}",
        "SUPABASE_KEY": "${SUPABASE_KEY}"
      },
      "timeout": 60
    }
  }
}
```

### 6.4 Quick Config Installation

```bash
# Create all config directories
mkdir -p ~/.config/kimi ~/.config/opencode ~/.config/goose

# Copy templates (after filling in your tokens)
cp /mnt/agents/output/mcp-kimi.json ~/.config/kimi/mcp.json
cp /mnt/agents/output/mcp-opencode.json ~/.config/opencode/mcp.json
cp /mnt/agents/output/mcp-goose.json ~/.config/goose/mcp-config.json

# Set permissions (configs contain secrets)
chmod 600 ~/.config/kimi/mcp.json ~/.config/opencode/mcp.json ~/.config/goose/mcp-config.json
```

---

## 7. Cross-Machine Setup

### 7.1 SSH Key Setup

MCP servers on `lean` need passwordless SSH to `ecolife-2` for certain operations (direct file transfer, remote command execution).

**On `lean` (192.168.1.135):**

```bash
# Generate SSH key if not exists
ssh-keygen -t ed25519 -C "lean@agent-toolkit" -f ~/.ssh/id_ed25519 -N ""

# Copy public key to ecolife-2
ssh-copy-id -i ~/.ssh/id_ed25519.pub lean@ecolife-2
# Or if different user on ecolife-2:
# ssh-copy-id -i ~/.ssh/id_ed25519.pub user@ecolife-2

# Test passwordless login
ssh ecolife-2 'echo "SSH OK from lean"'
```

**On `ecolife-2`:**

```bash
# Ensure SSH server is running
sudo systemctl status sshd
# If not: sudo systemctl enable --now sshd

# Check sshd is listening on all interfaces
ss -tlnp | grep :22
```

### 7.2 Ollama Network Path

The MCP servers on `lean` call Ollama via HTTP, not SSH. The data flow:

```
Kimi/OpenCode/Goose on lean
    |
    v (stdio)
ollama-bridge MCP server on lean
    |
    v (HTTP GET/POST to http://ecolife-2:11434)
Ollama API server on ecolife-2
    |
    v (inference)
Loaded model in ecolife-2 RAM/VRAM
```

No SSH tunnel is required since both machines are on the same LAN (192.168.1.0/24).

### 7.3 Firewall Configuration

**On `ecolife-2` — allow Ollama port:**

```bash
# Check current firewall status
sudo ufw status

# If UFW is active, allow port 11434 from LAN only
sudo ufw allow from 192.168.1.0/24 to any port 11434 comment "Ollama LAN access"

# Alternative: iptables
sudo iptables -A INPUT -p tcp -s 192.168.1.0/24 --dport 11434 -j ACCEPT
sudo iptables-save | sudo tee /etc/iptables/rules.v4

# Verify port is accessible from lean
# (run this on lean)
nc -zv ecolife-2 11434
# Expected: Connection to ecolife-2 11434 port [tcp/*] succeeded!
```

**On `lean` — outbound only (no inbound needed):**

No firewall changes needed on `lean` — it only makes outbound HTTP requests to `ecolife-2:11434`.

### 7.4 Service Discovery

For this two-machine setup, we use **hardcoded configuration** — the simplest and most reliable approach:

```yaml
# ~/.config/agent-toolkit/config.yaml
network:
  discovery_method: "static"  # options: static, dns, mdns

hosts:
  ecolife-2:
    ip: "192.168.1.XXX"     # fill in actual IP
    hostname: "ecolife-2"
    services:
      ollama: 11434
      ssh: 22

  lean:
    ip: "192.168.1.135"
    hostname: "lean"
    services:
      mcp_hub: "stdio"      # local only
```

**To find ecolife-2's IP:**

```bash
# On ecolife-2
ip addr show | grep "192.168.1"
# or
hostname -I
```

**Future: mDNS discovery** (if you want automatic detection):

```bash
# Install avahi for hostname.local resolution
sudo apt install avahi-daemon

# Then use http://ecolife-2.local:11434 instead of IP
```

### 7.5 Testing Cross-Machine Connectivity

Run this full verification from `lean`:

```bash
#!/bin/bash
# ~/bin/test-cross-machine.sh

echo "=== Cross-Machine Connectivity Test ==="
echo ""

echo "[1] SSH to ecolife-2..."
ssh ecolife-2 'echo "  SSH: OK"' || echo "  SSH: FAILED"
echo ""

echo "[2] Ollama API (tags)..."
curl -s http://ecolife-2:11434/api/tags | jq -r '.models[].name' | head -5 | sed 's/^/  /'
echo ""

echo "[3] Ollama generate test..."
curl -s http://ecolife-2:11434/api/generate \
  -H "Content-Type: application/json" \
  -d '{"model":"gemma4","prompt":"Say OK","stream":false}' | \
  jq -r '.response' | sed 's/^/  /'
echo ""

echo "[4] Ollama embedding test..."
curl -s http://ecolife-2:11434/api/embeddings \
  -H "Content-Type: application/json" \
  -d '{"model":"nomic-embed-text","prompt":"test"}' | \
  jq '.embedding | length' | sed 's/^/  Embedding dimensions: /'
echo ""

echo "=== Tests Complete ==="
```

---

## 8. Health Check & Monitoring

### 8.1 Per-Server Health Check

Each MCP server exposes a `health` tool that returns structured status:

```python
# Tool: health_check (available in every server)
result = await tools.health_check()
```

**Example response:**

```json
{
  "server": "ollama-bridge",
  "status": "healthy",
  "timestamp": "2025-01-20T14:30:22Z",
  "checks": {
    "ollama_reachable": true,
    "default_model_available": true,
    "embedding_model_available": true,
    "latency_ms": 12
  },
  "version": "1.0.0"
}
```

### 8.2 Hub-Level Health Aggregation

```bash
# Check all servers at once
agent-toolkit health

# Expected output:
# NAME            STATUS    HEALTH    LATENCY    LAST_CHECK
# file-ops-safe   running   ok        2ms        14:30:15
# solar-calc      running   ok        1ms        14:30:16
# health-ops      running   ok        1ms        14:30:14
# rag-bridge      running   ok        45ms       14:30:10
# memory-store    running   ok        1ms        14:30:17
# ollama-bridge   running   ok        12ms       14:30:12
# rclone-bridge   running   ok        8ms        14:30:18
# github          running   ok        156ms      14:30:08
# supabase        stopped   n/a       n/a        n/a
```

### 8.3 Integration Verification Commands

Run these in sequence to verify the full stack:

```bash
# ============================================================
# FULL INTEGRATION VERIFICATION SCRIPT
# Run this on: lean@192.168.1.135
# ============================================================

#!/bin/bash
set -e

echo "========================================="
echo "  agent-toolkit Integration Verification"
echo "========================================="
echo ""

# --- [1] Environment Variables ---
echo "[1/8] Environment variables..."
: "${GITHUB_TOKEN:?GITHUB_TOKEN not set}"
: "${OLLAMA_HOST:?OLLAMA_HOST not set}"
echo "      GITHUB_TOKEN: ${GITHUB_TOKEN:0:8}..."
echo "      OLLAMA_HOST: $OLLAMA_HOST"
echo "      ✓ OK"
echo ""

# --- [2] MCP Hub ---
echo "[2/8] MCP Hub..."
agent-toolkit --version
echo "      ✓ OK"
echo ""

# --- [3] Ollama Bridge ---
echo "[3/8] Ollama Bridge (ecolife-2)..."
curl -sf "$OLLAMA_HOST/api/tags" > /dev/null && echo "      ✓ Ollama reachable"
curl -sf "$OLLAMA_HOST/api/generate" \
  -H "Content-Type: application/json" \
  -d '{"model":"gemma4","prompt":"hi","stream":false}' > /dev/null && echo "      ✓ gemma4 responds"
echo ""

# --- [4] rclone Bridge ---
echo "[4/8] rclone Bridge..."
rclone lsf lean: > /dev/null && echo "      ✓ Remote 'lean' accessible"
echo ""

# --- [5] GitHub ---
echo "[5/8] GitHub API..."
curl -sf -H "Authorization: token $GITHUB_TOKEN" \
  https://api.github.com/user | jq -r '.login' | xargs echo "      ✓ Authenticated as:"
echo ""

# --- [6] SQLite Databases ---
echo "[6/8] Local databases..."
test -f ~/.local/share/agent-toolkit/memory.db && echo "      ✓ memory.db exists"
test -f ~/.local/share/agent-toolkit/health.db && echo "      ✓ health.db exists"
echo ""

# --- [7] Supabase (optional) ---
echo "[7/8] Supabase (optional)..."
if [ -n "$SUPABASE_URL" ]; then
  curl -sf "$SUPABASE_URL/rest/v1/" \
    -H "apikey: $SUPABASE_KEY" > /dev/null && echo "      ✓ Supabase reachable"
else
  echo "      ⊙ Skipped (SUPABASE_URL not set)"
fi
echo ""

# --- [8] MCP Servers Status ---
echo "[8/8] MCP Server processes..."
agent-toolkit status
echo ""

echo "========================================="
echo "  All integrations verified!"
echo "========================================="
```

### 8.4 Troubleshooting Guide

#### Problem: "Connection refused" to Ollama

**Symptoms:** `curl http://ecolife-2:11434` fails with "Connection refused"

**Diagnostics:**
```bash
# 1. Is Ollama running on ecolife-2?
ssh ecolife-2 'systemctl status ollama'

# 2. Is it listening on all interfaces?
ssh ecolife-2 'ss -tlnp | grep 11434'
# Should show 0.0.0.0:11434, not 127.0.0.1:11434

# 3. Firewall blocking?
ssh ecolife-2 'sudo ufw status'
# Should show port 11434 ALLOW from 192.168.1.0/24
```

**Fix:**
```bash
# On ecolife-2
sudo systemctl restart ollama
sudo ufw allow from 192.168.1.0/24 to any port 11434
```

---

#### Problem: GitHub API returns 401 Unauthorized

**Symptoms:** GitHub tools fail with "Bad credentials"

**Diagnostics:**
```bash
curl -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/user
echo $GITHUB_TOKEN | wc -c  # Should be ~40+ chars
```

**Fix:**
```bash
# 1. Check token is set
echo "Token prefix: ${GITHUB_TOKEN:0:4}"  # Should show "ghp_" or "gho_"

# 2. Regenerate at https://github.com/settings/tokens
# 3. Update in ~/.bashrc and reload
export GITHUB_TOKEN="ghp_NEWTOKEN"
# 4. Restart MCP server
agent-toolkit restart github
```

---

#### Problem: rclone "remote not found"

**Symptoms:** `gdrive_list()` returns "didn't find section in config file"

**Diagnostics:**
```bash
rclone listremotes  # Should show "lean:"
cat ~/.config/rclone/rclone.conf | grep "^\[lean\]"
```

**Fix:**
```bash
# Re-authenticate the remote
rclone config reconnect lean:
# Follow the OAuth flow, copy the token back
```

---

#### Problem: MCP server process crashes on startup

**Symptoms:** `agent-toolkit status` shows "stopped" immediately after start

**Diagnostics:**
```bash
# Check server logs
journalctl --user -u agent-toolkit -n 50

# Or run the server manually to see the error
python -m agent_toolkit.servers.ollama_bridge
```

**Common causes:**

| Cause | Error Sign | Fix |
|-------|-----------|-----|
| Missing env var | `KeyError: 'OLLAMA_HOST'` | Add to `~/.bashrc` and `source` it |
| Port conflict | `Address already in use` | Kill old process: `pkill -f ollama_bridge` |
| Module not found | `No module named 'agent_toolkit'` | `pip install -e .` from project root |
| Permission denied | `[Errno 13]` | `chmod 755` the module directory |

---

#### Problem: Supabase connection timeout

**Symptoms:** Supabase tools hang for 60 seconds then fail

**Diagnostics:**
```bash
curl -v "$SUPABASE_URL/rest/v1/" -H "apikey: $SUPABASE_KEY"
```

**Fix:**
```bash
# 1. Verify URL is correct (no trailing slash issues)
echo "URL: $SUPABASE_URL"

# 2. Verify key hasn't expired
# Get new anon key from Supabase dashboard > Project Settings > API

# 3. Check network connectivity
ping "$(echo $SUPABASE_URL | sed 's|https://||' | sed 's|/.*||')"

# 4. Disable Supabase server if not needed
agent-toolkit disable supabase
```

---

#### Problem: Kimi/OpenCode/Goose doesn't see MCP tools

**Symptoms:** AI assistant responds "I don't have access to that tool"

**Diagnostics:**
```bash
# Verify config file exists and is valid JSON
python -m json.tool ~/.config/kimi/mcp.json > /dev/null && echo "Valid JSON"

# Check if server process is running
ps aux | grep agent_toolkit.servers | grep -v grep
```

**Fix:**
```bash
# 1. Restart the specific CLI to pick up new config
# Kimi: press Ctrl+C then re-run `kimi`
# OpenCode: opencode --restart
# Goose: goose session --restart

# 2. Verify the MCP server starts manually
python -m agent_toolkit.servers.github_mcp
# Should show JSON-RPC initialization and wait for input
```

---

#### Problem: Slow Ollama responses

**Symptoms:** Responses take >30 seconds even for simple prompts

**Diagnostics:**
```bash
# Check if model is loaded in RAM
ssh ecolife-2 'ps aux | grep ollama'
ssh ecolife-2 'free -h'
# Check CPU usage during generation
ssh ecolife-2 'top -bn1 | head -20'
```

**Fix:**
```bash
# On ecolife-2:
# 1. Stop unnecessary services to free RAM
sudo systemctl stop unused-service

# 2. Use a smaller model for simple tasks
# Edit DEFAULT_MODEL to "gemma4" instead of "llama3.1"

# 3. Check if swap is being used (slow)
ssh ecolife-2 'free -h | grep Swap'
# If swap > 0, reduce concurrent model loading
```

---

### 8.5 Log Aggregation

All MCP servers write structured logs to `~/.local/share/agent-toolkit/logs/`:

```bash
# Tail all server logs
tail -f ~/.local/share/agent-toolkit/logs/*.log

# Search for errors across all servers
grep -r "ERROR" ~/.local/share/agent-toolkit/logs/ | tail -20

# Get log for a specific server
cat ~/.local/share/agent-toolkit/logs/ollama-bridge.log
```

**Log format (JSON Lines):**

```json
{"timestamp": "2025-01-20T14:30:22Z", "server": "ollama-bridge", "level": "INFO", "message": "Request completed", "latency_ms": 1250, "model": "gemma4"}
{"timestamp": "2025-01-20T14:30:23Z", "server": "github", "level": "WARNING", "message": "Rate limit low", "remaining": 47}
```

---

## Appendix A: Environment Variables Summary

| Variable | Required By | Set In | Description |
|----------|------------|--------|-------------|
| `GITHUB_TOKEN` | github server | `~/.bashrc` | GitHub Personal Access Token |
| `OLLAMA_HOST` | ollama-bridge, rag-bridge | `~/.bashrc` | Ollama API endpoint |
| `SUPABASE_URL` | supabase server | `~/.bashrc` | Supabase project URL |
| `SUPABASE_KEY` | supabase server | `~/.bashrc` | Supabase anon/public key |
| `RCLONE_CONFIG` | rclone-bridge | `config.yaml` | Path to rclone config file |

## Appendix B: Port Reference

| Port | Service | Machine | Direction |
|------|---------|---------|-----------|
| 22 | SSH | ecolife-2 | lean → ecolife-2 |
| 11434 | Ollama API | ecolife-2 | lean → ecolife-2 |
| 443 | GitHub API | github.com | lean → internet |
| 443 | Supabase API | *.supabase.co | lean → internet (optional) |

## Appendix C: File Locations

| File | Path | Purpose |
|------|------|---------|
| Hub config | `~/.config/agent-toolkit/config.yaml` | Server registry and settings |
| Kimi MCP | `~/.config/kimi/mcp.json` | Kimi CLI MCP configuration |
| OpenCode MCP | `~/.config/opencode/mcp.json` | OpenCode CLI MCP configuration |
| Goose MCP | `~/.config/goose/mcp-config.json` | Goose CLI MCP configuration |
| rclone config | `~/.config/rclone/rclone.conf` | Google Drive remote credentials |
| SQLite DBs | `~/.local/share/agent-toolkit/*.db` | Local databases |
| Logs | `~/.local/share/agent-toolkit/logs/*.log` | Server logs |
| Ollama override | `/etc/systemd/system/ollama.service.d/override.conf` | Ollama network binding |

---

> **End of Integration Guide.** For questions or issues, check the troubleshooting section above or run the integration verification script to diagnose.
