# agent-toolkit — Phased Execution Roadmap

> **Project:** Self-hosted MCP (Model Context Protocol) Server Hub
> **Philosophy:** Slow but safe. Part-time development. Production-grade from day one.
> **Dev Machine:** `lean@192.168.1.135`
> **Agent Machine:** `ecolife-2` (32GB RAM, Ollama 24/7)
> **Access:** mosh/ssh via Blink on iPad; persistent tmux sessions
> **Target CLIs:** Kimi CLI, OpenCode CLI, Goose CLI
> **Document Version:** 1.0
> **Last Updated:** 2025-01-20

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [High-Level Timeline](#2-high-level-timeline)
3. [Week 1: Foundation — Detailed Breakdown](#3-week-1-foundation)
4. [Week 2: Domain Servers — Detailed Breakdown](#4-week-2-domain-servers)
5. [Week 3: Cross-Machine Deployment — Detailed Breakdown](#5-week-3-cross-machine-deployment)
6. [Week 4: Hardening — Detailed Breakdown](#6-week-4-hardening)
7. [Dependency Graph](#7-dependency-graph)
8. [Resource Allocation](#8-resource-allocation)
9. [Go/No-Go Criteria](#9-gono-go-criteria)
10. [Risk Register](#10-risk-register)
11. [Definition of Done](#11-definition-of-done)
12. [Daily Workflow](#12-daily-workflow)
13. [Appendix A: MCP Server Registry](#appendix-a-mcp-server-registry)
14. [Appendix B: Configuration Schema](#appendix-b-configuration-schema)

---

## 1. Executive Summary

The **agent-toolkit** is a self-hosted hub of MCP (Model Context Protocol) servers designed to extend the capabilities of CLI-based AI coding assistants (Kimi CLI, OpenCode CLI, Goose CLI). It runs primarily on the `ecolife-2` agent machine with 32GB RAM, leveraging local Ollama for embeddings and inference, while development happens on the `lean` workstation.

This roadmap breaks the project into four weekly sprints, each with concrete deliverables, acceptance criteria, and risk mitigations. The total estimated effort is **40–48 hours** spread across four weeks (approximately **10–12 hours per week**), aligned with part-time availability.

### Core Design Principles

1. **Safety First:** Every destructive operation must pass through a `dry_run` gate, a confirmation prompt, and a git backup layer. No exceptions.
2. **Zero External Dependencies at Runtime:** All servers must function fully using only local resources (Ollama, SQLite, filesystem). External services (Google Drive via rclone, LINE POS) are bridged, not required.
3. **Shared Context:** All servers read from and write to a single SQLite-backed context layer, enabling cross-tool memory and state persistence.
4. **Graceful Degradation:** If Ollama is unavailable, if SSH to `ecolife-2` fails, or if a server crashes, the system must fall back to safe, predictable behavior — never silent failures.
5. **Observable:** Every action is logged. Every error is captured. Every decision is traceable.

---

## 2. High-Level Timeline

### Gantt-Style Sprint Overview

```
WEEK:        [Week 1: Foundation]         [Week 2: Domain]         [Week 3: Deploy]         [Week 4: Harden]
DAY:         M  T  W  T  F  S  S          M  T  W  T  F  S  S      M  T  W  T  F  S  S      M  T  W  T  F  S  S

Scaffold     ████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
Safety Utils  ░░████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
Shared Ctx   ░░░░░░████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
File Ops     ░░░░░░░░░░████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
Server Base  ░░░░░░░░░░░░░░░░████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
Solar Calc   ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
RAG Bridge   ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░████████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
Health Ops   ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
Memory Store ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
Ollama Br.   ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░
rclone Br.   ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░████████████████░░░░░░░░░░░░░░░░░░░░░░░░░░░
Integration  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░████████████████████░░░░░░░
systemd      ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░████████████████░░░░░░░░░░░
Hardening    ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░████████
Docs/Audit   ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░████████
```

---

## 3. Week 1: Foundation

> **Theme:** Build the bedrock. Nothing fancy — just solid, tested, observable infrastructure.
> **Estimated Hours:** 10–12
> **Key Deliverable:** A runnable file-ops-safe MCP server backed by safety utilities and shared context.

### 3.1 Task: Project Scaffold

- [ ] **Create project directory structure**
  - **Estimated Hours:** 1.5
  - **Dependencies:** None (first task)
  - **Acceptance Criteria:**
    - `agent-toolkit/` root directory exists on `lean`
    - `src/agent_toolkit/` package directory with `__init__.py`
    - `src/agent_toolkit/servers/` subdirectory for all MCP servers
    - `src/agent_toolkit/shared/` for common utilities
    - `tests/` directory mirroring `src/` structure
    - `docs/` directory for operational documentation
    - `scripts/` for deployment and automation scripts
    - `configs/` for server configuration templates
  - **Risk/Mitigation:** Directory confusion → Use `tree` command to verify structure; commit scaffold first before any code

- [ ] **Write `pyproject.toml` with full tool configuration**
  - **Estimated Hours:** 1.5
  - **Dependencies:** Project directory structure
  - **Acceptance Criteria:**
    - Package metadata (name, version `0.1.0`, description, author)
    - Build system: `setuptools` or `hatchling`
    - Dependencies: `mcp`, `httpx`, `sqlite-utils`, `ollama`, `pydantic`, `structlog`, `rich`
    - Dev dependencies: `pytest`, `pytest-asyncio`, `pytest-cov`, `ruff`, `mypy`, `pre-commit`
    - `[tool.ruff]` section: line length 100, select ALL, ignore specific rules (ANN101, D104, etc.)
    - `[tool.mypy]` section: strict mode, disallow untyped defs
    - `[tool.pytest.ini_options]`: asyncio mode auto, testpaths = tests/
    - `[tool.coverage.run]`: source = src/, branch = true
  - **Risk/Mitigation:** Dependency conflicts → Pin all versions; use `pip-compile` if available; test install in a fresh venv before proceeding

- [ ] **Configure pre-commit hooks and initial CI checks**
  - **Estimated Hours:** 1.0
  - **Dependencies:** `pyproject.toml` complete
  - **Acceptance Criteria:**
    - `.pre-commit-config.yaml` with `ruff` (format + lint), `mypy`, `trailing-whitespace`, `end-of-file-fixer`, `check-yaml`, `check-added-large-files`
    - `pre-commit install` has been run successfully
    - `pre-commit run --all-files` passes cleanly on empty scaffold
    - Git repository initialized with `.gitignore` (Python, `.env`, `*.db`, `__pycache__`, `.coverage`)
  - **Risk/Mitigation:** Hook failures blocking commits → Ensure hooks are lightweight; allow `--no-verify` only with explicit override flag

### 3.2 Task: Safety Utilities Module (`src/agent_toolkit/shared/safety.py`)

- [ ] **Implement `@dry_run` decorator**
  - **Estimated Hours:** 1.5
  - **Dependencies:** Project scaffold, pre-commit configured
  - **Acceptance Criteria:**
    - Decorator accepts `enabled: bool = True` parameter
    - When `enabled=True`, prints/log "DRY RUN: would call {func_name} with {args}" and returns without executing
    - When `enabled=False`, executes the wrapped function normally
    - Works with both sync and async functions
    - Preserves function signature and docstring via `functools.wraps`
    - Unit tests: 5 test cases (dry run on, dry run off, async variant, decorator with args, error handling)
  - **Risk/Mitigation:** Async compatibility issues → Test both sync and async variants explicitly

- [ ] **Implement `confirm_gate()` function**
  - **Estimated Hours:** 1.0
  - **Dependencies:** `@dry_run` decorator complete
  - **Acceptance Criteria:**
    - Function takes `operation: str`, `target: str`, `require_typing: bool = True`
    - Displays operation description and target to user via Rich console
    - If `require_typing=True`, requires user to type "yes" to proceed
    - Returns `bool`: `True` if confirmed, `False` if declined
    - Non-interactive mode: reads from environment variable `AGENT_TOOLKIT_CONFIRM=auto`
    - Unit tests: 4 test cases (confirm yes, confirm no, auto mode, invalid input)
  - **Risk/Mitigation:** Blocking in automated contexts → Always respect `AGENT_TOOLKIT_CONFIRM=auto`; never prompt in CI or systemd contexts

- [ ] **Implement `GitBackup` wrapper class**
  - **Estimated Hours:** 2.0
  - **Dependencies:** `@dry_run` decorator, `confirm_gate()` function
  - **Acceptance Criteria:**
    - Class `GitBackup` with methods: `snapshot(paths: list[str]) -> str`, `restore(snapshot_id: str) -> None`, `list_snapshots() -> list[dict]`
    - `snapshot()` creates a temporary git commit in a hidden `.agent-toolkit-backups` repo
    - Returns a snapshot ID (short SHA) for later reference
    - `restore()` checks out a previous snapshot to the original paths
    - Handles binary files gracefully
    - Unit tests: 4 test cases (snapshot creation, restore, list snapshots, snapshot with multiple files)
  - **Risk/Mitigation:** Git not available → Check for `git` binary on init; fail gracefully with warning log; unit tests use tmp_path fixtures

### 3.3 Task: Shared Context Layer (`src/agent_toolkit/shared/context.py`)

- [ ] **Design and implement SQLite schema**
  - **Estimated Hours:** 1.5
  - **Dependencies:** Safety utilities module
  - **Acceptance Criteria:**
    - Database path: `~/.local/share/agent-toolkit/context.db` (XDG compliant)
    - Tables:
      - `memory` (id, key, value, embedding_json, source_server, created_at, updated_at, tags_json)
      - `file_ops_log` (id, operation, target_path, snapshot_sha, result, created_at)
      - `server_health` (id, server_name, status, last_check, error_message, uptime_seconds)
      - `config` (id, key, value_json, updated_at)
    - Schema version table for migrations
    - Connection pooling via `sqlite_utils.Database` or custom pool
    - Automatic `created_at`/`updated_at` triggers
    - Unit tests: Schema validation, connection pool, CRUD operations on each table
  - **Risk/Mitigation:** Concurrent access issues → Use WAL mode (Write-Ahead Logging); implement connection retries with exponential backoff

- [ ] **Implement migration system**
  - **Estimated Hours:** 1.0
  - **Dependencies:** SQLite schema
  - **Acceptance Criteria:**
    - Migrations stored in `src/agent_toolkit/shared/migrations/`
    - Each migration file named `001_description.sql`, `002_description.sql`, etc.
    - `migrate(db_path)` function applies pending migrations in order
    - `get_schema_version(db_path)` returns current version
    - Migrations are idempotent (can be safely re-run)
    - Unit tests: Fresh migration, incremental migration, idempotency check
  - **Risk/Mitigation:** Migration failures → Wrap each migration in a transaction; on failure, rollback and log detailed error; never leave DB in inconsistent state

### 3.4 Task: File Operations MCP Server (`servers/file-ops-safe/`)

- [ ] **Implement MCP server with 4 tools**
  - **Estimated Hours:** 2.5
  - **Dependencies:** Safety utilities, shared context layer
  - **Acceptance Criteria:**
    - Server registered as `file-ops-safe`
    - Tool: `read_file(path: str) -> str` — reads file contents, raises if file > 10MB
    - Tool: `write_file(path: str, content: str, backup: bool = True) -> dict` — writes content, creates git snapshot if backup=True, logs to context DB
    - Tool: `delete_file(path: str, confirm: bool = True) -> dict` — requires `confirm_gate()` if confirm=True, creates snapshot before deletion, logs to context DB
    - Tool: `search_files(directory: str, pattern: str, max_results: int = 50) -> list[dict]` — recursive glob search with size and modification time metadata
    - All tools use `@dry_run` when `AGENT_TOOLKIT_DRY_RUN=1`
    - Server passes `mcp` protocol health checks
  - **Risk/Mitigation:** Accidental overwrites → Every write creates a backup snapshot; confirm gate for deletions; size limits on reads

- [ ] **Integration test: file-ops-safe end-to-end**
  - **Estimated Hours:** 1.0
  - **Dependencies:** File operations server implementation
  - **Acceptance Criteria:**
    - Test script spins up server via `mcp` SDK test client
    - Reads a test file successfully
    - Writes a file with backup, verifies snapshot exists in git
    - Deletes a file with confirmation, verifies restoration from snapshot
    - Search returns expected results
    - All operations logged to context database
  - **Risk/Mitigation:** Test flakiness → Use tmp_path fixtures; ensure clean state between tests; no real filesystem mutations outside test directories

### 3.5 Task: Base MCP Server Template (`src/agent_toolkit/shared/server_base.py`)

- [ ] **Implement abstract base class for all servers**
  - **Estimated Hours:** 1.5
  - **Dependencies:** File-ops-safe (reference implementation)
  - **Acceptance Criteria:**
    - Abstract class `BaseMCPServer` with:
      - `name: str` (abstract property)
      - `version: str` (abstract property)
      - `setup() -> None` (abstract — register tools)
      - `health_check() -> dict` (default: returns {"status": "ok", "timestamp": ...})
      - `run() -> None` (starts the MCP server loop)
      - Built-in config loading from `configs/{name}.json`
      - Built-in structured logging via structlog
      - Graceful shutdown on SIGTERM/SIGINT
    - Concrete usage demonstrated by refactored `file-ops-safe`
    - Unit tests: Base class instantiation, health check, config loading, signal handling
  - **Risk/Mitigation:** Over-engineering → Keep base class minimal; only add methods proven necessary by at least two servers

### Week 1 Summary

| Metric | Target |
|--------|--------|
| Lines of Code | ~800–1000 |
| Test Coverage | >= 85% |
| Passing Tests | All |
| Servers Running | 1 (file-ops-safe) |
| Git Commits | 5–7 |

---

## 4. Week 2: Domain Servers

> **Theme:** Build the six domain-specific MCP servers. Each is independent but shares the base class and context layer.
> **Estimated Hours:** 10–12
> **Key Deliverable:** Six running MCP servers: solar-calc, rag-bridge, health-ops, memory-store, ollama-bridge, rclone-bridge.

### 4.1 Task: Solar Calculator Server (`servers/solar-calc/`)

- [ ] **Implement 5 solar calculation tools**
  - **Estimated Hours:** 2.0
  - **Dependencies:** Base server template, shared context layer
  - **Acceptance Criteria:**
    - Server registered as `solar-calc`
    - Tool: `calculate_daily_production(latitude: float, longitude: float, system_kw: float, panel_tilt: float = 30, panel_azimuth: float = 180, date: str = "today") -> dict` — Uses PVWatts-style simplified formula or calls external API with caching
    - Tool: `calculate_shading_impact(obstacle_height: float, obstacle_distance: float, sun_altitude: float) -> dict` — Calculates shading factor using trigonometric model
    - Tool: `estimate_system_sizing(monthly_kwh: float, peak_sun_hours: float, system_losses: float = 0.14) -> dict` — Returns recommended system size, panel count, roof area
    - Tool: `calculate_roi(system_cost: float, annual_savings: float, incentive_amount: float = 0, loan_rate: float = 0, loan_years: int = 0) -> dict` — Returns payback period, 25-year NPV, ROI percentage
    - Tool: `get_solar_irradiance(latitude: float, longitude: float) -> dict` — Returns monthly irradiance data (kWh/m²/day) for the location; cache results in context DB for 30 days
    - All calculations documented with formula references
    - Results stored in context DB under `solar_calc` source tag
  - **Risk/Mitigation:** Formula accuracy → Cross-reference with NREL PVWatts; document all formulas and assumptions; flag estimates as approximate

### 4.2 Task: Ollama Bridge Server (`servers/ollama-bridge/`)

- [ ] **Implement model management and inference proxy tools**
  - **Estimated Hours:** 2.5
  - **Dependencies:** Base server template
  - **Acceptance Criteria:**
    - Server registered as `ollama-bridge`
    - Tool: `list_models() -> list[dict]` — Lists all downloaded Ollama models with size and parameter count
    - Tool: `pull_model(model_name: str) -> dict` — Downloads a model via Ollama API with progress reporting
    - Tool: `generate(prompt: str, model: str = "llama3.2", system_prompt: str = "", temperature: float = 0.7, max_tokens: int = 2048) -> str` — Proxies to Ollama generate endpoint; respects memory limits
    - Tool: `embed(text: str, model: str = "nomic-embed-text") -> list[float]` — Returns embedding vector via Ollama; cache in context DB
    - Tool: `get_model_info(model_name: str) -> dict` — Returns model details, VRAM requirements, recommended context window
    - Tool: `switch_model(target_model: str) -> dict` — Unloads current model, loads target model; checks available memory before switching
    - Memory-aware: checks `MAX_MEMORY_MB` env var before loading models; refuses if insufficient
    - All Ollama calls use `httpx` with 120s timeout and retry logic (3 retries, exponential backoff)
  - **Risk/Mitigation:** Ollama unavailable → Health check detects Ollama unavailability; all tools return graceful error messages; client can retry

### 4.3 Task: Memory Store Server (`servers/memory-store/`)

- [ ] **Implement cross-CLI shared memory with embedding support**
  - **Estimated Hours:** 2.0
  - **Dependencies:** Ollama bridge server (for embeddings), shared context layer
  - **Acceptance Criteria:**
    - Server registered as `memory-store`
    - Tool: `store_memory(key: str, value: str, tags: list[str] = [], embed: bool = True) -> dict` — Stores key-value pair; if embed=True, generates embedding via ollama-bridge and stores
    - Tool: `retrieve_memory(key: str) -> dict` — Retrieves memory by exact key
    - Tool: `search_memories(query: str, top_k: int = 5) -> list[dict]` — Semantic search: embeds query, finds nearest neighbors via cosine similarity in SQLite
    - Tool: `list_memories(tags: list[str] = [], limit: int = 100) -> list[dict]` — Filter by tags, paginated
    - Tool: `delete_memory(key: str) -> dict` — Deletes memory (with confirm_gate if not automated)
    - Tool: `update_memory(key: str, value: str, append: bool = False) -> dict` — Overwrites or appends to existing memory
    - Tag-based filtering works with JSON extraction in SQLite
    - Semantic search uses precomputed embeddings with cosine similarity calculation
  - **Risk/Mitigation:** Embedding dimension mismatch → Store embedding dimension in schema; validate on insert; auto-re-embed if model changes

### 4.4 Task: RAG Bridge Server (`servers/rag-bridge/`)

- [ ] **Implement document indexing and semantic search**
  - **Estimated Hours:** 2.5
  - **Dependencies:** Ollama bridge server, memory store server
  - **Acceptance Criteria:**
    - Server registered as `rag-bridge`
    - Tool: `index_document(file_path: str, chunk_size: int = 500, chunk_overlap: int = 50) -> dict` — Reads document (txt, md, pdf via PyPDF2), chunks text, embeds each chunk via ollama-bridge, stores in context DB
    - Tool: `index_directory(directory: str, file_extensions: list[str] = [".txt", ".md"]) -> dict` — Batch indexing with progress reporting
    - Tool: `query_documents(query: str, top_k: int = 5, min_score: float = 0.7) -> list[dict]` — Semantic search across all indexed chunks; returns chunk text, source file, relevance score
    - Tool: `list_indexed_documents() -> list[dict]` — Returns all indexed documents with chunk count and last indexed timestamp
    - Tool: `remove_document(file_path: str) -> dict` — Removes all chunks for a given document
    - Chunking strategy: simple sliding window with overlap; UTF-8 aware
    - Deduplication: skip re-indexing if file mtime hasn't changed
  - **Risk/Mitigation:** Large files causing OOM → Chunk before embedding; streaming read for large files; max file size 50MB; process chunks sequentially, not in parallel

### 4.5 Task: Health Operations Server (`servers/health-ops/`)

- [ ] **Implement inventory and health management tools**
  - **Estimated Hours:** 1.5
  - **Dependencies:** Base server template, shared context layer
  - **Acceptance Criteria:**
    - Server registered as `health-ops`
    - Tool: `check_inventory(item_name: str = "", category: str = "") -> list[dict]` — Queries inventory from context DB; supports filtering
    - Tool: `update_inventory(item_name: str, quantity: int, unit: str, location: str = "", expiry_date: str = "") -> dict` — Adds or updates inventory item
    - Tool: `check_expiring_items(days_ahead: int = 7) -> list[dict]` — Lists items expiring within N days
    - Tool: `generate_inventory_report() -> dict` — Summary report: total items, low-stock alerts, expiring items, by-category breakdown
    - Tool: `plan_line_pos_integration(endpoint: str = "", auth_token: str = "") -> dict` — Validates LINE POS API connectivity; stores config; returns test result
    - Tool: `log_health_observation(observation: str, category: str = "general", severity: str = "info") -> dict` — Logs health observation with optional embedding for later semantic search
    - Inventory data persisted to context DB with full CRUD
  - **Risk/Mitigation:** LINE POS API unavailable → Graceful fallback; store data locally; retry with exponential backoff; never block on external API

### 4.6 Task: rclone Bridge Server (`servers/rclone-bridge/`)

- [ ] **Implement Google Drive operations via rclone**
  - **Estimated Hours:** 1.5
  - **Dependencies:** Base server template
  - **Acceptance Criteria:**
    - Server registered as `rclone-bridge`
    - Tool: `list_remote(remote_name: str = "gdrive:", path: str = "") -> list[dict]` — Lists files/folders via `rclone lsjson`
    - Tool: `download_file(remote_path: str, local_path: str, remote_name: str = "gdrive:") -> dict` — Downloads file via `rclone copy`; verifies with checksum
    - Tool: `upload_file(local_path: str, remote_path: str, remote_name: str = "gdrive:") -> dict` — Uploads file via `rclone copy`; confirms with size check
    - Tool: `sync_directory(local_path: str, remote_path: str, direction: str = "up", dry_run: bool = True) -> dict` — Bi-directional sync with mandatory dry-run preview for safety
    - Tool: `get_remote_info(remote_name: str = "gdrive:") -> dict` — Returns remote storage usage, quota
    - All rclone commands run with `--stats-one-line` and `--progress`; output parsed into structured data
    - Commands wrapped with timeout (300s default) and subprocess safety
  - **Risk/Mitigation:** rclone not configured → Check `rclone config` on startup; provide clear setup instructions; fail gracefully with helpful error message

### 4.7 Task: Server Registration and Startup Scripts

- [ ] **Create unified server launcher and registry**
  - **Estimated Hours:** 1.0
  - **Dependencies:** All six servers implemented
  - **Acceptance Criteria:**
    - `scripts/start-server.py` — Takes `--server <name>` argument; starts specified MCP server with config loading
    - `scripts/start-all.sh` — Starts all servers in separate tmux sessions with naming convention: `mcp-<server_name>`
    - `scripts/stop-all.sh` — Gracefully terminates all MCP server tmux sessions
    - `scripts/status.sh` — Shows running MCP servers with PID, uptime, memory usage
    - Server registry JSON in `configs/servers.json` listing all servers with name, description, port/config path
    - README section documenting each server and its tools
  - **Risk/Mitigation:** Port conflicts → Use stdio transport (MCP default) instead of HTTP; no port allocation needed for stdio-based MCP servers

### Week 2 Summary

| Metric | Target |
|--------|--------|
| Lines of Code | ~2000–2500 (cumulative) |
| Test Coverage | >= 80% |
| Passing Tests | All |
| Servers Running | 7 (file-ops-safe + 6 new) |
| Git Commits | 8–12 |

---

## 5. Week 3: Cross-Machine Deployment

> **Theme:** Make it run on `ecolife-2` 24/7. Wire everything together. Test end-to-end.
> **Estimated Hours:** 10–12
> **Key Deliverable:** All MCP servers running as systemd services on `ecolife-2`, with SSH automation and cross-machine config sync.

### 5.1 Task: Ollama LAN Configuration on ecolife-2

- [ ] **Configure Ollama for LAN access**
  - **Estimated Hours:** 1.0
  - **Dependencies:** None (ops task on ecolife-2)
  - **Acceptance Criteria:**
    - Ollama systemd override configured: `OLLAMA_HOST=0.0.0.0:11434` in `/etc/systemd/system/ollama.service.d/override.conf`
    - Firewall (ufw) allows port 11434 from 192.168.1.0/24
    - Ollama accessible from `lean` via `curl http://ecolife-2:11434/api/tags`
    - `ollama-bridge` server config updated to point to `http://ecolife-2:11434`
    - Health check endpoint verified: `ollama-bridge` reports Ollama as available
  - **Risk/Mitigation:** Security exposure → Bind to LAN only (not 0.0.0.0 on WAN interface); use firewall rules; no authentication token needed for LAN-only access but document the risk

### 5.2 Task: SSH Automation Between lean ↔ ecolife-2

- [ ] **Set up passwordless SSH key authentication**
  - **Estimated Hours:** 0.5
  - **Dependencies:** None (ops task)
  - **Acceptance Criteria:**
    - SSH key pair generated on `lean` if not exists
    - Public key copied to `ecolife-2` via `ssh-copy-id`
    - `ssh ecolife-2 "echo ok"` returns "ok" without password prompt
    - `~/.ssh/config` entry on `lean`:
      ```
      Host ecolife-2
          HostName 192.168.1.XXX  # actual IP
          User ecolife
          IdentityFile ~/.ssh/id_ed25519
      ```
  - **Risk/Mitigation:** Key loss → Keep backup of private key in password manager; document recovery process

- [ ] **Implement remote execution wrapper**
  - **Estimated Hours:** 1.0
  - **Dependencies:** Passwordless SSH configured
  - **Acceptance Criteria:**
    - `RemoteExecutor` class in `src/agent_toolkit/shared/remote.py`
    - Methods: `run(command: str, timeout: int = 60) -> dict` (stdout, stderr, returncode)
    - `upload(local_path: str, remote_path: str) -> dict`
    - `download(remote_path: str, local_path: str) -> dict`
    - `is_reachable() -> bool` — Quick connectivity check
    - All commands logged to context DB
    - Graceful fallback: if `ecolife-2` unreachable, operations run locally with warning
  - **Risk/Mitigation:** SSH connection drops → Implement retry logic (3 attempts); cache results for non-critical operations; never hang indefinitely (strict timeouts)

### 5.3 Task: systemd Service Files

- [ ] **Create systemd unit files for all 7 MCP servers**
  - **Estimated Hours:** 1.5
  - **Dependencies:** Remote execution wrapper
  - **Acceptance Criteria:**
    - One unit file per server: `mcp-file-ops-safe.service`, `mcp-solar-calc.service`, etc.
    - All unit files stored in `systemd/` directory in the project repo
    - Unit file template includes:
      ```ini
      [Unit]
      Description=MCP Server: {name}
      After=network.target

      [Service]
      Type=simple
      User=ecolife
      WorkingDirectory=/home/ecolife/agent-toolkit
      ExecStart=/home/ecolife/agent-toolkit/.venv/bin/python -m agent_toolkit.servers.{name}
      Environment=AGENT_TOOLKIT_HOME=/home/ecolife/.local/share/agent-toolkit
      Environment=AGENT_TOOLKIT_LOG_LEVEL=INFO
      Environment=OLLAMA_HOST=http://localhost:11434
      Environment=MAX_MEMORY_MB=8192
      Restart=on-failure
      RestartSec=10
      StandardOutput=journal
      StandardError=journal

      [Install]
      WantedBy=multi-user.target
      ```
    - `scripts/install-systemd.sh` — Copies unit files, runs `daemon-reload`, enables and starts all services
    - `scripts/uninstall-systemd.sh` — Stops, disables, and removes all services
    - All services start successfully and pass health checks
  - **Risk/Mitigation:** Path mismatches → Use absolute paths everywhere; test on ecolife-2 before marking complete; validate with `systemctl status`

### 5.4 Task: tmux Session Management

- [ ] **Create tmux-based development session scripts**
  - **Estimated Hours:** 1.0
  - **Dependencies:** systemd service files
  - **Acceptance Criteria:**
    - `scripts/tmux-dev.sh` — Creates a development tmux session on `lean` with 4 panes: editor (vim), tests, server logs, shell
    - `scripts/tmux-ecolife.sh` — SSHs to ecolife-2 and creates monitoring session with: htop, Ollama logs, MCP server logs, interactive shell
    - `scripts/tmux-attach.sh` — Attaches to existing session by name
    - Session naming convention: `dev` (on lean), `ecolife-monitor` (on ecolife-2)
    - tmux config `.tmux.conf` included with mouse support, pane resizing, and status bar showing MCP server status
    - Documentation: `docs/tmux-workflow.md` explaining daily tmux workflow
  - **Risk/Mitigation:** Session conflicts → Use unique session names; check if session exists before creating; support attaching to existing

### 5.5 Task: Config Synchronization

- [ ] **Implement config sync between lean and ecolife-2**
  - **Estimated Hours:** 1.0
  - **Dependencies:** Remote execution wrapper
  - **Acceptance Criteria:**
    - `scripts/sync-config.sh` — Syncs `configs/` directory from `lean` to `ecolife-2` via rsync over SSH
    - `scripts/sync-db.sh` — Backs up and syncs context DB between machines (optional, for disaster recovery)
    - `scripts/deploy.sh` — Full deploy: git pull on ecolife-2, pip install, restart all systemd services
    - Config changes on `lean` reflected on `ecolife-2` within 60 seconds of running sync
    - Sync operations are idempotent and non-destructive
  - **Risk/Mitigation:** Data loss during sync → Always backup before overwrite; use `rsync --backup`; never delete files without confirmation

### 5.6 Task: Memory Monitoring and Alerting

- [ ] **Implement memory monitoring for ecolife-2**
  - **Estimated Hours:** 1.0
  - **Dependencies:** Config sync operational
  - **Acceptance Criteria:**
    - `scripts/memory-monitor.sh` — Runs every 60 seconds via cron, logs memory usage to context DB
    - Memory thresholds:
      - Warning: > 80% RAM usage
      - Critical: > 90% RAM usage
    - On critical: automatically triggers `ollama-bridge.switch_model()` to a smaller model or unloads current model
    - Alert log entries visible via `memory-store.search_memories("memory alert")`
    - Grafana-style text dashboard via `scripts/status.sh` showing:
      - Total RAM, Used RAM, Free RAM
      - Ollama model loaded and its VRAM usage
      - Per-server memory footprint
  - **Risk/Mitigation:** Monitoring itself consuming resources → Shell script (not Python) for monitoring to minimize overhead; run every 60s, not more frequently

### 5.7 Task: End-to-End Integration Testing

- [ ] **Write and execute full integration test suite**
  - **Estimated Hours:** 2.0
  - **Dependencies:** All prior Week 3 tasks
  - **Acceptance Criteria:**
    - Test scenario 1: **File Safety Chain**
      - Write file via `file-ops-safe` → verify git snapshot created → verify context DB log entry → read file back → delete with confirm → restore from snapshot
    - Test scenario 2: **Solar Analysis Pipeline**
      - Get solar irradiance for Tokyo → calculate system sizing → calculate ROI → store results in memory → retrieve via semantic search
    - Test scenario 3: **RAG Query Flow**
      - Index a markdown document → query with natural language → verify top result contains relevant chunk → verify embedding stored
    - Test scenario 4: **Cross-Machine Health**
      - Check Ollama availability from `lean` → verify `ollama-bridge` can list models → generate text via `ollama-bridge` → embed text → verify embedding dimension
    - Test scenario 5: **Memory Pressure Response**
      - Simulate memory load → verify monitor detects threshold → verify alert logged → verify graceful degradation (model switching or refusal)
    - All 5 scenarios pass; results logged; any failures documented with remediation steps
  - **Risk/Mitigation:** Test brittleness → Use retry loops for async operations; mock external APIs where possible; tests should be runnable in any order

### Week 3 Summary

| Metric | Target |
|--------|--------|
| Servers on systemd | 7/7 |
| Ollama LAN accessible | Yes |
| SSH automation working | Yes |
| Config sync verified | Yes |
| E2E tests passing | 5/5 scenarios |
| Git Commits | 6–10 |

---

## 6. Week 4: Hardening

> **Theme:** Make it production-worthy. Secure it. Document it. Benchmark it. Sleep soundly.
> **Estimated Hours:** 10–12
> **Key Deliverable:** Hardened, documented, benchmarked system ready for 24/7 unattended operation.

### 6.1 Task: Memory Limits Enforcement

- [ ] **Implement `MAX_MEMORY_MB` enforcement across all servers**
  - **Estimated Hours:** 1.5
  - **Dependencies:** All servers running on ecolife-2
  - **Acceptance Criteria:**
    - Global config `max_memory_mb` read from env var `MAX_MEMORY_MB` (default: 8192)
    - `MemoryLimiter` class in `src/agent_toolkit/shared/memory.py`
    - Methods: `check_available() -> int`, `can_allocate(requested_mb: int) -> bool`, `get_usage() -> dict`
    - `ollama-bridge.generate()` checks memory before loading model; refuses if insufficient
    - `ollama-bridge.embed()` checks memory before embedding batch; splits into smaller batches if needed
    - `rag-bridge.index_document()` checks memory per chunk batch; throttles if approaching limit
    - When memory is 90%+ used: enter "degraded mode" — disable non-essential servers (rclone-bridge, solar-calc), keep essential (file-ops-safe, memory-store, ollama-bridge)
    - Unit tests: Memory check, allocation refusal, degraded mode transition
  - **Risk/Mitigation:** False memory readings → Use `psutil.virtual_memory()` for accurate readings; add 10% buffer; re-check after allocation

### 6.2 Task: Comprehensive Logging

- [ ] **Implement structured JSON logging with rotation**
  - **Estimated Hours:** 1.5
  - **Dependencies:** Memory limits module
  - **Acceptance Criteria:**
    - All servers use `structlog` for structured logging
    - Log format: JSON with fields: `timestamp`, `level`, `server`, `event`, `tool`, `args`, `result`, `duration_ms`, `error`, `trace_id`
    - Log levels: DEBUG (dev only), INFO (default), WARNING, ERROR, CRITICAL
    - Log rotation: Daily rotation, keep 14 days, max 100MB per file
    - Log location: `~/.local/share/agent-toolkit/logs/{server_name}/{date}.jsonl`
    - `scripts/view-logs.sh` — Pretty-prints JSON logs with filtering by server, level, time range
    - All tool invocations logged with trace ID for request tracing across servers
    - Error logs include full traceback
    - Audit log: All destructive operations (write, delete, model switch) logged separately in `audit.jsonl`
  - **Risk/Mitigation:** Log bloat → Rotation prevents disk fill; separate audit log prevents tampering; max size limits

### 6.3 Task: Persona/Role System

- [ ] **Implement role-based access control**
  - **Estimated Hours:** 1.5
  - **Dependencies:** Logging system
  - **Acceptance Criteria:**
    - `Persona` enum in `src/agent_toolkit/shared/auth.py`: `DEV`, `OPS`, `SOLAR_ANALYST`, `HEALTH_MANAGER`, `ADMIN`
    - Each persona has a permission matrix:
      - `DEV`: file-ops-safe (read/write/delete), memory-store (all), rag-bridge (all)
      - `OPS`: file-ops-safe (read only), ollama-bridge (all), health-ops (all), rclone-bridge (all)
      - `SOLAR_ANALYST`: solar-calc (all), memory-store (read/write), file-ops-safe (read only)
      - `HEALTH_MANAGER`: health-ops (all), memory-store (read/write), file-ops-safe (read only)
      - `ADMIN`: all permissions
    - Persona loaded from env var `AGENT_TOOLKIT_PERSONA` or config file
    - Each tool checks permissions before execution; returns clear error if unauthorized
    - Permission check logged in audit log
    - Unit tests: Each persona's allowed/denied operations
  - **Risk/Mitigation:** Overly restrictive → Start with permissive defaults for initial deployment; tighten based on usage patterns; ADMIN always available as override

### 6.4 Task: Disaster Recovery Documentation

- [ ] **Write complete disaster recovery runbook**
  - **Estimated Hours:** 1.0
  - **Dependencies:** All systems operational
  - **Acceptance Criteria:**
    - Document: `docs/disaster-recovery.md` covering:
      - Scenario 1: Ollama crashes — restart procedure, data loss assessment, recovery time
      - Scenario 2: SQLite database corruption — backup restoration, manual repair steps
      - Scenario 3: ecolife-2 hardware failure — migration to lean as temporary host
      - Scenario 4: SSH key loss — key regeneration and redistribution
      - Scenario 5: Full system rebuild — step-by-step from bare metal to fully operational
    - Each scenario includes: detection method, immediate action, recovery steps, verification steps, estimated recovery time
    - All scripts referenced in recovery doc are tested and working
  - **Risk/Mitigation:** Outdated docs → Update docs whenever procedures change; include script version numbers in docs; test recovery procedures quarterly

### 6.5 Task: Performance Benchmarking

- [ ] **Run performance benchmarks and document results**
  - **Estimated Hours:** 1.5
  - **Dependencies:** All systems hardened
  - **Acceptance Criteria:**
    - Benchmark suite in `tests/benchmarks/`
    - Benchmarks:
      - File operations: read 1MB file, write 1MB file, search 1000 files — measure latency
      - Ollama inference: generate 512 tokens with each model (llama3.2, qwen2.5, phi4) — measure TPS and memory
      - Embedding: embed 100 chunks of 500 tokens — measure throughput
      - RAG query: semantic search over 1000 chunks — measure latency
      - Memory limiter: behavior under simulated memory pressure — measure degradation
    - Results stored in `docs/benchmarks/results-{date}.md`
    - Baseline established for regression detection
    - Performance requirements documented: max latency thresholds, minimum throughput
  - **Risk/Mitigation:** Benchmark noise → Run each benchmark 5 times, report median + stddev; note system load during benchmark; run on quiet system

### 6.6 Task: Documentation Finalization

- [ ] **Complete all project documentation**
  - **Estimated Hours:** 1.5
  - **Dependencies:** All other Week 4 tasks
  - **Acceptance Criteria:**
    - `README.md` — Project overview, architecture diagram, quick start guide, supported CLIs
    - `docs/installation.md` — Step-by-step installation on fresh Ubuntu/Debian
    - `docs/configuration.md` — All config options, environment variables, config file schema
    - `docs/servers.md` — Each server: purpose, tools, parameters, examples
    - `docs/architecture.md` — System architecture, data flow, component diagram
    - `docs/tmux-workflow.md` — Daily development workflow with tmux
    - `docs/api.md` — MCP protocol details, tool schemas, example requests/responses
    - All docs written in Markdown, cross-linked, with table of contents
    - No broken internal links
  - **Risk/Mitigation:** Documentation drift → Generate tool schemas from code (use MCP introspection); include version footer in each doc; review docs before each release

### 6.7 Task: Security Audit

- [ ] **Run security checks and dependency scan**
  - **Estimated Hours:** 1.0
  - **Dependencies:** All code complete
  - **Acceptance Criteria:**
    - Secret scanning: `git-secrets` or `trufflehog` run on full repo — zero findings
    - Dependency scan: `pip-audit` or `safety check` run — zero critical/high findings
    - Static analysis: `bandit` run on all Python files — zero high-severity findings
    - File permissions: No files with 777 permissions; no world-writable files in project
    - SSH config audit: No plaintext passwords; no overly permissive `Host *` entries
    - Ollama exposure: Verified LAN-only binding; no WAN exposure
    - SQLite: Database file permissions 0600; directory permissions 0700
    - Audit results in `docs/security-audit-{date}.md` with remediation status
  - **Risk/Mitigation:** New vulnerabilities post-audit → Pin dependency versions; schedule monthly dependency updates; subscribe to security advisories for critical packages

### Week 4 Summary

| Metric | Target |
|--------|--------|
| Memory limits enforced | Yes |
| JSON logging active | Yes |
| Persona system working | Yes |
| DR docs complete | Yes |
| Benchmarks run | Yes |
| Documentation | 8 docs complete |
| Security audit | Passed |
| Git Commits | 5–8 |

---

## 7. Dependency Graph

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         agent-toolkit Dependency Graph                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                             │
│   WEEK 1: FOUNDATION                                                        │
│   ══════════════════                                                        │
│                                                                             │
│                    ┌──────────────────┐                                     │
│   [Scaffold] ─────▶│  pyproject.toml  │                                     │
│        │           │  pre-commit      │                                     │
│        │           │  git init        │                                     │
│        │           └────────┬─────────┘                                     │
│        │                    │                                               │
│        │                    ▼                                               │
│        │           ┌──────────────────┐                                     │
│        └──────────▶│  Safety Utils    │◄──────────┐                        │
│                    │  @dry_run        │           │                        │
│                    │  confirm_gate()  │           │                        │
│                    │  GitBackup       │           │                        │
│                    └────────┬─────────┘           │                        │
│                             │                     │                        │
│                             ▼                     │                        │
│                    ┌──────────────────┐           │                        │
│                    │  Shared Context  │───────────┘                        │
│                    │  SQLite schema   │                                    │
│                    │  Connection pool │                                    │
│                    │  Migrations      │                                    │
│                    └────────┬─────────┘                                    │
│                             │                                              │
│              ┌──────────────┼──────────────┐                             │
│              ▼              ▼              ▼                             │
│   ┌────────────────┐ ┌──────────┐ ┌──────────────────┐                  │
│   │ Base Server    │ │ File Ops │ │ Migrations       │                  │
│   │ Template       │ │ (Safe)   │ │ System           │                  │
│   └────────┬───────┘ └────┬─────┘ └──────────────────┘                  │
│            │              │                                              │
│   ┌────────▼──────────────▼───────┐                                     │
│   │  Week 1 Gate: file-ops-safe   │                                     │
│   │  + base class + safety utils  │                                     │
│   │  ALL TESTS PASS               │                                     │
│   └───────────────┬───────────────┘                                     │
│                   │                                                       │
│   WEEK 2: DOMAIN SERVERS          │                                       │
│   ══════════════════════          ▼                                       │
│                                   │                                       │
│              ┌────────────────────┼────────────────────────┐             │
│              ▼                    ▼                        ▼             │
│   ┌────────────────┐   ┌────────────────┐   ┌────────────────────┐      │
│   │ Ollama Bridge  │   │ Memory Store   │   │ Solar Calculator   │      │
│   │ ─────────────  │◄──│ ─────────────  │   │ ────────────────   │      │
│   │ list_models()  │   │ store_memory() │   │ daily_production() │      │
│   │ pull_model()   │   │ retrieve()     │   │ shading_impact()   │      │
│   │ generate()     │   │ search()       │   │ system_sizing()    │      │
│   │ embed()        │   │ list/delete()  │   │ calculate_roi()    │      │
│   │ switch_model() │   │ update()       │   │ solar_irradiance() │      │
│   └───────┬────────┘   └───────┬────────┘   └────────────────────┘      │
│           │                    │                                          │
│           ▼                    ▼                                          │
│   ┌────────────────┐   ┌────────────────┐                                │
│   │ RAG Bridge     │   │ Health Ops     │   ┌────────────────────┐     │
│   │ ──────────     │   │ ──────────     │   │ rclone Bridge      │     │
│   │ index_document │   │ check_inventory│   │ ──────────────     │     │
│   │ index_dir      │   │ update_inventory│  │ list_remote()      │     │
│   │ query_docs     │   │ check_expiring │   │ download_file()    │     │
│   │ list/remove    │   │ gen_report     │   │ upload_file()      │     │
│   │                │   │ LINE POS plan  │   │ sync_directory()   │     │
│   │                │   │ log_observation│   │ get_remote_info()  │     │
│   └───────┬────────┘   └───────┬────────┘   └──────────┬─────────┘     │
│           │                    │                       │                │
│   ┌───────▼────────────────────▼───────────────────────▼───────┐       │
│   │  Week 2 Gate: All 6 domain servers running                │       │
│   │  + server registry + startup scripts                       │       │
│   │  ALL TESTS PASS                                           │       │
│   └──────────────────────┬────────────────────────────────────┘       │
│                          │                                              │
│   WEEK 3: DEPLOYMENT     ▼                                              │
│   ════════════════════════════════════════                              │
│                          │                                              │
│              ┌───────────┼───────────┬──────────────┐                  │
│              ▼           ▼           ▼              ▼                  │
│   ┌──────────────┐ ┌─────────┐ ┌──────────┐ ┌─────────────┐           │
│   │ Ollama LAN   │ │ SSH     │ │ systemd  │ │ tmux Mgmt   │           │
│   │ Config       │ │ Autom.  │ │ Services │ │ Sessions    │           │
│   │ (ecolife-2)  │ │ lean↔ec │ │ (7 units)│ │ (dev+mon)   │           │
│   └──────┬───────┘ └────┬────┘ └────┬─────┘ └──────┬──────┘           │
│          │              │             │              │                  │
│          └──────────────┼─────────────┘              │                  │
│                         ▼                            ▼                  │
│              ┌────────────────────┐      ┌──────────────────┐          │
│              │ Config Sync        │      │ Memory Monitor   │          │
│              │ lean → ecolife-2   │      │ + Alerting       │          │
│              └─────────┬──────────┘      └────────┬─────────┘          │
│                        │                         │                      │
│                        ▼                         ▼                      │
│              ┌────────────────────────────────────────┐                │
│              │  E2E Integration Testing (5 scenarios) │                │
│              │  ────────────────────────────────────  │                │
│              │  1. File Safety Chain                  │                │
│              │  2. Solar Analysis Pipeline            │                │
│              │  3. RAG Query Flow                     │                │
│              │  4. Cross-Machine Health               │                │
│              │  5. Memory Pressure Response           │                │
│              └──────────────────┬─────────────────────┘                │
│                                 │                                       │
│   ┌─────────────────────────────▼────────────────────────────────┐     │
│   │  Week 3 Gate: All services on ecolife-2 systemd             │     │
│   │  + Ollama LAN + SSH + 5/5 E2E tests pass                   │     │
│   └─────────────────────────────┬────────────────────────────────┘     │
│                                 │                                       │
│   WEEK 4: HARDENING             ▼                                       │
│   ═══════════════════════════════════════════════                       │
│                                 │                                       │
│              ┌──────────────────┼──────────────────┐                   │
│              ▼                  ▼                  ▼                   │
│   ┌────────────────┐ ┌────────────────┐ ┌────────────────┐            │
│   │ Memory Limits  │ │ JSON Logging   │ │ Persona/Roles  │            │
│   │ Enforcement    │ │ + Rotation     │ │ + Permissions  │            │
│   └───────┬────────┘ └───────┬────────┘ └───────┬────────┘            │
│           │                  │                  │                      │
│           ▼                  ▼                  ▼                      │
│   ┌────────────────┐ ┌────────────────┐ ┌────────────────┐            │
│   │ Benchmarks     │ │ DR Docs        │ │ Security Audit │            │
│   │ + Baselines    │ │ + Runbook      │ │ + Scanning     │            │
│   └───────┬────────┘ └───────┬────────┘ └───────┬────────┘            │
│           │                  │                  │                      │
│           └──────────────────┼──────────────────┘                      │
│                              ▼                                         │
│                   ┌────────────────────┐                               │
│                   │ Final Documentation│                               │
│                   │ (8 docs complete)  │                               │
│                   └──────────┬─────────┘                               │
│                              │                                         │
│   ┌──────────────────────────▼────────────────────────────────┐       │
│   │  PROJECT COMPLETE                                        │       │
│   │  ✅ All tests pass                                      │       │
│   │  ✅ 7 MCP servers on systemd 24/7                       │       │
│   │  ✅ Ollama LAN accessible                               │       │
│   │  ✅ Memory limits enforced                              │       │
│   │  ✅ Logging active                                      │       │
│   │  ✅ Security audit passed                               │       │
│   │  ✅ Documentation complete                              │       │
│   │  ✅ Benchmarks documented                               │       │
│   └──────────────────────────────────────────────────────────┘       │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

---

## 8. Resource Allocation

### 8.1 Machine Responsibilities

| Resource | `lean` (Dev) | `ecolife-2` (Agent) |
|----------|-------------|---------------------|
| **Code Editor** | vim/neovim via Blink mosh | Not used |
| **Git Repo** | Primary working copy | Read-only deploy target |
| **Development** | All coding, testing, debugging | Not used |
| **Ollama** | Not installed | 24/7 service (models, embeddings) |
| **MCP Servers** | Test instances only | Production systemd services |
| **SQLite DB** | Test databases | Production context database |
| **tmux Sessions** | `dev` session (editor, tests, logs) | `ecolife-monitor` (htop, Ollama, MCP logs) |
| **Memory Monitor** | Not needed | Always running |
| **rclone** | Config management | Execution for Google Drive ops |

### 8.2 tmux Session Layout

**On `lean` — Development Session (`tmux new -s dev`)**

```
┌─────────────────────────────────┬─────────────────────────────────┐
│                                 │                                 │
│  Pane 0: Editor (vim)           │  Pane 1: Test Runner            │
│  └── agent-toolkit source       │  └── pytest-watch or manual     │
│                                 │     pytest commands             │
│                                 │                                 │
├─────────────────────────────────┼─────────────────────────────────┤
│                                 │                                 │
│  Pane 2: Server Logs            │  Pane 3: Shell                  │
│  └── tail -f MCP logs           │  └── git, ssh, deploy, misc     │
│                                 │                                 │
└─────────────────────────────────┴─────────────────────────────────┘
```

**On `ecolife-2` — Monitor Session (`tmux new -s ecolife-monitor`)**

```
┌─────────────────────────────────┬─────────────────────────────────┐
│                                 │                                 │
│  Pane 0: htop                   │  Pane 1: Ollama Logs            │
│  └── System resource monitor    │  └── journalctl -u ollama -f    │
│                                 │                                 │
├─────────────────────────────────┼─────────────────────────────────┤
│                                 │                                 │
│  Pane 2: MCP Logs               │  Pane 3: Interactive Shell      │
│  └── journalctl -f              │  └── sqlite3, curl, debug     │
│      (all mcp-* services)       │                                 │
│                                 │                                 │
└─────────────────────────────────┴─────────────────────────────────┘
```

### 8.3 Daily Workflow Recommendations

```
┌──────────────────────────────────────────────────────────────────┐
│                    RECOMMENDED DAILY WORKFLOW                     │
├──────────────────────────────────────────────────────────────────┤
│                                                                   │
│  1. CONNECT (5 min)                                              │
│     ├── Open Blink on iPad                                       │
│     ├── mosh lean@192.168.1.135                                  │
│     ├── tmux attach -t dev (or create new session)              │
│     └── In another pane: ssh ecolife-2, tmux attach -t monitor  │
│                                                                   │
│  2. SYNC STATUS (5 min)                                          │
│     ├── On ecolife-2: check systemctl status mcp-*              │
│     ├── On ecolife-2: check Ollama: curl localhost:11434/api/tags│
│     ├── On lean: git status, git pull                            │
│     └── Review any alert logs from memory-monitor                │
│                                                                   │
│  3. DEVELOPMENT (45-90 min)                                      │
│     ├── Edit code in vim (Pane 0)                                │
│     ├── Run tests: pytest (Pane 1)                               │
│     ├── Check test coverage: pytest --cov                        │
│     ├── Commit: git add -p, git commit                           │
│     └── Push: git push                                           │
│                                                                   │
│  4. DEPLOY (5-10 min, when ready)                                │
│     ├── Run: ./scripts/deploy.sh                                 │
│     ├── Verify: ./scripts/status.sh                              │
│     ├── Check MCP logs for errors                                │
│     └── Run smoke test: python tests/smoke_test.py               │
│                                                                   │
│  5. SHUTDOWN (2 min)                                             │
│     ├── Detach tmux: Ctrl+b d                                    │
│     ├── mosh session persists                                    │
│     └── Disconnect from Blink                                    │
│                                                                   │
└──────────────────────────────────────────────────────────────────┘
```

---

## 9. Go/No-Go Criteria

### 9.1 Week 1 Gate: Foundation Complete

| # | Criterion | Status Required |
|---|-----------|-----------------|
| 1 | Project scaffold committed to git with clean pre-commit hooks | PASS |
| 2 | `pytest` runs with zero failures on all unit tests | PASS |
| 3 | Test coverage >= 85% for safety utilities and shared context | PASS |
| 4 | `file-ops-safe` MCP server responds to all 4 tools via test client | PASS |
| 5 | SQLite schema created, migrations run, CRUD verified | PASS |
| 6 | `BaseMCPServer` abstract class documented and tested | PASS |
| 7 | `ruff` and `mypy` pass cleanly on all code | PASS |

**Go Decision:** All 7 criteria pass → proceed to Week 2.
**No-Go Action:** If any criterion fails, spend up to 2 additional days fixing blockers before reassessing.

### 9.2 Week 2 Gate: Domain Servers Complete

| # | Criterion | Status Required |
|---|-----------|-----------------|
| 1 | All 6 domain servers implement their full tool set | PASS |
| 2 | `pytest` runs with zero failures on all tests | PASS |
| 3 | Test coverage >= 80% across all servers | PASS |
| 4 | Server registry JSON is complete and accurate | PASS |
| 5 | Startup scripts (`start-all.sh`, `stop-all.sh`, `status.sh`) work | PASS |
| 6 | Ollama bridge successfully lists models and generates text on lean (pointing to ecolife-2) | PASS |
| 7 | Memory store supports semantic search with meaningful results | PASS |

**Go Decision:** All 7 criteria pass → proceed to Week 3.
**No-Go Action:** If Ollama bridge fails, proceed with local-only servers (skip RAG); reassess after fixing Ollama connectivity.

### 9.3 Week 3 Gate: Deployment Complete

| # | Criterion | Status Required |
|---|-----------|-----------------|
| 1 | All 7 MCP servers running as systemd services on ecolife-2 | PASS |
| 2 | Ollama accessible from lean via LAN | PASS |
| 3 | SSH automation works (passwordless, reliable) | PASS |
| 4 | Config sync (lean → ecolife-2) completes without errors | PASS |
| 5 | tmux sessions usable on both machines | PASS |
| 6 | Memory monitor active and logging | PASS |
| 7 | All 5 E2E integration scenarios pass | PASS |

**Go Decision:** All 7 criteria pass → proceed to Week 4.
**No-Go Action:** If E2E tests fail, fix failures before proceeding; if systemd fails, debug unit files; maximum 3-day extension.

### 9.4 Week 4 Gate: Production Ready

| # | Criterion | Status Required |
|---|-----------|-----------------|
| 1 | Memory limits enforced and tested under simulated pressure | PASS |
| 2 | JSON logging active on all servers with rotation working | PASS |
| 3 | Persona/role system restricts unauthorized tool access | PASS |
| 4 | Disaster recovery runbook written and procedures tested | PASS |
| 5 | Performance benchmarks run with documented baselines | PASS |
| 6 | All 8 documentation files complete and cross-linked | PASS |
| 7 | Security audit passes (zero critical findings) | PASS |

**Go Decision:** All 7 criteria pass → **PROJECT COMPLETE**.
**No-Go Action:** Fix any critical findings; security issues are blockers; documentation gaps can be addressed post-release.

---

## 10. Risk Register

| ID | Risk | Probability | Impact | Mitigation | Owner |
|----|------|------------|--------|------------|-------|
| R1 | **32GB RAM insufficient for multiple Ollama models** | Medium | High | Implement `MAX_MEMORY_MB` enforcement; model switching on memory pressure; load only one model at a time; use smaller models (3B–7B) for embeddings | Dev |
| R2 | **Ollama API breaking changes** | Low | Medium | Pin Ollama version in docs and systemd config; version-check on startup with warning; abstract Ollama calls behind `OllamaBridge` class to localize changes | Dev |
| R3 | **Cross-machine SSH connectivity fails** | Low | High | Local fallback mode: all MCP servers can run on `lean` if `ecolife-2` unavailable; Ollama can be installed on `lean` as backup; `RemoteExecutor.is_reachable()` gates all remote ops | Dev |
| R4 | **CLI MCP config format changes (Kimi/OpenCode/Goose)** | Medium | Medium | Adapter pattern for MCP client configs; versioned config schemas; monitor CLI release notes; maintain compatibility layer | Dev |
| R5 | **Part-time availability delays project** | High | Medium | Scope reduction plan (see below); weekly checkpoints with go/no-go criteria; minimum viable scope defined for each week | Dev |
| R6 | **SQLite performance degradation at scale** | Medium | Medium | WAL mode enabled; connection pooling; indexing on frequently queried columns (key, tags, source_server); consider migration to PostgreSQL if > 100K records | Dev |
| R7 | **rclone token expiry for Google Drive** | Medium | Medium | Document rclone re-auth procedure; monitor token expiry; use rclone's built-in token refresh; alert on auth failures | Dev |
| R8 | **Pre-commit hooks slow down commits** | Low | Low | Keep hooks fast (ruff < 2s, mypy < 10s); use `--no-verify` only for WIP commits with explicit flag; split hooks into fast (pre-commit) and slow (pre-push) | Dev |
| R9 | **ecolife-2 hardware failure** | Low | High | Weekly automated backup of context DB to `lean`; disaster recovery runbook with migration steps; `lean` can temporarily host all services | Dev |
| R10 | **Dependency vulnerability discovered** | Medium | Medium | Monthly `pip-audit` runs; pinned versions in pyproject.toml; subscribe to security advisories for critical packages; maintain lock file | Dev |

### 10.1 Scope Reduction Plan (for R5 — Part-time Availability)

If time is critically limited, the following reduction order applies:

**Priority 1 (Must Have — Minimum Viable Product):**
1. Project scaffold + safety utilities (`@dry_run`, `confirm_gate`)
2. File-ops-safe server (the core safety feature)
3. Ollama bridge server (enables all AI capabilities)
4. systemd services for the above

**Priority 2 (Should Have — Functional System):**
5. Memory store server (cross-CLI memory)
6. RAG bridge server (document search)
7. Solar calculator server

**Priority 3 (Nice to Have — Full System):**
8. Health operations server
9. rclone bridge server
10. Persona/role system
11. Performance benchmarks
12. Full documentation suite

**Decision Rule:** If a week's work exceeds 15 hours, drop the lowest-priority items from that week and defer to a future "Phase 2" iteration. Never compromise on safety utilities or testing.

---

## 11. Definition of Done

The **agent-toolkit** project is considered **COMPLETE** when ALL of the following conditions are met:

### 11.1 Functional Requirements

- [ ] **7 MCP servers** are implemented, tested, and running as systemd services on `ecolife-2`:
  - `file-ops-safe` — File operations with backup and confirmation
  - `solar-calc` — Solar energy calculations
  - `ollama-bridge` — Ollama model management and inference
  - `memory-store` — Cross-CLI shared memory with semantic search
  - `rag-bridge` — Document indexing and semantic search
  - `health-ops` — Health inventory and management
  - `rclone-bridge` — Google Drive operations

- [ ] **All servers pass** their individual unit test suites (zero failures)
- [ ] **Test coverage** is >= 80% across the entire codebase
- [ ] **All 5 E2E integration scenarios** pass successfully
- [ ] **Ollama is accessible** from `lean` via LAN on `ecolife-2`
- [ ] **SSH automation** works reliably between `lean` and `ecolife-2`
- [ ] **Config sync** from `lean` to `ecolife-2` completes without errors

### 11.2 Non-Functional Requirements

- [ ] **Memory limits** are enforced: `MAX_MEMORY_MB` prevents OOM; degraded mode activates at 90% memory
- [ ] **Structured JSON logging** is active on all servers with daily rotation and 14-day retention
- [ ] **Audit logging** captures all destructive operations (write, delete, model switch)
- [ ] **Persona system** restricts tool access by role (dev, ops, solar_analyst, health_manager, admin)
- [ ] **Pre-commit hooks** pass cleanly on every commit (ruff, mypy)
- [ ] **Security audit** passes with zero critical or high findings

### 11.3 Documentation Requirements

- [ ] `README.md` with architecture overview and quick start
- [ ] `docs/installation.md` with step-by-step setup
- [ ] `docs/configuration.md` with all options documented
- [ ] `docs/servers.md` with per-server tool reference
- [ ] `docs/architecture.md` with system design
- [ ] `docs/tmux-workflow.md` with daily workflow
- [ ] `docs/api.md` with MCP protocol details
- [ ] `docs/disaster-recovery.md` with tested recovery procedures
- [ ] `docs/security-audit-{date}.md` with audit results
- [ ] `docs/benchmarks/results-{date}.md` with performance baselines

### 11.4 Operational Requirements

- [ ] **systemd services** auto-start on boot and restart on failure
- [ ] **tmux sessions** are usable for development and monitoring
- [ ] **Memory monitor** is actively monitoring and alerting
- [ ] **Git repository** has clean history with meaningful commit messages
- [ ] **No uncommitted changes** on the main branch
- [ ] **Version tag** `v0.1.0` applied to the final commit

### 11.5 The "Sleep Soundly" Test

The ultimate Definition of Done: **Can you walk away for a week and come back to a fully functional system?**

If the answer is **yes** — all systemd services running, Ollama responding, logs rotating, memory monitored, disaster recovery documented — then the project is done.

---

## 12. Daily Workflow

### 12.1 Quick Reference Commands

```bash
# ── Connect ──────────────────────────────────────────
mosh lean@192.168.1.135                          # Connect to dev machine
tmux attach -t dev || tmux new -s dev            # Start/attach dev session
ssh ecolife-2                                     # Connect to agent machine
tmux attach -t ecolife-monitor || tmux new -s ecolife-monitor

# ── Development ──────────────────────────────────────
pytest                                            # Run all tests
pytest --cov --cov-report=html                    # Run with coverage
ruff check . && ruff format .                     # Lint and format
mypy src/                                         # Type check
pre-commit run --all-files                        # Run all hooks

# ── Server Management (on ecolife-2) ─────────────────
systemctl status mcp-*                            # Check all MCP servers
journalctl -u mcp-file-ops-safe -f                # Follow server logs
sudo systemctl restart mcp-file-ops-safe          # Restart a server
./scripts/status.sh                               # Show all server status

# ── Ollama (on ecolife-2) ──────────────────────────
curl http://localhost:11434/api/tags              # List models
curl http://localhost:11434/api/generate -d '{"model":"llama3.2","prompt":"hi"}'
ollama ps                                         # Show loaded model and VRAM

# ── Deploy ───────────────────────────────────────────
./scripts/deploy.sh                               # Full deploy from lean
./scripts/sync-config.sh                          # Sync configs only
./scripts/sync-db.sh                              # Backup and sync DB

# ── Monitoring ───────────────────────────────────────
./scripts/memory-monitor.sh                       # Manual memory check
./scripts/view-logs.sh --server file-ops-safe     # View pretty logs
sqlite3 ~/.local/share/agent-toolkit/context.db "SELECT * FROM server_health;"

# ── Disconnect ───────────────────────────────────────
Ctrl+b d                                          # Detach tmux
exit                                              # Close ssh/mosh
```

### 12.2 Session Persistence Strategy

Since development happens via Blink on iPad with mosh, sessions should persist across network changes:

1. **mosh** handles network roaming automatically — no need to reconnect when switching WiFi/cellular
2. **tmux** persists terminal sessions — if mosh drops, reattach with `tmux attach -t <name>`
3. **systemd** persists services — servers survive reboots, crashes, and SSH disconnections
4. **journald** persists logs — `journalctl` retains logs across sessions

---

## Appendix A: MCP Server Registry

| Server Name | Tools | Depends On | Data Store | Personas |
|-------------|-------|------------|------------|----------|
| `file-ops-safe` | read, write, delete, search | Safety Utils, Shared Context | git snapshots, SQLite log | All |
| `solar-calc` | daily_production, shading_impact, system_sizing, calculate_roi, solar_irradiance | Shared Context | SQLite results | SOLAR_ANALYST, ADMIN |
| `ollama-bridge` | list_models, pull_model, generate, embed, get_model_info, switch_model | None (external Ollama) | None (proxies to Ollama) | All |
| `memory-store` | store, retrieve, search, list, delete, update | Ollama Bridge (embed), Shared Context | SQLite memory + embeddings | All |
| `rag-bridge` | index_document, index_directory, query, list, remove | Ollama Bridge, Memory Store | SQLite chunks + embeddings | DEV, ADMIN |
| `health-ops` | check_inventory, update_inventory, check_expiring, gen_report, plan_line_pos, log_observation | Shared Context | SQLite inventory | HEALTH_MANAGER, ADMIN |
| `rclone-bridge` | list_remote, download, upload, sync, get_remote_info | None (external rclone) | None (proxies to rclone) | OPS, ADMIN |

## Appendix B: Configuration Schema

```json
{
  "agent_toolkit": {
    "version": "0.1.0",
    "environment": "production",
    "paths": {
      "data_dir": "~/.local/share/agent-toolkit",
      "log_dir": "~/.local/share/agent-toolkit/logs",
      "backup_repo": "~/.local/share/agent-toolkit/backups.git"
    },
    "limits": {
      "max_memory_mb": 8192,
      "max_file_read_mb": 10,
      "max_file_write_mb": 50,
      "max_embedding_batch": 32
    },
    "security": {
      "persona": "admin",
      "confirm_destructive": true,
      "dry_run_default": false
    },
    "ollama": {
      "host": "http://ecolife-2:11434",
      "default_model": "llama3.2",
      "embedding_model": "nomic-embed-text",
      "timeout_seconds": 120,
      "max_retries": 3
    },
    "ssh": {
      "ecolife_2_host": "ecolife-2",
      "ecolife_2_user": "ecolife",
      "timeout_seconds": 60
    },
    "logging": {
      "level": "INFO",
      "format": "json",
      "rotation_days": 1,
      "retention_days": 14,
      "max_file_size_mb": 100
    }
  }
}
```

---

> **End of Roadmap**
>
> This document is a living plan. Update it weekly with actual progress, blockers encountered, and lessons learned. The goal is not speed — it is correctness, safety, and maintainability.
>
> *"Slow is smooth, smooth is fast."*
