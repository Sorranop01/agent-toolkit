# DOMAIN_REQUIREMENTS.md — agent-toolkit MCP Server Hub

## Document Control

| Field | Value |
|-------|-------|
| **Project** | agent-toolkit — Self-Hosted MCP Server Hub |
| **Version** | 1.0.0 |
| **Date** | 2025-01-20 |
| **Author** | Domain Specialist / System Architect |
| **Status** | DRAFT |
| **Review Cycle** | Before implementation sprint |

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [Architecture Overview](#2-architecture-overview)
3. [SOLAR-CALC MCP Server](#3-solar-calc-mcp-server)
4. [HEALTH-OPS MCP Server](#4-health-ops-mcp-server)
5. [RAG-BRIDGE MCP Server](#5-rag-bridge-mcp-server)
6. [Cross-Server Integration Patterns](#6-cross-server-integration-patterns)
7. [Infrastructure & Deployment](#7-infrastructure--deployment)
8. [Security & Governance](#8-security--governance)
9. [Appendices](#9-appendices)

---

## 1. Executive Summary

**agent-toolkit** is a self-hosted Model Context Protocol (MCP) Server Hub designed to provide specialized computational and operational tools to existing AI CLI clients (Kimi CLI, OpenCode CLI, Goose CLI). It does NOT implement a new CLI — instead, it exposes domain-specific capabilities through the MCP protocol so that established CLI tools can invoke them.

### 1.1 Business Domains Covered

| Domain | Business Context | Primary User |
|--------|-----------------|--------------|
| **Solar O&M** | Rooftop solar installations in Bangkok, Thailand — performance monitoring, financial modeling, maintenance planning | Solar technicians, financial analysts, asset managers |
| **Health Franchise** | Health-focused franchise with LINE POS integration, inventory management, and customer engagement | Store operators, franchise managers, supply chain coordinators |
| **RAG Knowledge Base** | Document Q&A system for technical manuals, reports, and operational documents across all business units | All stakeholders needing document retrieval |

### 1.2 Guiding Principles

1. **CLI-Agnostic**: MCP servers expose tools; any MCP-compliant client can consume them
2. **Self-Hosted**: All inference runs on owned hardware (`ecolife-2`, 32GB RAM)
3. **JSON-Native**: All tool outputs are structured JSON for programmatic consumption
4. **Formula-Transparent**: Every calculation includes the formula used, enabling auditability
5. **Thai-Market Aware**: Currency (THB), units, and regulatory context target Thailand

---

## 2. Architecture Overview

### 2.1 System Topology

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           CLIENT LAYER                                   │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                      │
│  │  Kimi CLI   │  │ OpenCode CLI│  │ Goose CLI   │   (MCP Clients)     │
│  └──────┬──────┘  └──────┬──────┘  └──────┬──────┘                      │
└─────────┼────────────────┼────────────────┼─────────────────────────────┘
          │                │                │
          └────────────────┼────────────────┘
                           │  stdio / SSE transport
┌──────────────────────────┼─────────────────────────────────────────────┐
│                      MCP SERVER HUB (lean@192.168.1.135)               │
│                                                                        │
│  ┌─────────────────┐  ┌─────────────────┐  ┌─────────────────┐        │
│  │  SOLAR-CALC     │  │  HEALTH-OPS     │  │  RAG-BRIDGE     │        │
│  │  Port: 3001     │  │  Port: 3002     │  │  Port: 3003     │        │
│  │  Python/FastMCP │  │  Python/FastMCP │  │  Python/FastMCP │        │
│  └────────┬────────┘  └────────┬────────┘  └────────┬────────┘        │
│           │                    │                    │                  │
│           │  ┌─────────────────────────────────────────┐               │
│           │  │     Shared: SQLite / Chroma / Redis     │               │
│           │  │     (for state, vectors, caching)       │               │
│           │  └─────────────────────────────────────────┘               │
│           │                                                            │
└───────────┼────────────────────────────────────────────────────────────┘
            │                    HTTP API calls
┌───────────┼────────────────────────────────────────────────────────────┐
│      INFERENCE LAYER (ecolife-2)                                       │
│                                                                        │
│  ┌─────────────────────────────────────────────────────────────┐      │
│  │  Ollama (24/7)                                               │      │
│  │  - Embedding: nomic-embed-text / mxbai-embed-large          │      │
│  │  - Vision: llava / bakllava (for OCR)                       │      │
│  │  - LLM: qwen2.5 / mistral / llama3.2 (for reranking)       │      │
│  │  - 32GB RAM — max 4K context, ~8B param models              │      │
│  └─────────────────────────────────────────────────────────────┘      │
│                                                                        │
│  ┌─────────────────────────────────────────────────────────────┐      │
│  │  sqlite-vec (vector extension)                              │      │
│  │  ChromaDB (alternative vector store)                        │      │
│  └─────────────────────────────────────────────────────────────┘      │
└────────────────────────────────────────────────────────────────────────┘
            │
            ▼
┌────────────────────────────────────────────────────────────────────────┐
│      EXTERNAL SERVICES                                                 │
│  - LINE Messaging API (health notifications)                          │
│  - LINE POS API (order sync, menu management)                         │
│  - Provincial Electricity Authority (PEA) rate schedules (Thailand)   │
│  - SolarGIS / NASA POWER (irradiance data — optional)                │
└────────────────────────────────────────────────────────────────────────┘
```

### 2.2 Transport Configuration

| Server | Transport | Port | Endpoint |
|--------|-----------|------|----------|
| SOLAR-CALC | SSE | 3001 | `http://192.168.1.135:3001/sse` |
| HEALTH-OPS | SSE | 3002 | `http://192.168.1.135:3002/sse` |
| RAG-BRIDGE | SSE | 3003 | `http://192.168.1.135:3003/sse` |

### 2.3 Technology Stack

| Component | Selection | Rationale |
|-----------|-----------|-----------|
| MCP Framework | `FastMCP` (Python) | Native Python, async support, SSE transport |
| Computation | NumPy / SciPy / Pandas | Mature scientific stack for solar calculations |
| API Client | httpx | Async HTTP for LINE API, Ollama API |
| Vector Store | sqlite-vec (primary), Chroma (backup) | Zero-config, file-based, fits 32GB constraint |
| Document Parsing | pymupdf, openpyxl, python-docx, pytesseract | Comprehensive format coverage |
| Orchestration | systemd services + simple queue files | No K8s overhead for single-node setup |
| Monitoring | Log files + optional Prometheus | Operational visibility |

---

## 3. SOLAR-CALC MCP Server

### 3.1 Domain Background

The solar O&M domain covers rooftop photovoltaic (PV) systems installed in Bangkok, Thailand. Key characteristics:

- **Location**: Bangkok (~13.75°N, 100.5°E), tropical climate
- **Average GHI**: ~4.5–5.5 kWh/m²/day annually
- **Grid**: Provincial Electricity Authority (PEA) — residential rates ~4.0–4.5 THB/kWh
- **Regulation**: Net metering (PEA buyback ~2.0 THB/kWh for excess)
- **System sizes**: 3–20 kWp typical for residential/commercial rooftops
- **Degradation**: 0.5–0.8% per year (tier-1 panels)
- **Performance Ratio (PR)**: 0.75–0.85 for well-designed Bangkok systems

### 3.2 Core Formulas Reference

All calculations in SOLAR-CALC derive from these foundational equations:

#### 3.2.1 Energy Yield Estimation

```
E = P × H × PR × SF

Where:
  E    = Annual energy yield (kWh/year)
  P    = System DC capacity (kWp)
  H    = Annual solar irradiance on tilted plane (kWh/m²/year)
  PR   = Performance Ratio (dimensionless, 0.0–1.0)
  SF   = Shading Factor (dimensionless, 0.0–1.0)

Monthly: E_month = P × H_month × PR × SF × Days_in_month / 30.44
Daily:   E_day   = P × H_day × PR × SF
```

#### 3.2.2 Performance Ratio (PR)

```
PR = η_inverter × η_wiring × η_dust × η_temp × η_mismatch × η_availability

Typical Bangkok breakdown:
  η_inverter     = 0.97–0.985 (98% nominal, derate at partial load)
  η_wiring       = 0.985 (1.5% DC + AC losses)
  η_dust         = 0.95–0.98 (soiling in Bangkok, monthly cleaning)
  η_temp         = 0.90–0.94 (Bangkok ambient 30°C avg, cell temp ~55–60°C)
  η_mismatch     = 0.98 (manufacturing tolerance)
  η_availability = 0.995 (0.5% downtime for maintenance)

Expected PR range: 0.75–0.85 for Bangkok rooftop systems
```

#### 3.2.3 Temperature Derating

```
T_cell = T_ambient + (NOCT - 20) × (G / 800) × (1 - η_panel / 0.9)

Where:
  T_cell     = Cell temperature (°C)
  T_ambient  = Ambient temperature (°C)
  NOCT       = Nominal Operating Cell Temperature (°C, typically 45±2)
  G          = Irradiance (W/m²)
  η_panel    = Panel efficiency (decimal)

Power at temperature:
  P_actual = P_rated × (1 + γ × (T_cell - 25))

Where:
  γ = Temperature coefficient of power (typically -0.35%/°C to -0.40%/°C)
```

#### 3.2.4 Internal Rate of Return (IRR)

```
NPV = Σ (CF_t / (1 + IRR)^t) = 0

Where:
  CF_0   = -Initial_Investment (negative cash flow)
  CF_t   = Annual_cash_flow_t for year t = 1..N
  N      = System lifetime (years, typically 25)

Annual Cash Flow:
  CF_t = (E_t × Electricity_rate × Self_consumption_ratio)
       + (E_t × Feed_in_tariff × (1 - Self_consumption_ratio))
       - O&M_cost_t

Where:
  E_t    = Energy yield in year t, accounting for degradation
  Self_consumption_ratio = fraction of energy used on-site (typically 0.7–0.9)
```

#### 3.2.5 Simple Payback Period

```
Payback = Initial_Investment / Annual_net_savings

Where:
  Annual_net_savings = (E × Electricity_rate × Self_consumption)
                     + (E × FIT × (1 - Self_consumption))
                     - Annual_O&M_cost

Break-even occurs when cumulative CF_t >= Initial_Investment
```

#### 3.2.6 Degradation Model

```
E_t = E_0 × (1 - d)^t

Where:
  E_t = Energy yield in year t
  E_0 = First-year energy yield
  d   = Annual degradation rate (0.005 to 0.008, i.e., 0.5–0.8%)
  t   = Year number (0 = first year)

Cumulative energy over lifetime:
  E_cumulative = Σ E_t for t = 0 to N-1
               = E_0 × (1 - (1 - d)^N) / d
```

#### 3.2.7 Inverter Efficiency Curve

```
η_inv = η_max / (1 + a × (PLR - PLR_opt)^2)

Where:
  η_inv  = Inverter efficiency at given load
  η_max  = Maximum efficiency (typically 0.97–0.99)
  PLR    = Partial Load Ratio = P_out / P_rated (0.0–1.0)
  PLR_opt = Optimal load ratio (typically 0.3–0.5)
  a      = Curve shape parameter (determines Euro-efficiency match)

Euro Efficiency (weighted average):
  η_euro = 0.03×η_5% + 0.06×η_10% + 0.13×η_20% + 0.10×η_30%
         + 0.48×η_50% + 0.20×η_100%
```

#### 3.2.8 CO2 Offset Calculation

```
CO2_offset = E × EF_grid

Where:
  E        = Annual energy yield (kWh)
  EF_grid  = Thailand grid emission factor (typically ~0.56 kg CO2/kWh)

Reference: Thailand GHG Inventory — electricity sector emission factor
2023 value: 0.5629 kg CO2e/kWh (published by ONEP)

Lifetime CO2 offset:
  CO2_lifetime = Σ (E_t × EF_grid) for t = 0 to N-1
```

### 3.3 MCP Tool Specifications

---

#### Tool: `solar_estimate_yield`

**Description**: Estimate annual and monthly energy yield for a rooftop solar installation given system parameters and local conditions.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `system_capacity_kwp` | float | Yes | Total DC system capacity in kilowatts-peak (kWp) |
| `annual_irradiance_kwh_m2` | float | Yes | Annual solar irradiance on the tilted plane (kWh/m²/year) |
| `monthly_irradiance` | array[float] | No | 12-element array of monthly irradiance values [Jan..Dec] (kWh/m²/month). If omitted, evenly distributed from annual |
| `performance_ratio` | float | No | System performance ratio (0.0–1.0). Default: 0.80 |
| `shading_factor` | float | No | Shading reduction factor (0.0–1.0, where 1.0 = no shading). Default: 1.0 |
| `tilt_angle` | float | No | Panel tilt angle in degrees from horizontal. Default: 13 (Bangkok latitude approximation) |
| `azimuth` | float | No | Panel azimuth in degrees (0 = North, 90 = East, 180 = South, 270 = West). Default: 180 (South-facing) |
| `panel_efficiency` | float | No | Panel nameplate efficiency (0.0–1.0). Default: 0.21 (21%) |
| `temperature_coefficient` | float | No | Power temperature coefficient (%/°C, negative). Default: -0.35 |
| `noct` | float | No | Nominal Operating Cell Temperature in °C. Default: 45 |
| `ambient_temperature_avg` | float | No | Average ambient temperature in °C. Default: 30 (Bangkok) |
| `inverter_capacity_kw` | float | No | Inverter AC rated capacity in kW. If omitted, assumed equal to system_capacity_kwp |
| `inverter_max_efficiency` | float | No | Inverter maximum efficiency (0.0–1.0). Default: 0.98 |
| `dc_ac_ratio` | float | No | DC-to-AC ratio. Default: 1.1 |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `annual_yield_kwh` | float | Estimated annual energy yield (kWh) |
| `monthly_yields_kwh` | array[float] | 12-element array of monthly yields [Jan..Dec] (kWh) |
| `daily_average_kwh` | float | Average daily energy yield (kWh/day) |
| `specific_yield_kwh_kwp` | float | Specific yield (kWh/kWp/year) |
| `capacity_factor` | float | Capacity factor (0.0–1.0) = annual_yield / (system_capacity_kwp × 8760) |
| `performance_ratio_applied` | float | The PR value used in calculation |
| `temperature_derate_factor` | float | Estimated temperature derating factor applied |
| `inverter_clipping_loss_pct` | float | Estimated energy loss from inverter clipping (%) |
| `shading_loss_kwh` | float | Annual energy loss from shading (kWh) |
| `formula_used` | string | Reference formula: "E = P × H × PR × SF" |
| `assumptions` | object | Key assumptions applied (temperature, soiling, etc.) |

**Example Input:**
```json
{
  "system_capacity_kwp": 10.0,
  "annual_irradiance_kwh_m2": 1850,
  "monthly_irradiance": [162, 165, 175, 178, 170, 155, 150, 152, 155, 160, 165, 168],
  "performance_ratio": 0.82,
  "shading_factor": 0.95,
  "tilt_angle": 13,
  "azimuth": 180,
  "panel_efficiency": 0.22,
  "temperature_coefficient": -0.35,
  "ambient_temperature_avg": 30,
  "inverter_capacity_kw": 9.0,
  "inverter_max_efficiency": 0.985,
  "dc_ac_ratio": 1.11
}
```

**Example Output:**
```json
{
  "annual_yield_kwh": 14387.5,
  "monthly_yields_kwh": [1272.3, 1295.8, 1374.5, 1398.1, 1335.2, 1217.5, 1178.2, 1193.9, 1217.5, 1256.8, 1295.8, 1317.0],
  "daily_average_kwh": 39.4,
  "specific_yield_kwh_kwp": 1438.8,
  "capacity_factor": 0.164,
  "performance_ratio_applied": 0.82,
  "temperature_derate_factor": 0.893,
  "inverter_clipping_loss_pct": 1.2,
  "shading_loss_kwh": 757.2,
  "formula_used": "E = P × H × PR × SF",
  "assumptions": {
    "temperature_derating": "Applied: -0.35%/°C above 25°C cell temp",
    "soiling_loss": "3% monthly cleaning assumed",
    "availability": "99.5% system availability",
    "inverter_model": "Efficiency curve with max 98.5%"
  }
}
```

---

#### Tool: `solar_calculate_irr`

**Description**: Calculate Internal Rate of Return (IRR), Net Present Value (NPV), and payback period for a solar investment with detailed year-by-year cash flow projection.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `system_cost_thb` | float | Yes | Total system installation cost in Thai Baht (THB) |
| `system_capacity_kwp` | float | Yes | System DC capacity (kWp) |
| `annual_yield_kwh` | float | Yes | First-year energy yield (kWh) |
| `electricity_rate_thb_per_kwh` | float | Yes | Current electricity rate (THB/kWh) |
| `self_consumption_ratio` | float | No | Fraction of solar energy consumed on-site (0.0–1.0). Default: 0.80 |
| `feed_in_tariff_thb_per_kwh` | float | No | Rate for selling excess to grid (THB/kWh). Default: 2.0 |
| `annual_om_cost_thb` | float | No | Annual O&M cost (THB/year). Default: 2% of system_cost_thb |
| `annual_om_escalation_pct` | float | No | Annual O&M cost escalation (%). Default: 2.5 |
| `electricity_rate_escalation_pct` | float | No | Annual electricity rate escalation (%). Default: 3.0 |
| `degradation_rate_pct` | float | No | Annual panel degradation (%). Default: 0.55 |
| `discount_rate_pct` | float | No | Discount rate for NPV calculation (%). Default: 6.0 |
| `project_lifetime_years` | int | No | Analysis period in years. Default: 25 |
| `inverter_replacement` | object | No | Inverter replacement plan (see below) |

**Inverter Replacement Sub-schema:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `year` | int | Yes | Year of replacement (1-indexed) |
| `cost_thb` | float | Yes | Replacement cost in THB |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `irr_pct` | float | Internal Rate of Return (%) |
| `npv_thb` | float | Net Present Value at given discount rate (THB) |
| `discount_rate_pct` | float | Discount rate used for NPV |
| `simple_payback_years` | float | Simple payback period (years) |
| `discounted_payback_years` | float | Discounted payback period (years) |
| `lcoe_thb_per_kwh` | float | Levelized Cost of Energy (THB/kWh) |
| `total_lifetime_savings_thb` | float | Cumulative savings over project lifetime (THB) |
| `yearly_cashflows` | array[object] | Year-by-year breakdown (see below) |
| `break_even_year` | int | First year where cumulative savings exceed initial investment |
| `roi_pct` | float | Return on Investment (%) = (total_savings - cost) / cost × 100 |

**Yearly Cashflow Object:**

| Field | Type | Description |
|-------|------|-------------|
| `year` | int | Year number (1 = first year) |
| `energy_yield_kwh` | float | Degraded energy yield for this year (kWh) |
| `electricity_rate_thb_kwh` | float | Escalated electricity rate this year (THB/kWh) |
| `savings_from_self_consumption_thb` | float | Savings from self-consumed energy (THB) |
| `revenue_from_export_thb` | float | Revenue from exported energy (THB) |
| `om_cost_thb` | float | O&M cost this year (THB) |
| `inverter_replacement_thb` | float | Inverter replacement cost this year, if any (THB) |
| `net_cashflow_thb` | float | Net cash flow this year (THB) |
| `cumulative_cashflow_thb` | float | Cumulative cash flow to date (THB) |
| `discounted_cashflow_thb` | float | Discounted net cash flow (THB) |

**Example Input:**
```json
{
  "system_cost_thb": 350000,
  "system_capacity_kwp": 10.0,
  "annual_yield_kwh": 14387.5,
  "electricity_rate_thb_per_kwh": 4.32,
  "self_consumption_ratio": 0.85,
  "feed_in_tariff_thb_per_kwh": 2.0,
  "annual_om_cost_thb": 7000,
  "degradation_rate_pct": 0.55,
  "discount_rate_pct": 6.0,
  "project_lifetime_years": 25,
  "inverter_replacement": {"year": 13, "cost_thb": 80000}
}
```

**Example Output (abbreviated):**
```json
{
  "irr_pct": 14.82,
  "npv_thb": 287450,
  "discount_rate_pct": 6.0,
  "simple_payback_years": 6.8,
  "discounted_payback_years": 8.2,
  "lcoe_thb_per_kwh": 1.94,
  "total_lifetime_savings_thb": 912340,
  "break_even_year": 7,
  "roi_pct": 160.7,
  "yearly_cashflows": [
    {
      "year": 1,
      "energy_yield_kwh": 14387.5,
      "electricity_rate_thb_kwh": 4.32,
      "savings_from_self_consumption_thb": 52870.0,
      "revenue_from_export_thb": 4316.3,
      "om_cost_thb": 7000.0,
      "inverter_replacement_thb": 0,
      "net_cashflow_thb": 50186.3,
      "cumulative_cashflow_thb": -299813.7,
      "discounted_cashflow_thb": 47345.6
    }
  ]
}
```

---

#### Tool: `solar_panel_degradation`

**Description**: Project multi-year energy yield accounting for panel degradation, with optional scenario comparison.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `initial_annual_yield_kwh` | float | Yes | First-year energy yield (kWh) |
| `degradation_rate_low_pct` | float | No | Low degradation scenario (%/year). Default: 0.50 |
| `degradation_rate_mid_pct` | float | No | Mid degradation scenario (%/year). Default: 0.55 |
| `degradation_rate_high_pct` | float | No | High degradation scenario (%/year). Default: 0.80 |
| `project_lifetime_years` | int | No | Analysis period. Default: 25 |
| `include_cumulative` | bool | No | Include cumulative energy output. Default: true |
| `compare_scenarios` | bool | No | Return all three scenarios. Default: true |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `scenarios` | array[object] | Degradation scenarios (low/mid/high) |
| `yearly_projections` | array[object] | Year-by-year yield for each scenario |

**Scenario Object:**

| Field | Type | Description |
|-------|------|-------------|
| `scenario_name` | string | "Low (0.5%)", "Mid (0.55%)", or "High (0.8%)" |
| `degradation_rate_pct` | float | Degradation rate for this scenario |
| `final_year_yield_kwh` | float | Energy yield in final year (kWh) |
| `cumulative_lifetime_kwh` | float | Total energy over project lifetime (kWh) |
| `total_degradation_pct` | float | Total % degradation from year 1 to final year |

**Yearly Projection Object:**

| Field | Type | Description |
|-------|------|-------------|
| `year` | int | Year number |
| `yield_low_kwh` | float | Yield under low degradation scenario (kWh) |
| `yield_mid_kwh` | float | Yield under mid degradation scenario (kWh) |
| `yield_high_kwh` | float | Yield under high degradation scenario (kWh) |
| `cumulative_low_kwh` | float | Cumulative yield, low scenario (kWh) |
| `cumulative_mid_kwh` | float | Cumulative yield, mid scenario (kWh) |
| `cumulative_high_kwh` | float | Cumulative yield, high scenario (kWh) |

**Formula Used:**
```
E_t = E_0 × (1 - d)^t
Cumulative = E_0 × (1 - (1 - d)^N) / d
```

---

#### Tool: `solar_inverter_efficiency`

**Description**: Calculate inverter efficiency at various partial load ratios and compute Euro/CEC efficiency ratings.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `inverter_capacity_kw` | float | Yes | Inverter rated AC capacity (kW) |
| `max_efficiency` | float | No | Maximum efficiency (0.0–1.0). Default: 0.98 |
| `european_efficiency` | float | No | Published European efficiency if known (0.0–1.0) |
| `cec_efficiency` | float | No | Published CEC efficiency if known (0.0–1.0) |
| `load_profile_pct` | array[float] | No | Custom load percentages to evaluate (%). Default: [5, 10, 20, 30, 50, 75, 100] |
| `calculate_weighted` | bool | No | Calculate Euro and CEC weighted efficiencies. Default: true |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `efficiency_curve` | array[object] | Efficiency at each load point |
| `euro_efficiency_pct` | float | Calculated European weighted efficiency (%) |
| `cec_efficiency_pct` | float | Calculated CEC weighted efficiency (%) |
| `peak_efficiency_pct` | float | Maximum efficiency from curve (%) |
| `optimal_load_range` | object | Load range where efficiency > 95% of peak |

**Efficiency Curve Point:**

| Field | Type | Description |
|-------|------|-------------|
| `load_pct` | float | Load as percentage of rated capacity (%) |
| `output_kw` | float | AC output power (kW) |
| `efficiency_pct` | float | Conversion efficiency at this load (%) |
| `power_loss_kw` | float | Power loss at this load (kW) |

**Formula Used:**
```
η(PLR) = η_max × (1 - a × (PLR - PLR_opt)^2)
Where PLR = P_out / P_rated, PLR_opt typically 0.35–0.50

Euro η = 0.03×η_5% + 0.06×η_10% + 0.13×η_20% + 0.10×η_30%
       + 0.48×η_50% + 0.20×η_100%

CEC η  = 0.04×η_10% + 0.05×η_20% + 0.12×η_30% + 0.21×η_50%
       + 0.53×η_75% + 0.05×η_100%
```

---

#### Tool: `solar_co2_offset`

**Description**: Calculate CO2 emissions offset by solar generation using Thailand-specific grid emission factors.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `annual_yield_kwh` | float | Yes | Annual energy yield (kWh) |
| `project_lifetime_years` | int | No | Analysis period. Default: 25 |
| `degradation_rate_pct` | float | No | Annual degradation (%). Default: 0.55 |
| `emission_factor_kg_co2_per_kwh` | float | No | Grid emission factor (kg CO2/kWh). Default: 0.5629 (Thailand 2023) |
| `include_tree_equivalent` | bool | No | Include tree-sequestration equivalent. Default: true |
| `include_vehicle_equivalent` | bool | No | Include passenger vehicle equivalent. Default: true |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `annual_co2_offset_kg` | float | CO2 offset in first year (kg) |
| `annual_co2_offset_tons` | float | CO2 offset in first year (metric tons) |
| `lifetime_co2_offset_tons` | float | Total CO2 offset over project lifetime (metric tons) |
| `yearly_offset` | array[object] | Year-by-year breakdown |
| `equivalencies` | object | Human-contextual equivalents |

**Equivalencies Object:**

| Field | Type | Description |
|-------|------|-------------|
| `trees_planted_equivalent` | int | Number of tree seedlings grown for 10 years equivalent |
| `passenger_km_avoided` | int | Passenger vehicle kilometers avoided |
| `homes_powered_equivalent` | float | Equivalent number of Thai homes powered for one year |
| `coal_burned_kg` | float | kg of coal not burned |

**Yearly Offset Object:**

| Field | Type | Description |
|-------|------|-------------|
| `year` | int | Year number |
| `yield_kwh` | float | Energy yield this year (kWh) |
| `co2_offset_kg` | float | CO2 offset this year (kg) |
| `cumulative_co2_offset_tons` | float | Cumulative CO2 offset (metric tons) |

**Formula Used:**
```
CO2_annual = E × EF_grid
  E     = Annual energy yield (kWh)
  EF_grid = Thailand grid emission factor (0.5629 kg CO2/kWh, ONEP 2023)

Tree equivalent: 1 tree seedling × 10 years ≈ 60 kg CO2 sequestered
(FAO/IPCC methodology)

Vehicle equivalent: 1 km in passenger car ≈ 0.12 kg CO2
(Thailand LPG/gasoline vehicle average)
```

---

#### Tool: `solar_system_optimizer`

**Description**: Recommend optimal system configuration (tilt, azimuth, DC/AC ratio) for a given location and constraints. Useful for initial system design.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `roof_area_m2` | float | Yes | Available roof area (m²) |
| `roof_tilt_deg` | float | No | Existing roof tilt (°). Default: 0 (flat) |
| `roof_azimuth_deg` | float | No | Roof azimuth (°). Default: 180 (South) |
| `panel_watt_peak` | float | No | Panel rating (W). Default: 550 |
| `panel_efficiency` | float | No | Panel efficiency (0.0–1.0). Default: 0.22 |
| `panel_dimensions_m` | array[float] | No | [width, height] in meters. Default: [1.134, 2.278] |
| `budget_thb` | float | No | Maximum budget (THB). Optional constraint |
| `cost_per_watt_thb` | float | No | Installation cost per watt (THB/W). Default: 35 |
| `monthly_irradiance` | array[float] | No | 12 monthly irradiance values (kWh/m²/month) |
| `latitude` | float | No | Latitude (°N). Default: 13.75 (Bangkok) |
| `shading_obstacles` | array[object] | No | Array of shading obstacles (see below) |

**Shading Obstacle Sub-schema:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `azimuth` | float | Yes | Azimuth angle of obstacle (°) |
| `elevation` | float | Yes | Elevation angle of obstacle top (° above horizon) |
| `distance_m` | float | No | Distance to obstacle (m) |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `max_capacity_kwp` | float | Maximum achievable capacity with given roof area (kWp) |
| `recommended_capacity_kwp` | float | Recommended system size considering constraints (kWp) |
| `panel_count` | int | Number of panels |
| `array_layout` | object | Recommended physical layout |
| `optimal_tilt_deg` | float | Recommended tilt angle (°) |
| `optimal_azimuth_deg` | float | Recommended azimuth (°) |
| `estimated_annual_yield_kwh` | float | Projected annual yield (kWh) |
| `estimated_cost_thb` | float | Estimated system cost (THB) |
| `within_budget` | bool | Whether estimated cost is within budget |
| `specific_design_notes` | array[string] | Array of design recommendations |

---

### 3.4 Data Constants (Hard-Coded Defaults)

| Constant | Value | Source |
|----------|-------|--------|
| `THAILAND_GRID_EF` | 0.5629 kg CO2/kWh | ONEP Thailand GHG Inventory 2023 |
| `BANGKOK_AVG_GHI` | 1850 kWh/m²/year | SolarGIS / NASA POWER historical |
| `PEA_RESIDENTIAL_RATE` | 4.32 THB/kWh | PEA residential tariff (variable block) |
| `PEA_FEED_IN_TARIFF` | 2.0 THB/kWh | Net metering excess rate (approximate) |
| `DEFAULT_PANEL_EFFICIENCY` | 0.22 | Tier-1 monocrystalline PERC/TOPCon |
| `DEFAULT_DEGRADATION_RATE` | 0.0055 | Manufacturer warranty (0.55%/year) |
| `DEFAULT_TEMP_COEFFICIENT` | -0.0035 | -0.35%/°C (standard) |
| `DEFAULT_NOCT` | 45°C | IEC 61215 standard test conditions |
| `DEFAULT_COST_PER_WATT` | 35 THB/W | Bangkok market rate (2024) |
| `DEFAULT_PROJECT_LIFETIME` | 25 | Panel warranty period |

---

## 4. HEALTH-OPS MCP Server

### 4.1 Domain Background

The health franchise operates multiple health-focused retail locations in Thailand. Key operational characteristics:

- **POS System**: LINE POS (integrated with LINE Official Account)
- **Customer Communication**: LINE Messaging API (Liff, Rich Menu, Push messages)
- **Inventory**: Perishable health products with expiry tracking
- **Sales Channels**: In-store (POS) + LINE pre-order + pickup
- **Regulatory**: FDA Thailand compliance for health products
- **Staff**: Store operators with limited technical expertise — tools must be simple

### 4.2 LINE POS Integration Architecture

```
┌──────────────────────────────────────────────────────────────┐
│                    LINE ECOSYSTEM                             │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐                   │
│  │ LINE POS │  │ LINE OA  │  │ LINE Pay │                   │
│  │ (Orders) │  │(Messaging│  │(Payments)│                   │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘                   │
│       │             │             │                          │
│       └─────────────┼─────────────┘                          │
│                     │  Webhook / API                          │
└─────────────────────┼────────────────────────────────────────┘
                      │
              ┌───────┴───────┐
              │ HEALTH-OPS    │
              │ MCP Server    │
              │ (Port 3002)   │
              └───────┬───────┘
                      │
        ┌─────────────┼─────────────┐
        ▼             ▼             ▼
   ┌─────────┐  ┌──────────┐  ┌──────────┐
   │ SQLite  │  │ LINE API │  │ Inventory│
   │ (State) │  │ (Client) │  │ (Logic)  │
   └─────────┘  └──────────┘  └──────────┘
```

### 4.3 LINE POS Webhook Events

The HEALTH-OPS server subscribes to the following LINE POS webhook events:

| Event Type | Trigger | Data Payload |
|------------|---------|-------------|
| `order.created` | New order placed | order_id, items[], total, timestamp, customer_line_id |
| `order.updated` | Order status change | order_id, old_status, new_status, timestamp |
| `order.completed` | Order fulfilled | order_id, completion_time, payment_method |
| `payment.received` | Payment confirmed | order_id, amount, payment_method, transaction_id |
| `menu.updated` | Menu item changed | item_id, name, price, availability |
| `refund.processed` | Refund issued | order_id, refund_amount, reason |

### 4.4 MCP Tool Specifications

---

#### Tool: `health_inventory_check`

**Description**: Query current inventory levels for specified items or all items. Supports filtering by category, location, and stock status.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `store_id` | string | Yes | Store/location identifier |
| `item_ids` | array[string] | No | Specific item SKUs to check. If omitted, returns all items |
| `category` | string | No | Filter by product category (e.g., "supplements", "beverages") |
| `status_filter` | enum | No | "all", "in_stock", "low_stock", "out_of_stock". Default: "all" |
| `include_expiry` | bool | No | Include expiry date information. Default: true |
| `as_of_date` | string | No | Check inventory as of specific date (YYYY-MM-DD). Default: today |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `store_id` | string | Store identifier |
| `check_timestamp` | string | ISO 8601 timestamp of check |
| `items` | array[InventoryItem] | Inventory records |
| `summary` | object | Aggregated summary |

**InventoryItem Object:**

| Field | Type | Description |
|-------|------|-------------|
| `item_id` | string | SKU / product code |
| `item_name` | string | Product name (Thai + English) |
| `category` | string | Product category |
| `current_stock` | int | Current quantity on hand |
| `unit` | string | Unit of measure (bottle, box, sachet, etc.) |
| `reorder_point` | int | Stock level triggering reorder alert |
| `reorder_quantity` | int | Suggested reorder amount |
| `status` | enum | "in_stock", "low_stock", "out_of_stock" |
| `expiry_dates` | array[object] | Batch-level expiry tracking |
| `last_restock_date` | string | Date of last restock (YYYY-MM-DD) |
| `avg_daily_consumption` | float | 7-day rolling average daily usage |
| `days_of_inventory_remaining` | float | Estimated days until stockout |

**Expiry Date Object:**

| Field | Type | Description |
|-------|------|-------------|
| `batch_id` | string | Batch/lot identifier |
| `expiry_date` | string | Expiry date (YYYY-MM-DD) |
| `quantity` | int | Units in this batch |
| `days_until_expiry` | int | Days until expiry |
| `alert_level` | enum | "safe", "warning" (< 30 days), "critical" (< 7 days) |

**Summary Object:**

| Field | Type | Description |
|-------|------|-------------|
| `total_items` | int | Total products tracked |
| `in_stock_count` | int | Items with adequate stock |
| `low_stock_count` | int | Items below reorder point |
| `out_of_stock_count` | int | Items with zero stock |
| `expiring_within_30_days` | int | Batches expiring within 30 days |
| `critical_expiry` | int | Batches expiring within 7 days |

---

#### Tool: `health_low_stock_alerts`

**Description**: Generate low-stock and critical-expiry alerts for a store. Can trigger auto-reorder suggestions.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `store_id` | string | Yes | Store identifier |
| `alert_types` | array[enum] | No | ["low_stock", "expiry", "both"]. Default: ["both"] |
| `include_reorder_suggestions` | bool | No | Include recommended reorder quantities. Default: true |
| `auto_generate_po` | bool | No | Generate draft purchase orders. Default: false |
| `supplier_filter` | string | No | Filter alerts by supplier ID |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `store_id` | string | Store identifier |
| `generated_at` | string | ISO 8601 timestamp |
| `low_stock_alerts` | array[LowStockAlert] | Low stock items |
| `expiry_alerts` | array[ExpiryAlert] | Expiring items |
| `reorder_suggestions` | array[ReorderSuggestion] | Suggested orders |
| `draft_purchase_orders` | array[object] | Draft POs (if auto_generate_po=true) |
| `alert_summary` | object | Counts by severity |

**LowStockAlert Object:**

| Field | Type | Description |
|-------|------|-------------|
| `item_id` | string | SKU |
| `item_name` | string | Product name |
| `current_stock` | int | Current quantity |
| `reorder_point` | int | Reorder threshold |
| `shortfall` | int | Quantity below reorder point |
| `severity` | enum | "warning" (within 20% of reorder point), "critical" (zero or negative) |
| `suggested_reorder_qty` | int | Recommended order quantity |
| `estimated_stockout_date` | string | Projected stockout date (YYYY-MM-DD) |
| `last_7day_sales` | int | Units sold in last 7 days |

**ExpiryAlert Object:**

| Field | Type | Description |
|-------|------|-------------|
| `item_id` | string | SKU |
| `item_name` | string | Product name |
| `batch_id` | string | Batch identifier |
| `expiry_date` | string | Expiry date (YYYY-MM-DD) |
| `days_until_expiry` | int | Days remaining |
| `quantity_at_risk` | int | Units in this batch |
| `severity` | enum | "warning" (8–30 days), "critical" (0–7 days), "expired" (past date) |
| `recommended_action` | enum | "discount_sell", "transfer", "dispose", "monitor" |
| `potential_loss_thb` | float | Estimated financial loss if discarded (THB) |

**ReorderSuggestion Object:**

| Field | Type | Description |
|-------|------|-------------|
| `item_id` | string | SKU |
| `item_name` | string | Product name |
| `suggested_order_qty` | int | Recommended quantity to order |
| `supplier_id` | string | Preferred supplier |
| `supplier_name` | string | Supplier name |
| `estimated_unit_cost_thb` | float | Unit cost (THB) |
| `estimated_total_cost_thb` | float | Total order cost (THB) |
| `lead_time_days` | int | Expected delivery lead time |
| `reasoning` | string | Explanation for suggestion |

---

#### Tool: `health_sync_menu`

**Description**: Synchronize menu items between the internal inventory system and LINE POS. Push new items, update prices, or disable out-of-stock items.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `store_id` | string | Yes | Store identifier |
| `sync_mode` | enum | Yes | "full_replace", "upsert", "deactivate_only", "price_update" |
| `items` | array[MenuItem] | Conditional | Items to sync (required for upsert/full_replace modes) |
| `category` | string | No | Sync only items in this category |
| `dry_run` | bool | No | Preview changes without applying. Default: false |

**MenuItem Sub-schema:**

| Field | Type | Required | Description |
|-------|------|----------|-------------|
| `item_id` | string | Yes | Unique item identifier |
| `name_th` | string | Yes | Product name in Thai |
| `name_en` | string | No | Product name in English |
| `description_th` | string | No | Description in Thai |
| `category` | string | Yes | Menu category |
| `price_thb` | float | Yes | Selling price (THB) |
| `cost_thb` | float | No | Cost price for margin calculation (THB) |
| `available` | bool | Yes | Whether item is currently available |
| `image_url` | string | No | Product image URL |
| `options` | array[object] | No | Customization options (size, add-ons, etc.) |
| `allergens` | array[string] | No | Allergen warnings |
| `nutritional_info` | object | No | Calories, protein, etc. |
| `pos_category_id` | string | No | LINE POS internal category ID |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `store_id` | string | Store identifier |
| `sync_status` | enum | "synced", "partial", "failed", "dry_run" |
| `items_processed` | int | Total items in sync request |
| `items_created` | int | New items added to LINE POS |
| `items_updated` | int | Existing items modified |
| `items_deactivated` | int | Items marked unavailable |
| `items_failed` | int | Items that failed to sync |
| `errors` | array[object] | Detailed error records |
| `dry_run_preview` | array[object] | Preview of changes (if dry_run=true) |
| `sync_timestamp` | string | ISO 8601 timestamp |

**Error Object:**

| Field | Type | Description |
|-------|------|-------------|
| `item_id` | string | Item that caused error |
| `error_code` | string | LINE API error code or internal code |
| `error_message` | string | Human-readable error description |
| `suggested_action` | string | Recommended remediation |

---

#### Tool: `health_notify_customers`

**Description**: Send notifications to customers via LINE Messaging API. Supports order notifications, broadcasts, and targeted promotions with rate limiting.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `store_id` | string | Yes | Store identifier |
| `notification_type` | enum | Yes | "order_confirmation", "pickup_ready", "broadcast", "promotion", "custom" |
| `recipient_line_ids` | array[string] | Conditional | Target LINE user IDs (required for direct messages) |
| `recipient_audience` | enum | Conditional | "all", "recent_customers", "vip", "inactive". Alternative to explicit IDs |
| `order_id` | string | Conditional | Order reference (required for order_confirmation, pickup_ready) |
| `message_template` | enum | No | Predefined template name. Overrides custom message if specified |
| `message_th` | string | Conditional | Thai message text (required if no template) |
| `message_en` | string | No | English message text (for bilingual) |
| `rich_media` | object | No | Flex message / rich menu payload |
| `coupon_code` | string | No | Attach promotional coupon |
| `scheduled_time` | string | No | ISO 8601 datetime for scheduled delivery |
| `rate_limit_check` | bool | No | Enforce LINE API rate limits. Default: true |

**Rate Limiting Configuration:**

| Limit | Value | Source |
|-------|-------|--------|
| Push API | 500 messages/second | LINE Messaging API |
| Broadcast | 1,000 messages/minute | LINE Messaging API |
| Multicast | 500 messages/second | LINE Messaging API |
| Free tier monthly | 1,000 push messages | LINE Official Account |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `notification_id` | string | Internal notification tracking ID |
| `status` | enum | "queued", "sent", "partial", "failed", "scheduled" |
| `recipients_total` | int | Total target recipients |
| `recipients_success` | int | Successfully delivered |
| `recipients_failed` | int | Failed delivery |
| `rate_limit_applied` | bool | Whether rate limiting was enforced |
| `estimated_delivery_time` | string | Estimated completion timestamp |
| `line_message_ids` | array[string] | LINE API message IDs for tracking |
| `cost_estimate_thb` | float | Estimated LINE messaging cost (THB) |
| `errors` | array[object] | Failed delivery details |

---

#### Tool: `health_daily_sales_report`

**Description**: Aggregate daily sales data from LINE POS. Generate summary reports with revenue breakdown, top items, and trend comparison.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `store_id` | string | Yes | Store identifier |
| `report_date` | string | No | Report date (YYYY-MM-DD). Default: yesterday |
| `compare_with` | enum | No | "previous_day", "previous_week", "previous_month", "none". Default: "previous_day" |
| `group_by` | enum | No | "hour", "category", "payment_method", "item". Default: "hour" |
| `include_inventory_impact` | bool | No | Include stock consumption analysis. Default: true |
| `output_format` | enum | No | "json", "csv", "xlsx". Default: "json" |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `store_id` | string | Store identifier |
| `report_date` | string | Report date (YYYY-MM-DD) |
| `report_generated_at` | string | ISO 8601 timestamp |
| `summary` | DailySummary | Aggregated metrics |
| `hourly_breakdown` | array[HourlySales] | Hour-by-hour sales data |
| `category_breakdown` | array[CategorySales] | Sales by product category |
| `payment_breakdown` | array[PaymentSales] | Sales by payment method |
| `top_items` | array[TopItem] | Best-selling items |
| `comparison` | ComparisonData | Period-over-period comparison |
| `inventory_impact` | InventoryImpact | Stock consumption analysis |

**DailySummary Object:**

| Field | Type | Description |
|-------|------|-------------|
| `total_orders` | int | Total order count |
| `total_revenue_thb` | float | Gross revenue (THB) |
| `total_discounts_thb` | float | Discounts applied (THB) |
| `net_revenue_thb` | float | Revenue after discounts (THB) |
| `average_order_value_thb` | float | AOV (THB) |
| `total_items_sold` | int | Units sold |
| `unique_customers` | int | Distinct customers |
| `new_customers` | int | First-time customers |
| `refund_count` | int | Number of refunds |
| `refund_amount_thb` | float | Total refunded (THB) |
| `peak_hour` | string | Busiest hour (HH:00) |

**HourlySales Object:**

| Field | Type | Description |
|-------|------|-------------|
| `hour` | int | Hour of day (0–23) |
| `orders` | int | Order count in this hour |
| `revenue_thb` | float | Revenue in this hour (THB) |
| `items_sold` | int | Units sold |

**TopItem Object:**

| Field | Type | Description |
|-------|------|-------------|
| `rank` | int | Sales rank |
| `item_id` | string | SKU |
| `item_name` | string | Product name |
| `quantity_sold` | int | Units sold |
| `revenue_thb` | float | Revenue contribution (THB) |
| `revenue_share_pct` | float | Percentage of total revenue |
| `stock_remaining` | int | Current inventory level |

**ComparisonData Object:**

| Field | Type | Description |
|-------|------|-------------|
| `compare_period` | string | What we're comparing against |
| `revenue_change_pct` | float | Revenue change (%) |
| `order_change_pct` | float | Order count change (%) |
| `aov_change_pct` | float | AOV change (%) |
| `trend_direction` | enum | "up", "down", "stable" |

**InventoryImpact Object:**

| Field | Type | Description |
|-------|------|-------------|
| `items_consumed` | int | Unique products sold |
| `total_units_consumed` | int | Total units removed from inventory |
| `items_reaching_low_stock` | array[string] | SKUs that hit low-stock threshold |
| `recommended_reorders` | array[ReorderSuggestion] | Auto-generated reorder suggestions |

---

#### Tool: `health_reconcile_payments`

**Description**: Reconcile LINE POS payment records against bank deposits and LINE Pay settlement reports. Identify discrepancies.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `store_id` | string | Yes | Store identifier |
| `reconcile_date` | string | Yes | Date to reconcile (YYYY-MM-DD) |
| `pos_report` | object | No | POS payment data (if not auto-fetched) |
| `bank_statement` | object | No | Bank deposit data (if not auto-fetched) |
| `tolerance_thb` | float | No | Tolerance for matching (THB). Default: 0.50 |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `reconcile_date` | string | Reconciliation date |
| `status` | enum | "matched", "partial", "unmatched" |
| `pos_total_thb` | float | Total per POS (THB) |
| `bank_total_thb` | float | Total per bank (THB) |
| `variance_thb` | float | Difference (THB) |
| `matched_transactions` | int | Count of matched transactions |
| `unmatched_pos` | array[object] | POS transactions without bank match |
| `unmatched_bank` | array[object] | Bank deposits without POS match |
| `discrepancy_summary` | array[object] | Grouped discrepancy analysis |

---

### 4.5 Data Model

#### Inventory Schema (SQLite)

```sql
-- Core inventory table
CREATE TABLE inventory (
    id INTEGER PRIMARY KEY,
    store_id TEXT NOT NULL,
    item_id TEXT NOT NULL,
    item_name_th TEXT NOT NULL,
    item_name_en TEXT,
    category TEXT NOT NULL,
    unit TEXT NOT NULL,
    current_stock INTEGER NOT NULL DEFAULT 0,
    reorder_point INTEGER NOT NULL DEFAULT 10,
    reorder_quantity INTEGER NOT NULL DEFAULT 50,
    unit_cost_thb REAL,
    supplier_id TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(store_id, item_id)
);

-- Batch tracking for expiry
CREATE TABLE inventory_batches (
    id INTEGER PRIMARY KEY,
    store_id TEXT NOT NULL,
    item_id TEXT NOT NULL,
    batch_id TEXT NOT NULL,
    quantity INTEGER NOT NULL,
    expiry_date DATE,
    received_date DATE DEFAULT CURRENT_DATE,
    FOREIGN KEY (store_id, item_id) REFERENCES inventory(store_id, item_id)
);

-- Sales transaction log (from LINE POS webhook)
CREATE TABLE sales_transactions (
    id INTEGER PRIMARY KEY,
    store_id TEXT NOT NULL,
    order_id TEXT NOT NULL UNIQUE,
    line_user_id TEXT,
    order_timestamp TIMESTAMP NOT NULL,
    total_amount_thb REAL NOT NULL,
    payment_method TEXT,
    status TEXT NOT NULL,
    items_json TEXT NOT NULL,  -- JSON array of {item_id, qty, unit_price}
    synced_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Notification log
CREATE TABLE notification_log (
    id INTEGER PRIMARY KEY,
    store_id TEXT NOT NULL,
    notification_type TEXT NOT NULL,
    recipient_count INTEGER NOT NULL,
    message_th TEXT,
    status TEXT NOT NULL,
    line_api_response TEXT,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## 5. RAG-BRIDGE MCP Server

### 5.1 Domain Background

The RAG-BRIDGE server provides document understanding and question-answering across all business units. It bridges documents stored on the development machine (`lean@192.168.1.135`) with embedding inference on the dedicated inference machine (`ecolife-2`, 32GB RAM).

**Supported Document Sources:**
- Solar: Installation manuals, PEA grid codes, irradiance reports, warranty documents
- Health Franchise: Product datasheets, FDA certificates, SOP manuals, supplier contracts
- General: Financial reports, legal documents, internal policies

### 5.2 Embedding Strategy

#### 5.2.1 Chunking Configuration

| Parameter | Value | Rationale |
|-----------|-------|-----------|
| `chunk_size_tokens` | 512 | Fits ~380–400 English words; balances context vs. granularity |
| `chunk_overlap_tokens` | 50 (~10%) | Preserves context across chunk boundaries |
| `chunking_strategy` | "recursive" | Splits on semantic boundaries (paragraphs → sentences → words) |
| `max_chunk_size_chars` | 2000 | Hard limit for non-Latin scripts |
| `min_chunk_size_tokens` | 100 | Discard chunks too small to be meaningful |

#### 5.2.2 Embedding Pipeline

```
Document Upload (lean) → Parse → Chunk → Queue → Embed (ecolife-2) → Store (lean)
```

**Step-by-step:**
1. **Parse**: Extract text from PDF (pymupdf), spreadsheets (openpyxl), images (Ollama vision), text (direct)
2. **Chunk**: Recursive character text splitter with 512-token chunks, 50-token overlap
3. **Queue**: Write chunk to SQLite `embedding_queue` table with status `pending`
4. **Embed** (on `ecolife-2`): Ollama `nomic-embed-text` or `mxbai-embed-large` model
5. **Store**: Update SQLite `embeddings` table with vector and metadata

#### 5.2.3 Ollama Configuration on ecolife-2

| Model | Purpose | Dimensions | Context | VRAM Estimate |
|-------|---------|-----------|---------|---------------|
| `nomic-embed-text` | Default embeddings | 768 | 2048 | ~2GB |
| `mxbai-embed-large` | Higher quality embeddings | 1024 | 512 | ~4GB |
| `llava:13b` | Image OCR / vision | 5120 | 4096 | ~8GB |
| `qwen2.5:7b` | Reranking / query understanding | 4096 | 32768 | ~6GB |

**Ollama startup parameters:**
```bash
OLLAMA_HOST=0.0.0.0:11434 OLLAMA_NUM_PARALLEL=2 ollama serve
```

### 5.3 Vector Store Configuration

#### Option A: sqlite-vec (Primary)

```sql
-- Enable vector extension
.load vec0

-- Documents table
CREATE TABLE documents (
    id INTEGER PRIMARY KEY,
    source_path TEXT NOT NULL,
    source_name TEXT NOT NULL,
    doc_type TEXT NOT NULL,  -- 'pdf', 'xlsx', 'csv', 'image', 'txt'
    file_hash TEXT NOT NULL, -- SHA-256 for dedup
    total_chunks INTEGER NOT NULL DEFAULT 0,
    indexed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    metadata_json TEXT  -- {author, date_created, page_count, etc.}
);

-- Chunks with embeddings (sqlite-vec)
CREATE VIRTUAL TABLE chunk_embeddings USING vec0(
    chunk_id INTEGER PRIMARY KEY,
    document_id INTEGER,
    chunk_text TEXT,
    chunk_index INTEGER,
    page_number INTEGER,
    embedding FLOAT[768]  -- or 1024 for mxbai
);

-- Embedding queue for cross-machine sync
CREATE TABLE embedding_queue (
    id INTEGER PRIMARY KEY,
    document_id INTEGER NOT NULL,
    chunk_text TEXT NOT NULL,
    chunk_index INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',  -- pending, processing, completed, failed
    assigned_worker TEXT,  -- ecolife-2 instance ID
    attempts INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    processed_at TIMESTAMP,
    error_message TEXT
);

-- Query log for analytics
CREATE TABLE query_log (
    id INTEGER PRIMARY KEY,
    query_text TEXT NOT NULL,
    filters_json TEXT,
    top_k INTEGER,
    results_count INTEGER,
    duration_ms INTEGER,
    reranker_used BOOLEAN,
    queried_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

#### Option B: ChromaDB (Backup)

```python
import chromadb
client = chromadb.PersistentClient(path="/mnt/agents/data/chroma")
collection = client.get_or_create_collection(
    name="agent-toolkit-kb",
    metadata={"hnsw:space": "cosine"}
)
```

### 5.4 Retrieval Parameters

| Parameter | Default | Range | Description |
|-----------|---------|-------|-------------|
| `top_k` | 5 | 1–20 | Number of chunks to retrieve |
| `similarity_threshold` | 0.70 | 0.0–1.0 | Minimum cosine similarity for inclusion |
| `reranker` | "none" | "none", "cross_encoder", "llm" | Post-retrieval reranking strategy |
| `reranker_top_n` | 3 | 1–10 | Number of chunks after reranking |
| `metadata_filter` | null | object | Filter by source, date, doc_type |
| `hybrid_alpha` | 0.7 | 0.0–1.0 | Weight for semantic vs. keyword search (1.0 = pure semantic) |

### 5.5 Cross-Machine Flow

```
lean@192.168.1.135                    ecolife-2 (32GB)
┌─────────────────────────┐          ┌─────────────────────────┐
│  1. Document uploaded   │          │                         │
│  2. Parsed → chunks     │          │                         │
│  3. Chunks queued in    │─────────▶│  4. Worker polls queue  │
│     embedding_queue     │   HTTP   │     via HTTP API        │
│     (status=pending)    │          │                         │
│                         │          │  5. Ollama generates    │
│  7. Embeddings stored   │◀─────────│     embeddings          │
│     in sqlite-vec       │   HTTP   │     (nomic-embed-text)  │
│                         │          │                         │
│  8. Document marked     │          │  6. Embeddings returned │
│     as indexed          │          │     via HTTP callback   │
└─────────────────────────┘          └─────────────────────────┘
```

**Queue Polling API (on lean):**

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/queue/pop` | POST | Claim next pending chunk(s) |
| `/api/queue/complete` | POST | Submit completed embedding |
| `/api/queue/fail` | POST | Report processing failure |
| `/api/queue/stats` | GET | Queue depth and throughput stats |

### 5.6 MCP Tool Specifications

---

#### Tool: `rag_index_document`

**Description**: Add a document to the knowledge base. Handles parsing, chunking, embedding generation, and vector storage. Supports PDF, spreadsheets, images (with OCR), CSV, and text files.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `file_path` | string | Yes | Absolute path to document on lean |
| `doc_type` | enum | No | "pdf", "xlsx", "csv", "image", "txt", "auto". Default: "auto" (detect from extension) |
| `source_name` | string | No | Human-readable document name. Default: filename |
| `metadata` | object | No | Custom metadata key-value pairs |
| `chunk_size` | int | No | Override default chunk size (tokens). Default: 512 |
| `chunk_overlap` | int | No | Override default overlap (tokens). Default: 50 |
| `embedding_model` | enum | No | "nomic-embed-text", "mxbai-embed-large". Default: "nomic-embed-text" |
| `priority` | enum | No | "low", "normal", "high". Affects queue ordering. Default: "normal" |
| `wait_for_completion` | bool | No | Block until indexing complete. Default: false |
| `ocr_language` | string | No | Language hint for OCR ("en", "th", "auto"). Default: "auto" |

**Metadata Object (optional keys):**

| Key | Type | Description |
|-----|------|-------------|
| `author` | string | Document author or organization |
| `date_created` | string | Document creation date (YYYY-MM-DD) |
| `category` | string | Business category ("solar", "health", "general") |
| `tags` | array[string] | Searchable tags |
| `description` | string | Document description |
| `language` | string | Primary language ("th", "en", "mixed") |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `document_id` | string | Internal document UUID |
| `status` | enum | "queued", "indexing", "completed", "failed" |
| `file_path` | string | Original file path |
| `source_name` | string | Document name |
| `doc_type` | string | Detected document type |
| `total_chunks` | int | Number of chunks created |
| `chunks_queued` | int | Chunks sent to embedding queue |
| `chunks_embedded` | int | Chunks with embeddings completed |
| `embedding_model` | string | Model used for embeddings |
| `file_hash` | string | SHA-256 hash for deduplication |
| `estimated_completion` | string | ISO 8601 timestamp (if async) |
| `errors` | array[string] | Any processing errors |
| `indexed_at` | string | Completion timestamp (if completed) |

**Processing Flow:**
1. Validate file exists and is readable
2. Compute SHA-256 hash; skip if already indexed (unless `force_reindex`)
3. Detect document type (if `auto`)
4. Parse document:
   - PDF: `pymupdf` → extract text per page + layout
   - XLSX: `openpyxl` → extract per-sheet as markdown tables
   - CSV: Pandas → chunked by rows
   - Image: Ollama vision (`llava:13b`) → OCR text extraction
   - TXT: Direct read with encoding detection
5. Chunk text using recursive splitter (512 tokens, 50 overlap)
6. Queue chunks for embedding
7. If `wait_for_completion=true`, poll until all chunks embedded

---

#### Tool: `rag_query`

**Description**: Perform semantic search over the knowledge base with optional reranking, metadata filtering, and hybrid search.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `query` | string | Yes | Natural language query text |
| `top_k` | int | No | Number of results to retrieve. Default: 5 |
| `similarity_threshold` | float | No | Minimum similarity score (0.0–1.0). Default: 0.70 |
| `metadata_filter` | object | No | Filter results by metadata fields (see below) |
| `reranker` | enum | No | "none", "cross_encoder", "llm". Default: "none" |
| `reranker_top_n` | int | No | Final results after reranking. Default: 3 |
| `hybrid_alpha` | float | No | Semantic weight (1.0 = pure semantic). Default: 0.7 |
| `include_metadata` | bool | No | Include full metadata in response. Default: true |
| `include_chunk_text` | bool | No | Include full chunk text in response. Default: true |
| `embedding_model` | enum | No | Override embedding model for query. Default: system default |

**Metadata Filter Object:**

| Key | Type | Description |
|-----|------|-------------|
| `source_name` | string / array[string] | Match specific document name(s) |
| `doc_type` | string / array[string] | Filter by document type ("pdf", "xlsx", etc.) |
| `category` | string / array[string] | Filter by business category ("solar", "health", "general") |
| `date_created_after` | string | Include documents created after (YYYY-MM-DD) |
| `date_created_before` | string | Include documents created before (YYYY-MM-DD) |
| `tags` | array[string] | Match any of these tags |
| `language` | string | Filter by document language |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `query` | string | Original query |
| `results` | array[RetrievalResult] | Retrieved chunks |
| `total_chunks_searched` | int | Total chunks in filtered index |
| `retrieval_time_ms` | int | Query execution time (milliseconds) |
| `reranker_used` | string | Reranker that was applied |
| `embedding_model` | string | Embedding model used |

**RetrievalResult Object:**

| Field | Type | Description |
|-------|------|-------------|
| `rank` | int | Result rank (after any reranking) |
| `document_id` | string | Source document UUID |
| `source_name` | string | Document name |
| `doc_type` | string | Document type |
| `chunk_index` | int | Chunk sequence number in document |
| `page_number` | int | Source page (if applicable) |
| `chunk_text` | string | Chunk content (if include_chunk_text=true) |
| `similarity_score` | float | Cosine similarity (0.0–1.0) |
| `reranker_score` | float | Reranker score (if reranker used) |
| `metadata` | object | Full document metadata (if include_metadata=true) |

**Reranking Options:**

| Reranker | Model | Latency | Quality | Use Case |
|----------|-------|---------|---------|----------|
| `none` | N/A | <50ms | Baseline | Fast retrieval, many queries |
| `cross_encoder` | Local cross-encoder (small) | 200–500ms | Medium | Balanced quality/speed |
| `llm` | Ollama `qwen2.5:7b` | 1–3s | Highest | Complex queries, low QPS |

---

#### Tool: `rag_list_sources`

**Description**: List all indexed documents with their metadata, chunk counts, and indexing status.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `category` | string | No | Filter by category ("solar", "health", "general") |
| `doc_type` | string | No | Filter by document type |
| `status` | enum | No | "all", "completed", "indexing", "failed". Default: "all" |
| `limit` | int | No | Maximum results. Default: 50 |
| `offset` | int | No | Pagination offset. Default: 0 |
| `sort_by` | enum | No | "indexed_at", "source_name", "chunk_count". Default: "indexed_at" |
| `sort_order` | enum | No | "asc", "desc". Default: "desc" |

**Output Schema:**

| Output | Type | Description |
|--------|------|-------------|
| `total_documents` | int | Total matching documents |
| `documents` | array[DocumentInfo] | Document records |
| `pagination` | object | {limit, offset, has_more} |

**DocumentInfo Object:**

| Field | Type | Description |
|-------|------|-------------|
| `document_id` | string | Document UUID |
| `source_name` | string | Document name |
| `file_path` | string | Original file path |
| `doc_type` | string | Document type |
| `category` | string | Business category |
| `file_hash` | string | SHA-256 hash |
| `total_chunks` | int | Total chunks |
| `chunks_embedded` | int | Chunks with embeddings |
| `status` | enum | "completed", "indexing", "failed" |
| `file_size_bytes` | int | Original file size |
| `metadata` | object | Custom metadata |
| `indexed_at` | string | Indexing timestamp (ISO 8601) |
| `last_queried_at` | string | Last time retrieved (ISO 8601, from query_log) |

---

#### Tool: `rag_delete_source`

**Description**: Remove a document and all its chunks from the knowledge base. Requires explicit confirmation gate to prevent accidental deletion.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `document_id` | string | Conditional | Document UUID to delete |
| `source_name` | string | Conditional | Document name to delete (alternative to document_id) |
| `confirm_delete` | bool | Yes | Must be `true` to execute deletion. If `false`, returns preview only |
| `delete_embedding_queue` | bool | No | Also remove pending chunks from queue. Default: true |

**Output Schema (Preview — confirm_delete=false):**

| Output | Type | Description |
|--------|------|-------------|
| `preview_only` | bool | true |
| `document_id` | string | Target document UUID |
| `source_name` | string | Document name |
| `chunks_to_delete` | int | Number of chunks that would be removed |
| `embedding_queue_entries` | int | Pending queue entries that would be cleared |
| `last_queried_at` | string | When document was last retrieved |
| `warning` | string | "Set confirm_delete=true to execute" |

**Output Schema (Confirmed — confirm_delete=true):**

| Output | Type | Description |
|--------|------|-------------|
| `deleted` | bool | true if deletion succeeded |
| `document_id` | string | Deleted document UUID |
| `source_name` | string | Deleted document name |
| `chunks_deleted` | int | Chunks removed from vector store |
| `queue_entries_cleared` | int | Queue entries removed |
| `deleted_at` | string | Deletion timestamp (ISO 8601) |

---

#### Tool: `rag_query_with_context`

**Description**: Advanced query that returns structured context for LLM consumption, including source citations and confidence scoring. Designed for "answer this question using our documents" workflows.

**Input Schema:**

| Input | Type | Required | Description |
|-------|------|----------|-------------|
| `query` | string | Yes | Question to answer |
| `context_window_tokens` | int | No | Target context size for LLM. Default: 2048 |
| `response_format` | enum | No | "structured", "cited_text", "raw_chunks". Default: "cited_text" |
| `top_k` | int | No | Chunks to retrieve. Default: 5 |
| `metadata_filter` | object | No | Same filter as `rag_query` |
| `reranker` | enum | No | "none", "cross_encoder", "llm". Default: "cross_encoder" |
| `generate_answer` | bool | No | If true, call Ollama LLM to synthesize answer. Default: false |
| `llm_model` | string | No | Ollama model for answer generation. Default: "qwen2.5:7b" |

**Output Schema (response_format="cited_text"):**

| Output | Type | Description |
|--------|------|-------------|
| `query` | string | Original query |
| `context_prepared` | string | Concatenated, cited chunk text for LLM context window |
| `source_chunks` | array[CitedChunk] | Individual chunks with citations |
| `retrieval_metadata` | object | Query execution metadata |
| `generated_answer` | string | LLM-synthesized answer (if generate_answer=true) |
| `confidence_score` | float | Aggregate confidence (0.0–1.0) |

**CitedChunk Object:**

| Field | Type | Description |
|-------|------|-------------|
| `citation_id` | string | Short citation ID (e.g., "[1]", "[2]") |
| `source_name` | string | Document name |
| `page_number` | int | Page number |
| `chunk_text` | string | Chunk content |
| `similarity_score` | float | Retrieval similarity |
| `doc_type` | string | Document type |

---

### 5.7 Document Type Handling Matrix

| Document Type | Parser | Chunking Strategy | OCR Required | Notes |
|---------------|--------|-------------------|--------------|-------|
| PDF | pymupdf | Per-page + recursive | No (unless scanned) | Extract text + table structures |
| Scanned PDF | pymupdf → Ollama vision | Page image → text | Yes | Convert pages to images, OCR via llava |
| XLSX | openpyxl | Per-sheet as markdown tables | No | Preserve table structure |
| CSV | pandas | Row groups (100 rows/chunk) | No | Header repeated per chunk |
| Image (PNG/JPG) | Ollama vision | Single chunk per image | Yes | llava:13b extracts descriptive text |
| TXT | Direct | Recursive character | No | Encoding auto-detection |
| DOCX | python-docx | Paragraph-based | No | Preserve heading hierarchy |

### 5.8 Ollama Vision OCR Pipeline

For image documents and scanned PDFs, the OCR pipeline uses Ollama vision models on `ecolife-2`:

```python
async def ollama_vision_ocr(image_path: str, language: str = "auto") -> str:
    """
    Send image to Ollama vision model for text extraction.
    Runs on ecolife-2 via HTTP API.
    """
    prompt = f"""Extract all text visible in this image.
    Preserve the original layout and structure as much as possible.
    If the text is in Thai, preserve Thai characters exactly.
    Do not add any commentary — output only the extracted text.
    Language hint: {language}
    """

    response = await httpx.post(
        "http://ecolife-2:11434/api/generate",
        json={
            "model": "llava:13b",
            "prompt": prompt,
            "images": [base64_encoded_image],
            "stream": False
        },
        timeout=120.0
    )
    return response.json()["response"]
```

**OCR Performance Expectations:**

| Document Type | Model | Avg. Time | Accuracy |
|---------------|-------|-----------|----------|
| Printed English | llava:13b | 3–5s/page | ~95% |
| Printed Thai | llava:13b | 4–6s/page | ~85% |
| Handwritten | llava:13b | 5–8s/page | ~60% |
| Tables | llava:13b | 5–7s/page | ~80% (structure) |

---

## 6. Cross-Server Integration Patterns

### 6.1 Solar + RAG Integration

**Use case**: "What does the PEA grid code say about net metering rates for my 10kW system?"

**Flow:**
1. Kimi CLI calls `rag_query` with query about PEA net metering
2. RAG-BRIDGE retrieves relevant PEA documents
3. Kimi CLI calls `solar_calculate_irr` with the rate information
4. Combined answer includes both regulatory context and financial projection

### 6.2 Health-Ops + RAG Integration

**Use case**: "What are the storage requirements for this supplement according to the FDA datasheet?"

**Flow:**
1. Kimi CLI calls `rag_query` to find FDA storage guidelines
2. RAG-BRIDGE retrieves product datasheet
3. Kimi CLI calls `health_inventory_check` for current storage conditions
4. Combined answer shows both regulatory requirement and current compliance

### 6.3 Solar + Health-Ops Integration (Indirect)

Both businesses share:
- **RAG-BRIDGE**: Same document Q&A infrastructure
- **LINE notifications**: HEALTH-OPS can send solar performance alerts to customers
- **Financial reporting**: Similar IRR/cost analysis patterns (though different domains)

---

## 7. Infrastructure & Deployment

### 7.1 Network Configuration

| Host | IP / Hostname | Role | Specs |
|------|---------------|------|-------|
| `lean` | 192.168.1.135 | Dev + MCP servers + storage | Primary development machine |
| `ecolife-2` | 192.168.1.x (internal) | Inference (Ollama 24/7) | 32GB RAM, GPU optional |

### 7.2 systemd Service Definitions

```ini
# /etc/systemd/system/solar-calc.service
[Unit]
Description=SOLAR-CALC MCP Server
After=network.target

[Service]
Type=simple
User=lean
WorkingDirectory=/opt/agent-toolkit/solar-calc
ExecStart=/opt/agent-toolkit/.venv/bin/python -m solar_calc.server --port 3001
Restart=always
RestartSec=5
Environment=PYTHONPATH=/opt/agent-toolkit

[Install]
WantedBy=multi-user.target
```

```ini
# /etc/systemd/system/health-ops.service
[Unit]
Description=HEALTH-OPS MCP Server
After=network.target

[Service]
Type=simple
User=lean
WorkingDirectory=/opt/agent-toolkit/health-ops
ExecStart=/opt/agent-toolkit/.venv/bin/python -m health_ops.server --port 3002
Restart=always
RestartSec=5
Environment=PYTHONPATH=/opt/agent-toolkit
Environment=LINE_CHANNEL_SECRET={{secret}}
Environment=LINE_CHANNEL_TOKEN={{token}}

[Install]
WantedBy=multi-user.target
```

```ini
# /etc/systemd/system/rag-bridge.service
[Unit]
Description=RAG-BRIDGE MCP Server
After=network.target

[Service]
Type=simple
User=lean
WorkingDirectory=/opt/agent-toolkit/rag-bridge
ExecStart=/opt/agent-toolkit/.venv/bin/python -m rag_bridge.server --port 3003
Restart=always
RestartSec=5
Environment=PYTHONPATH=/opt/agent-toolkit
Environment=OLLAMA_HOST=http://ecolife-2:11434
Environment=VEC_DB_PATH=/opt/agent-toolkit/data/vectors.db

[Install]
WantedBy=multi-user.target
```

### 7.3 Directory Structure

```
/opt/agent-toolkit/
├── solar-calc/
│   ├── __init__.py
│   ├── server.py          # FastMCP app
│   ├── formulas.py        # Core calculations
│   ├── constants.py       # Thailand-specific defaults
│   └── tests/
├── health-ops/
│   ├── __init__.py
│   ├── server.py          # FastMCP app
│   ├── line_client.py     # LINE API client
│   ├── inventory.py       # Inventory logic
│   ├── models.py          # SQLAlchemy/Pydantic models
│   └── tests/
├── rag-bridge/
│   ├── __init__.py
│   ├── server.py          # FastMCP app
│   ├── parser.py          # Document parsers
│   ├── chunker.py         # Text chunking
│   ├── embedder.py        # Ollama embedding client
│   ├── vector_store.py    # sqlite-vec / Chroma wrapper
│   ├── queue_manager.py   # Cross-machine queue
│   └── tests/
├── shared/
│   ├── __init__.py
│   ├── models.py          # Common Pydantic models
│   ├── utils.py           # Shared utilities
│   └── config.py          # Configuration management
├── data/
│   ├── health_ops.db      # HEALTH-OPS SQLite
│   ├── vectors.db         # RAG vector store
│   ├── queue.db           # Embedding queue
│   └── documents/         # Uploaded documents
└── pyproject.toml         # Project dependencies
```

### 7.4 Health Check Endpoints

Each MCP server exposes a health endpoint:

| Endpoint | Response | Description |
|----------|----------|-------------|
| `GET /health` | `{"status": "ok", "version": "1.0.0", "uptime_seconds": 12345}` | Liveness probe |
| `GET /health/ready` | `{"ready": true, "dependencies": {"ollama": "ok", "database": "ok"}}` | Readiness probe |

---

## 8. Security & Governance

### 8.1 Authentication

| Layer | Mechanism | Notes |
|-------|-----------|-------|
| MCP Transport | None (local network) | Servers bind to 192.168.1.135 only |
| LINE API | HMAC-SHA256 webhook signature | Standard LINE security |
| Ollama API | No auth (internal network) | Firewall-restricted to 192.168.1.0/24 |
| Document Access | File system permissions | lean user only |

### 8.2 Data Handling

| Concern | Mitigation |
|---------|-----------|
| Customer PII (LINE IDs) | Stored only in SQLite, not in logs; hash for analytics |
| Financial data | Solar calculations transient — no persistent storage |
| Document content | Local only — no external cloud upload |
| LINE messages | Logged with content hash only, not full text |

### 8.3 Rate Limiting

| Resource | Limit | Action on Exceed |
|----------|-------|-----------------|
| LINE Push API | 500 msg/sec | Queue + exponential backoff |
| LINE Free Tier | 1000 msg/month | Log warning, suggest upgrade |
| Ollama API | 2 concurrent | Queue with fair scheduling |
| MCP tool calls | 100 req/min per client | HTTP 429 + Retry-After header |

---

## 9. Appendices

### Appendix A: MCP Protocol Compliance

All servers implement:
- **Tools capability**: All functions exposed as `tools/list` and `tools/call`
- **SSE transport**: Server-Sent Events for real-time updates
- **JSON-RPC 2.0**: Standard MCP message format
- **Progress reporting**: Long-running operations (indexing) report progress

### Appendix B: Error Codes

| Code | Meaning | HTTP Status |
|------|---------|-------------|
| `SOLAR_INVALID_INPUT` | Invalid solar calculation parameter | 400 |
| `SOLAR_NEGATIVE_VALUE` | Negative value where positive required | 400 |
| `SOLAR_IRR_NO_CONVERGENCE` | IRR calculation failed to converge | 422 |
| `HEALTH_LINE_API_ERROR` | LINE API returned error | 502 |
| `HEALTH_STORE_NOT_FOUND` | Store ID does not exist | 404 |
| `HEALTH_INVALID_SKU` | Product SKU not found | 404 |
| `RAG_FILE_NOT_FOUND` | Document file not found | 404 |
| `RAG_ALREADY_INDEXED` | Document with same hash exists | 409 |
| `RAG_EMBEDDING_FAILED` | Ollama embedding failed | 502 |
| `RAG_QUEUE_FULL` | Embedding queue at capacity | 503 |
| `RAG_DELETE_NOT_CONFIRMED` | Deletion requires confirm_delete=true | 400 |
| `INTERNAL_ERROR` | Unhandled server error | 500 |

### Appendix C: Thailand-Specific References

| Reference | Value | Source |
|-----------|-------|--------|
| PEA Residential Tariff | 4.32 THB/kWh (avg) | Provincial Electricity Authority, 2024 |
| PEA Feed-in Tariff | ~2.0 THB/kWh | Net Metering scheme (variable) |
| Grid Emission Factor | 0.5629 kg CO2/kWh | ONEP Thailand GHG Inventory 2023 |
| Bangkok Solar Resource | 4.8–5.2 kWh/m²/day | DNI annual average |
| VAT Rate | 7% | Thailand Revenue Department |
| Corporate Tax Rate | 20% | Revenue Department (SME: 0–20% progressive) |

### Appendix D: Version History

| Version | Date | Changes |
|---------|------|---------|
| 1.0.0 | 2025-01-20 | Initial specification |

---

*End of Document — DOMAIN_REQUIREMENTS.md v1.0.0*
