# agent-toolkit: Master Plan

> **The Definitive Project Document**  
> **Version:** 1.0.0 (post-review)  
> **Date:** 2025-01-20  
> **Status:** Implementation-ready (all CRITICAL issues resolved)  
> **Purpose:** Single reference for architecture, implementation, deployment, and daily operations.

---

## Table of Contents

1. [Project Vision](#1-project-vision)
2. [System Architecture Summary](#2-system-architecture-summary)
3. [MCP Server Catalog](#3-mcp-server-catalog)
4. [Domain Tools Quick Reference](#4-domain-tools-quick-reference)
5. [Safety Protocol Summary](#5-safety-protocol-summary)
6. [Integration Quick Start](#6-integration-quick-start)
7. [4-Week Roadmap](#7-4-week-roadmap)
8. [Agent Cognition Layer](#8-agent-cognition-layer)
9. [Getting Started](#9-getting-started)
10. [Appendix: Configuration Templates](#10-appendix-configuration-templates)

---

## 1. Project Vision

**We don't build another CLI. We build the arms and legs that make existing CLIs more capable.**

The agent-toolkit is a self-hosted MCP (Model Context Protocol) server hub that adds domain-specific tools, persistent cross-CLI memory, safe file operations, and local LLM inference to any MCP-compatible client. It runs on two Linux machines in a LAN — a development workstation and a dedicated inference server — and serves Kimi CLI, OpenCode CLI, and Goose CLI simultaneously with shared context.

**Core Principles:**
- **Safety First:** Every destructive operation requires dry-run preview + explicit confirmation
- **Local-First:** All LLM inference runs on self-hosted hardware; no cloud LLM dependency
- **Cross-CLI Memory:** Switch between Kimi, OpenCode, and Goose without losing context
- **Domain-Built-In:** Solar O&M calculations and Health Franchise operations are first-class citizens
- **Memory-Conscious:** Never exceed 32GB aggregate RAM; degraded mode activates automatically

---

## 2. System Architecture Summary

### 2.1 Two-Machine Topology

```
+------------------------+     LAN (SSH/HTTP)     +------------------------+
|                        | <-------------------> |                        |
|   Dev Machine          |                       |   Agent Machine        |
|   (MCP Hub Host)       |                       |   (Inference Server)   |
|                        |                       |                        |
|  - All MCP servers     |     HTTP:11434        |  - Ollama 24/7         |
|  - SQLite context DB   | <------------------   |  - Background jobs     |
|  - Config authority    |                       |  - Model weights       |
|  - rclone (GDrive)     |     SSH (commands)    |  - Job working dirs    |
|  - Git repository      | <------------------   |                        |
|                        |                       |                        |
+------------------------+                       +------------------------+
```

**Transport Rules:**
- Ollama communication: HTTP on port 11434 (LAN-local, never internet-exposed)
- Command execution: SSH key-based, non-interactive
- File sync: rclone over HTTPS to Google Drive
- All MCP servers: stdio transport (localhost only, no network ports)

### 2.2 High-Level Architecture Diagram

```
                    +-------------------------------+
                    |       Kimi / OpenCode /       |
                    |          Goose CLI            |
                    +---------------+---------------+
                                    |
                                    | stdio
                                    v
+-------------------+  +------------+-------------+  +-------------------+
|  cognition-layer  |  |      MCP Server Hub      |  |    Integrated     |
|  (patterns,       |  |                          |  |    Servers:       |
|   skills,         |  |  +------------------+    |  |  - github-mcp     |
|   diagnostics)    |  |  | file-ops-safe    |    |  |  - supabase-mcp   |
|                   |  |  +------------------+    |  |                   |
|  pattern_record   |  |  +------------------+    |  +-------------------+
|  pattern_suggest  |  |  | solar-calc       |    |
|  skill_list       |  |  +------------------+    |
|  performance_     |  |  +------------------+    |
|    review         |  |  | health-ops       |    |
|  self_assess      |  |  +------------------+    |
|  cognition_health |  |  +------------------+    |
|                   |  |  | memory-store     |    |
|  [ADDITIVE ONLY]  |  |  +------------------+    |
|  Delegates basic  |  |  +------------------+    |
|  memory to        |  |  | rag-bridge       |    |
|  memory-store     |  |  +------------------+    |
+-------------------+  |  +------------------+    |
                       |  | ollama-bridge    |    |
                       |  +------------------+    |
                       |  +------------------+    |
                       |  | rclone-bridge    |    |
                       |  +------------------+    |
                       +------------+-------------+
                                    |
                                    | HTTP (LAN)
                                    v
+-------------------+  +------------+-------------+
|   Ollama API      |  |   Shared Context DB      |
|   (ecolife-2)     |  |   (SQLite + sqlite-vec)  |
|                   |  |                          |
|  - gemma4 (9B)    |  |  - conversations         |
|  - nomic-embed    |  |  - tool_calls            |
|  - qwen2.5 (7B)   |  |  - memories              |
|                   |  |  - skills                |
|  Max 2 loaded     |  |  - patterns              |
|  simultaneously   |  |  - audit_log             |
+-------------------+  +--------------------------+
```

### 2.3 Technology Stack

| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
| **Language** | Python | 3.11+ | Primary implementation |
| **MCP Framework** | FastMCP | ^1.0 | MCP server library |
| **HTTP Server** | Uvicorn (via FastMCP) | ^0.25 | ASGI for MCP transport |
| **Data Validation** | Pydantic | ^2.0 | Request/response schemas |
| **Database** | SQLite | 3.40+ | Shared context + vectors |
| **Vector Search** | sqlite-vec | ^0.1 | ANN search in SQLite |
| **HTTP Client** | httpx | ^0.27 | Async HTTP for Ollama bridge |
| **Local LLM** | Ollama | 0.3+ | Model hosting + inference |
| **Process Mgmt** | systemd | any | Service orchestration |
| **Cloud Sync** | rclone | 1.65+ | Google Drive backup |
| **CLI Hub** | asyncio | stdlib | Async server management |

### 2.4 Directory Structure (XDG-Compliant)

```
# Source code (clone location, any user)
~/workspace/agent-toolkit/          (or wherever you clone)
├── src/
│   └── agent_toolkit/
│       ├── servers/               # MCP server implementations
│       │   ├── file_ops_safe/
│       │   ├── solar_calc/
│       │   ├── health_ops/
│       │   ├── memory_store/
│       │   ├── rag_bridge/
│       │   ├── ollama_bridge/
│       │   ├── rclone_bridge/
│       │   └── cognition_layer/   # NEW: pattern/skill/diagnostic tools
│       ├── shared/                # Common utilities
│       │   ├── config.py          # Config hierarchy
│       │   ├── safety.py          # Safety wrapper
│       │   ├── memory_budget.py   # RAM budget validator
│       │   └── audit.py           # Audit logger
│       └── config/
│           └── defaults.py        # Built-in defaults
│
# Runtime data (XDG-compliant, auto-created)
~/.config/agent-toolkit/           # Config files
│   ├── config.yaml                # Main configuration
│   ├── secrets.env                # API keys (NEVER commit)
│   └── environment.yaml           # Deployment variables
│
~/.local/share/agent-toolkit/      # Data files
│   ├── context.db                 # Shared context + audit
│   ├── memory.db                  # Memory store data
│   ├── health.db                  # Health operations data
│   ├── vectors.db                 # RAG vector store (sqlite-vec)
│   ├── vectors/                   # RAG document storage
│   └── logs/                      # Server logs (JSON Lines)
│
~/.local/state/agent-toolkit/      # State files
│   ├── jobs/                      # Background job queue
│   └── pid/                       # PID files
│
~/.cache/agent-toolkit/            # Cache files
│   └── embeddings/               # Embedding cache
```

### 2.5 Network Configuration

All machine-specific values are in `~/.config/agent-toolkit/environment.yaml`:

```yaml
# environment.yaml — DEPLOYMENT-SPECIFIC, .gitignored
dev_machine:
  host: 192.168.1.135       # Change to your dev machine IP
  user: lean                # Change to your dev username
  hostname: lean            # hostname on LAN

agent_machine:
  host: ecolife-2           # Change to your agent machine hostname
  user: ecolife             # Change to your agent username
  hostname: ecolife-2

lan_subnet: 192.168.1.0/24
ollama_port: 11434

# Convenience aliases (auto-generated, do not edit manually)
ollama_url: "http://${agent_machine.host}:${ollama_port}"
```

**Generated configs** (run `scripts/configure-environment.sh` after editing the above):
- `~/.config/kimi/mcp.json`
- `~/.config/opencode/mcp.json`
- `~/.config/goose/mcp-config.json`
- `~/.config/systemd/user/agent-toolkit-*.service`
- `~/bin/test-cross-machine.sh`
- `~/bin/verify-integration.sh`

---

## 3. MCP Server Catalog

### 3.1 Custom Servers (agent-toolkit)

| # | Server | Tools | Data Store | Role |
|---|--------|-------|------------|------|
| 1 | **file-ops-safe** | safe_read, safe_write, safe_delete, safe_search, safe_append | Git snapshots + SQLite log | Path-validated file operations |
| 2 | **solar-calc** | solar_irradiance, solar_position, pv_production, system_sizing, energy_yield, roi_analysis, lcoe_calc | SQLite results | Solar O&M calculations (TH-specific) |
| 3 | **health-ops** | health_trend, health_risk, health_correlate, health_sync_menu, health_notify_customers, health_reconcile_payments | SQLite inventory | Health franchise operations |
| 4 | **memory-store** | remember, recall, forget, search, update, list_categories | SQLite + embeddings | Cross-CLI persistent memory |
| 5 | **rag-bridge** | rag_index_document, rag_query, rag_list_sources, rag_delete_source, rag_query_with_context | SQLite + sqlite-vec | Document RAG pipeline |
| 6 | **ollama-bridge** | list_models, pull_model, generate, embed, get_model_info, switch_model | None (proxies to Ollama) | LLM inference gateway |
| 7 | **rclone-bridge** | gdrive_list, gdrive_download, gdrive_upload, gdrive_sync, gdrive_sync_to | None (proxies to rclone) | Google Drive sync |
| 8 | **cognition-layer** | pattern_record, pattern_suggest, skill_list, skill_learn_from_interaction, performance_review, self_assess, cognition_health | SQLite patterns/skills | Pattern recognition + skill learning |

### 3.2 Integrated Servers (Third-Party)

| # | Server | Source | Tools | Role |
|---|--------|--------|-------|------|
| 9 | **github-mcp** | `@modelcontextprotocol/server-github` (npx) | repo operations, issues, PRs, code search | GitHub integration |
| 10 | **supabase-mcp** | `@modelcontextprotocol/server-supabase` (npx) | SQL queries, table management | Supabase cloud DB (optional) |

### 3.3 Server Dependency Graph

```
file-ops-safe ──→ (no deps)
solar-calc ─────→ shared context
health-ops ─────→ shared context
memory-store ───→ ollama-bridge (for embeddings)
rag-bridge ─────→ ollama-bridge (for embeddings + generation)
                  memory-store (for context)
ollama-bridge ──→ Ollama API (external)
rclone-bridge ──→ rclone binary (external)
cognition-layer → memory-store (delegates storage)
                  ollama-bridge (for assessment)
                  shared context (for analytics)
github-mcp ─────→ GitHub API (external)
supabase-mcp ───→ Supabase API (external, optional)
```

**Key Design Rule:** cognition-layer does NOT duplicate memory-store tools. It delegates basic memory CRUD to memory-store via MCP protocol calls and focuses on pattern/skill/diagnostic tools only.

---

## 4. Domain Tools Quick Reference

### 4.1 Solar O&M (solar-calc)

**Thailand-Specific Constants:**
- Bangkok solar resource: 4.8-5.2 kWh/m²/day (DNI annual average)
- PEA residential tariff: 4.32 THB/kWh (2024)
- Grid emission factor: 0.5629 kg CO2/kWh
- VAT: 7%, Corporate tax: 20%
- Optimal tilt Bangkok: ~13° latitude-adjusted

**Key Formulas:**

```python
# Daily energy production (kWh)
daily_kwh = system_kw * peak_sun_hours * performance_ratio * (1 - degradation_yearly * age_years)

# Net present value (NPV)
npv = sum((energy_kwh_yr * tariff_rate * (1 + tariff_growth)**yr) / (1 + discount_rate)**yr 
          for yr in range(1, lifespan_yrs + 1)) - capex_thb

# Levelized cost of energy (LCOE)
lcoe_thb_per_kwh = (capex_thb + sum(opex_yr / (1 + discount_rate)**yr 
                                     for yr in range(1, lifespan_yrs + 1))) \
                   / sum(energy_kwh_yr * (1 - degradation_yearly)**yr 
                         for yr in range(1, lifespan_yrs + 1))

# Simple payback period (years)
payback_yrs = capex_thb / (annual_savings_thb + annual_revenue_thb)
```

**Tools:**

| Tool | Purpose | Key Inputs |
|------|---------|------------|
| `solar_irradiance` | Calculate solar resource at location | lat, lon, tilt, azimuth, date_range |
| `solar_position` | Sun position for shading analysis | lat, lon, datetime, timezone |
| `pv_production` | Daily/annual energy production | system_kw, peak_sun_hrs, module_type, age |
| `system_sizing` | Size system from energy needs | monthly_kwh, roof_area, budget_thb |
| `energy_yield` | Detailed hourly yield simulation | system_spec, weather_data, losses |
| `roi_analysis` | Financial ROI with Thai market | capex, opex_yr, tariff, degradation, lifespan |
| `lcoe_calc` | Levelized cost of energy | capex, opex_profile, production_profile, discount_rate |

### 4.2 Health Franchise (health-ops)

**Tools:**

| Tool | Purpose | Safety Notes |
|------|---------|-------------|
| `health_trend` | Metric trends over time | Read-only |
| `health_risk` | Risk scoring from vitals | Read-only |
| `health_correlate` | Find metric correlations | Read-only |
| `health_sync_menu` | Sync menu items from Google Sheet | `dry_run: bool = True`, `confirm: bool = False` |
| `health_notify_customers` | Send LINE notifications | `confirm: bool = False` (required for broadcast/promotion) |
| `health_reconcile_payments` | Reconcile LINE POS vs bank | Read-only analysis |

**Data Model:**
- `inventory` — core stock table (store_id, item_id, current_stock, reorder_point)
- `inventory_batches` — batch tracking with expiry dates
- `sales_transactions` — LINE POS order log
- `notification_log` — message delivery tracking

### 4.3 RAG Pipeline (rag-bridge)

**Chunking:** 512 tokens, 50-token overlap, recursive splitting

| Tool | Purpose | Key Inputs |
|------|---------|------------|
| `rag_index_document` | Add doc to knowledge base | file_path, doc_type, metadata, chunk_size, priority |
| `rag_query` | Semantic search | query, top_k, similarity_threshold, metadata_filter, reranker |
| `rag_list_sources` | List indexed documents | category, doc_type, status, limit |
| `rag_delete_source` | Remove document + chunks | document_id, confirm_delete: bool = False |
| `rag_query_with_context` | Search + structured context for LLM | query, context_window_tokens, response_format |

**Cross-Machine Flow:**
1. Document uploaded on dev machine → parsed → chunked
2. Chunks queued in SQLite `embedding_queue` table (status: `pending`)
3. Worker on agent machine polls queue via HTTP API
4. Ollama (`nomic-embed-text`) generates embeddings on agent machine
5. Embeddings returned via HTTP callback → stored in sqlite-vec on dev machine

---

## 5. Safety Protocol Summary

### 5.1 The Safety Decision Tree

Every write tool follows this gate sequence:

```
Tool called with args
        |
        v
  +-------------+
  | dry_run = ? |
  +------+------+
    True |   | False
         v   v
    +---------+  +-------------+
    | Preview |  | confirm = ? |
    | results |  +------+------+
    | shown   |    True |   | False
    +---------+         v   v
                  +---------+  +--------+
                  | Execute |  | Abort  |
                  | with log|  | safely |
                  +---------+  +--------+
```

### 5.2 Confirmation Gate Matrix

| Tool Category | dry_run Default | confirm Required | Approval Level | Notes |
|--------------|-----------------|------------------|----------------|-------|
| FILE_READ | N/A | No | AUTO | Read-only |
| FILE_WRITE | True | Yes | USER | Preview diff, git stash auto-created |
| FILE_DELETE | True | Yes | USER+GIT | Preview + git checkpoint required |
| DIRECTORY_CREATE | True | Yes | USER | Preview created directories |
| GIT_PUSH | True | Yes | USER | Preview commits to push |
| RCLONE_SYNC_TO | True | Yes | USER | Preview what would be uploaded |
| RCLONE_SYNC_FROM | True | Yes | USER | **Collision detection:** if local target exists, escalate to USER+GIT |
| MODEL_SWITCH | True | Yes | USER | Preview memory impact, verify budget |
| MEMORY_STORE | False | No | AUTO | Safe by design (append-only log) |
| MEMORY_DELETE | True | Yes | USER | Preview what memories would be deleted |
| RAG_DELETE | True | Yes | USER | Preview chunks to remove |
| HEALTH_SYNC | True | Yes | USER | Preview menu changes |
| HEALTH_NOTIFY | N/A | Yes (broadcast) | USER | Single messages: AUTO; Broadcast: USER |

### 5.3 Memory Budget Safety

**The 32GB Rule:** At startup, the hub validates:

```python
# memory_budget.py — runs at hub startup
def validate_memory_budget(servers: list, ollama_config: dict) -> bool:
    """
    Verify total configured memory does not exceed system capacity.
    Called before accepting any CLI connections.
    Raises MemoryBudgetError if budget is exceeded.
    """
    SYSTEM_RAM_MB = 32 * 1024          # 32768 MB
    SYSTEM_HEADROOM_MB = 8 * 1024      # 8192 MB for OS + buffer
    MAX_MCP_MEMORY_MB = 8 * 1024       # 8192 MB total for all MCP servers
    MAX_OLLAMA_MODEL_MB = 14 * 1024    # 14336 MB max single model

    total_mcp = sum(s.max_memory_mb for s in servers)
    max_ollama = ollama_config.get("max_model_mb", MAX_OLLAMA_MODEL_MB)
    required = total_mcp + max_ollama + SYSTEM_HEADROOM_MB

    if required > SYSTEM_RAM_MB:
        raise MemoryBudgetError(
            f"Memory budget exceeded: config requires {required}MB "
            f"(MCP: {total_mcp}MB + Ollama: {max_ollama}MB + headroom: "
            f"{SYSTEM_HEADROOM_MB}MB) but system has {SYSTEM_RAM_MB}MB. "
            f"Reduce MAX_MEMORY_MB per server or OLLAMA_MAX_MODEL_MB."
        )
    return True
```

**Model Memory Limits on 32GB:**

| Model | Params | VRAM | Allowed? | Notes |
|-------|--------|------|----------|-------|
| gemma4 | 9B | ~8GB | YES | Primary model (recommended) |
| gemma4 | 27B | ~20GB | **NO** | Exceeds single-model budget |
| nomic-embed-text | ~1B | ~1GB | YES | Always loaded |
| qwen2.5 | 7B | ~4GB | YES | Secondary (code/QA) |
| mistral | 7B | ~4GB | YES | Fallback |
| llava | 13B | ~8GB | CONDITIONAL | Only when no other LLM loaded |
| mxbai-embed-large | ~1B | ~2GB | YES | Alternative embedder |

**Rule: Maximum 2 Ollama models loaded simultaneously.** When switching models, the old model is unloaded before the new one loads (verified by `ollama-bridge.switch_model`).

### 5.4 Degraded Mode (Memory Low)

When system memory drops below threshold (configurable, default 90% = ~29GB used):

```python
# Automatic actions (no human intervention required)
if memory_usage_percent > 90:
    # Priority order for shutdown
    actions = [
        "1. Stop non-essential MCP servers (rclone-bridge, solar-calc)",
        "2. Reduce MCP server concurrency limits to 1",
        "3. Pause background embedding jobs",
        "4. If still critical: unload secondary LLM (qwen2.5), keep primary",
        "5. If still critical: unload embedding model (RAG unavailable)",
    ]
    for action in actions:
        apply(action)
        if memory_usage_percent < 85:
            break  # Sufficient relief achieved
```

**Recovery:** When memory drops below 75% for 5 minutes, non-essential servers auto-restart.

### 5.5 Emergency Stop (Kill Switch)

Four methods to immediately halt all operations:

```bash
# Method 1: Via MCP tool (from any CLI)
# Call: emergency_stop(reason="...", confirm=True)

# Method 2: Sentinel file (any user on the server)
echo "EMERGENCY_STOP|manual-trigger|$(date -Iseconds)" > /tmp/agent-toolkit-emergency-stop

# Method 3: systemd stop
systemctl --user stop agent-toolkit-hub

# Method 4: Nuclear option
pkill -f "mcp.server"
```

**Post-Emergency Recovery:**
1. Check `cat /tmp/agent-toolkit-emergency-stop` for reason
2. Review logs: `journalctl --user -u agent-toolkit-hub --since "10 min ago"`
3. Check memory/disk: `free -h && df -h`
4. Review audit: `sqlite3 ~/.local/share/agent-toolkit/context.db "SELECT * FROM audit_log ORDER BY timestamp DESC LIMIT 20;"`
5. Fix root cause
6. Clear sentinel: `rm -f /tmp/agent-toolkit-emergency-stop`
7. Restart hub: `systemctl --user restart agent-toolkit-hub`

### 5.6 Audit Trail

Every tool call is recorded in `~/.local/share/agent-toolkit/context.db`:

```sql
-- Key fields tracked:
-- tool, category, parameters (JSON), caller, timestamp, execution_ms,
-- dry_run (0/1), confirmed (0/1), approval_level, result/error,
-- stash_hash, dangerous (0/1), blast_radius, server_version, host
```

**Retention:** Dev: 14 days / 1GB; Production: 90 days / 10GB; Archive: 2 years.

---

## 6. Integration Quick Start

### 6.1 Step 1: Set Environment Variables

Add to `~/.bashrc` on the **dev machine**:

```bash
# agent-toolkit environment
export AGENT_TOOLKIT_HOME="$HOME/.config/agent-toolkit"
export AGENT_TOOLKIT_DATA="$HOME/.local/share/agent-toolkit"
export AGENT_TOOLKIT_USER="$(whoami)"
export AGENT_TOOLKIT_DEV_HOST="192.168.1.135"     # CHANGE ME
export AGENT_MACHINE="ecolife-2"                   # CHANGE ME
export OLLAMA_HOST="http://${AGENT_MACHINE}:11434"

# API keys (NEVER commit this file)
export GITHUB_TOKEN="ghp_xxxxxxxxxxxxxxxx"         # CHANGE ME
export SUPABASE_URL=""                              # Optional
export SUPABASE_KEY=""                              # Optional
```

Reload: `source ~/.bashrc`

### 6.2 Step 2: Create Directories

```bash
# Data directories
mkdir -p "$AGENT_TOOLKIT_DATA"/{logs,vectors,documents}
mkdir -p "$AGENT_TOOLKIT_HOME"

# Config directories for CLIs
mkdir -p ~/.config/{kimi,opencode,goose}
```

### 6.3 Step 3: Configure MCP Servers

Generate mcp.json configs from templates (substitutes env vars):

```bash
# Copy and substitute environment variables into mcp.json configs
envsubst < templates/mcp-kimi.json > ~/.config/kimi/mcp.json
envsubst < templates/mcp-opencode.json > ~/.config/opencode/mcp.json
envsubst < templates/mcp-goose.json > ~/.config/goose/mcp-config.json

# Set permissions (configs may contain secrets)
chmod 600 ~/.config/kimi/mcp.json \
           ~/.config/opencode/mcp.json \
           ~/.config/goose/mcp-config.json
```

> **Note:** `envsubst` is from the `gettext` package. Install with `sudo apt-get install gettext` if needed.

### 6.4 Step 4: Kimi MCP Config (Reference)

```json
{
  "mcpServers": {
    "file-ops-safe": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.file_ops_safe"],
      "env": {
        "ALLOWED_DIRS": "${AGENT_TOOLKIT_ALLOWED_DIRS:-${HOME}/projects,${HOME}/documents}",
        "REQUIRE_CONFIRM": "true",
        "MAX_FILE_SIZE_MB": "50"
      },
      "timeout": 30,
      "description": "Safe file operations with path validation and confirmation gates"
    },
    "solar-calc": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.solar_calc"],
      "env": {},
      "timeout": 10,
      "description": "Solar energy calculations for Thailand"
    },
    "health-ops": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.health_ops"],
      "env": {
        "DB_PATH": "${AGENT_TOOLKIT_DATA}/health.db"
      },
      "timeout": 10,
      "description": "Health franchise operations"
    },
    "rag-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rag_bridge"],
      "env": {
        "OLLAMA_HOST": "${OLLAMA_HOST}",
        "EMBED_MODEL": "nomic-embed-text",
        "CHUNK_SIZE": "512",
        "CHUNK_OVERLAP": "64",
        "VECTOR_STORE_PATH": "${AGENT_TOOLKIT_DATA}/vectors"
      },
      "timeout": 120,
      "description": "Document RAG pipeline"
    },
    "memory-store": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.memory_store"],
      "env": {
        "DB_PATH": "${AGENT_TOOLKIT_DATA}/memory.db",
        "MAX_CONTEXT_MESSAGES": "50"
      },
      "timeout": 10,
      "description": "Cross-CLI persistent memory"
    },
    "ollama-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.ollama_bridge"],
      "env": {
        "OLLAMA_HOST": "${OLLAMA_HOST}",
        "DEFAULT_MODEL": "gemma4",
        "EMBED_MODEL": "nomic-embed-text",
        "MAX_CONTEXT_LENGTH": "8192",
        "REQUEST_TIMEOUT": "300"
      },
      "timeout": 300,
      "description": "LLM inference gateway"
    },
    "rclone-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rclone_bridge"],
      "env": {
        "RCLONE_REMOTE": "lean",
        "RCLONE_CONFIG": "${HOME}/.config/rclone/rclone.conf",
        "RCLONE_BACKUP_RETENTION": "10",
        "RCLONE_DRY_RUN_REQUIRED": "true",
        "RCLONE_DEFAULT_BACKUP_ROOT": "backups",
        "RCLONE_TRANSFERS": "4",
        "RCLONE_CHECKERS": "8",
        "RCLONE_FAST_LIST": "true"
      },
      "timeout": 300,
      "description": "Google Drive sync with dry-run safety"
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}"
      },
      "timeout": 60,
      "description": "GitHub operations"
    }
  }
}
```

> **Note:** For OpenCode, add `supabase` server. For Goose, use same config with `mcp-config.json` filename. See Appendix for full configs.

### 6.5 Step 5: Start the Hub

```bash
# Option A: systemd user service (recommended)
systemctl --user enable agent-toolkit-hub
systemctl --user start agent-toolkit-hub
systemctl --user status agent-toolkit-hub

# Option B: Direct (for development)
python -m agent_toolkit.hub --config "$AGENT_TOOLKIT_HOME/config.yaml"

# View logs
journalctl --user -u agent-toolkit-hub -f
tail -f "$AGENT_TOOLKIT_DATA/logs/hub.log"
```

### 6.6 Step 6: Verify Integration

```bash
# Run the verification script (uses env vars, copy-paste ready)
~/bin/verify-integration.sh

# Or test individual components:
curl -s "$OLLAMA_HOST/api/tags" | jq '.models[].name'
python -m agent_toolkit.servers.file_ops_safe --health
rclone lsf lean:
```

---

## 7. 4-Week Roadmap

### 7.1 Week 1: Foundation + Safety (ALL P0 tasks)

| Day | Task | Acceptance Criteria | Server |
|-----|------|---------------------|--------|
| 1 | Project scaffold (`uv init` + pyproject.toml + src layout) | `pytest` runs (empty), `ruff check` passes | Hub |
| 1 | XDG directory layout + config hierarchy | All paths use `$AGENT_TOOLKIT_HOME`, tests pass | Hub |
| 1 | `environment.yaml` template + `configure-environment.sh` | Running script generates all mcp.json configs with correct values | Hub |
| 2 | Safety wrapper `@dry_run` + `@confirm_gate` decorators | Decorators enforce dry_run default=True on all write tools, unit tests pass | Shared |
| 2 | Memory budget validator | Startup refuses to start if RAM budget exceeded, tests for all scenarios | Shared |
| 3 | Audit logger (`AuditLogger` class) | SQLite schema created, every tool call logged with all fields, retention policy tested | Shared |
| 3 | `file-ops-safe` server scaffold | Server starts, registers tools, passes MCP stdio handshake | file-ops-safe |
| 4 | `file-ops-safe` tool implementations | All 4 tools (read/write/delete/search) pass integration tests with safety gates | file-ops-safe |
| 5 | `solar-calc` server + formulas | 7 tools implemented, Thailand constants verified, 80%+ test coverage | solar-calc |
| 6 | `ollama-bridge` server | list_models, generate, embed, switch_model all working, model-switch unloads-before-load | ollama-bridge |
| 7 | systemd unit template + `install-services.sh` | All custom servers start as user services, auto-restart on crash | Hub |

**Week 1 Safety Gate:** All P0 CRITICAL issues from review must be resolved before Week 2 starts.

### 7.2 Week 2: Memory + RAG + Health

| Day | Task | Acceptance Criteria | Server |
|-----|------|---------------------|--------|
| 8 | `memory-store` server + SQLite schema | remember/recall/forget/search working, cross-CLI persistence tested | memory-store |
| 9 | Embedding pipeline + `sqlite-vec` integration | Chunks embed and retrieve, similarity search works end-to-end | memory-store, rag-bridge |
| 10 | `rag-bridge` document indexing | PDF/TXT/CSV parsing, chunking, queue workflow tested | rag-bridge |
| 11 | `rag-bridge` query + reranking | Semantic search + hybrid search, metadata filters working | rag-bridge |
| 12 | `health-ops` server + inventory tools | CRUD operations, expiry tracking, reorder alerts | health-ops |
| 13 | `health-ops` sync + LINE integration | Menu sync from Google Sheets, LINE notification tool | health-ops |
| 14 | Integration tests for all Week 1-2 servers | E2E scenarios pass: solar ROI calc, memory recall, RAG query, health sync | All |

### 7.3 Week 3: Integration + Persona System

| Day | Task | Acceptance Criteria | Server |
|-----|------|---------------------|--------|
| 15 | rclone integration (rclone-bridge) | Dry-run sync, backup/restore, Google Drive listing | rclone-bridge |
| 16 | GitHub MCP + Supabase MCP integration | Third-party servers connected, token auth working | github, supabase |
| 17 | Persona/role system + tool permissions | Admin/Analyst roles restrict tool access, tests pass | Hub |
| 18 | Cross-CLI memory end-to-end | Kimi stores → OpenCode recalls → Goose updates, all persisted | memory-store |
| 19 | Background job system scaffold | Job queue, worker polling, status tracking on agent machine | Hub |
| 20 | Cross-machine SSH automation | `run_on_ecolife2()` executes remote commands, status files polled | Hub |
| 21 | Performance benchmarks + baseline | All servers benchmarked, baseline JSON committed | All |

### 7.4 Week 4: Cognition + Polish + Deployment

| Day | Task | Acceptance Criteria | Server |
|-----|------|---------------------|--------|
| 22 | `cognition-layer` server scaffold | Server starts, registers tools, MCP handshake passes | cognition-layer |
| 23 | Pattern recognition (Phase 2) | `pattern_record` + `pattern_suggest` working, SQL-based frequency analysis | cognition-layer |
| 24 | Error learning tables + skill tools | `error_lessons` schema, `skill_list`, `skill_learn_from_interaction` | cognition-layer |
| 25 | Self-diagnostics + health dashboard | `cognition_health`, `performance_review`, text dashboard generated | cognition-layer |
| 26 | Memory monitoring + degraded mode | Monitors RAM, triggers degraded mode, auto-recovery tested | Hub |
| 27 | JSON logging + log rotation | All servers emit JSON Lines, daily rotation, 14-day retention | All |
| 28 | Disaster recovery runbook + final E2E | DR procedures tested (restore from backup, full restart), all 5 E2E scenarios pass | All |

**Week 4 Deliverable:** All 8 custom MCP servers running, cognition layer integrated, monitoring active, DR documented.

### 7.5 Post-Month: Cognition Evolution

| Phase | Timeline | Scope |
|-------|----------|-------|
| Phase 3: Skill Evolution | Month 2 | Skill auto-discovery, workflow templates, cross-domain transfer |
| Phase 4: Self-Diagnostics | Month 2 | Full dashboard, suggestion engine, error trending |
| Phase 5: Autonomous Improvement | Month 3+ | Self-assessment, auto-skill refinement, proactive suggestions |

> **Phase 5 Gate:** Begins only after Phases 1-4 are production-stable for 30 days. Requires explicit scope approval.

---

## 8. Agent Cognition Layer

### 8.1 Philosophy

The cognition layer makes the agent **learn from experience**. It observes tool usage patterns, extracts reusable workflows as skills, records error lessons, and provides performance diagnostics. It is an **additive** MCP server — it enhances capability without changing existing tools.

**Design Rule:** cognition-layer delegates basic memory CRUD to `memory-store`. It focuses exclusively on:
- Pattern recognition and recording
- Skill discovery and evolution
- Performance analysis and self-diagnostics
- Knowledge accumulation with versioning

### 8.2 Key Concepts

| Concept | Definition | Example |
|---------|------------|---------|
| **Pattern** | A frequent tool sequence | `[file-ops-safe.safe_read → solar-calc.roi_analysis → file-ops-safe.safe_write]` |
| **Skill** | A reusable workflow derived from patterns | "Solar ROI Report" = read specs → calculate ROI → generate markdown → save |
| **Error Lesson** | Institutional knowledge from failures | "solar-calc.roi_analysis fails when capex=0" |
| **Reflection** | Post-task cognitive analysis | "What worked: using cached irradiance. What failed: missing tariff input." |
| **Suggestion** | Auto-generated improvement ideas | "You often read then calc then write — create a workflow?" |

### 8.3 Cognition Tools

| Tool | Purpose | Delegates To |
|------|---------|-------------|
| `pattern_record` | Save a tool sequence as reusable pattern | cognition-layer DB |
| `pattern_suggest` | Find patterns matching current task | cognition-layer DB |
| `skill_list` | List all learned skills | cognition-layer DB |
| `skill_learn_from_interaction` | Extract skill from recent session | memory-store (for trace) → cognition-layer (for skill gen) |
| `performance_review` | Analyze recent tool usage | cognition-layer DB |
| `self_assess` | Rate output quality vs goal | ollama-bridge (for assessment) |
| `cognition_health` | System health dashboard | cognition-layer DB |

### 8.4 Implementation Phases

**Phase 1: Basic Memory** (Week 2 — Foundation)
- SQLite tables: conversations, tool_calls, memories
- memory-store server: remember/recall/forget/search
- Session tracking across CLI clients

**Phase 2: Pattern Recognition** (Week 4 — ROADMAP)
- Tables: recent_patterns, learned_patterns, error_lessons
- Tools: pattern_record, pattern_suggest
- Background job: pattern extraction on agent machine

**Phase 3: Skill Evolution** (Month 2)
- Tables: skills, parameter_performance
- Tools: skill_list, skill_learn_from_interaction
- Cross-domain pattern transfer

**Phase 4: Self-Diagnostics** (Month 2)
- Tables: tool_usage_stats, suggestions
- Tools: performance_review, cognition_health
- Text-based health dashboard

**Phase 5: Autonomous Improvement** (Month 3+ — Gated)
- Self-assessment of output quality
- Automatic skill refinement from feedback
- Proactive pattern suggestions
- Human correction integration

### 8.5 Schema Extension

The cognition layer extends the core schema with 12 tables (see AGENT_COGNITION_LAYER.md Section 10.1 for full SQL). Key tables:

```sql
-- Pattern recognition
CREATE TABLE learned_patterns (
    id INTEGER PRIMARY KEY,
    pattern_name TEXT UNIQUE,
    tool_sequence TEXT,           -- JSON array
    success_rate REAL DEFAULT 1.0,
    confidence_score REAL DEFAULT 0.5,
    description_embedding BLOB    -- for semantic matching
);

-- Skills
CREATE TABLE skills (
    id INTEGER PRIMARY KEY,
    name TEXT UNIQUE,
    domain TEXT DEFAULT 'general',
    workflow TEXT,                -- JSON array of steps
    confidence REAL DEFAULT 0.5,
    description_embedding BLOB
);

-- Performance analytics
CREATE TABLE tool_usage_stats (
    tool_name TEXT,
    server_name TEXT,
    period_start DATETIME,
    call_count INTEGER,
    error_count INTEGER,
    p95_duration_ms INTEGER,
    PRIMARY KEY (tool_name, period_start)
);
```

---

## 9. Getting Started

### 9.1 Prerequisites

| Requirement | Minimum | Recommended |
|------------|---------|-------------|
| Dev machine | Any Linux/macOS with Python 3.11+ | Same LAN as agent machine |
| Agent machine | 32GB RAM, Linux | GPU (CUDA) for faster inference |
| Network | Both on same LAN | SSH key auth configured |
| Software | Python 3.11, git, rclone | tmux, mosh, uv/poetry |
| Ollama | 0.3+ on agent machine | With gemma4:9b pulled |

### 9.2 5-Minute Deployment (Day 0 Checklist)

```bash
# === PRE-FLIGHT ===
# [ ] 1. Both machines on same LAN
# [ ] 2. SSH key auth: ssh ecolife-2 'echo OK' succeeds without password
# [ ] 3. Ollama running on agent: curl http://ecolife-2:11434/api/tags returns models
# [ ] 4. rclone configured: rclone listremotes shows "lean:"
# [ ] 5. GITHUB_TOKEN set in ~/.bashrc

# === STEP 1: Clone (on dev machine) ===
cd ~/workspace  # or your preferred location
git clone <repo-url> agent-toolkit
cd agent-toolkit

# === STEP 2: Install ===
uv venv .venv
source .venv/bin/activate
uv pip install -e ".[dev]"

# === STEP 3: Configure environment ===
cp templates/environment.yaml.example ~/.config/agent-toolkit/environment.yaml
# Edit: set your dev_machine.host, agent_machine.host, usernames
${EDITOR} ~/.config/agent-toolkit/environment.yaml

# === STEP 4: Generate configs ===
./scripts/configure-environment.sh
# This creates: mcp.json files, systemd units, test scripts

# === STEP 5: Install services ===
./scripts/install-services.sh
systemctl --user daemon-reload
systemctl --user start agent-toolkit-hub

# === STEP 6: Verify ===
~/bin/verify-integration.sh
# All checks should pass

# === STEP 7: Test a tool ===
# In Kimi/OpenCode/Goose:
# "Calculate solar irradiance for Bangkok, tilt 13 degrees"

# === DONE ===
```

### 9.3 Day 0 Checklist (Tick When Complete)

- [ ] `environment.yaml` created with correct machine names/IPs
- [ ] `configure-environment.sh` ran successfully (no errors)
- [ ] All mcp.json configs generated and valid JSON
- [ ] `agent-toolkit-hub` systemd service starts without errors
- [ ] `systemctl --user status agent-toolkit-hub` shows "active (running)"
- [ ] `~/bin/verify-integration.sh` passes all checks
- [ ] Ollama responds: `curl $OLLAMA_HOST/api/tags` returns model list
- [ ] First tool call succeeds (e.g., solar irradiance calculation)
- [ ] Memory persistence works: store in Kimi, recall in Goose
- [ ] Safety gates work: `safe_delete` without `confirm=True` is rejected
- [ ] rclone dry-run enforced: `gdrive_sync` runs in preview mode by default
- [ ] Backup configured: `rclone lsf lean:backups/` shows accessible
- [ ] Logs rotating: `ls ~/.local/share/agent-toolkit/logs/` shows JSON log files

### 9.4 Common First-Time Issues

| Symptom | Cause | Fix |
|---------|-------|-----|
| `Connection refused` to Ollama | Ollama not bound to LAN interface | On agent: `OLLAMA_HOST=0.0.0.0:11434 ollama serve` |
| `KeyError: 'OLLAMA_HOST'` | Env var not loaded | Run `source ~/.bashrc`, check with `echo $OLLAMA_HOST` |
| `No module named 'agent_toolkit'` | Not installed in venv | Run `uv pip install -e .` from repo root |
| `Permission denied` on DB | Directory not created | `mkdir -p ~/.local/share/agent-toolkit` |
| MCP tools not visible in CLI | Config file wrong location | Verify path: `ls ~/.config/kimi/mcp.json` |
| `MemoryBudgetError` at startup | Configured RAM exceeds 32GB | Reduce MAX_MEMORY_MB in server configs |

---

## 10. Appendix: Configuration Templates

### 10.1 Environment Configuration Template

```yaml
# ~/.config/agent-toolkit/environment.yaml
# DEPLOYMENT-SPECIFIC — .gitignored, never committed

dev_machine:
  host: 192.168.1.135
  user: lean
  hostname: lean

agent_machine:
  host: ecolife-2
  user: ecolife
  hostname: ecolife-2

lan_subnet: 192.168.1.0/24
ollama_port: 11434

# Paths (auto-derived from XDG, override if needed)
data_dir: "${HOME}/.local/share/agent-toolkit"
config_dir: "${HOME}/.config/agent-toolkit"
cache_dir: "${HOME}/.cache/agent-toolkit"
state_dir: "${HOME}/.local/state/agent-toolkit"

# Resource limits (32GB system)
max_mcp_memory_mb: 8192
ollama_max_model_mb: 14336
system_headroom_mb: 8192

# Models
primary_model: gemma4:9b
embedding_model: nomic-embed-text
secondary_model: qwen2.5:7b

# Features
enable_cognition_layer: true
enable_health_ops: true
enable_rclone: true
enable_github: true
enable_supabase: false
```

### 10.2 Main Config (config.yaml)

```yaml
# ~/.config/agent-toolkit/config.yaml
# Auto-generated from environment.yaml + defaults

general:
  project_name: "agent-toolkit"
  log_level: "INFO"
  log_format: "json"
  data_dir: "${AGENT_TOOLKIT_DATA}"

mcp:
  transport: "stdio"
  hub_port: 8000
  max_concurrent_tools: 10

ollama:
  host: "${AGENT_MACHINE}"
  port: 11434
  default_model: "gemma4:9b"
  embedding_model: "nomic-embed-text"
  timeout_generate: 120
  timeout_embed: 30
  fallback_model: "qwen2.5:7b"
  max_model_mb: 14336

safety:
  dry_run_default: true
  confirm_destructive: true
  git_safety_check: true
  max_delete_batch: 10

memory:
  conversation_retention_days: 90
  tool_call_retention_days: 30
  default_memory_ttl_hours: null
  max_context_messages: 50

rag:
  default_chunk_size: 512
  chunk_overlap: 128
  max_file_size_mb: 50
  supported_formats: ["txt", "md", "pdf", "docx", "csv"]

background_jobs:
  max_concurrent: 3
  poll_interval_seconds: 30
  default_timeout_hours: 2

integrations:
  github:
    enabled: true
  supabase:
    enabled: false
```

### 10.3 Secrets Template (secrets.env)

```bash
# ~/.config/agent-toolkit/secrets.env
# NEVER commit this file
# Loaded by python-dotenv

# GitHub
GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Supabase (optional)
# SUPABASE_URL=https://xxxx.supabase.co
# SUPABASE_KEY=eyJ...

# LINE (for health-ops, optional)
# LINE_CHANNEL_SECRET=...
# LINE_CHANNEL_TOKEN=...
```

### 10.4 systemd User Service Template

```ini
# ~/.config/systemd/user/agent-toolkit-@SERVER@.service
# Generated by configure-environment.sh for each server

[Unit]
Description=agent-toolkit MCP Server: %i
After=network-online.target

[Service]
Type=simple
ExecStart=%h/workspace/agent-toolkit/.venv/bin/python -m agent_toolkit.servers.%i
Restart=on-failure
RestartSec=5
Environment="AGENT_TOOLKIT_HOME=%h/.config/agent-toolkit"
Environment="AGENT_TOOLKIT_DATA=%h/.local/share/agent-toolkit"
Environment="PYTHONPATH=%h/workspace/agent-toolkit/src"

# Memory limit per server (prevents OOM)
MemoryMax=%MEMORY_LIMIT%

[Install]
WantedBy=default.target
```

### 10.5 Test Cross-Machine Script (Template)

```bash
#!/usr/bin/env bash
# ~/bin/test-cross-machine.sh
# Uses environment variables — no hardcoded values

set -euo pipefail

AGENT_MACHINE="${AGENT_MACHINE:-ecolife-2}"
OLLAMA_HOST="${OLLAMA_HOST:-http://${AGENT_MACHINE}:11434}"

echo "=== Cross-Machine Connectivity Test ==="
echo "  Agent machine: $AGENT_MACHINE"
echo "  Ollama URL: $OLLAMA_HOST"
echo ""

echo "[1] SSH to agent machine..."
ssh "$AGENT_MACHINE" 'echo "  SSH: OK"' || echo "  SSH: FAILED"
echo ""

echo "[2] Ollama API (tags)..."
curl -sf "$OLLAMA_HOST/api/tags" | jq -r '.models[].name' 2>/dev/null | head -5 | sed 's/^/  /' || echo "  Ollama tags: FAILED"
echo ""

echo "[3] Ollama generate test..."
RESPONSE=$(curl -sf "$OLLAMA_HOST/api/generate" \
  -H "Content-Type: application/json" \
  -d '{"model":"gemma4","prompt":"Say OK","stream":false}' 2>/dev/null | jq -r '.response' 2>/dev/null || true)
if [ -n "$RESPONSE" ]; then echo "  Response: $RESPONSE"; else echo "  Ollama generate: FAILED"; fi
echo ""

echo "[4] Ollama embedding test..."
EMBED_DIMS=$(curl -sf "$OLLAMA_HOST/api/embeddings" \
  -H "Content-Type: application/json" \
  -d '{"model":"nomic-embed-text","prompt":"test"}' 2>/dev/null | jq '.embedding | length' 2>/dev/null || true)
if [ -n "$EMBED_DIMS" ] && [ "$EMBED_DIMS" != "null" ]; then
  echo "  Embedding dimensions: $EMBED_DIMS"
else
  echo "  Ollama embeddings: FAILED"
fi
echo ""

echo "=== Tests Complete ==="
```

### 10.6 Full Verification Script (Template)

```bash
#!/usr/bin/env bash
# ~/bin/verify-integration.sh
set -euo pipefail

OLLAMA_HOST="${OLLAMA_HOST:-http://${AGENT_MACHINE:-ecolife-2}:11434}"
AGENT_TOOLKIT_DATA="${AGENT_TOOLKIT_DATA:-$HOME/.local/share/agent-toolkit}"

echo "========================================="
echo "  agent-toolkit Integration Verification"
echo "========================================="
echo ""

echo "[1/8] Environment..."
[ -n "${GITHUB_TOKEN:-}" ] && echo "  GITHUB_TOKEN: ${GITHUB_TOKEN:0:8}... OK" || echo "  GITHUB_TOKEN: not set"
echo "  OLLAMA_HOST: $OLLAMA_HOST"
echo ""

echo "[2/8] Directories..."
mkdir -p "$AGENT_TOOLKIT_DATA"/{logs,vectors}
echo "  Data dir: $AGENT_TOOLKIT_DATA OK"
echo ""

echo "[3/8] Ollama ($AGENT_MACHINE)..."
curl -sf "$OLLAMA_HOST/api/tags" > /dev/null && echo "  Ollama: reachable" || echo "  Ollama: FAILED"
echo ""

echo "[4/8] rclone..."
command -v rclone &>/dev/null && rclone listremotes | grep -q "lean:" && echo "  rclone 'lean': OK" || echo "  rclone: check config"
echo ""

echo "[5/8] GitHub..."
if [ -n "${GITHUB_TOKEN:-}" ]; then
  GH_USER=$(curl -sf -H "Authorization: token $GITHUB_TOKEN" https://api.github.com/user 2>/dev/null | jq -r '.login // empty' 2>/dev/null || true)
  [ -n "$GH_USER" ] && echo "  GitHub: $GH_USER" || echo "  GitHub: token invalid"
else
  echo "  GitHub: skipped"
fi
echo ""

echo "[6/8] Databases..."
mkdir -p "$AGENT_TOOLKIT_DATA"
touch "$AGENT_TOOLKIT_DATA/context.db" 2>/dev/null && echo "  context.db: OK" || echo "  context.db: will create"
echo ""

echo "[7/8] MCP Hub..."
if systemctl --user is-active agent-toolkit-hub &>/dev/null; then
  echo "  Hub: running"
else
  echo "  Hub: not running (start with: systemctl --user start agent-toolkit-hub)"
fi
echo ""

echo "[8/8] Summary..."
echo "  Data dir: $AGENT_TOOLKIT_DATA"
echo "  Config dir: ${AGENT_TOOLKIT_HOME:-$HOME/.config/agent-toolkit}"
echo "  Ollama: $OLLAMA_HOST"
echo ""

echo "========================================="
echo "  Verification complete!"
echo "========================================="
```

### 10.7 Complete Model Memory Budget (32GB System)

```
32,768 MB Total System RAM
-  8,192 MB Headroom (OS + buffer)
-  8,192 MCP Servers (combined)
- 14,336 Ollama max single model
=  2,048 MB Contingency buffer

Per-Model Budgets:
  gemma4:9b       8,192 MB  (primary, always loaded)
  nomic-embed     1,024 MB  (always loaded)
  qwen2.5:7b      4,096 MB  (secondary, loaded on demand)
  llava:13b       8,192 MB  (vision, loaded on demand)

Maximum simultaneous: gemma4:9b + nomic-embed + qwen2.5:7b = 13,312 MB
Remaining for MCP + OS: 19,456 MB (comfortable)

FORBIDDEN: gemma4:27B (20,480 MB) — exceeds single-model budget
           gemma4:9b + qwen2.5:7b + llava:13b = 20,480 MB — exceeds safe limit
           More than 3 models loaded simultaneously
```

---

## Document Control

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0.0 | 2025-01-20 | Review Lead | Consolidated from 6 deliverables; all CRITICAL issues resolved |

**Source Documents:**
- ARCHITECTURE.md v1.0 → Sections 1, 2, 3
- DOMAIN_REQUIREMENTS.md v1.0.0 → Section 4
- SAFETY_PROTOCOL.md v1.0.0 → Section 5
- INTEGRATION_GUIDE.md → Section 6
- ROADMAP.md → Section 7
- AGENT_COGNITION_LAYER.md → Section 8

**Next Review:** 2025-02-01

---

*"We don't build another CLI. We build the arms and legs that make existing CLIs more capable."*
