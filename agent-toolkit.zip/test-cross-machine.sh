#!/bin/bash
# ~/bin/test-cross-machine.sh
# Cross-machine connectivity test for agent-toolkit
# Run this on: lean@192.168.1.135

echo "=== Cross-Machine Connectivity Test ==="
echo ""

echo "[1] SSH to ecolife-2..."
ssh ecolife-2 'echo "  SSH: OK"' || echo "  SSH: FAILED"
echo ""

echo "[2] Ollama API (tags)..."
curl -s http://ecolife-2:11434/api/tags 2>/dev/null | jq -r '.models[].name' 2>/dev/null | head -5 | sed 's/^/  /' || echo "  Ollama tags: FAILED"
echo ""

echo "[3] Ollama generate test..."
RESPONSE=$(curl -s http://ecolife-2:11434/api/generate \
  -H "Content-Type: application/json" \
  -d '{"model":"gemma4","prompt":"Say OK","stream":false}' 2>/dev/null | jq -r '.response' 2>/dev/null)
if [ -n "$RESPONSE" ]; then
  echo "  Response: $RESPONSE"
else
  echo "  Ollama generate: FAILED"
fi
echo ""

echo "[4] Ollama embedding test..."
EMBED_DIMS=$(curl -s http://ecolife-2:11434/api/embeddings \
  -H "Content-Type: application/json" \
  -d '{"model":"nomic-embed-text","prompt":"test"}' 2>/dev/null | jq '.embedding | length' 2>/dev/null)
if [ -n "$EMBED_DIMS" ] && [ "$EMBED_DIMS" != "null" ]; then
  echo "  Embedding dimensions: $EMBED_DIMS"
else
  echo "  Ollama embeddings: FAILED"
fi
echo ""

echo "=== Tests Complete ==="
