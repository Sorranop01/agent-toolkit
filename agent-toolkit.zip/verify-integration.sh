#!/bin/bash
set -e

# ============================================================
# FULL INTEGRATION VERIFICATION SCRIPT
# Run this on: lean@192.168.1.135
# ============================================================

echo "========================================="
echo "  agent-toolkit Integration Verification"
echo "========================================="
echo ""

# --- [1] Environment Variables ---
echo "[1/8] Environment variables..."
if [ -z "${GITHUB_TOKEN:-}" ]; then
  echo "      ✗ GITHUB_TOKEN not set (required for github tools)"
else
  echo "      GITHUB_TOKEN: ${GITHUB_TOKEN:0:8}... ✓"
fi

if [ -z "${OLLAMA_HOST:-}" ]; then
  echo "      ✗ OLLAMA_HOST not set (defaulting to http://ecolife-2:11434)"
  export OLLAMA_HOST="http://ecolife-2:11434"
else
  echo "      OLLAMA_HOST: $OLLAMA_HOST ✓"
fi
echo ""

# --- [2] MCP Hub ---
echo "[2/8] MCP Hub..."
if command -v agent-toolkit &> /dev/null; then
  agent-toolkit --version 2>/dev/null || echo "      agent-toolkit installed"
  echo "      ✓ OK"
else
  echo "      ⊙ agent-toolkit CLI not in PATH (install with: pip install -e .)"
fi
echo ""

# --- [3] Ollama Bridge ---
echo "[3/8] Ollama Bridge (ecolife-2)..."
if curl -sf "$OLLAMA_HOST/api/tags" > /dev/null 2>&1; then
  echo "      ✓ Ollama reachable"
  MODELS=$(curl -sf "$OLLAMA_HOST/api/tags" 2>/dev/null | jq -r '.models[].name' 2>/dev/null | wc -l)
  echo "      ✓ $MODELS models available"
else
  echo "      ✗ Ollama not reachable at $OLLAMA_HOST"
fi

if curl -sf "$OLLAMA_HOST/api/generate" \
    -H "Content-Type: application/json" \
    -d '{"model":"gemma4","prompt":"hi","stream":false}' > /dev/null 2>&1; then
  echo "      ✓ gemma4 responds"
else
  echo "      ✗ gemma4 generation failed"
fi
echo ""

# --- [4] rclone Bridge ---
echo "[4/8] rclone Bridge..."
if command -v rclone &> /dev/null; then
  if rclone lsf lean: > /dev/null 2>&1; then
    echo "      ✓ Remote 'lean' accessible"
  else
    echo "      ✗ Remote 'lean' not accessible (run: rclone config reconnect lean:)"
  fi
else
  echo "      ✗ rclone not installed"
fi
echo ""

# --- [5] GitHub ---
echo "[5/8] GitHub API..."
if [ -n "${GITHUB_TOKEN:-}" ]; then
  GH_USER=$(curl -sf -H "Authorization: token $GITHUB_TOKEN" \
    https://api.github.com/user 2>/dev/null | jq -r '.login' 2>/dev/null || true)
  if [ -n "$GH_USER" ] && [ "$GH_USER" != "null" ]; then
    echo "      ✓ Authenticated as: $GH_USER"
  else
    echo "      ✗ GitHub token invalid"
  fi
else
  echo "      ⊙ Skipped (GITHUB_TOKEN not set)"
fi
echo ""

# --- [6] SQLite Databases ---
echo "[6/8] Local databases..."
mkdir -p ~/.local/share/agent-toolkit
test -f ~/.local/share/agent-toolkit/memory.db && echo "      ✓ memory.db exists" || echo "      ⊙ memory.db will be created on first use"
test -f ~/.local/share/agent-toolkit/health.db && echo "      ✓ health.db exists" || echo "      ⊙ health.db will be created on first use"
echo ""

# --- [7] Supabase (optional) ---
echo "[7/8] Supabase (optional)..."
if [ -n "${SUPABASE_URL:-}" ]; then
  if curl -sf "$SUPABASE_URL/rest/v1/" -H "apikey: $SUPABASE_KEY" > /dev/null 2>&1; then
    echo "      ✓ Supabase reachable"
  else
    echo "      ✗ Supabase not reachable"
  fi
else
  echo "      ⊙ Skipped (SUPABASE_URL not set)"
fi
echo ""

# --- [8] MCP Servers Status ---
echo "[8/8] MCP Server processes..."
if pgrep -f "agent_toolkit.servers" > /dev/null 2>&1; then
  ps aux | grep agent_toolkit.servers | grep -v grep | while read line; do
    echo "      $line"
  done
else
  echo "      ⊙ No MCP servers running (start with: agent-toolkit start)"
fi
echo ""

echo "========================================="
echo "  Verification complete!"
echo "========================================="
