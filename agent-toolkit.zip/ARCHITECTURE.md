# agent-toolkit — System Architecture Document

**Version:** 1.0  
**Date:** 2025-01-20  
**Project:** agent-toolkit — Self-Hosted MCP Server Hub  
**Repository:** `lean@192.168.1.135:~/workspace/agent-toolkit`  
**Author:** System Architect  
**Status:** Production-grade architecture specification

---

## Table of Contents

1. [Executive Summary](#1-executive-summary)
2. [MCP Server Inventory](#2-mcp-server-inventory)
3. [System Architecture Diagram](#3-system-architecture-diagram)
4. [Shared Context Layer Design](#4-shared-context-layer-design)
5. [Module Structure](#5-module-structure)
6. [Data Flow Specifications](#6-data-flow-specifications)
7. [Technology Stack](#7-technology-stack)
8. [Key Design Decisions](#8-key-design-decisions)
9. [Deployment Topology](#9-deployment-topology)
10. [Configuration Management](#10-configuration-management)
11. [Security Model](#11-security-model)
12. [Operational Runbooks](#12-operational-runbooks)
13. [Appendix A: Glossary](#appendix-a-glossary)
14. [Appendix B: mcp.json Configuration Templates](#appendix-b-mcpjson-configuration-templates)

---

## 1. Executive Summary

### What agent-toolkit IS

**agent-toolkit** is a self-hosted, modular hub of MCP (Model Context Protocol) servers that expose specialized domain tools and infrastructure capabilities to multiple AI CLI clients. It transforms two headless Linux machines — a development workstation and a dedicated inference server — into a unified cognitive platform where AI assistants gain persistent memory, domain expertise, safe file operations, and autonomous background processing capabilities.

The project follows the **"arms and legs" philosophy**: we do NOT build another CLI client. Instead, we build specialized MCP servers that serve as the appendages — the hands that safely manipulate files, the eyes that read solar panel data, the memory that persists across sessions — which existing CLI clients (Kimi CLI, OpenCode CLI, Goose CLI) invoke through the standardized Model Context Protocol.

agent-toolkit enables:

- **Cross-CLI persistent memory** — Conversations, tool executions, and learned facts survive across different CLI clients via a shared SQLite database
- **Business domain expertise** — Specialized calculators and data processors for Solar Energy O&M and Health Franchise operations in Bangkok
- **Safe file system operations** — Every destructive action requires dry-run preview, explicit confirmation, or git safety verification
- **Local-first inference** — Heavy LLM workloads (embeddings, summarization, reasoning) run on the dedicated 32GB agent machine without cloud dependency
- **Background job execution** — Long-running tasks (document indexing, batch calculations, sync operations) execute asynchronously via the agent machine
- **Multi-client service** — One unified MCP hub serves Kimi, OpenCode, Goose, and future MCP-compatible clients simultaneously

### What agent-toolkit IS NOT

| NOT This | Why |
|----------|-----|
| A new CLI client | We integrate with existing CLIs via MCP, not compete with them |
| A cloud service | Entirely self-hosted on local machines via LAN |
| A general-purpose framework | Purpose-built for the lean@192.168.1.135 + ecolife-2 topology |
| An automation bot | Tools require human confirmation for destructive operations |
| A replacement for Ollama | Ollama runs independently; we bridge to it, not wrap it |
| A chat UI | No web interface; all interaction is through MCP tool calls from CLI clients |

### Target Topology

```
                    +---------------------------+
                    |    iPad (Blink/mosh)      |
                    |  Primary human interface  |
                    +------------+--------------+
                                 |
                          mosh/ssh over LAN
                                 |
             +-------------------v--------------------+
             |  lean@192.168.1.135 (Dev Machine)     |
             |  - MCP Server Hub (FastMCP)            |
             |  - SQLite shared context               |
             |  - Safety gatekeeper                   |
             |  - Config & orchestration              |
             |  - tmux session management             |
             +-------------------+--------------------+
                                 |
                    ssh tunnel / HTTP / rclone
                                 |
             +-------------------v--------------------+
             |  ecolife-2 (Agent Machine)            |
             |  - Ollama 24/7 (Gemma4, etc.)         |
             |  - Heavy inference (embeddings)       |
             |  - Background job workers             |
             |  - 32GB RAM for model hosting         |
             |  - rclone sync target (Google Drive)  |
             +----------------------------------------+
```

---

## 2. MCP Server Inventory

### 2.1 Server Overview Table

| # | Server | Type | Status | Primary Consumer | Data Flow | Purpose Summary |
|---|--------|------|--------|-----------------|-----------|-----------------|
| 1 | `file-ops-safe` | Custom | Core | All CLIs | Bidirectional | File operations with mandatory safety gates (dry-run, confirm, git-check) |
| 2 | `solar-calc` | Custom | Domain | Kimi/OpenCode | Read → Calc → Out | Solar O&M calculations (ROI, degradation, shading analysis, production estimates) |
| 3 | `health-ops` | Custom | Domain | Kimi/OpenCode | Read → Calc → Out | Health franchise KPIs, patient flow, inventory projections, revenue modeling |
| 4 | `rag-bridge` | Custom | Core | All CLIs | Ingest → Embed → Query | Document ingestion, embedding generation, semantic search over business documents |
| 5 | `memory-store` | Custom | Core | All CLIs | Read/Write persistent | Cross-CLI shared memory: conversations, facts, preferences, task history |
| 6 | `ollama-bridge` | Custom | Core | All CLIs | Request → Inference → Response | Bridge to Ollama HTTP API on ecolife-2 for local LLM inference |
| 7 | `rclone-bridge` | Custom | Integration | Kimi/Goose | Command → Sync → Verify | Safe interface to rclone for Google Drive (remote: `lean`) operations |
| 8 | `github-mcp` | Off-the-shelf | Integration | All CLIs | API ↔ GitHub | GitHub issue/PR/repo management via official MCP server |
| 9 | `supabase-mcp` | Off-the-shelf | Integration | Kimi/OpenCode | SQL ↔ Supabase | PostgreSQL database access via official Supabase MCP server |

### 2.2 Detailed Server Specifications

#### 2.2.1 `file-ops-safe` — Safe File Operations Server

**Purpose:** The ONLY file system manipulation gateway. Every file operation passes through safety gates.

**Tools exposed:**
| Tool | Description | Safety Gate |
|------|-------------|-------------|
| `safe_read` | Read file contents with path validation | Path whitelist check |
| `safe_write` | Write file after dry-run diff preview | Dry-run → confirm OR git-clean check |
| `safe_append` | Append to file | Same as safe_write |
| `safe_delete` | Delete file after confirmation | Git-tracked files blocked unless `--force` |
| `safe_move` | Move/rename file or directory | Dry-run preview → confirm |
| `safe_copy` | Copy file or directory | Destination overwrite check |
| `safe_find` | Find files by pattern | Read-only, no gate |
| `safe_grep` | Search file contents | Read-only, no gate |
| `safe_tree` | List directory tree | Read-only, no gate |
| `safe_mkdir` | Create directory | Idempotent, no gate for new dirs |
| `safe_chmod` | Change permissions | Confirmation for 777 or removal of read |
| `safe_disk_usage` | Check disk usage | Read-only, no gate |

**Configuration:** `config/safety.toml` defines path whitelist, blacklist, and auto-confirm patterns.

**Data flow:** CLI → MCP transport → `file-ops-safe` server → OS filesystem (local on dev machine only).

**Safety philosophy:** *"Every delete is a potential disaster. Every write is a potential regret."*

---

#### 2.2.2 `solar-calc` — Solar Energy Operations Server

**Purpose:** Domain-specific calculation engine for Solar Energy O&M business operations in Thailand.

**Tools exposed:**
| Tool | Input | Output | Description |
|------|-------|--------|-------------|
| `calculate_production` | Array[panel specs], location, tilt, azimuth | Annual/monthly kWh estimates | PV production estimation using local irradiance data |
| `calculate_degradation` | Install date, degradation rate, current date | Remaining capacity % | Panel degradation projection over time |
| `calculate_roi` | System cost, energy price, production, years | ROI, payback period, NPV | Financial return analysis |
| `shading_analysis` | Array[obstruction specs], panel position | Shading factor, adjusted production | Obstruction impact on array performance |
| `maintenance_schedule` | System size, install date, last service | Next service dates, estimated costs | Predictive maintenance calendar |
| `performance_ratio` | Actual production, theoretical production, period | PR %, efficiency delta | Performance ratio calculation against theoretical |
| `thai_regulatory_check` | System size, location, grid type | Compliance status, required permits | Thailand solar regulation checker (rule-based) |

**Data flow:** CLI → solar-calc → calculation engine → JSON result → CLI.

**External data:** Embedded Thai irradiance lookup tables, PEA/MET regulatory rule sets.

---

#### 2.2.3 `health-ops` — Health Franchise Operations Server

**Purpose:** Business intelligence tools for health franchise operations in Bangkok.

**Tools exposed:**
| Tool | Input | Output | Description |
|------|-------|--------|-------------|
| `clinic_kpi_dashboard` | Clinic ID, date range | Revenue, visits, conversion, AOV | Aggregated clinic performance metrics |
| `patient_flow_model` | Historical visit data, seasonality params | Projected visits, peak hours | Patient volume forecasting |
| `inventory_projection` | Current stock, consumption rate, lead times | Reorder dates, stock-out risk | Inventory optimization for medical supplies |
| `revenue_forecast` | Historical revenue, growth assumptions, months | Monthly projections, confidence intervals | Revenue forecasting with uncertainty bounds |
| `staff_optimization` | Patient volume, service mix, staff costs | Optimal FTE allocation, cost per visit | Workforce scheduling recommendations |
| `franchise_comparison` | Array[clinic IDs], metric | Ranked comparison, benchmarks | Cross-clinic performance benchmarking |
| `regulatory_compliance` | Clinic type, services offered | Compliance checklist, renewal dates | Thai healthcare regulation tracker |

**Data flow:** CLI → health-ops → calculation engine → JSON result → CLI.

**External data:** Franchise data stores (future: Supabase integration), Thai healthcare regulations.

---

#### 2.2.4 `rag-bridge` — Retrieval-Augmented Generation Server

**Purpose:** Document intelligence pipeline — ingest, embed, index, and semantically search business documents.

**Tools exposed:**
| Tool | Input | Output | Description |
|------|-------|--------|-------------|
| `ingest_documents` | File paths or directory, collection name | Ingestion report (files, chunks, errors) | Parse and chunk documents for indexing |
| `search` | Query text, collection, top_k, filters | Ranked results with scores, excerpts | Semantic search over embedded documents |
| `list_collections` | None | Collection names, document counts, last updated | Available document collections |
| `delete_collection` | Collection name | Confirmation | Remove a collection and all embeddings |
| `get_document_summary` | Document ID, collection | Summary, key topics, chunk count | Auto-generated document overview |
| `hybrid_search` | Query text + metadata filters, collection | Ranked results (semantic + keyword) | Combined vector + keyword search |

**Architecture:**
```
Ingest: Documents → Parse → Chunk → Embed (Ollama on ecolife-2) → Store (SQLite vec)
Query:  Query → Embed (Ollama) → Vector Search (SQLite) → Rerank → Results
```

**Data flow:** CLI → rag-bridge → (embeddings via HTTP to ecolife-2) → SQLite (local on dev machine) → results.

**Embedding model:** Configurable via Ollama (default: `nomic-embed-text` or `all-minilm`).

---

#### 2.2.5 `memory-store` — Cross-CLI Persistent Memory Server

**Purpose:** The shared brain. All CLIs read from and write to a unified memory store, enabling context to persist across client switches.

**Tools exposed:**
| Tool | Input | Output | Description |
|------|-------|--------|-------------|
| `remember` | Key, value, category, importance, TTL | Memory ID | Store a fact or observation |
| `recall` | Key or query, category filter, limit | Matching memories with relevance scores | Retrieve stored information |
| `recall_recent` | Hours, category filter | Recent memories in timeframe | Time-bounded recall |
| `forget` | Memory ID or key pattern | Deleted count | Remove specific memories |
| `list_categories` | None | Category names, memory counts | Browse memory organization |
| `get_conversation_context` | Session hint, max_messages | Recent conversation history | Context window for current thread |
| `store_preference` | Key, value, scope (global/project) | Confirmation | Store user preferences |
| `get_preference` | Key, scope | Value or null | Retrieve user preferences |
| `log_tool_call` | Tool name, args, result, duration | Log ID | Audit trail of tool usage |
| `get_tool_history` | Tool name, hours, status filter | Recent tool executions | Tool usage analytics |

**Data flow:** CLI → memory-store → SQLite (local on dev machine) → results.

**Special behavior:** Automatic session tracking — each CLI invocation writes session metadata for continuity.

---

#### 2.2.6 `ollama-bridge` — Local LLM Inference Bridge

**Purpose:** Unified interface to Ollama on ecolife-2. All LLM calls go through this bridge for consistent handling, fallback, and monitoring.

**Tools exposed:**
| Tool | Input | Output | Description |
|------|-------|--------|-------------|
| `generate` | Model, prompt, system prompt, options | Generated text, tokens used, timing | Text generation via Ollama |
| `chat` | Model, messages[], options | Assistant response, usage stats | Chat completion via Ollama |
| `embed` | Model, texts | Embeddings array, dimensions | Embedding generation (primary consumer: rag-bridge) |
| `list_models` | None | Available models, sizes, parameters | Discover what's loaded/available |
| `model_info` | Model name | Architecture, parameters, quantization | Detailed model metadata |
| `pull_model` | Model name | Progress, final status | Download new models to ecolife-2 |
| `health_check` | None | Status, available models, GPU info | Verify Ollama availability |

**Data flow:** CLI → ollama-bridge → HTTP POST to `http://ecolife-2:11434` → Ollama → response.

**Fallback chain:** Primary model → fallback model → error with context.

---

#### 2.2.7 `rclone-bridge` — Cloud Storage Operations Server

**Purpose:** Safe interface to rclone for Google Drive operations (remote configured as `lean`).

**Tools exposed:**
| Tool | Input | Output | Description |
|------|-------|--------|-------------|
| `list_remote` | Remote path, filters | File/directory listing | Browse Google Drive contents |
| `sync_to_remote` | Local path, remote path, dry-run | Sync report (files transferred, deleted) | Upload with dry-run default |
| `sync_from_remote` | Remote path, local path, dry-run | Sync report | Download with dry-run default |
| `copy_file` | Source, destination, overwrite check | Confirmation + result | Single file copy |
| `move_file` | Source, destination | Confirmation + result | Single file move |
| `delete_remote` | Remote path, confirm | Confirmation + result | Remote deletion (always requires confirm) |
| `check_sync_status` | Local path, remote path | Differences list | Compare local vs remote |
| `mount_remote` | Remote path, local mount point | Mount status | FUSE mount (if supported) |

**Data flow:** CLI → rclone-bridge → subprocess(rclone) → Google Drive API (remote: `lean`) → results.

**Safety:** Dry-run is ALWAYS the default. Confirmation required for destructive operations.

---

#### 2.2.8 `github-mcp` — GitHub Integration (Off-the-shelf)

**Source:** `@modelcontextprotocol/server-github` (official GitHub MCP server)

**Purpose:** GitHub repository, issue, PR, and workflow management.

**Tools:** Issues, PRs, repositories, code search, commits — as provided by the official server.

**Data flow:** CLI → github-mcp → GitHub API → results.

---

#### 2.2.9 `supabase-mcp` — Supabase Integration (Off-the-shelf)

**Source:** `@modelcontextprotocol/server-supabase` (official Supabase MCP server)

**Purpose:** Direct SQL access to Supabase PostgreSQL databases for persistent business data.

**Tools:** SQL queries, table management, row operations — as provided by the official server.

**Data flow:** CLI → supabase-mcp → Supabase API → PostgreSQL → results.

---

## 3. System Architecture Diagram

### 3.1 Complete System Overview

```
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                                    CLI CLIENT LAYER                                      │
│  ┌────────────────────┐  ┌────────────────────┐  ┌────────────────────┐                │
│  │   Kimi CLI         │  │   OpenCode CLI     │  │   Goose CLI        │                │
│  │   (mcp.json)       │  │   (mcp.json)       │  │   (mcp.json)       │                │
│  │                    │  │                    │  │                    │                │
│  │  Reads/writes via  │  │  Reads/writes via  │  │  Reads/writes via  │                │
│  │  MCP stdio/sse     │  │  MCP stdio/sse     │  │  MCP stdio/sse     │                │
│  └────────┬───────────┘  └────────┬───────────┘  └────────┬───────────┘                │
│           │                       │                       │                              │
│           └───────────────────────┼───────────────────────┘                              │
│                                   │                                                      │
│                        MCP TRANSPORT (stdio / SSE)                                      │
│                                   │                                                      │
└───────────────────────────────────┼──────────────────────────────────────────────────────┘
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              MCP SERVER HUB (lean@192.168.1.135)                         │
│                                                                                          │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │                        FASTMCP APPLICATION SERVER                                │    │
│  │                     (Python 3.11+, runs as systemd service)                      │    │
│  │                                                                                  │    │
│  │   ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │    │
│  │   │ file-ops-safe│  │ memory-store │  │ rag-bridge   │  │ ollama-bridge│        │    │
│  │   │              │  │              │  │              │  │              │        │    │
│  │   │ Safety gates │  │ Shared brain │  │ Ingest/Embed │  │ LLM proxy    │        │    │
│  │   │ every op     │  │ cross-CLI    │  │ /Search      │  │ to ecolife-2 │        │    │
│  │   └──────┬───────┘  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘        │    │
│  │          │                 │                 │                 │                 │    │
│  │   ┌──────┴───────┐  ┌──────┴───────┐  ┌──────┴───────┐  ┌──────┴───────┐        │    │
│  │   │ solar-calc   │  │ health-ops   │  │ rclone-bridge│  │ config-mgr   │        │    │
│  │   │              │  │              │  │              │  │              │        │    │
│  │   │ Solar O&M    │  │ Franchise    │  │ Google Drive │  │ Dynamic      │        │    │
│  │   │ calculators  │  │ BI tools     │  │ via rclone   │  │ server cfg   │        │    │
│  │   └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘        │    │
│  │                                                                                  │    │
│  │   External bridges (child processes):                                            │    │
│  │   ┌──────────────────┐    ┌──────────────────┐                                  │    │
│  │   │ github-mcp (npx) │    │ supabase-mcp     │                                  │    │
│  │   │ GitHub API       │    │ (npx)            │                                  │    │
│  │   └──────────────────┘    └──────────────────┘                                  │    │
│  └─────────────────────────────────────────────────────────────────────────────────┘    │
│                                           │                                              │
│   ┌───────────────────────────────────────┼───────────────────────────────────────┐    │
│   │           SHARED CONTEXT LAYER         │                                       │    │
│   │                                        ▼                                       │    │
│   │  ┌─────────────────────────────────────────────────────────────────────────┐  │    │
│   │  │  SQLite Database  (~/.agent-toolkit/context.db)                         │  │    │
│   │  │  ├── conversations      (session history, cross-CLI)                    │  │    │
│   │  │  ├── tool_calls         (audit log of every tool invocation)            │  │    │
│   │  │  ├── memories           (facts, preferences, learned context)           │  │    │
│   │  │  ├── embeddings_cache   (document chunks + vectors)                     │  │    │
│   │  │  ├── document_meta      (ingested documents metadata)                   │  │    │
│   │  │  └── sessions           (CLI session tracking)                          │  │    │
│   │  └─────────────────────────────────────────────────────────────────────────┘  │    │
│   └───────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                          │
│   ┌───────────────────────────────────────────────────────────────────────────────┐    │
│   │  Config & Safety Layer                                                        │    │
│   │  ├── ~/.agent-toolkit/config.toml    (server config, paths, thresholds)     │    │
│   │  ├── ~/.agent-toolkit/safety.toml    (whitelist, blacklist, auto-confirm)   │    │
│   │  ├── ~/.agent-toolkit/secrets.env    (API keys, tokens — never in git)      │    │
│   │  └── ~/.agent-toolkit/logs/          (structured JSON logs, rotated)        │    │
│   └───────────────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────────────────┘
                                    │
                         ssh tunnel │ HTTP API calls
                         (rclone for│ file sync)
                                    │
                                    ▼
┌─────────────────────────────────────────────────────────────────────────────────────────┐
│                              INFERENCE LAYER (ecolife-2)                                 │
│                                                                                          │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │  Ollama Service (systemd, 24/7)                                                  │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │    │
│  │  │ Gemma 4      │  │ nomic-embed  │  │ Qwen2.5      │  │ Mistral      │        │    │
│  │  │ (chat/reason)│  │ -text        │  │ (code)       │  │ (general)    │        │    │
│  │  │ 9B-27B param │  │ 768d vectors │  │ 7B-14B param │  │ 7B param     │        │    │
│  │  │ ~8-20GB VRAM │  │ ~1GB VRAM    │  │ ~4-8GB VRAM  │  │ ~4GB VRAM    │        │    │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘        │    │
│  │                                                                                  │    │
│  │  Total: 32GB RAM — hosts 1 large + 2 small models simultaneously               │    │
│  │  API endpoint: http://ecolife-2:11434 (LAN only, no public exposure)           │    │
│  └─────────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                          │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │  Background Job Workers (async, via SSH-triggered processes)                     │    │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐        │    │
│  │  │ Doc Ingest   │  │ Embed Batch  │  │ Sync Worker  │  │ Report Gen   │        │    │
│  │  │ Pipeline     │  │ Processor    │  │ (rclone)     │  │ (scheduled)  │        │    │
│  │  │ Long parse   │  │ Chunk + vec  │  │ GDRIVE ↔ FS  │  │ Batch calc   │        │    │
│  │  └──────────────┘  └──────────────┘  └──────────────┘  └──────────────┘        │    │
│  └─────────────────────────────────────────────────────────────────────────────────┘    │
│                                                                                          │
│  ┌─────────────────────────────────────────────────────────────────────────────────┐    │
│  │  Data Storage (ecolife-2 local)                                                  │    │
│  │  ├── /var/lib/ollama/          (model weights, ~20-50GB)                       │    │
│  │  ├── ~/agent-toolkit-data/     (synced docs, job outputs, temp files)           │    │
│  │  └── ~/.cache/rclone/          (rclone cache, VFS)                             │    │
│  └─────────────────────────────────────────────────────────────────────────────────┘    │
└─────────────────────────────────────────────────────────────────────────────────────────┘
```

### 3.2 Component Interaction Diagram

```
    Kimi CLI                    OpenCode CLI                Goose CLI
        │                           │                           │
        │  MCP (stdio)              │  MCP (stdio)              │  MCP (stdio)
        ▼                           ▼                           ▼
┌─────────────────────────────────────────────────────────────────────────────┐
│                        MCP SERVER HUB PROCESS                                │
│  ┌─────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌───────────────┐  │
│  │ Router  │  │ Safety   │  │ Memory   │  │ Config   │  │ Bridge        │  │
│  │ (which  │→ │ Gate     │→ │ Store    │→│ Manager  │→│ Dispatcher    │  │
│  │ tool?)  │  │ (dry-run │  │ (context │  │ (servers │  │ (ollama/      │  │
│  │         │  │  confirm)│  │  persist)│  │  config) │  │  rclone)      │  │
│  └────┬────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘  └───────┬───────┘  │
│       └─────────────┴─────────────┴─────────────┘                │          │
│                          │                                        │          │
│       ┌──────────────────┘                                        │          │
│       ▼                                                           ▼          │
│  ┌─────────┐  ┌─────────┐  ┌──────────┐                  ┌──────────────┐   │
│  │ file-   │  │ solar-  │  │ health-  │                  │ ollama-bridge│   │
│  │ ops-safe│  │ calc    │  │ ops      │                  │              │   │
│  └────┬────┘  └────┬────┘  └────┬─────┘                  └──────┬───────┘   │
│       │            │            │                                │           │
│       ▼            ▼            ▼                                ▼           │
│  [filesystem]  [calculator] [calculator]              HTTP over LAN          │
│                                                          │                   │
└──────────────────────────────────────────────────────────┼───────────────────┘
                                                           │
                                              ┌────────────▼────────────┐
                                              │    ecolife-2:11434      │
                                              │      OLLAMA API         │
                                              │  ┌──────┐  ┌────────┐  │
                                              │  │Gemma4│  │nomic-  │  │
                                              │  │      │  │embed   │  │
                                              │  └──────┘  └────────┘  │
                                              └─────────────────────────┘
```

---

## 4. Shared Context Layer Design

### 4.1 Philosophy

The Shared Context Layer is the **central nervous system** of agent-toolkit. Without it, each CLI client operates in isolation — conversations evaporate when the terminal closes, learned preferences are forgotten, and switching from Kimi to Goose means starting from zero. With it, all CLIs share a single source of truth.

**Design principles:**
1. **Every CLI is a peer** — No client owns the data; all read/write equally
2. **Automatic capture** — Conversations and tool calls are logged without explicit user action
3. **Structured memory** — Facts, preferences, and observations are tagged and queryable
4. **Time-aware retrieval** — Recent context weighted more heavily; old context summarized
5. **Privacy-first** — All data stays on local machines; never leaves the LAN

### 4.2 Database: SQLite with sqlite-vec

**Location:** `~/.agent-toolkit/context.db` (on dev machine, lean@192.168.1.135)

**Why SQLite:**
- Zero external dependencies or network services
- Single-file portability for backup/restore
- ACID transactions for consistency across concurrent CLIs
- `sqlite-vec` extension enables vector search for embeddings
- Sufficient for the anticipated data volume (millions of rows, not billions)

**Why not PostgreSQL:** The overhead of running a PostgreSQL server is unjustified for local, single-user operation. If requirements change (multi-user, network access), migration is straightforward via `pgloader`.

### 4.3 Complete Schema

```sql
-- ============================================================
-- CORE TABLES
-- ============================================================

-- Sessions: Track each CLI invocation for continuity
CREATE TABLE sessions (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_uuid    TEXT NOT NULL UNIQUE,         -- UUID v4 for cross-reference
    cli_client      TEXT NOT NULL,                -- 'kimi' | 'opencode' | 'goose'
    cli_version     TEXT,                         -- Version of the CLI client
    working_dir     TEXT NOT NULL,                -- CWD at session start
    started_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ended_at        DATETIME,                     -- NULL until session ends
    exit_status     TEXT,                         -- 'success' | 'error' | 'interrupted'
    metadata_json   TEXT,                         -- Extra client-specific info (JSON)
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_sessions_cli_client ON sessions(cli_client);
CREATE INDEX idx_sessions_started_at ON sessions(started_at);

-- Conversations: Message-level log of all interactions
CREATE TABLE conversations (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    turn_number     INTEGER NOT NULL,             -- Sequential within session
    role            TEXT NOT NULL,                -- 'user' | 'assistant' | 'system'
    content         TEXT NOT NULL,                -- Message content (text)
    model_used      TEXT,                         -- Which LLM generated this (if assistant)
    tokens_input    INTEGER,                      -- Token count (if available)
    tokens_output   INTEGER,                      -- Token count (if available)
    latency_ms      INTEGER,                      -- Response time in milliseconds
    timestamp       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(session_id, turn_number)
);

CREATE INDEX idx_conversations_session ON conversations(session_id);
CREATE INDEX idx_conversations_timestamp ON conversations(timestamp);

-- Tool Calls: Audit log of every tool invocation (the "nervous system")
CREATE TABLE tool_calls (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    tool_name       TEXT NOT NULL,                -- Fully qualified: 'file-ops-safe.safe_read'
    arguments_json  TEXT NOT NULL,                -- Arguments as JSON
    result_json     TEXT,                         -- Result as JSON (NULL if pending)
    status          TEXT NOT NULL DEFAULT 'pending', -- 'pending' | 'success' | 'error' | 'denied'
    error_message   TEXT,                         -- Error details if status='error'
    safety_decision TEXT,                         -- 'auto-allowed' | 'dry-run' | 'confirmed' | 'denied'
    duration_ms     INTEGER,                      -- Execution time
    server_name     TEXT NOT NULL,                -- Which MCP server handled it
    timestamp       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_tool_calls_session ON tool_calls(session_id);
CREATE INDEX idx_tool_calls_tool_name ON tool_calls(tool_name);
CREATE INDEX idx_tool_calls_timestamp ON tool_calls(timestamp);
CREATE INDEX idx_tool_calls_status ON tool_calls(status);

-- Memories: Structured facts and observations (the "long-term memory")
CREATE TABLE memories (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    memory_key      TEXT NOT NULL,                -- Human-readable key, e.g., 'user_prefers_vim'
    content         TEXT NOT NULL,                -- The actual memory content
    category        TEXT NOT NULL DEFAULT 'general', -- 'preference' | 'fact' | 'observation' | 'project' | 'person' | 'todo'
    importance      INTEGER NOT NULL DEFAULT 5,   -- 1-10 scale, 10 = critical
    source_session  INTEGER REFERENCES sessions(id) ON DELETE SET NULL,
    confidence      REAL NOT NULL DEFAULT 1.0,    -- 0.0 - 1.0, certainty level
    access_count    INTEGER NOT NULL DEFAULT 0,   -- How many times recalled
    last_accessed   DATETIME,                     -- When last recalled
    ttl_hours       INTEGER,                      -- NULL = permanent; else auto-expire
    expires_at      DATETIME,                     -- Computed from created_at + ttl_hours
    metadata_json   TEXT,                         -- Extra structured data (JSON)
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_memories_key ON memories(memory_key);
CREATE INDEX idx_memories_category ON memories(category);
CREATE INDEX idx_memories_importance ON memories(importance);
CREATE INDEX idx_memories_created ON memories(created_at);

-- Preferences: Typed user preferences with scoping
CREATE TABLE preferences (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    pref_key        TEXT NOT NULL,                -- 'editor' | 'shell' | 'theme' | etc.
    pref_value      TEXT NOT NULL,                -- The value
    scope           TEXT NOT NULL DEFAULT 'global', -- 'global' | 'project:{path}' | 'session'
    scope_target    TEXT,                         -- Project path if scope='project'
    source_session  INTEGER REFERENCES sessions(id) ON DELETE SET NULL,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(pref_key, scope, scope_target)
);

CREATE INDEX idx_preferences_scope ON preferences(scope, scope_target);

-- ============================================================
-- RAG / DOCUMENT TABLES
-- ============================================================

-- Collections: Logical groupings of documents
CREATE TABLE document_collections (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    name            TEXT NOT NULL UNIQUE,         -- 'solar-docs' | 'health-sop' | 'personal-notes'
    description     TEXT,
    embedding_model TEXT NOT NULL,                -- 'nomic-embed-text' | 'all-minilm'
    embedding_dim   INTEGER NOT NULL,             -- 768 | 384 | etc.
    document_count  INTEGER NOT NULL DEFAULT 0,
    chunk_count     INTEGER NOT NULL DEFAULT 0,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Documents: Metadata about ingested documents
CREATE TABLE documents (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    collection_id   INTEGER NOT NULL REFERENCES document_collections(id) ON DELETE CASCADE,
    file_path       TEXT NOT NULL,                -- Original file path
    file_hash       TEXT NOT NULL,                -- SHA256 for deduplication
    file_size       INTEGER NOT NULL,             -- Bytes
    mime_type       TEXT,                         -- 'application/pdf' | 'text/markdown' | etc.
    title           TEXT,                         -- Extracted or inferred title
    summary         TEXT,                         -- Auto-generated summary
    chunk_count     INTEGER NOT NULL DEFAULT 0,
    ingest_status   TEXT NOT NULL DEFAULT 'pending', -- 'pending' | 'chunking' | 'embedding' | 'complete' | 'error'
    error_message   TEXT,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_documents_collection ON documents(collection_id);
CREATE INDEX idx_documents_hash ON documents(file_hash);
CREATE INDEX idx_documents_status ON documents(ingest_status);

-- Document Chunks: Individual text chunks with vector embeddings
CREATE TABLE document_chunks (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id     INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    collection_id   INTEGER NOT NULL REFERENCES document_collections(id) ON DELETE CASCADE,
    chunk_index     INTEGER NOT NULL,             -- Position within document
    chunk_text      TEXT NOT NULL,                -- The actual text content
    embedding       BLOB,                         -- Serialized float32 vector (or use sqlite-vec virtual table)
    token_count     INTEGER,
    char_count      INTEGER NOT NULL,
    metadata_json   TEXT,                         -- Page numbers, headers, etc.
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(document_id, chunk_index)
);

CREATE INDEX idx_chunks_document ON document_chunks(document_id);
CREATE INDEX idx_chunks_collection ON document_chunks(collection_id);

-- Using sqlite-vec for efficient vector search (alternative to BLOB embeddings):
-- CREATE VIRTUAL TABLE vec_chunks USING vec0(embedding float[768]);
-- With shadow table sync triggered on document_chunks insert/update/delete

-- ============================================================
-- EMBEDDINGS CACHE (for non-document embeddings)
-- ============================================================

CREATE TABLE embeddings_cache (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    text_hash       TEXT NOT NULL UNIQUE,         -- SHA256 of input text
    original_text   TEXT NOT NULL,                -- Full text (for debugging)
    model_name      TEXT NOT NULL,                -- Which model produced embedding
    embedding       BLOB NOT NULL,                -- Serialized float32 vector
    embedding_dim   INTEGER NOT NULL,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_embeddings_hash ON embeddings_cache(text_hash);
CREATE INDEX idx_embeddings_model ON embeddings_cache(model_name);

-- ============================================================
-- OPERATIONAL TABLES
-- ============================================================

-- Background Jobs: Track async job execution
CREATE TABLE background_jobs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    job_type        TEXT NOT NULL,                -- 'ingest' | 'embed_batch' | 'sync' | 'report'
    job_name        TEXT NOT NULL,                -- Human-readable name
    payload_json    TEXT NOT NULL,                -- Job parameters
    status          TEXT NOT NULL DEFAULT 'queued', -- 'queued' | 'running' | 'completed' | 'failed' | 'cancelled'
    progress_pct    INTEGER,                      -- 0-100
    result_json     TEXT,                         -- Output data
    error_message   TEXT,
    started_at      DATETIME,
    completed_at    DATETIME,
    created_at      DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_jobs_status ON background_jobs(status);
CREATE INDEX idx_jobs_type ON background_jobs(job_type);

-- System Events: Log for debugging and monitoring
CREATE TABLE system_events (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    event_type      TEXT NOT NULL,                -- 'server_start' | 'error' | 'config_reload' | etc.
    severity        TEXT NOT NULL DEFAULT 'info', -- 'debug' | 'info' | 'warning' | 'error' | 'critical'
    message         TEXT NOT NULL,
    context_json    TEXT,                         -- Additional structured data
    timestamp       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_events_type ON system_events(event_type);
CREATE INDEX idx_events_severity ON system_events(severity);
CREATE INDEX idx_events_timestamp ON system_events(timestamp);
```

### 4.4 Cross-CLI Memory Access Patterns

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                        CROSS-CLI MEMORY FLOW                                 │
│                                                                              │
│   Kimi CLI starts new session:                                               │
│   → memory-store.get_conversation_context("last 24h")                        │
│   → Reads: sessions + conversations (recent)                                 │
│   → Kimi now has context from yesterday's Goose session                      │
│                                                                              │
│   Kimi asks user question:                                                   │
│   → memory-store.remember("user_asked_about_solar_roi", "user wants to      │
│     calculate solar ROI for their Bangkok project", category="observation")  │
│                                                                              │
│   User switches to Goose CLI:                                                │
│   → memory-store.get_conversation_context("last 24h")                        │
│   → Reads SAME sessions + conversations table                                │
│   → Goose sees: "user asked about solar ROI" observation                     │
│   → Goose proactively offers: "Continue with solar ROI calculation?"         │
│                                                                              │
│   Tool execution (solar-calc.calculate_roi):                                 │
│   → memory-store.log_tool_call() → writes to tool_calls table                │
│   → memory-store.remember("solar_roi_result", "ROI = 14.2%, payback = 7yr") │
│                                                                              │
│   OpenCode CLI starts:                                                       │
│   → memory-store.recall("solar_roi", category="fact")                        │
│   → Returns: "ROI = 14.2%, payback = 7yr"                                   │
│   → OpenCode has full continuity                                             │
│                                                                              │
│   Automatic cleanup (nightly):                                               │
│   → DELETE FROM memories WHERE expires_at < datetime('now')                  │
│   → VACUUM to reclaim space                                                  │
└─────────────────────────────────────────────────────────────────────────────┘
```

### 4.5 Persistence Strategy

| Aspect | Strategy | Rationale |
|--------|----------|-----------|
| **Backup** | Daily `rclone sync` of `~/.agent-toolkit/` to Google Drive remote `lean:/agent-toolkit-backups/` | Single-file SQLite is easy to backup; rclone handles dedup and versioning |
| **Retention** | Conversations: 90 days; Tool calls: 30 days; Memories: user-defined TTL or permanent; Embeddings: tied to document lifecycle | Balance between utility and storage growth |
| **Rotation** | Nightly cron job compresses conversations older than 7 days into weekly archives; deletes raw daily entries | Keeps active DB small for query performance |
| **Recovery** | `rclone` restore from Google Drive + `sqlite3 .recover` for corruption scenarios | Two-tier recovery: cloud backup + SQLite-native recovery mode |
| **Size limit** | Target < 1GB active DB; archive chunks when collections exceed 100K documents | 32GB RAM on agent machine is for models, not DB cache |

---

## 5. Module Structure

### 5.1 Complete Python Package Tree

```
~/workspace/agent-toolkit/
├── pyproject.toml                          # Poetry/uv project configuration
├── README.md                               # Quick start and overview
├── .gitignore                              # Ignores: secrets.env, *.db, __pycache__/
├── .python-version                         # 3.11
│
├── src/
│   └── agent_toolkit/
│       ├── __init__.py                     # Package version: __version__ = "0.1.0"
│       │
│       ├── servers/                        # MCP SERVER IMPLEMENTATIONS
│       │   ├── __init__.py                 # Server registry and discovery
│       │   ├── base_server.py              # Abstract base: BaseMCPServer class
│       │   │                             #   - tool registration decorator
│       │   │                             #   - request/response lifecycle
│       │   │                             #   - error handling and logging
│       │   │
│       │   ├── file_ops_safe/
│       │   │   ├── __init__.py             # Server factory: create_server()
│       │   │   ├── server.py               # FastMCP server instance + tool definitions
│       │   │   ├── tools.py                # 12 tool implementations (read, write, delete, etc.)
│       │   │   ├── validators.py           # Path validation, whitelist/blacklist checks
│       │   │   ├── safety_gates.py         # Dry-run generator, confirmation logic, git checker
│       │   │   └── models.py               # Pydantic models: ReadRequest, WriteRequest, etc.
│       │   │
│       │   ├── solar_calc/
│       │   │   ├── __init__.py
│       │   │   ├── server.py
│       │   │   ├── tools.py                # 7 solar calculation tool implementations
│       │   │   ├── calculator.py           # Core calculation engine (pure math, no I/O)
│       │   │   ├── irradiance_data.py      # Thai irradiance lookup tables by province
│       │   │   ├── regulations.py          # Thailand solar regulations (rule-based)
│       │   │   └── models.py               # Pydantic: PanelSpec, Location, ROIModel, etc.
│       │   │
│       │   ├── health_ops/
│       │   │   ├── __init__.py
│       │   │   ├── server.py
│       │   │   ├── tools.py                # 7 health franchise tool implementations
│       │   │   ├── calculator.py           # KPI aggregation, forecasting formulas
│       │   │   ├── models.py               # Pydantic: ClinicData, ForecastInput, etc.
│       │   │   └── templates.py            # Report templates and formatting
│       │   │
│       │   ├── rag_bridge/
│       │   │   ├── __init__.py
│       │   │   ├── server.py
│       │   │   ├── tools.py                # 6 RAG tool implementations
│       │   │   ├── ingest_pipeline.py      # Document → parse → chunk → queue for embed
│       │   │   ├── chunker.py              # Text chunking strategies (fixed, semantic, recursive)
│       │   │   ├── search_engine.py        # Vector search + keyword hybrid ranking
│       │   │   ├── embed_client.py         # HTTP client for Ollama embedding endpoint
│       │   │   └── models.py               # Pydantic: IngestRequest, SearchResult, etc.
│       │   │
│       │   ├── memory_store/
│       │   │   ├── __init__.py
│       │   │   ├── server.py
│       │   │   ├── tools.py                # 10 memory tool implementations
│       │   │   ├── db_manager.py           # SQLite CRUD operations for all context tables
│       │   │   ├── session_tracker.py      # Automatic session detection and management
│       │   │   ├── context_builder.py      # Assembles conversation context for LLM prompt
│       │   │   └── models.py               # Pydantic: Memory, RecallQuery, Session, etc.
│       │   │
│       │   ├── ollama_bridge/
│       │   │   ├── __init__.py
│       │   │   ├── server.py
│       │   │   ├── tools.py                # 7 Ollama tool implementations
│       │   │   ├── ollama_client.py        # Async HTTP client for Ollama API
│       │   │   ├── model_registry.py       # Available models, capabilities, fallback chain
│       │   │   └── models.py               # Pydantic: GenerateRequest, ChatMessage, etc.
│       │   │
│       │   └── rclone_bridge/
│       │       ├── __init__.py
│       │       ├── server.py
│       │       ├── tools.py                # 8 rclone tool implementations
│       │       ├── rclone_client.py        # Subprocess wrapper for rclone binary
│       │       ├── parsers.py              # Output parsers for rclone ls, sync, check
│       │       └── models.py               # Pydantic: SyncRequest, RemotePath, etc.
│       │
│       ├── shared/                         # SHARED INFRASTRUCTURE
│       │   ├── __init__.py
│       │   ├── database.py                 # SQLite connection pool, migrations, schema init
│       │   ├── models.py                   # Common Pydantic models used across servers
│       │   ├── exceptions.py               # Custom exceptions: SafetyError, BridgeError, etc.
│       │   ├── logging_config.py           # Structured JSON logging with rotation
│       │   ├── constants.py                # Paths, defaults, magic numbers
│       │   └── utils.py                    # Common utilities: hash, timing, JSON helpers
│       │
│       ├── safety/                         # SAFETY GOVERNANCE
│       │   ├── __init__.py
│       │   ├── config.py                   # SafetyConfig dataclass, loads safety.toml
│       │   ├── gates.py                    # Gate implementations: DryRunGate, ConfirmGate, GitGate
│       │   ├── path_policy.py              # Path whitelist/blacklist enforcement
│       │   ├── git_checker.py              # Git repository safety checks
│       │   └── decorators.py               # @safety_gate decorator for tool methods
│       │
│       ├── bridges/                        # EXTERNAL SERVICE BRIDGES
│       │   ├── __init__.py
│       │   ├── base_bridge.py              # Abstract bridge with health check and retry
│       │   ├── ollama_bridge_impl.py       # Ollama HTTP bridge (used by rag_bridge + ollama_bridge)
│       │   └── rclone_bridge_impl.py       # rclone subprocess bridge (used by rclone_bridge)
│       │
│       ├── config/                         # CONFIGURATION MANAGEMENT
│       │   ├── __init__.py
│       │   ├── manager.py                  # Unified config loader, hot-reload support
│       │   ├── defaults.py                 # Built-in default configuration values
│       │   ├── schema.py                   # Configuration schema validation (Pydantic)
│       │   └── templates/                  # Default config file templates
│       │       ├── config.toml.template    # Main config template
│       │       └── safety.toml.template    # Safety rules template
│       │
│       ├── cli_hub/                        # CLI HUB / ORCHESTRATION
│       │   ├── __init__.py
│       │   ├── main.py                     # Entry point: python -m agent_toolkit.cli_hub
│       │   ├── server_manager.py           # Spawn/stop individual MCP servers, process lifecycle
│       │   ├── config_generator.py         # Generate mcp.json for each CLI client
│       │   ├── health_monitor.py           # Per-server health checks, restart on failure
│       │   └── status_reporter.py          # Pretty-print hub status, server list, health
│       │
│       └── extensions/                     # FUTURE EXTENSIONS (placeholder)
│           ├── __init__.py
│           └── README.md
│
├── scripts/                                # OPERATIONAL SCRIPTS
│   ├── install.sh                          # One-shot installation: deps, config, systemd
│   ├── setup-env.sh                        # Environment setup: dirs, perms, templates
│   ├── start-hub.sh                        # Start the MCP server hub
│   ├── stop-hub.sh                         # Stop all servers gracefully
│   ├── status.sh                           # Quick health check of all components
│   ├── backup.sh                           # Backup context.db + config to Google Drive
│   ├── restore.sh                          # Restore from Google Drive backup
│   └── systemd/
│       ├── agent-toolkit.service            # systemd service definition
│       └── agent-toolkit-backup.timer       # Daily backup timer + service
│
├── config/                                 # USER CONFIGURATION (gitignored after init)
│   ├── config.toml                         # Main configuration file
│   ├── safety.toml                         # Safety rules and path policies
│   └── secrets.env                         # API keys and tokens (NEVER in git)
│
├── docs/                                   # DOCUMENTATION
│   ├── ARCHITECTURE.md                     # This document
│   ├── DOMAIN_REQUIREMENTS.md             # Business domain specifications
│   ├── SAFETY_PROTOCOL.md                 # Safety governance details
│   ├── INTEGRATION_GUIDE.md               # mcp.json setup for each CLI
│   ├── ROADMAP.md                         # Development roadmap
│   └── AGENT_COGNITION_LAYER.md           # Self-improvement architecture
│
├── tests/                                  # TEST SUITE
│   ├── __init__.py
│   ├── conftest.py                         # Shared pytest fixtures
│   ├── unit/
│   │   ├── test_safety_gates.py
│   │   ├── test_path_policy.py
│   │   ├── test_solar_calc.py
│   │   ├── test_health_ops.py
│   │   ├── test_memory_store.py
│   │   └── test_database.py
│   ├── integration/
│   │   ├── test_file_ops_safe.py
│   │   ├── test_ollama_bridge.py
│   │   ├── test_rag_pipeline.py
│   │   └── test_rclone_bridge.py
│   └── fixtures/
│       ├── sample_documents/               # Test documents for RAG
│       ├── solar_test_data.json
│       └── health_test_data.json
│
└── data/                                   # RUNTIME DATA (gitignored)
    ├── context.db                          # SQLite shared context database
    ├── context.db.backup                   # Last good backup
    ├── embeddings/                         # Vector store files (if not in SQLite)
    ├── logs/                               # Server logs (rotated daily)
    │   ├── hub.log
    │   ├── file-ops-safe.log
    │   ├── ollama-bridge.log
    │   └── ...
    └── tmp/                                # Temporary processing files
```

### 5.2 Key Module Responsibilities

| Module | Lines of Code (est.) | Responsibility |
|--------|---------------------|----------------|
| `servers/` | ~3,500 | MCP server implementations — one subdirectory per server |
| `shared/` | ~800 | Database, logging, common models, utilities — used by all servers |
| `safety/` | ~600 | Safety gate framework, path policies, git integration |
| `bridges/` | ~500 | External service connectivity (Ollama HTTP, rclone subprocess) |
| `config/` | ~400 | Configuration loading, validation, hot-reload, templates |
| `cli_hub/` | ~700 | Process management, health monitoring, mcp.json generation |
| `tests/` | ~2,000 | Unit + integration tests with fixtures |
| **Total** | **~8,500** | Complete, production-ready codebase |

---

## 6. Data Flow Specifications

### 6.1 Flow Summary Matrix

| Flow | Source | Destination | Data | Trigger | Transport |
|------|--------|-------------|------|---------|-----------|
| F1 | CLI clients | Dev machine | Tool call requests | User prompt | MCP stdio |
| F2 | Dev machine | ecolife-2 | LLM inference requests | Tool call needs generation | HTTP (port 11434) |
| F3 | Dev machine | ecolife-2 | Embedding requests | RAG ingest or search | HTTP (port 11434) |
| F4 | Dev machine | ecolife-2 | Background job triggers | Scheduled or async request | SSH command |
| F5 | ecolife-2 | Dev machine | Job completion results | Background job finishes | SSH stdout capture |
| F6 | Dev machine | Google Drive | Config + context backup | Daily cron or manual | rclone (LAN→internet) |
| F7 | Google Drive | Dev machine | Restore data | Recovery scenario | rclone sync |
| F8 | Dev machine | GitHub | Issue/PR operations | User request | HTTPS via github-mcp |
| F9 | Dev machine | Supabase | SQL queries | Health data operations | HTTPS via supabase-mcp |

### 6.2 Detailed Flow Specifications

#### Flow F1: CLI → MCP Server Hub (Dev Machine)

```
┌──────────┐     MCP stdio      ┌─────────────────────────────────────┐
│          │ ─────────────────→ │  agent_toolkit.cli_hub.server_      │
│  Any CLI │   JSON-RPC 2.0     │  manager (process spawner)          │
│          │                    │  - Receives tool call request       │
│ (Kimi/   │ ←────────────────  │  - Routes to appropriate server     │
│ OpenCode/│   JSON-RPC 2.0     │  - Returns tool call result         │
│ Goose)   │   result           │                                     │
└──────────┘                    └─────────────────────────────────────┘

Transport:    stdin/stdout pipes (stdio) or HTTP SSE (future)
Protocol:     Model Context Protocol over JSON-RPC 2.0
Data size:    < 10KB per message (text-based)
Latency:      < 50ms for routing
Frequency:    Every user prompt that triggers tool use
```

#### Flow F2/F3: Dev Machine ↔ Ollama on ecolife-2 (Inference)

```
┌──────────────────────┐     HTTP POST     ┌──────────────────────┐
│                      │ ────────────────→ │                      │
│  ollama_bridge tool  │  /api/generate    │  Ollama server       │
│  or rag-bridge embed │  /api/chat        │  (port 11434)        │
│  on dev machine      │  /api/embed       │  on ecolife-2        │
│                      │                   │                      │
│                      │ ←───────────────  │                      │
│                      │  JSON response    │  (model inference)    │
└──────────────────────┘                   └──────────────────────┘

Transport:    HTTP/1.1 over LAN (WiFi/Ethernet between machines)
Address:      http://ecolife-2:11434 (configurable in config.toml)
Timeout:      120s for generation, 30s for embeddings, 10s for chat
Retry:        3 retries with exponential backoff (1s, 2s, 4s)
Fallback:     Primary model → secondary model → error with context
Data size:    Request: 1-50KB prompt; Response: 1-500KB generated text
Latency:      500ms-30s depending on model size and prompt
Frequency:    On every LLM call from any tool
Bandwidth:    ~1-10 Mbps sustained during inference (well within LAN capacity)
```

#### Flow F4/F5: Dev Machine ↔ ecolife-2 (Background Jobs)

```
┌──────────────────────┐     SSH command     ┌──────────────────────┐
│                      │ ─────────────────→ │                      │
│  cli_hub triggers    │  ssh ecolife-2     │  Background worker   │
│  background job      │  "python -m        │  starts on ecolife-2 │
│  via server_manager  │   agent_toolkit    │  - Processes in bg   │
│                      │   .worker ..."     │  - Writes status to  │
│                      │                    │    shared file       │
│                      │ ←────────────────  │                      │
│                      │  stdout + file     │  Completion signal   │
│                      │  poll for status   │  via ~/jobs/status/  │
└──────────────────────┘                    └──────────────────────┘

Transport:    SSH command execution (non-interactive)
Authentication: SSH key pair (pre-shared, no password)
Trigger:      Explicit user request or scheduled cron
Data:         Job parameters (JSON file passed via SSH), job results (JSON file polled)
Latency:      SSH overhead ~200ms; job duration varies (seconds to hours)
Concurrency:  Max 3 simultaneous background jobs (memory-limited on 32GB machine)
Monitoring:   Dev machine polls `~/jobs/status/` on ecolife-2 every 30s
```

#### Flow F6/F7: Dev Machine ↔ Google Drive (Backup/Restore)

```
┌──────────────────────┐     rclone          ┌──────────────────────┐
│                      │ ─────────────────→ │                      │
│  rclone binary on    │  sync/copy/move    │  Google Drive API    │
│  dev machine         │  remote: lean      │  (cloud)             │
│  (rclone configured  │                    │                      │
│   with remote        │ ←────────────────  │                      │
│   "lean")            │  sync status       │                      │
└──────────────────────┘                    └──────────────────────┘

Transport:    rclone binary → HTTPS → Google Drive API
Direction:    F6: Dev machine → Google Drive (backup)
              F7: Google Drive → Dev machine (restore)
Data:         ~/.agent-toolkit/ directory (SQLite DB, config, logs)
Frequency:    Daily automated (cron) + manual on-demand
Security:     rclone encrypted config; Google OAuth tokens stored in rclone config
Bandwidth:    Depends on DB size (typically < 100MB, negligible)
```

#### Flow F8: GitHub Integration

```
┌──────────────────────┐     HTTPS           ┌──────────────────────┐
│  github-mcp server   │ ─────────────────→ │  GitHub REST API      │
│  (npx, local)        │  Auth: token from   │  api.github.com       │
│                      │  secrets.env        │                      │
│                      │ ←────────────────  │                      │
│                      │  JSON response      │                      │
└──────────────────────┘                    └──────────────────────┘

Transport:    HTTPS over internet
Auth:         GitHub personal access token stored in secrets.env
Rate limit:   Respected via built-in github-mcp rate limiting
Data:         Issue/PR/repo data (JSON, typically < 100KB)
```

#### Flow F9: Supabase Integration

```
┌──────────────────────┐     HTTPS           ┌──────────────────────┐
│  supabase-mcp server │ ─────────────────→ │  Supabase API         │
│  (npx, local)        │  Auth: service      │  *.supabase.co        │
│                      │  role key from      │                      │
│                      │  secrets.env        │                      │
│                      │ ←────────────────  │                      │
│                      │  SQL result sets    │                      │
└──────────────────────┘                    └──────────────────────┘

Transport:    HTTPS over internet
Auth:         Supabase service role key in secrets.env
Data:         SQL queries and result sets (health franchise data)
```

---

## 7. Technology Stack

### 7.1 Core Stack

| Layer | Technology | Version | Purpose |
|-------|-----------|---------|---------|
| **Language** | Python | 3.11+ | Primary implementation language |
| **MCP Framework** | FastMCP | ^1.0 | MCP server implementation library |
| **HTTP Server** | Uvicorn (via FastMCP) | ^0.25 | ASGI server for MCP transport |
| **Data Validation** | Pydantic | ^2.0 | Request/response models, config schemas |
| **Database** | SQLite | 3.40+ | Shared context storage, document vectors |
| **Vector Search** | sqlite-vec | ^0.1 | Vector similarity search in SQLite |
| **HTTP Client** | httpx | ^0.27 | Async HTTP for Ollama bridge |
| **Local LLM** | Ollama | 0.3+ | Model hosting and inference API |
| **Process Mgmt** | systemd | any | Service orchestration on both machines |
| **Cloud Sync** | rclone | 1.65+ | Google Drive backup and sync |
| **CLI Hub** | asyncio | stdlib | Async server management and health monitoring |

### 7.2 Model Stack (on ecolife-2)

| Model | Size | VRAM | Role | Priority |
|-------|------|------|------|----------|
| `gemma2` or `gemma4` | 9B-27B | 8-20GB | Primary chat, reasoning, tool orchestration | Required |
| `nomic-embed-text` | ~1GB | 1GB | Document and query embeddings for RAG | Required |
| `qwen2.5` | 7B-14B | 4-8GB | Code generation, secondary chat | Recommended |
| `mistral` | 7B | 4GB | Fallback general-purpose model | Optional |
| `deepseek-coder` | 7B-33B | 4-20GB | Specialized code tasks | Optional |

**Memory budget:** 32GB RAM — can run gemma (9B, ~8GB) + nomic-embed (~1GB) + qwen2.5 (7B, ~4GB) simultaneously with ~19GB headroom for OS, background jobs, and model context windows.

### 7.3 Development Tools

| Tool | Purpose |
|------|---------|
| `poetry` or `uv` | Dependency management and packaging |
| `pytest` | Unit and integration testing |
| `ruff` | Linting and code formatting |
| `mypy` | Static type checking |
| `pre-commit` | Git hooks for code quality |
| `tmux` | Terminal session management |
| `mosh` | Persistent SSH (via Blink on iPad) |

---

## 8. Key Design Decisions

### 8.1 Decision Registry

| # | Decision | Chosen | Rejected Alternatives | Rationale |
|---|----------|--------|----------------------|-----------|
| D1 | **No new CLI** | Build MCP servers only | Build yet-another-CLI | Existing CLIs (Kimi, OpenCode, Goose) are mature. We add capabilities, not interfaces. |
| D2 | **Local-first** | Self-hosted, no cloud LLMs | OpenAI/Anthropic APIs | Eliminates subscription costs, latency, and data sovereignty concerns for business data |
| D3 | **SQLite over PostgreSQL** | SQLite with sqlite-vec | PostgreSQL + pgvector | Zero admin overhead, single-file portability, sufficient for single-user scale |
| D4 | **Two-machine topology** | Dev + agent separation | Single machine or cloud VPS | Dev machine handles orchestration; 32GB agent machine focuses on inference. Cost-efficient. |
| D5 | **Safety-first file ops** | Mandatory gates on all writes | Trust-based, optional gates | "Slow but safe" — every destructive operation verified. Aligns with business-critical data. |
| D6 | **MCP stdio transport** | Stdio pipes | HTTP/SSE for everything | Simpler setup, no port management, works with all current CLIs. HTTP available for future. |
| D7 | **Shared memory across CLIs** | Unified SQLite context | Per-CLI isolated storage | Seamless context switching between Kimi, OpenCode, and Goose without data loss |
| D8 | **Python 3.11+** | Modern Python | 3.9 or 3.10 | Required for `asyncio.TaskGroup`, better `typing`, and FastMCP compatibility |
| D9 | **FastMCP framework** | FastMCP library | Raw MCP protocol or mcp-python-sdk | Faster server development, built-in tool registration, automatic schema generation |
| D10 | **Pydantic v2** | Pydantic 2.x | Pydantic 1.x or dataclasses | Superior performance, better JSON schema generation, MCP ecosystem standard |
| D11 | **rclone for cloud sync** | rclone binary | Custom Google Drive API | Battle-tested, handles all edge cases, already configured with remote `lean` |
| D12 | **No containerization** | Direct process execution | Docker/Podman | Simpler deployment, direct access to filesystem and Ollama, systemd sufficient |
| D13 | **Semantic versioning** | CalVer or SemVer | No version scheme | Clear compatibility contract with CLI clients and config formats |
| D14 | **Business domains built-in** | solar-calc + health-ops | Generic calculation framework | Domain-specific tools are more useful than generic ones for the user's actual businesses |
| D15 | **Embeddings via Ollama** | Ollama embed API | SentenceTransformers library | Centralized model management, same infrastructure as chat, no extra Python dependencies |

### 8.2 Design Decision Deep-Dives

#### D1: Why MCP Servers Instead of a New CLI

The Model Context Protocol (MCP) provides a standardized way for AI systems to discover and invoke tools. By building MCP servers rather than a custom CLI:

- **Immediate reach:** Kimi CLI, OpenCode CLI, and Goose CLI all speak MCP natively
- **Future-proof:** Any new MCP-compatible client (IDEs, web UIs, automation tools) can use our tools
- **Focused investment:** We invest in tool quality, not CLI UX (which existing tools do well)
- **Ecosystem leverage:** We benefit from improvements in the CLI clients without any work

#### D4: Why Two Machines

The two-machine topology (dev + agent) is not arbitrary — it reflects practical constraints:

- **The dev machine** (lean@192.168.1.135) is the primary workspace — it runs tmux sessions, holds the codebase, and manages configuration. It may not have GPU or large RAM.
- **The agent machine** (ecolife-2) has 32GB RAM dedicated to running Ollama 24/7, executing background jobs, and handling heavy inference. It may be physically separate or a dedicated box.
- **Network separation** means the agent machine can be rebooted, updated, or throttled without affecting the dev workflow.
- **Scalability:** If inference needs grow, the agent machine can be upgraded independently.

#### D5: Why Mandatory Safety Gates

The "slow but safe" philosophy is a direct response to the high-stakes nature of the business domains:

- Solar O&M calculations inform investment decisions (wrong data = financial loss)
- Health franchise operations involve patient data and regulatory compliance
- File operations on business documents must not accidentally delete critical records

Every write tool follows this decision tree:

```
                    ┌─────────────┐
                    │ Tool called │
                    │ with args   │
                    └──────┬──────┘
                           ▼
                    ┌─────────────┐
                    │ Dry-run     │
                    │ preview?    │
                    └──────┬──────┘
                      Yes /    \ No
                         /      \
                        ▼        ▼
               ┌──────────┐  ┌──────────┐
               │ Show diff│  │ Auto-    │
               │ Ask user │  │ allowed? │
               │ confirm  │  │ (pattern)│
               └────┬─────┘  └────┬─────┘
                  Confirm/ Deny   Yes/  No
                         \         /    \
                          ▼       ▼      ▼
                    ┌────────┐ ┌──────┐ ┌──────┐
                    │Execute │ │Abort │ │Git   │
                    │with log│ │safely│ │check │
                    └────────┘ └──────┘ └──┬───┘
                                           │
                              Clean/  Dirty
                                 \     /
                                  ▼   ▼
                            ┌────────┐ ┌────────┐
                            │Execute │ │Require │
                            │with log│ │explicit│
                            └────────┘ │confirm │
                                       └────────┘
```

#### D7: Why Shared Memory Across CLIs

Without shared memory, each CLI session is an island:

```
BEFORE (isolated):
  Kimi CLI:     "Calculate solar ROI for Bangkok project" → result stored in Kimi memory
  Later, Goose CLI: "What was the ROI?" → "I don't know what you're referring to"

AFTER (shared):
  Kimi CLI:     "Calculate solar ROI" → result stored in agent-toolkit memory-store
  Later, Goose CLI: "What was the ROI?" → memory-store.recall("solar ROI") → "14.2%"
```

This cross-CLI memory is the single most important capability for productivity. It means the user can use the best CLI for each task without losing context.

---

## 9. Deployment Topology

### 9.1 Machine Roles

```
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          lean@192.168.1.135 (Dev Machine)                        │
│                                                                                  │
│  Role: Primary workstation, MCP hub host, configuration authority                │
│  Access: mosh/ssh from iPad (Blink), tmux sessions                               │
│  Responsibilities:                                                               │
│    - Run all MCP servers via cli_hub                                             │
│    - Host SQLite shared context database                                         │
│    - Manage configuration files                                                  │
│    - Orchestrate background jobs on ecolife-2                                    │
│    - Backup to Google Drive                                                      │
│    - Git repository for agent-toolkit source code                                │
│  Services:                                                                       │
│    - agent-toolkit-hub.service (systemd, all MCP servers)                        │
│    - agent-toolkit-backup.timer (daily cron via systemd)                         │
│  Ports:                                                                          │
│    - 11434 → forwarded to ecolife-2 (optional ssh tunnel for local access)       │
│    - 8000-8009 → MCP servers if using HTTP transport (future)                    │
│                                                                                  │
│  Directory layout:                                                               │
│    ~/workspace/agent-toolkit/          Source code                               │
│    ~/.agent-toolkit/                   Runtime data, config, DB                  │
│    ~/.config/systemd/user/             User systemd units                        │
└─────────────────────────────────────────────────────────────────────────────────┘
                                        │
                                        │ SSH / LAN
                                        │
┌─────────────────────────────────────────────────────────────────────────────────┐
│                          ecolife-2 (Agent Machine)                               │
│                                                                                  │
│  Role: Dedicated inference server, background job executor                       │
│  Hardware: 32GB RAM                                                              │
│  Responsibilities:                                                               │
│    - Run Ollama 24/7 with loaded models                                          │
│    - Execute background embedding and indexing jobs                              │
│    - Run rclone for cloud sync operations initiated from dev machine             │
│    - Store model weights and job working directories                             │
│  Services:                                                                       │
│    - ollama.service (systemd, binds to 0.0.0.0:11434)                            │
│    - agent-toolkit-worker.service (background job listener)                      │
│  Ports:                                                                          │
│    - 11434 → Ollama HTTP API (LAN-accessible, NOT internet-exposed)              │
│                                                                                  │
│  Directory layout:                                                               │
│    /var/lib/ollama/                  Model weights (~20-50GB)                    │
│    ~/agent-toolkit-data/             Job outputs, temp files                     │
│    ~/jobs/{queue,running,completed}/ Background job state                        │
└─────────────────────────────────────────────────────────────────────────────────┘
```

### 9.2 Network Configuration

```
┌────────────────────────────────────────────────────────────────┐
│                      LAN (192.168.1.0/24)                       │
│                                                                │
│   ┌─────────────────┐          ┌─────────────────┐            │
│   │  iPad (Blink)   │◄────────►│  Router/Gateway │            │
│   │  192.168.1.x    │  mosh    │  192.168.1.1    │            │
│   └─────────────────┘          └────────┬────────┘            │
│                                          │                     │
│                    ┌─────────────────────┼─────────────────┐   │
│                    │                     │                 │   │
│                    ▼                     ▼                 │   │
│   ┌──────────────────────┐   ┌──────────────────────┐     │   │
│   │ lean@192.168.1.135   │   │ ecolife-2            │     │   │
│   │ Dev Machine          │──►│ 192.168.1.yyy        │     │   │
│   │ - MCP hub            │SSH│ - Ollama :11434      │     │   │
│   │ - SQLite DB          │   │ - Background workers │     │   │
│   │ - Config             │◄──│ - Job queue          │     │   │
│   └──────────────────────┘   └──────────────────────┘     │   │
│                                                           │   │
│   Trust boundary: Full LAN access between machines        │   │
│   No external exposure of Ollama or MCP ports             │   │
└───────────────────────────────────────────────────────────────┘

Security model:
  - Ollama API bound to LAN interface only (not 0.0.0.0 if router exposes)
  - MCP servers bound to localhost only (stdio transport)
  - SSH key authentication between machines
  - rclone Google Drive OAuth tokens stored encrypted
```

---

## 10. Configuration Management

### 10.1 Configuration Hierarchy

```
Configuration is loaded in this priority order (later overrides earlier):

1. Built-in defaults (src/agent_toolkit/config/defaults.py)
2. User config file (~/.agent-toolkit/config.toml)
3. Environment variables (AGENT_TOOLKIT_* prefix)
4. Project-local config (./.agent-toolkit.toml in working directory)
5. Runtime command-line flags (if applicable)
```

### 10.2 Main Configuration (config.toml)

```toml
[general]
project_name = "agent-toolkit"
log_level = "INFO"
log_format = "json"
data_dir = "~/.agent-toolkit"

[mcp]
transport = "stdio"           # "stdio" or "sse"
hub_port = 8000               # Only used with "sse" transport
max_concurrent_tools = 10     # Per-server concurrency limit

[ollama]
host = "ecolife-2"
port = 11434
default_model = "gemma2:9b"
embedding_model = "nomic-embed-text"
timeout_generate = 120
timeout_embed = 30
fallback_model = "qwen2.5:7b"

[models.gemma2_9b]
name = "gemma2:9b"
purpose = "primary_chat"
vram_gb = 8
context_length = 8192

[models.nomic_embed]
name = "nomic-embed-text"
purpose = "embeddings"
vram_gb = 1
embedding_dim = 768

[safety]
dry_run_default = true
confirm_destructive = true
git_safety_check = true
max_delete_batch = 10

[safety.path_whitelist]
paths = [
    "~/workspace/",
    "~/agent-toolkit-data/",
    "/tmp/agent-toolkit/"
]

[safety.auto_confirm]
# Patterns that skip confirmation (use sparingly)
patterns = [
    "*.log",
    "/tmp/**"
]

[rclone]
remote_name = "lean"
backup_path = "agent-toolkit-backups"
auto_backup = true
backup_time = "02:00"  # Daily at 2 AM

[memory]
conversation_retention_days = 90
tool_call_retention_days = 30
default_memory_ttl_hours = null  # null = permanent
max_context_messages = 50

[rag]
default_chunk_size = 512
chunk_overlap = 128
max_file_size_mb = 50
supported_formats = ["txt", "md", "pdf", "docx", "csv"]

[background_jobs]
max_concurrent = 3
poll_interval_seconds = 30
default_timeout_hours = 2

[integrations.github]
enabled = true
# Token loaded from secrets.env, not this file

[integrations.supabase]
enabled = false
# URL and key loaded from secrets.env
```

### 10.3 Secrets Management (secrets.env)

```bash
# NEVER commit this file to git
# Loaded by python-dotenv, referenced by config.toml

# GitHub
GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Supabase
SUPABASE_URL=https://xxxxxxxxxxxxxxxx.supabase.co
SUPABASE_KEY=eyJxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Ollama (if API key required in future)
# OLLAMA_API_KEY=

# Google Drive (managed by rclone, not needed here)
# RCLONE_CONFIG_LEAN_TOKEN=
```

---

## 11. Security Model

### 11.1 Threat Model

| Threat | Likelihood | Impact | Mitigation |
|--------|-----------|--------|------------|
| Accidental file deletion | High | High | Safety gates: dry-run, confirm, git-check |
| Malicious tool invocation via compromised CLI | Low | Medium | Path whitelist, no sudo escalation |
| Data loss (hardware failure) | Medium | High | Daily automated backups to Google Drive |
| Unauthorized Ollama access from LAN | Low | Medium | Bind to LAN only, no internet exposure |
| Credential exposure in git | Medium | High | secrets.env in .gitignore, pre-commit hooks |
| Prompt injection via documents | Medium | Medium | Input sanitization, no direct code execution |
| Excessive resource consumption | Medium | Medium | Concurrency limits, timeouts, memory monitoring |

### 11.2 Security Principles

1. **Principle of least privilege:** Each tool can only access its designated resources
2. **Defense in depth:** Safety gates at tool level + path policies + git checks
3. **Explicit consent:** Destructive actions require confirmation, never silent execution
4. **Audit everything:** Every tool call logged with arguments, result, and decision rationale
5. **Secrets isolation:** API keys in `secrets.env`, never in code or config.toml
6. **Network minimization:** Ollama on LAN only; MCP servers on localhost only

---

## 12. Operational Runbooks

### 12.1 Daily Operations

```bash
# Check hub status
~/.local/bin/agent-toolkit status

# View recent logs
journalctl --user -u agent-toolkit-hub -n 100

# Check Ollama health
curl http://ecolife-2:11434/api/tags

# View memory store stats
~/.local/bin/agent-toolkit memory-stats

# Force immediate backup
~/.local/bin/agent-toolkit backup-now
```

### 12.2 Recovery Procedures

```bash
# Restore context.db from backup
~/.local/bin/agent-toolkit restore --from-backup --date 2025-01-19

# Restart hub after config change
systemctl --user restart agent-toolkit-hub

# Reload config without restart
~/.local/bin/agent-toolkit reload-config

# Emergency stop all servers
~/.local/bin/agent-toolkit emergency-stop

# Check disk space on both machines
ssh ecolife-2 "df -h" && df -h
```

### 12.3 Adding a New MCP Server

```python
# 1. Create directory structure
mkdir src/agent_toolkit/servers/my_new_server

# 2. Implement server (see base_server.py for template)
#    - server.py: FastMCP instance
#    - tools.py: Tool functions with @mcp.tool() decorator
#    - models.py: Pydantic request/response models

# 3. Register in servers/__init__.py
#    SERVERS["my-new-server"] = MyNewServer

# 4. Add tests in tests/unit/test_my_new_server.py

# 5. Update config.toml with server-specific settings

# 6. Restart hub
systemctl --user restart agent-toolkit-hub
```

---

## Appendix A: Glossary

| Term | Definition |
|------|------------|
| **MCP** | Model Context Protocol — standard protocol for AI tool calling |
| **CLI** | Command Line Interface — text-based AI client (Kimi, OpenCode, Goose) |
| **MCP Server** | A process that exposes tools via the MCP protocol |
| **Tool** | A callable function exposed by an MCP server (e.g., `safe_read`) |
| **Shared Context** | The SQLite database that persists memory across CLI sessions |
| **Safety Gate** | A verification step before executing a potentially destructive operation |
| **Dry Run** | Preview of changes without actually executing them |
| **Ollama** | Self-hosted LLM inference server |
| **RAG** | Retrieval-Augmented Generation — document search + LLM generation |
| **Embedding** | A vector representation of text for semantic search |
| **ecolife-2** | The dedicated inference machine (32GB RAM, Ollama host) |
| **rclone** | Command-line cloud storage sync tool |
| **O&M** | Operations and Maintenance (solar energy domain) |

---

## Appendix B: mcp.json Configuration Templates

### B.1 Kimi CLI

```json
{
  "mcpServers": {
    "file-ops-safe": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.file_ops_safe"]
    },
    "memory-store": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.memory_store"]
    },
    "solar-calc": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.solar_calc"]
    },
    "health-ops": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.health_ops"]
    },
    "rag-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rag_bridge"]
    },
    "ollama-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.ollama_bridge"]
    },
    "rclone-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rclone_bridge"]
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}"
      }
    }
  }
}
```

### B.2 OpenCode CLI

```json
{
  "mcpServers": {
    "file-ops-safe": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.file_ops_safe"]
    },
    "memory-store": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.memory_store"]
    },
    "solar-calc": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.solar_calc"]
    },
    "health-ops": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.health_ops"]
    },
    "rag-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rag_bridge"]
    },
    "ollama-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.ollama_bridge"]
    },
    "supabase": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-supabase"],
      "env": {
        "SUPABASE_ACCESS_TOKEN": "${SUPABASE_KEY}",
        "SUPABASE_PROJECT_ID": "your-project-id"
      }
    }
  }
}
```

### B.3 Goose CLI

```json
{
  "mcpServers": {
    "file-ops-safe": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.file_ops_safe"]
    },
    "memory-store": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.memory_store"]
    },
    "rag-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rag_bridge"]
    },
    "ollama-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.ollama_bridge"]
    },
    "rclone-bridge": {
      "command": "python",
      "args": ["-m", "agent_toolkit.servers.rclone_bridge"]
    },
    "github": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-github"],
      "env": {
        "GITHUB_PERSONAL_ACCESS_TOKEN": "${GITHUB_TOKEN}"
      }
    }
  }
}
```

---

## Document Control

| Version | Date | Author | Changes |
|---------|------|--------|---------|
| 1.0 | 2025-01-20 | System Architect | Initial architecture specification |

---

*End of Document*

*"We don't build another CLI. We build the arms and legs that make existing CLIs more capable."*
